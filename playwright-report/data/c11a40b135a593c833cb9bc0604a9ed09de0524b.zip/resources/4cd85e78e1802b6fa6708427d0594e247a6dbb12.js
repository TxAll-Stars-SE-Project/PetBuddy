import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/SitterProfileCard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import ProfileCardSkeleton from "/src/components/ui/ProfileCardSkeleton.jsx";
export default function SitterProfileCard({ profile, isLoading = false, onEditProfile }) {
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV(ProfileCardSkeleton, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
      lineNumber: 36,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 custom-shadow relative", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row gap-6 items-start justify-between", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-5 items-start sm:items-center flex-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative flex-shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 sm:w-22 sm:h-22 rounded-2xl bg-[#FFF3E8] border-2 border-[#FED7AA] flex items-end justify-center overflow-hidden shadow-xs", children: /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-16 h-16 sm:w-18 sm:h-18 text-[#F97316] translate-y-1",
            width: "64",
            height: "64",
            fill: "currentColor",
            viewBox: "0 0 24 24",
            "aria-label": "Sitter Avatar",
            children: /* @__PURE__ */ jsxDEV("path", { d: "M12 12c2.7 0 4.8-2.13 4.8-4.8S14.7 2.4 12 2.4 7.2 4.53 7.2 7.2 9.33 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
              lineNumber: 55,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 47,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
          lineNumber: 46,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: "absolute -bottom-1 -right-1 bg-[#16A34A] text-white p-1 rounded-full text-[10px] shadow-xs font-bold leading-none flex items-center justify-center w-5 h-5",
            title: "ยืนยันตัวตนแล้ว",
            children: "✓"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 58,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
        lineNumber: 45,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5 flex-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold text-slate-900", children: profile?.name || "พี่เลี้ยงสัตว์เลี้ยง" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 68,
            columnNumber: 15
          }, this),
          profile?.username && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 font-medium", children: [
            "(@",
            profile.username,
            ")"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 72,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-[#16A34A] flex items-center gap-1", children: "✓ ยืนยันตัวตนแล้ว" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 76,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
          lineNumber: 67,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 text-xs sm:text-sm text-slate-600", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 font-medium", children: [
            "⭐ ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-slate-900", children: profile?.rating || "not found" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
              lineNumber: 83,
              columnNumber: 19
            }, this),
            " (",
            profile?.reviewCount || 0,
            " รีวิว)"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 82,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "•" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 86,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
            "📞 ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-800", children: profile?.tel || "ไม่มีข้อมูลติดต่อ" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
              lineNumber: 88,
              columnNumber: 20
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 87,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "•" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 90,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
            "📍 ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700", children: profile?.address || "ไม่มีที่อยู่ระบุ" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
              lineNumber: 92,
              columnNumber: 20
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 91,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
          lineNumber: 81,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-[#FFF3E8] border border-[#FED7AA] rounded-xl p-3 mt-1.5 max-w-2xl", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-[#EA580C] mb-0.5", children: "ประสบการณ์และเกี่ยวกับฉัน:" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 97,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs sm:text-sm text-slate-700 leading-relaxed font-medium", children: profile?.experience || "ยังไม่มีข้อมูลประสบการณ์ กรุณาเพิ่มข้อมูลในหน้าโปรไฟล์" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 100,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
          lineNumber: 96,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full lg:w-auto flex justify-end items-center border-t lg:border-t-0 pt-4 lg:pt-0 border-slate-200", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onEditProfile,
        className: "w-full sm:w-auto px-4 py-2.5 bg-white hover:bg-[#FFF3E8] text-[#EA580C] font-bold text-xs sm:text-sm rounded-xl border-2 border-[#FED7AA] transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer",
        children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
              d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
              lineNumber: 115,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          "แก้ไขข้อมูลส่วนตัว"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
        lineNumber: 109,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
      lineNumber: 108,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
    lineNumber: 41,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_c = SitterProfileCard;
var _c;
$RefreshReg$(_c, "SitterProfileCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/SitterProfileCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JXOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJYLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MseUJBQXlCO0FBYWhDLHdCQUF3QkMsa0JBQWtCLEVBQUVDLFNBQVNDLFlBQVksT0FBT0MsY0FBYyxHQUFHO0FBQ3ZGLE1BQUlELFdBQVc7QUFDYixXQUFPLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0I7QUFBQSxFQUM3QjtBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLGtGQUNqQixpQ0FBQyxTQUFJLFdBQVUsK0RBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0lBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU07QUFBQSxZQUNOLFFBQU87QUFBQSxZQUNQLE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLGNBQVc7QUFBQSxZQUVYLGlDQUFDLFVBQUssR0FBRSxxSkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SjtBQUFBO0FBQUEsVUFSM0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFNO0FBQUEsWUFBaUI7QUFBQTtBQUFBLFVBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdEQUNYRCxtQkFBU0csUUFBUSwwQkFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NILFNBQVNJLFlBQ1IsdUJBQUMsVUFBSyxXQUFVLHNDQUFvQztBQUFBO0FBQUEsWUFDL0NKLFFBQVFJO0FBQUFBLFlBQVM7QUFBQSxlQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRix1QkFBQyxVQUFLLFdBQVUsNERBQTBELGlDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSx1Q0FBcUM7QUFBQTtBQUFBLFlBQ2pELHVCQUFDLFlBQU8sV0FBVSxrQkFBa0JKLG1CQUFTSyxVQUFVLGVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsWUFBUztBQUFBLFlBQzdFTCxTQUFTTSxlQUFlO0FBQUEsWUFBRTtBQUFBLGVBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLFVBQ1AsdUJBQUMsVUFBSyxXQUFVLDJCQUF5QjtBQUFBO0FBQUEsWUFDcEMsdUJBQUMsVUFBSyxXQUFVLGdDQUFnQ04sbUJBQVNPLE9BQU8sdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsZUFEekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFDUCx1QkFBQyxVQUFLLFdBQVUsMkJBQXlCO0FBQUE7QUFBQSxZQUNwQyx1QkFBQyxVQUFLLFdBQVUsa0JBQWtCUCxtQkFBU1EsV0FBVyxzQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxlQUQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQ0FBeUMsMENBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxpRUFDVlIsbUJBQVNTLGNBQWMsNERBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxTQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOERBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQVNQO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxlQUFjO0FBQUEsY0FDZCxnQkFBZTtBQUFBLGNBQ2YsYUFBWTtBQUFBLGNBQ1osR0FBRTtBQUFBO0FBQUEsWUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJNEgsS0FMOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQUs7QUFBQTtBQUFBO0FBQUEsTUFaUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQW5GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0ZBLEtBckZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzRkE7QUFFSjtBQUFDUSxLQTlGdUJYO0FBQWlCLElBQUFXO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiUHJvZmlsZUNhcmRTa2VsZXRvbiIsIlNpdHRlclByb2ZpbGVDYXJkIiwicHJvZmlsZSIsImlzTG9hZGluZyIsIm9uRWRpdFByb2ZpbGUiLCJuYW1lIiwidXNlcm5hbWUiLCJyYXRpbmciLCJyZXZpZXdDb3VudCIsInRlbCIsImFkZHJlc3MiLCJleHBlcmllbmNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2l0dGVyUHJvZmlsZUNhcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBQcm9maWxlQ2FyZFNrZWxldG9uIGZyb20gXCIuLi8uLi91aS9Qcm9maWxlQ2FyZFNrZWxldG9uLmpzeFwiO1xuXG4vKipcbiAqIFNpdHRlclByb2ZpbGVDYXJkIENvbXBvbmVudFxuICogXG4gKiBEaXNwbGF5cyB0aGUgdmVyaWZpZWQgcGV0IHNpdHRlcidzIHByb2ZpbGUgY2FyZCwgYXZhdGFyIHNpbGhvdWV0dGUsXG4gKiByYXRpbmcsIGNvbnRhY3QgZGV0YWlscywgZXhwZXJpZW5jZSBzdW1tYXJ5LCBhbmQgYW4gRWRpdCBQcm9maWxlIGFjdGlvbi5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHMucHJvZmlsZSAtIFNpdHRlciBwcm9maWxlIGRhdGEgb2JqZWN0LlxuICogQHBhcmFtIHtib29sZWFufSBbcHJvcHMuaXNMb2FkaW5nPWZhbHNlXSAtIFdoZXRoZXIgdGhlIHByb2ZpbGUgaXMgY3VycmVudGx5IGxvYWRpbmcuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vbkVkaXRQcm9maWxlIC0gQWN0aW9uIGNhbGxiYWNrIHRvIG5hdmlnYXRlIHRvIHByb2ZpbGUgZWRpdCBwYWdlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaXR0ZXJQcm9maWxlQ2FyZCh7IHByb2ZpbGUsIGlzTG9hZGluZyA9IGZhbHNlLCBvbkVkaXRQcm9maWxlIH0pIHtcbiAgaWYgKGlzTG9hZGluZykge1xuICAgIHJldHVybiA8UHJvZmlsZUNhcmRTa2VsZXRvbiAvPjtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC01IHNtOnAtNiBjdXN0b20tc2hhZG93IHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgZ2FwLTYgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgIHsvKiBTaXR0ZXIgUHJvZmlsZSBJbmZvICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTUgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGZsZXgtMVwiPlxuICAgICAgICAgIHsvKiBPcmFuZ2UgU2lsaG91ZXR0ZSBBdmF0YXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjAgaC0yMCBzbTp3LTIyIHNtOmgtMjIgcm91bmRlZC0yeGwgYmctWyNGRkYzRThdIGJvcmRlci0yIGJvcmRlci1bI0ZFRDdBQV0gZmxleCBpdGVtcy1lbmQganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHNtOnctMTggc206aC0xOCB0ZXh0LVsjRjk3MzE2XSB0cmFuc2xhdGUteS0xXCJcbiAgICAgICAgICAgICAgICB3aWR0aD1cIjY0XCJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9XCI2NFwiXG4gICAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNpdHRlciBBdmF0YXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMiAxMmMyLjcgMCA0LjgtMi4xMyA0LjgtNC44UzE0LjcgMi40IDEyIDIuNCA3LjIgNC41MyA3LjIgNy4yIDkuMzMgMTIgMTIgMTJ6bTAgMi40Yy0zLjIgMC05LjYgMS42LTkuNiA0Ljh2Mi40aDE5LjJ2LTIuNGMwLTMuMi02LjQtNC44LTkuNi00Ljh6XCIgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tMSAtcmlnaHQtMSBiZy1bIzE2QTM0QV0gdGV4dC13aGl0ZSBwLTEgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIHNoYWRvdy14cyBmb250LWJvbGQgbGVhZGluZy1ub25lIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctNSBoLTVcIlxuICAgICAgICAgICAgICB0aXRsZT1cIuC4ouC4t+C4meC4ouC4seC4meC4leC4seC4p+C4leC4meC5geC4peC5ieC4p1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIOKck1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBmbGV4LTFcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgIHtwcm9maWxlPy5uYW1lIHx8IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJ9XG4gICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgIHtwcm9maWxlPy51c2VybmFtZSAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgKEB7cHJvZmlsZS51c2VybmFtZX0pXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMTZBMzRBXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgIOKckyDguKLguLfguJnguKLguLHguJnguJXguLHguKfguJXguJnguYHguKXguYnguKdcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgIOKtkCA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwXCI+e3Byb2ZpbGU/LnJhdGluZyB8fCBcIm5vdCBmb3VuZFwifTwvc3Ryb25nPiAoXG4gICAgICAgICAgICAgICAge3Byb2ZpbGU/LnJldmlld0NvdW50IHx8IDB9IOC4o+C4teC4p+C4tOC4pylcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAg8J+TniA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwXCI+e3Byb2ZpbGU/LnRlbCB8fCBcIuC5hOC4oeC5iOC4oeC4teC4guC5ieC4reC4oeC4ueC4peC4leC4tOC4lOC4leC5iOC4rVwifTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAg8J+TjSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPntwcm9maWxlPy5hZGRyZXNzIHx8IFwi4LmE4Lih4LmI4Lih4Li14LiX4Li14LmI4Lit4Lii4Li54LmI4Lij4Liw4Lia4Li4XCJ9PC9zcGFuPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI0ZGRjNFOF0gYm9yZGVyIGJvcmRlci1bI0ZFRDdBQV0gcm91bmRlZC14bCBwLTMgbXQtMS41IG1heC13LTJ4bFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtWyNFQTU4MENdIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgIOC4m+C4o+C4sOC4quC4muC4geC4suC4o+C4k+C5jOC5geC4peC4sOC5gOC4geC4teC5iOC4ouC4p+C4geC4seC4muC4ieC4seC4mTpcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTcwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICB7cHJvZmlsZT8uZXhwZXJpZW5jZSB8fCBcIuC4ouC4seC4h+C5hOC4oeC5iOC4oeC4teC4guC5ieC4reC4oeC4ueC4peC4m+C4o+C4sOC4quC4muC4geC4suC4o+C4k+C5jCDguIHguKPguLjguJPguLLguYDguJ7guLTguYjguKHguILguYnguK3guKHguLnguKXguYPguJnguKvguJnguYnguLLguYLguJvguKPguYTguJ/guKXguYxcIn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBFZGl0IFByb2ZpbGUgQWN0aW9uIEJ1dHRvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6dy1hdXRvIGZsZXgganVzdGlmeS1lbmQgaXRlbXMtY2VudGVyIGJvcmRlci10IGxnOmJvcmRlci10LTAgcHQtNCBsZzpwdC0wIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uRWRpdFByb2ZpbGV9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHB4LTQgcHktMi41IGJnLXdoaXRlIGhvdmVyOmJnLVsjRkZGM0U4XSB0ZXh0LVsjRUE1ODBDXSBmb250LWJvbGQgdGV4dC14cyBzbTp0ZXh0LXNtIHJvdW5kZWQteGwgYm9yZGVyLTIgYm9yZGVyLVsjRkVEN0FBXSB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHNoYWRvdy14cyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgICAgICAgIGQ9XCJNMTEgNUg2YTIgMiAwIDAwLTIgMnYxMWEyIDIgMCAwMDIgMmgxMWEyIDIgMCAwMDItMnYtNW0tMS40MTQtOS40MTRhMiAyIDAgMTEyLjgyOCAyLjgyOEwxMS44MjggMTVIOXYtMi44MjhsOC41ODYtOC41ODZ6XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAg4LmB4LiB4LmJ4LmE4LiC4LiC4LmJ4Lit4Lih4Li54Lil4Liq4LmI4Lin4LiZ4LiV4Lix4LinXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL2Rhc2hib2FyZC9TaXR0ZXJQcm9maWxlQ2FyZC5qc3gifQ==