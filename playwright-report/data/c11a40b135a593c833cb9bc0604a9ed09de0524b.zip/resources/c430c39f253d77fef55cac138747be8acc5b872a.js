import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ThaiAddressSelects.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
export default function ThaiAddressSelects({ value, onChange, errors, mode = "form" }) {
  _s();
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [subDistricts, setSubDistricts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [provinceId, setProvinceId] = useState("");
  const [districtId, setDistrictId] = useState("");
  const [subId, setSubId] = useState("");
  useEffect(() => {
    let mounted = true;
    Promise.all(
      [
        import("/src/assets/thai-address/province.json?import"),
        import("/src/assets/thai-address/district.json?import"),
        import("/src/assets/thai-address/sub_district.json?import")
      ]
    ).then(([p, d, s]) => {
      if (!mounted) return;
      setProvinces(p.default);
      setDistricts(d.default);
      setSubDistricts(s.default);
      setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, []);
  const districtOptions = useMemo(
    () => districts.filter((d) => String(d.province_id) === String(provinceId)),
    [districts, provinceId]
  );
  const subOptions = useMemo(
    () => subDistricts.filter((s) => String(s.district_id) === String(districtId)),
    [subDistricts, districtId]
  );
  const handleProvince = (e) => {
    const id = e.target.value;
    const prov = provinces.find((p) => String(p.id) === String(id));
    setProvinceId(id);
    setDistrictId("");
    setSubId("");
    onChange({ province: prov?.name_th || "", district: "", subdistrict: "", postalCode: "" });
  };
  const handleDistrict = (e) => {
    const id = e.target.value;
    const dist = districtOptions.find((d) => String(d.id) === String(id));
    setDistrictId(id);
    setSubId("");
    onChange({ district: dist?.name_th || "", subdistrict: "", postalCode: "" });
  };
  const handleSub = (e) => {
    const id = e.target.value;
    const sub = subOptions.find((s) => String(s.id) === String(id));
    setSubId(id);
    onChange({
      subdistrict: sub?.name_th || "",
      // 👈 ส่งชื่อขึ้นไปด้วย
      postalCode: sub?.zip_code ? String(sub.zip_code) : ""
    });
  };
  if (mode === "filter") {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "filter-province", children: "จังหวัด" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 88,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("select", { id: "filter-province", className: "input", value: provinceId, onChange: handleProvince, disabled: loading, children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: loading ? "กำลังโหลดข้อมูลที่อยู่..." : "ทุกจังหวัด" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
            lineNumber: 90,
            columnNumber: 13
          }, this),
          provinces.map((p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.name_th }, p.id, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
            lineNumber: 91,
            columnNumber: 35
          }, this))
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 89,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "filter-district", children: [
          "อำเภอ/เขต ",
          /* @__PURE__ */ jsxDEV("span", { className: "filter-optional", children: "(ไม่บังคับ)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
            lineNumber: 96,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 95,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("select", { id: "filter-district", className: "input", value: districtId, onChange: handleDistrict, disabled: !provinceId || loading, children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", children: "ทุกอำเภอ/เขต" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
            lineNumber: 99,
            columnNumber: 13
          }, this),
          districtOptions.map((d) => /* @__PURE__ */ jsxDEV("option", { value: d.id, children: d.name_th }, d.id, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
            lineNumber: 100,
            columnNumber: 41
          }, this))
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 98,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
      lineNumber: 86,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "grid-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: [
        "จังหวัด ",
        /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 110,
          columnNumber: 48
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("select", { className: "input", value: provinceId, onChange: handleProvince, disabled: loading, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: loading ? "กำลังโหลดข้อมูลที่อยู่..." : "— เลือกจังหวัด —" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 112,
          columnNumber: 11
        }, this),
        provinces.map((p) => /* @__PURE__ */ jsxDEV("option", { value: p.id, children: p.name_th }, p.id, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 113,
          columnNumber: 33
        }, this))
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      errors?.province && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: errors.province }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 115,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: [
        "อำเภอ/เขต ",
        /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 119,
          columnNumber: 50
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("select", { className: "input", value: districtId, onChange: handleDistrict, disabled: !provinceId || loading, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "— เลือกอำเภอ/เขต —" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        districtOptions.map((d) => /* @__PURE__ */ jsxDEV("option", { value: d.id, children: d.name_th }, d.id, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 122,
          columnNumber: 39
        }, this))
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      errors?.district && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: errors.district }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 124,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
      lineNumber: 118,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: [
        "ตำบล/แขวง ",
        /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 128,
          columnNumber: 50
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("select", { className: "input", value: subId, onChange: handleSub, disabled: !districtId || loading, children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "— เลือกตำบล/แขวง —" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 130,
          columnNumber: 11
        }, this),
        subOptions.map((s) => /* @__PURE__ */ jsxDEV("option", { value: s.id, children: s.name_th }, s.id, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
          lineNumber: 131,
          columnNumber: 34
        }, this))
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 129,
        columnNumber: 9
      }, this),
      errors?.subdistrict && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: errors.subdistrict }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 133,
        columnNumber: 33
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: "รหัสไปรษณีย์" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { className: "input", value: value.postalCode || "", readOnly: true, placeholder: "ระบบเติมให้อัตโนมัติ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 138,
        columnNumber: 9
      }, this),
      errors?.postalCode && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: errors.postalCode }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
        lineNumber: 139,
        columnNumber: 32
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx",
    lineNumber: 108,
    columnNumber: 5
  }, this);
}
_s(ThaiAddressSelects, "9sejOkP46OILGt/Vgx9+t4M7QMw=");
_c = ThaiAddressSelects;
var _c;
$RefreshReg$(_c, "ThaiAddressSelects");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ThaiAddressSelects.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VNLG1CQUVJLGNBRko7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbEVOLFNBQVNBLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUU3Qyx3QkFBd0JDLG1CQUFtQixFQUFFQyxPQUFPQyxVQUFVQyxRQUFRQyxPQUFPLE9BQU8sR0FBRztBQUFBQyxLQUFBO0FBQ3JGLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJUixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDUyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNXLGNBQWNDLGVBQWUsSUFBSVosU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2EsU0FBU0MsVUFBVSxJQUFJZCxTQUFTLElBQUk7QUFFM0MsUUFBTSxDQUFDZSxZQUFZQyxhQUFhLElBQUloQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDaUIsWUFBWUMsYUFBYSxJQUFJbEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUdyQ0YsWUFBVSxNQUFNO0FBQ2QsUUFBSXVCLFVBQVU7QUFDZEMsWUFBUUM7QUFBQUEsTUFBSTtBQUFBLFFBQ1YsT0FBTyxzQ0FBc0M7QUFBQSxRQUM3QyxPQUFPLHNDQUFzQztBQUFBLFFBQzdDLE9BQU8sMENBQTBDO0FBQUEsTUFBQztBQUFBLElBQ25ELEVBQUVDLEtBQUssQ0FBQyxDQUFDQyxHQUFHQyxHQUFHQyxDQUFDLE1BQU07QUFDckIsVUFBSSxDQUFDTixRQUFTO0FBQ2RiLG1CQUFhaUIsRUFBRUcsT0FBTztBQUN0QmxCLG1CQUFhZ0IsRUFBRUUsT0FBTztBQUN0QmhCLHNCQUFnQmUsRUFBRUMsT0FBTztBQUN6QmQsaUJBQVcsS0FBSztBQUFBLElBQ2xCLENBQUM7QUFDRCxXQUFPLE1BQU07QUFBRU8sZ0JBQVU7QUFBQSxJQUFPO0FBQUEsRUFDbEMsR0FBRyxFQUFFO0FBRUwsUUFBTVEsa0JBQWtCOUI7QUFBQUEsSUFDdEIsTUFBTVUsVUFBVXFCLE9BQU8sQ0FBQ0osTUFBTUssT0FBT0wsRUFBRU0sV0FBVyxNQUFNRCxPQUFPaEIsVUFBVSxDQUFDO0FBQUEsSUFDMUUsQ0FBQ04sV0FBV00sVUFBVTtBQUFBLEVBQ3hCO0FBQ0EsUUFBTWtCLGFBQWFsQztBQUFBQSxJQUNqQixNQUFNWSxhQUFhbUIsT0FBTyxDQUFDSCxNQUFNSSxPQUFPSixFQUFFTyxXQUFXLE1BQU1ILE9BQU9kLFVBQVUsQ0FBQztBQUFBLElBQzdFLENBQUNOLGNBQWNNLFVBQVU7QUFBQSxFQUMzQjtBQUVBLFFBQU1rQixpQkFBaUJBLENBQUNDLE1BQU07QUFDOUIsVUFBTUMsS0FBS0QsRUFBRUUsT0FBT3BDO0FBQ3BCLFVBQU1xQyxPQUFPaEMsVUFBVWlDLEtBQUssQ0FBQ2YsTUFBTU0sT0FBT04sRUFBRVksRUFBRSxNQUFNTixPQUFPTSxFQUFFLENBQUM7QUFDOURyQixrQkFBY3FCLEVBQUU7QUFBR25CLGtCQUFjLEVBQUU7QUFBR0UsYUFBUyxFQUFFO0FBQ2pEakIsYUFBUyxFQUFFc0MsVUFBVUYsTUFBTUcsV0FBVyxJQUFJQyxVQUFVLElBQUlDLGFBQWEsSUFBSUMsWUFBWSxHQUFHLENBQUM7QUFBQSxFQUN6RjtBQUVBLFFBQU1DLGlCQUFpQkEsQ0FBQ1YsTUFBTTtBQUM1QixVQUFNQyxLQUFLRCxFQUFFRSxPQUFPcEM7QUFDcEIsVUFBTTZDLE9BQU9sQixnQkFBZ0JXLEtBQUssQ0FBQ2QsTUFBTUssT0FBT0wsRUFBRVcsRUFBRSxNQUFNTixPQUFPTSxFQUFFLENBQUM7QUFDcEVuQixrQkFBY21CLEVBQUU7QUFBR2pCLGFBQVMsRUFBRTtBQUM5QmpCLGFBQVMsRUFBRXdDLFVBQVVJLE1BQU1MLFdBQVcsSUFBSUUsYUFBYSxJQUFJQyxZQUFZLEdBQUcsQ0FBQztBQUFBLEVBQzdFO0FBRUEsUUFBTUcsWUFBWUEsQ0FBQ1osTUFBTTtBQUN2QixVQUFNQyxLQUFLRCxFQUFFRSxPQUFPcEM7QUFDcEIsVUFBTStDLE1BQU1oQixXQUFXTyxLQUFLLENBQUNiLE1BQU1JLE9BQU9KLEVBQUVVLEVBQUUsTUFBTU4sT0FBT00sRUFBRSxDQUFDO0FBQzlEakIsYUFBU2lCLEVBQUU7QUFDWGxDLGFBQVM7QUFBQSxNQUNQeUMsYUFBYUssS0FBS1AsV0FBVztBQUFBO0FBQUEsTUFDN0JHLFlBQVlJLEtBQUtDLFdBQVduQixPQUFPa0IsSUFBSUMsUUFBUSxJQUFJO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0g7QUFJQSxNQUFJN0MsU0FBUyxVQUFVO0FBQ3JCLFdBQ0UsbUNBQ0U7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxXQUFNLFNBQVEsbUJBQWtCLHVCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsWUFBTyxJQUFHLG1CQUFrQixXQUFVLFNBQVEsT0FBT1UsWUFBWSxVQUFVb0IsZ0JBQWdCLFVBQVV0QixTQUNwRztBQUFBLGlDQUFDLFlBQU8sT0FBTSxJQUFJQSxvQkFBVSw4QkFBOEIsZ0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsVUFDdEVOLFVBQVU0QyxJQUFJLENBQUMxQixNQUFNLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVZLElBQUtaLFlBQUVpQixXQUF0QmpCLEVBQUVZLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkMsQ0FBUztBQUFBLGFBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxXQUFNLFNBQVEsbUJBQWlCO0FBQUE7QUFBQSxVQUNwQix1QkFBQyxVQUFLLFdBQVUsbUJBQWtCLDJCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLGFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxJQUFHLG1CQUFrQixXQUFVLFNBQVEsT0FBT3BCLFlBQVksVUFBVTZCLGdCQUFnQixVQUFVLENBQUMvQixjQUFjRixTQUNuSDtBQUFBLGlDQUFDLFlBQU8sT0FBTSxJQUFHLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQzVCZ0IsZ0JBQWdCc0IsSUFBSSxDQUFDekIsTUFBTSx1QkFBQyxZQUFrQixPQUFPQSxFQUFFVyxJQUFLWCxZQUFFZ0IsV0FBdEJoQixFQUFFVyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDLENBQVM7QUFBQSxhQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGVBQWM7QUFBQTtBQUFBLFFBQVEsdUJBQUMsVUFBSyxXQUFVLE9BQU0saUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsWUFBTyxXQUFVLFNBQVEsT0FBT3RCLFlBQVksVUFBVW9CLGdCQUFnQixVQUFVdEIsU0FDL0U7QUFBQSwrQkFBQyxZQUFPLE9BQU0sSUFBSUEsb0JBQVUsOEJBQThCLHNCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsUUFDNUVOLFVBQVU0QyxJQUFJLENBQUMxQixNQUFNLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUVZLElBQUtaLFlBQUVpQixXQUF0QmpCLEVBQUVZLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQyxDQUFTO0FBQUEsV0FGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQ2pDLFFBQVFxQyxZQUFZLHVCQUFDLFNBQUksV0FBVSxlQUFlckMsaUJBQU9xQyxZQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsU0FOckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSxlQUFjO0FBQUE7QUFBQSxRQUFVLHVCQUFDLFVBQUssV0FBVSxPQUFNLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsV0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLE1BQ3ZFLHVCQUFDLFlBQU8sV0FBVSxTQUFRLE9BQU94QixZQUFZLFVBQVU2QixnQkFBZ0IsVUFBVSxDQUFDL0IsY0FBY0YsU0FDOUY7QUFBQSwrQkFBQyxZQUFPLE9BQU0sSUFBRyxrQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ2xDZ0IsZ0JBQWdCc0IsSUFBSSxDQUFDekIsTUFBTSx1QkFBQyxZQUFrQixPQUFPQSxFQUFFVyxJQUFLWCxZQUFFZ0IsV0FBdEJoQixFQUFFVyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkMsQ0FBUztBQUFBLFdBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0NqQyxRQUFRdUMsWUFBWSx1QkFBQyxTQUFJLFdBQVUsZUFBZXZDLGlCQUFPdUMsWUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLFNBTnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsZUFBYztBQUFBO0FBQUEsUUFBVSx1QkFBQyxVQUFLLFdBQVUsT0FBTSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxNQUN2RSx1QkFBQyxZQUFPLFdBQVUsU0FBUSxPQUFPeEIsT0FBTyxVQUFVNkIsV0FBVyxVQUFVLENBQUMvQixjQUFjSixTQUNwRjtBQUFBLCtCQUFDLFlBQU8sT0FBTSxJQUFHLGtDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsUUFDbENvQixXQUFXa0IsSUFBSSxDQUFDeEIsTUFBTSx1QkFBQyxZQUFrQixPQUFPQSxFQUFFVSxJQUFLVixZQUFFZSxXQUF0QmYsRUFBRVUsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDLENBQVM7QUFBQSxXQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNDakMsUUFBUXdDLGVBQWUsdUJBQUMsU0FBSSxXQUFVLGVBQWV4QyxpQkFBT3dDLGVBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxTQU4zRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGVBQWMsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUMzQyx1QkFBQyxXQUFNLFdBQVUsU0FBUSxPQUFPMUMsTUFBTTJDLGNBQWMsSUFBSSxVQUFRLE1BQUMsYUFBWSwwQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRztBQUFBLE1BQ2xHekMsUUFBUXlDLGNBQWMsdUJBQUMsU0FBSSxXQUFVLGVBQWV6QyxpQkFBT3lDLGNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxTQUh6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ3ZDLEdBekh1Qkwsb0JBQWtCO0FBQUEsS0FBbEJBO0FBQWtCLElBQUFtRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJUaGFpQWRkcmVzc1NlbGVjdHMiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZXJyb3JzIiwibW9kZSIsIl9zIiwicHJvdmluY2VzIiwic2V0UHJvdmluY2VzIiwiZGlzdHJpY3RzIiwic2V0RGlzdHJpY3RzIiwic3ViRGlzdHJpY3RzIiwic2V0U3ViRGlzdHJpY3RzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJwcm92aW5jZUlkIiwic2V0UHJvdmluY2VJZCIsImRpc3RyaWN0SWQiLCJzZXREaXN0cmljdElkIiwic3ViSWQiLCJzZXRTdWJJZCIsIm1vdW50ZWQiLCJQcm9taXNlIiwiYWxsIiwidGhlbiIsInAiLCJkIiwicyIsImRlZmF1bHQiLCJkaXN0cmljdE9wdGlvbnMiLCJmaWx0ZXIiLCJTdHJpbmciLCJwcm92aW5jZV9pZCIsInN1Yk9wdGlvbnMiLCJkaXN0cmljdF9pZCIsImhhbmRsZVByb3ZpbmNlIiwiZSIsImlkIiwidGFyZ2V0IiwicHJvdiIsImZpbmQiLCJwcm92aW5jZSIsIm5hbWVfdGgiLCJkaXN0cmljdCIsInN1YmRpc3RyaWN0IiwicG9zdGFsQ29kZSIsImhhbmRsZURpc3RyaWN0IiwiZGlzdCIsImhhbmRsZVN1YiIsInN1YiIsInppcF9jb2RlIiwibWFwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGhhaUFkZHJlc3NTZWxlY3RzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRoYWlBZGRyZXNzU2VsZWN0cyh7IHZhbHVlLCBvbkNoYW5nZSwgZXJyb3JzLCBtb2RlID0gXCJmb3JtXCIgfSkge1xuICBjb25zdCBbcHJvdmluY2VzLCBzZXRQcm92aW5jZXNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbZGlzdHJpY3RzLCBzZXREaXN0cmljdHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbc3ViRGlzdHJpY3RzLCBzZXRTdWJEaXN0cmljdHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICBjb25zdCBbcHJvdmluY2VJZCwgc2V0UHJvdmluY2VJZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Rpc3RyaWN0SWQsIHNldERpc3RyaWN0SWRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzdWJJZCwgc2V0U3ViSWRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgLy8gbGF6eSBsb2FkIEpTT04gKGNvZGUtc3BsaXR0aW5nKSDguYDguJ7guLfguYjguK3guYTguKHguYjguYPguKvguYkgYnVuZGxlIOC4q+C4meC5ieC4suC5geC4o+C4geC4muC4p+C4oVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBtb3VudGVkID0gdHJ1ZTtcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICBpbXBvcnQoXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL3Byb3ZpbmNlLmpzb25cIiksXG4gICAgICBpbXBvcnQoXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL2Rpc3RyaWN0Lmpzb25cIiksXG4gICAgICBpbXBvcnQoXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL3N1Yl9kaXN0cmljdC5qc29uXCIpLFxuICAgIF0pLnRoZW4oKFtwLCBkLCBzXSkgPT4ge1xuICAgICAgaWYgKCFtb3VudGVkKSByZXR1cm47XG4gICAgICBzZXRQcm92aW5jZXMocC5kZWZhdWx0KTtcbiAgICAgIHNldERpc3RyaWN0cyhkLmRlZmF1bHQpO1xuICAgICAgc2V0U3ViRGlzdHJpY3RzKHMuZGVmYXVsdCk7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4geyBtb3VudGVkID0gZmFsc2U7IH07XG4gIH0sIFtdKTtcblxuICBjb25zdCBkaXN0cmljdE9wdGlvbnMgPSB1c2VNZW1vKFxuICAgICgpID0+IGRpc3RyaWN0cy5maWx0ZXIoKGQpID0+IFN0cmluZyhkLnByb3ZpbmNlX2lkKSA9PT0gU3RyaW5nKHByb3ZpbmNlSWQpKSxcbiAgICBbZGlzdHJpY3RzLCBwcm92aW5jZUlkXVxuICApO1xuICBjb25zdCBzdWJPcHRpb25zID0gdXNlTWVtbyhcbiAgICAoKSA9PiBzdWJEaXN0cmljdHMuZmlsdGVyKChzKSA9PiBTdHJpbmcocy5kaXN0cmljdF9pZCkgPT09IFN0cmluZyhkaXN0cmljdElkKSksXG4gICAgW3N1YkRpc3RyaWN0cywgZGlzdHJpY3RJZF1cbiAgKTtcblxuICBjb25zdCBoYW5kbGVQcm92aW5jZSA9IChlKSA9PiB7XG4gIGNvbnN0IGlkID0gZS50YXJnZXQudmFsdWU7XG4gIGNvbnN0IHByb3YgPSBwcm92aW5jZXMuZmluZCgocCkgPT4gU3RyaW5nKHAuaWQpID09PSBTdHJpbmcoaWQpKTtcbiAgc2V0UHJvdmluY2VJZChpZCk7IHNldERpc3RyaWN0SWQoXCJcIik7IHNldFN1YklkKFwiXCIpO1xuICBvbkNoYW5nZSh7IHByb3ZpbmNlOiBwcm92Py5uYW1lX3RoIHx8IFwiXCIsIGRpc3RyaWN0OiBcIlwiLCBzdWJkaXN0cmljdDogXCJcIiwgcG9zdGFsQ29kZTogXCJcIiB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEaXN0cmljdCA9IChlKSA9PiB7XG4gICAgY29uc3QgaWQgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBjb25zdCBkaXN0ID0gZGlzdHJpY3RPcHRpb25zLmZpbmQoKGQpID0+IFN0cmluZyhkLmlkKSA9PT0gU3RyaW5nKGlkKSk7XG4gICAgc2V0RGlzdHJpY3RJZChpZCk7IHNldFN1YklkKFwiXCIpO1xuICAgIG9uQ2hhbmdlKHsgZGlzdHJpY3Q6IGRpc3Q/Lm5hbWVfdGggfHwgXCJcIiwgc3ViZGlzdHJpY3Q6IFwiXCIsIHBvc3RhbENvZGU6IFwiXCIgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3ViID0gKGUpID0+IHtcbiAgICBjb25zdCBpZCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgIGNvbnN0IHN1YiA9IHN1Yk9wdGlvbnMuZmluZCgocykgPT4gU3RyaW5nKHMuaWQpID09PSBTdHJpbmcoaWQpKTtcbiAgICBzZXRTdWJJZChpZCk7XG4gICAgb25DaGFuZ2Uoe1xuICAgICAgc3ViZGlzdHJpY3Q6IHN1Yj8ubmFtZV90aCB8fCBcIlwiLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDwn5GIIOC4quC5iOC4h+C4iuC4t+C5iOC4reC4guC4tuC5ieC4meC5hOC4m+C4lOC5ieC4p+C4olxuICAgICAgcG9zdGFsQ29kZTogc3ViPy56aXBfY29kZSA/IFN0cmluZyhzdWIuemlwX2NvZGUpIDogXCJcIixcbiAgICB9KTtcbiAgfTtcblxuICAvLyBtb2RlPVwiZmlsdGVyXCI6IOC5g+C4iuC5ieC5gOC4m+C5h+C4meC4leC4seC4p+C4geC4o+C4reC4h+C4hOC5ieC4meC4q+C4siDigJQg4LmB4Liq4LiU4LiH4LmB4LiE4LmI4LiI4Lix4LiH4Lir4Lin4Lix4LiUICsg4Lit4Liz4LmA4Lig4LitL+C5gOC4guC4lSAo4LmE4Lih4LmI4Lia4Lix4LiH4LiE4Lix4LiaKSDguYHguKXguLDguITguLfguJkgZnJhZ21lbnRcbiAgLy8g4LmA4Lie4Li34LmI4Lit4LmD4Lir4LmJIDIg4LiK4LmI4Lit4LiH4Lit4Lii4Li54LmI4LmD4LiZIGdyaWQg4LiC4Lit4LiH4LiV4Lix4Lin4LiB4Lij4Lit4LiH4LmE4LiU4LmJ4LmA4Lil4LiiOyBtb2RlPVwiZm9ybVwiICjguITguYjguLLguYDguKPguLTguYjguKHguJXguYnguJkpIOC4hOC4t+C4reC4n+C4reC4o+C5jOC4oeC4quC4oeC4seC4hOC4oy/guYHguIHguYnguYTguILguJfguLXguYjguK3guKLguLnguYjguYDguJTguLTguKFcbiAgaWYgKG1vZGUgPT09IFwiZmlsdGVyXCIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItZmllbGRcIj5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImZpbHRlci1wcm92aW5jZVwiPuC4iOC4seC4h+C4q+C4p+C4seC4lDwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCBpZD1cImZpbHRlci1wcm92aW5jZVwiIGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e3Byb3ZpbmNlSWR9IG9uQ2hhbmdlPXtoYW5kbGVQcm92aW5jZX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPntsb2FkaW5nID8gXCLguIHguLPguKXguLHguIfguYLguKvguKXguJTguILguYnguK3guKHguLnguKXguJfguLXguYjguK3guKLguLnguYguLi5cIiA6IFwi4LiX4Li44LiB4LiI4Lix4LiH4Lir4Lin4Lix4LiUXCJ9PC9vcHRpb24+XG4gICAgICAgICAgICB7cHJvdmluY2VzLm1hcCgocCkgPT4gPG9wdGlvbiBrZXk9e3AuaWR9IHZhbHVlPXtwLmlkfT57cC5uYW1lX3RofTwvb3B0aW9uPil9XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1maWVsZFwiPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZmlsdGVyLWRpc3RyaWN0XCI+XG4gICAgICAgICAgICDguK3guLPguYDguKDguK0v4LmA4LiC4LiVIDxzcGFuIGNsYXNzTmFtZT1cImZpbHRlci1vcHRpb25hbFwiPijguYTguKHguYjguJrguLHguIfguITguLHguJopPC9zcGFuPlxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCBpZD1cImZpbHRlci1kaXN0cmljdFwiIGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e2Rpc3RyaWN0SWR9IG9uQ2hhbmdlPXtoYW5kbGVEaXN0cmljdH0gZGlzYWJsZWQ9eyFwcm92aW5jZUlkIHx8IGxvYWRpbmd9PlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPuC4l+C4uOC4geC4reC4s+C5gOC4oOC4rS/guYDguILguJU8L29wdGlvbj5cbiAgICAgICAgICAgIHtkaXN0cmljdE9wdGlvbnMubWFwKChkKSA9PiA8b3B0aW9uIGtleT17ZC5pZH0gdmFsdWU9e2QuaWR9PntkLm5hbWVfdGh9PC9vcHRpb24+KX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8Lz5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQtMlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmllbGQtbGFiZWxcIj7guIjguLHguIfguKvguKfguLHguJQgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e3Byb3ZpbmNlSWR9IG9uQ2hhbmdlPXtoYW5kbGVQcm92aW5jZX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj57bG9hZGluZyA/IFwi4LiB4Liz4Lil4Lix4LiH4LmC4Lir4Lil4LiU4LiC4LmJ4Lit4Lih4Li54Lil4LiX4Li14LmI4Lit4Lii4Li54LmILi4uXCIgOiBcIuKAlCDguYDguKXguLfguK3guIHguIjguLHguIfguKvguKfguLHguJQg4oCUXCJ9PC9vcHRpb24+XG4gICAgICAgICAge3Byb3ZpbmNlcy5tYXAoKHApID0+IDxvcHRpb24ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+e3AubmFtZV90aH08L29wdGlvbj4pfVxuICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAge2Vycm9ycz8ucHJvdmluY2UgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMucHJvdmluY2V9PC9kaXY+fVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGRcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCI+4Lit4Liz4LmA4Lig4LitL+C5gOC4guC4lSA8c3BhbiBjbGFzc05hbWU9XCJyZXFcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiaW5wdXRcIiB2YWx1ZT17ZGlzdHJpY3RJZH0gb25DaGFuZ2U9e2hhbmRsZURpc3RyaWN0fSBkaXNhYmxlZD17IXByb3ZpbmNlSWQgfHwgbG9hZGluZ30+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPuKAlCDguYDguKXguLfguK3guIHguK3guLPguYDguKDguK0v4LmA4LiC4LiVIOKAlDwvb3B0aW9uPlxuICAgICAgICAgIHtkaXN0cmljdE9wdGlvbnMubWFwKChkKSA9PiA8b3B0aW9uIGtleT17ZC5pZH0gdmFsdWU9e2QuaWR9PntkLm5hbWVfdGh9PC9vcHRpb24+KX1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIHtlcnJvcnM/LmRpc3RyaWN0ICYmIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57ZXJyb3JzLmRpc3RyaWN0fTwvZGl2Pn1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZC1sYWJlbFwiPuC4leC4s+C4muC4pS/guYHguILguKfguIcgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e3N1YklkfSBvbkNoYW5nZT17aGFuZGxlU3VifSBkaXNhYmxlZD17IWRpc3RyaWN0SWQgfHwgbG9hZGluZ30+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPuKAlCDguYDguKXguLfguK3guIHguJXguLPguJrguKUv4LmB4LiC4Lin4LiHIOKAlDwvb3B0aW9uPlxuICAgICAgICAgIHtzdWJPcHRpb25zLm1hcCgocykgPT4gPG9wdGlvbiBrZXk9e3MuaWR9IHZhbHVlPXtzLmlkfT57cy5uYW1lX3RofTwvb3B0aW9uPil9XG4gICAgICAgIDwvc2VsZWN0PlxuICAgICAgICB7ZXJyb3JzPy5zdWJkaXN0cmljdCAmJiA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2Vycm9ycy5zdWJkaXN0cmljdH08L2Rpdj59XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmllbGQtbGFiZWxcIj7guKPguKvguLHguKrguYTguJvguKPguKnguJPguLXguKLguYw8L2xhYmVsPlxuICAgICAgICA8aW5wdXQgY2xhc3NOYW1lPVwiaW5wdXRcIiB2YWx1ZT17dmFsdWUucG9zdGFsQ29kZSB8fCBcIlwifSByZWFkT25seSBwbGFjZWhvbGRlcj1cIuC4o+C4sOC4muC4muC5gOC4leC4tOC4oeC5g+C4q+C5ieC4reC4seC4leC5guC4meC4oeC4seC4leC4tFwiIC8+XG4gICAgICAgIHtlcnJvcnM/LnBvc3RhbENvZGUgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMucG9zdGFsQ29kZX08L2Rpdj59XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9UaGFpQWRkcmVzc1NlbGVjdHMuanN4In0=