import { api } from "/src/services/api.js";
export async function getSitterPaymentInfo() {
  const res = await api.get("/sitter/payment-info");
  if (res && typeof res === "object") {
    const raw = res;
    if (raw.data && typeof raw.data === "object") {
      const inner = raw.data;
      if (inner.data && typeof inner.data === "object") {
        return inner.data;
      }
      return inner;
    }
  }
  return {
    sitterId: 0,
    accountName: null,
    qrCodeUrl: null,
    hasPaymentInfo: false
  };
}
export async function getSitterBookings(status) {
  const res = await api.get("/sitter/bookings", {
    params: { status }
  });
  if (Array.isArray(res)) {
    return res;
  }
  if (res && typeof res === "object") {
    const raw = res;
    if (Array.isArray(raw.data)) {
      return raw.data;
    }
    if (raw.data && typeof raw.data === "object") {
      const inner = raw.data;
      if (Array.isArray(inner.data)) {
        return inner.data;
      }
      if (Array.isArray(inner)) {
        return inner;
      }
    }
  }
  return [];
}
export async function getOwnerBookings(status) {
  const res = await api.get("/owner/bookings", {
    params: { status }
  });
  if (Array.isArray(res)) {
    return res;
  }
  if (res && typeof res === "object") {
    const raw = res;
    if (Array.isArray(raw.data)) {
      return raw.data;
    }
    if (raw.data && typeof raw.data === "object") {
      const inner = raw.data;
      if (Array.isArray(inner.data)) {
        return inner.data;
      }
      if (Array.isArray(inner)) {
        return inner;
      }
    }
  }
  return [];
}
export async function updateBookingStatus(bookingId, action) {
  try {
    const res = await api.patch("/sitter/bookings/" + bookingId, { action });
    if (res && typeof res === "object") {
      const raw = res;
      if (raw.data && typeof raw.data === "object") {
        const inner = raw.data;
        if (inner.data && typeof inner.data === "object") {
          return inner.data;
        }
        return inner;
      }
      return raw;
    }
    return res;
  } catch (err) {
    const axiosErr = err;
    const backendMessage = axiosErr?.response?.data?.message || axiosErr?.message || "ไม่สามารถอัปเดตสถานะการจองได้";
    throw new Error(backendMessage);
  }
}
export async function createBooking(payload) {
  const res = await api.post("/bookings", payload);
  if (res && typeof res === "object") {
    const raw = res;
    if (raw.data && typeof raw.data === "object") {
      const inner = raw.data;
      if (inner.data && typeof inner.data === "object") {
        return inner.data;
      }
      return inner;
    }
  }
  return res;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJvb2tpbmcuYXBpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGFwaSB9IGZyb20gJy4vYXBpLmpzJztcbmltcG9ydCB0eXBlIHsgQm9va2luZywgQm9va2luZ0FjdGlvbiwgQm9va2luZ1N0YXR1cywgT3duZXJCb29raW5nIH0gZnJvbSAnLi4vdHlwZXMvYm9va2luZyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2l0dGVyUGF5bWVudEluZm9TdGF0dXMge1xuICBzaXR0ZXJJZDogbnVtYmVyO1xuICBhY2NvdW50TmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgcXJDb2RlVXJsOiBzdHJpbmcgfCBudWxsO1xuICBoYXNQYXltZW50SW5mbzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNpdHRlclBheW1lbnRJbmZvKCk6IFByb21pc2U8U2l0dGVyUGF5bWVudEluZm9TdGF0dXM+IHtcbiAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCgnL3NpdHRlci9wYXltZW50LWluZm8nKTtcbiAgaWYgKHJlcyAmJiB0eXBlb2YgcmVzID09PSAnb2JqZWN0Jykge1xuICAgIGNvbnN0IHJhdyA9IHJlcyBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGlmIChyYXcuZGF0YSAmJiB0eXBlb2YgcmF3LmRhdGEgPT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBpbm5lciA9IHJhdy5kYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKGlubmVyLmRhdGEgJiYgdHlwZW9mIGlubmVyLmRhdGEgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIHJldHVybiBpbm5lci5kYXRhIGFzIFNpdHRlclBheW1lbnRJbmZvU3RhdHVzO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGlubmVyIGFzIHVua25vd24gYXMgU2l0dGVyUGF5bWVudEluZm9TdGF0dXM7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgc2l0dGVySWQ6IDAsXG4gICAgYWNjb3VudE5hbWU6IG51bGwsXG4gICAgcXJDb2RlVXJsOiBudWxsLFxuICAgIGhhc1BheW1lbnRJbmZvOiBmYWxzZSxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNpdHRlckJvb2tpbmdzKHN0YXR1cz86IEJvb2tpbmdTdGF0dXMpOiBQcm9taXNlPEJvb2tpbmdbXT4ge1xuICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KCcvc2l0dGVyL2Jvb2tpbmdzJywge1xuICAgIHBhcmFtczogeyBzdGF0dXMgfSxcbiAgfSk7XG5cbiAgaWYgKEFycmF5LmlzQXJyYXkocmVzKSkge1xuICAgIHJldHVybiByZXM7XG4gIH1cblxuICBpZiAocmVzICYmIHR5cGVvZiByZXMgPT09ICdvYmplY3QnKSB7XG4gICAgY29uc3QgcmF3ID0gcmVzIGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocmF3LmRhdGEpKSB7XG4gICAgICByZXR1cm4gcmF3LmRhdGEgYXMgQm9va2luZ1tdO1xuICAgIH1cbiAgICBpZiAocmF3LmRhdGEgJiYgdHlwZW9mIHJhdy5kYXRhID09PSAnb2JqZWN0Jykge1xuICAgICAgY29uc3QgaW5uZXIgPSByYXcuZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGlubmVyLmRhdGEpKSB7XG4gICAgICAgIHJldHVybiBpbm5lci5kYXRhIGFzIEJvb2tpbmdbXTtcbiAgICAgIH1cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGlubmVyKSkge1xuICAgICAgICByZXR1cm4gaW5uZXIgYXMgQm9va2luZ1tdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBbXTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE93bmVyQm9va2luZ3Moc3RhdHVzPzogQm9va2luZ1N0YXR1cyk6IFByb21pc2U8T3duZXJCb29raW5nW10+IHtcbiAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCgnL293bmVyL2Jvb2tpbmdzJywge1xuICAgIHBhcmFtczogeyBzdGF0dXMgfSxcbiAgfSk7XG5cbiAgaWYgKEFycmF5LmlzQXJyYXkocmVzKSkge1xuICAgIHJldHVybiByZXM7XG4gIH1cblxuICBpZiAocmVzICYmIHR5cGVvZiByZXMgPT09ICdvYmplY3QnKSB7XG4gICAgY29uc3QgcmF3ID0gcmVzIGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocmF3LmRhdGEpKSB7XG4gICAgICByZXR1cm4gcmF3LmRhdGEgYXMgT3duZXJCb29raW5nW107XG4gICAgfVxuICAgIGlmIChyYXcuZGF0YSAmJiB0eXBlb2YgcmF3LmRhdGEgPT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBpbm5lciA9IHJhdy5kYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5uZXIuZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIGlubmVyLmRhdGEgYXMgT3duZXJCb29raW5nW107XG4gICAgICB9XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShpbm5lcikpIHtcbiAgICAgICAgcmV0dXJuIGlubmVyIGFzIE93bmVyQm9va2luZ1tdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBbXTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUJvb2tpbmdTdGF0dXMoXG4gIGJvb2tpbmdJZDogbnVtYmVyLFxuICBhY3Rpb246IEJvb2tpbmdBY3Rpb24sXG4pOiBQcm9taXNlPHsgYm9va2luZ0lkOiBudW1iZXI7IGJvb2tpbmdzdGF0dXM6IEJvb2tpbmdTdGF0dXMgfT4ge1xuICB0eXBlIEJvb2tpbmdTdGF0dXNVcGRhdGUgPSB7XG4gICAgYm9va2luZ0lkOiBudW1iZXI7XG4gICAgYm9va2luZ3N0YXR1czogQm9va2luZ1N0YXR1cztcbiAgfTtcblxuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5wYXRjaCgnL3NpdHRlci9ib29raW5ncy8nICsgYm9va2luZ0lkLCB7IGFjdGlvbiB9KTtcblxuICAgIGlmIChyZXMgJiYgdHlwZW9mIHJlcyA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IHJhdyA9IHJlcyBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKHJhdy5kYXRhICYmIHR5cGVvZiByYXcuZGF0YSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgY29uc3QgaW5uZXIgPSByYXcuZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgICAgaWYgKGlubmVyLmRhdGEgJiYgdHlwZW9mIGlubmVyLmRhdGEgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgcmV0dXJuIGlubmVyLmRhdGEgYXMgQm9va2luZ1N0YXR1c1VwZGF0ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaW5uZXIgYXMgQm9va2luZ1N0YXR1c1VwZGF0ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByYXcgYXMgQm9va2luZ1N0YXR1c1VwZGF0ZTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzIGFzIEJvb2tpbmdTdGF0dXNVcGRhdGU7XG4gIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgIGNvbnN0IGF4aW9zRXJyID0gZXJyIGFzIHsgcmVzcG9uc2U/OiB7IGRhdGE/OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSB9OyBtZXNzYWdlPzogc3RyaW5nIH07XG4gICAgY29uc3QgYmFja2VuZE1lc3NhZ2UgPSBheGlvc0Vycj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgYXhpb3NFcnI/Lm1lc3NhZ2UgfHwgJ+C5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4reC4seC4m+C5gOC4lOC4leC4quC4luC4suC4meC4sOC4geC4suC4o+C4iOC4reC4h+C5hOC4lOC5iSc7XG4gICAgdGhyb3cgbmV3IEVycm9yKGJhY2tlbmRNZXNzYWdlKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQm9va2luZyhwYXlsb2FkOiB7XG4gIHNpdHRlcklkOiBudW1iZXI7XG4gIHNlcnZpY2VJZDogbnVtYmVyO1xuICBwZXRzOiB7IHBldElkOiBudW1iZXI7IHBldE5vdGU/OiBzdHJpbmcgfCBudWxsIH1bXTtcbiAgc3RhcnR0aW1lOiBzdHJpbmc7XG4gIGVuZHRpbWU6IHN0cmluZztcbiAgcGF5bWVudHBsYW46ICdmdWxsJyB8ICdkZXBvc2l0JztcbiAgbm90ZT86IHN0cmluZztcbn0pOiBQcm9taXNlPEJvb2tpbmc+IHtcbiAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoJy9ib29raW5ncycsIHBheWxvYWQpO1xuICBpZiAocmVzICYmIHR5cGVvZiByZXMgPT09ICdvYmplY3QnKSB7XG4gICAgY29uc3QgcmF3ID0gcmVzIGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgaWYgKHJhdy5kYXRhICYmIHR5cGVvZiByYXcuZGF0YSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IGlubmVyID0gcmF3LmRhdGEgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAoaW5uZXIuZGF0YSAmJiB0eXBlb2YgaW5uZXIuZGF0YSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIGlubmVyLmRhdGEgYXMgQm9va2luZztcbiAgICAgIH1cbiAgICAgIHJldHVybiBpbm5lciBhcyB1bmtub3duIGFzIEJvb2tpbmc7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXMgYXMgdW5rbm93biBhcyBCb29raW5nO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFdBQVc7QUFVcEIsc0JBQXNCLHVCQUF5RDtBQUM3RSxRQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksc0JBQXNCO0FBQ2hELE1BQUksT0FBTyxPQUFPLFFBQVEsVUFBVTtBQUNsQyxVQUFNLE1BQU07QUFDWixRQUFJLElBQUksUUFBUSxPQUFPLElBQUksU0FBUyxVQUFVO0FBQzVDLFlBQU0sUUFBUSxJQUFJO0FBQ2xCLFVBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFTLFVBQVU7QUFDaEQsZUFBTyxNQUFNO0FBQUEsTUFDZjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLGFBQWE7QUFBQSxJQUNiLFdBQVc7QUFBQSxJQUNYLGdCQUFnQjtBQUFBLEVBQ2xCO0FBQ0Y7QUFFQSxzQkFBc0Isa0JBQWtCLFFBQTRDO0FBQ2xGLFFBQU0sTUFBTSxNQUFNLElBQUksSUFBSSxvQkFBb0I7QUFBQSxJQUM1QyxRQUFRLEVBQUUsT0FBTztBQUFBLEVBQ25CLENBQUM7QUFFRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxNQUFJLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDbEMsVUFBTSxNQUFNO0FBQ1osUUFBSSxNQUFNLFFBQVEsSUFBSSxJQUFJLEdBQUc7QUFDM0IsYUFBTyxJQUFJO0FBQUEsSUFDYjtBQUNBLFFBQUksSUFBSSxRQUFRLE9BQU8sSUFBSSxTQUFTLFVBQVU7QUFDNUMsWUFBTSxRQUFRLElBQUk7QUFDbEIsVUFBSSxNQUFNLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDN0IsZUFBTyxNQUFNO0FBQUEsTUFDZjtBQUNBLFVBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN4QixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsU0FBTyxDQUFDO0FBQ1Y7QUFFQSxzQkFBc0IsaUJBQWlCLFFBQWlEO0FBQ3RGLFFBQU0sTUFBTSxNQUFNLElBQUksSUFBSSxtQkFBbUI7QUFBQSxJQUMzQyxRQUFRLEVBQUUsT0FBTztBQUFBLEVBQ25CLENBQUM7QUFFRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxNQUFJLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDbEMsVUFBTSxNQUFNO0FBQ1osUUFBSSxNQUFNLFFBQVEsSUFBSSxJQUFJLEdBQUc7QUFDM0IsYUFBTyxJQUFJO0FBQUEsSUFDYjtBQUNBLFFBQUksSUFBSSxRQUFRLE9BQU8sSUFBSSxTQUFTLFVBQVU7QUFDNUMsWUFBTSxRQUFRLElBQUk7QUFDbEIsVUFBSSxNQUFNLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDN0IsZUFBTyxNQUFNO0FBQUEsTUFDZjtBQUNBLFVBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN4QixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsU0FBTyxDQUFDO0FBQ1Y7QUFFQSxzQkFBc0Isb0JBQ3BCLFdBQ0EsUUFDOEQ7QUFNOUQsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLElBQUksTUFBTSxzQkFBc0IsV0FBVyxFQUFFLE9BQU8sQ0FBQztBQUV2RSxRQUFJLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDbEMsWUFBTSxNQUFNO0FBQ1osVUFBSSxJQUFJLFFBQVEsT0FBTyxJQUFJLFNBQVMsVUFBVTtBQUM1QyxjQUFNLFFBQVEsSUFBSTtBQUNsQixZQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBUyxVQUFVO0FBQ2hELGlCQUFPLE1BQU07QUFBQSxRQUNmO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNULFNBQVMsS0FBYztBQUNyQixVQUFNLFdBQVc7QUFDakIsVUFBTSxpQkFBaUIsVUFBVSxVQUFVLE1BQU0sV0FBVyxVQUFVLFdBQVc7QUFDakYsVUFBTSxJQUFJLE1BQU0sY0FBYztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxzQkFBc0IsY0FBYyxTQVFmO0FBQ25CLFFBQU0sTUFBTSxNQUFNLElBQUksS0FBSyxhQUFhLE9BQU87QUFDL0MsTUFBSSxPQUFPLE9BQU8sUUFBUSxVQUFVO0FBQ2xDLFVBQU0sTUFBTTtBQUNaLFFBQUksSUFBSSxRQUFRLE9BQU8sSUFBSSxTQUFTLFVBQVU7QUFDNUMsWUFBTSxRQUFRLElBQUk7QUFDbEIsVUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVMsVUFBVTtBQUNoRCxlQUFPLE1BQU07QUFBQSxNQUNmO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUOyIsIm5hbWVzIjpbXX0=