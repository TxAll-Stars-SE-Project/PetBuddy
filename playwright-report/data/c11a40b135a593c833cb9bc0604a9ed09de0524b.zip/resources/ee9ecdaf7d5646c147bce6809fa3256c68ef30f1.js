import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/careReport/CareReportsModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"];
import CareReportTimeline from "/src/components/careReport/CareReportTimeline.jsx";
import "/src/components/careReport/careReport.css";
export default function CareReportsModal({
  subtitle,
  status,
  reports = [],
  errorMessage = "โหลดรายงานไม่สำเร็จ กรุณาลองใหม่อีกครั้ง",
  viewer = "owner",
  canSubmit = false,
  onRetry,
  onAddReport,
  onClose
}) {
  _s();
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose]);
  const emptyText = viewer === "sitter" ? "ยังไม่มีรายงาน ส่งรายงานแรกเพื่อให้เจ้าของอุ่นใจ" : "พี่เลี้ยงยังไม่ได้ส่งรายงาน รายงานจะแสดงที่นี่เมื่อเริ่มดูแลน้อง";
  let body;
  if (status === "loading" && reports.length === 0) {
    body = /* @__PURE__ */ jsxDEV("div", { className: "care-report-skeleton", "aria-busy": "true", "aria-label": "กำลังโหลดรายงาน", children: [0, 1].map(
      (i) => /* @__PURE__ */ jsxDEV("div", { className: "care-report-skeleton-row", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "care-report-skeleton-dot" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-skeleton-line care-report-skeleton-line--short" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
            lineNumber: 59,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-skeleton-line" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
            lineNumber: 60,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-skeleton-photo" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
            lineNumber: 61,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
          lineNumber: 58,
          columnNumber: 13
        }, this)
      ] }, i, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 56,
        columnNumber: 7
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 54,
      columnNumber: 5
    }, this);
  } else if (status === "error") {
    body = /* @__PURE__ */ jsxDEV("div", { className: "payment-modal-state payment-modal-state--error", children: [
      /* @__PURE__ */ jsxDEV("p", { children: errorMessage }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn--small", onClick: onRetry, children: "ลองใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 69,
      columnNumber: 5
    }, this);
  } else if (reports.length === 0) {
    body = /* @__PURE__ */ jsxDEV("div", { className: "care-report-empty", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "care-report-empty-emoji", "aria-hidden": "true", children: "📝" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: emptyText }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 78,
      columnNumber: 5
    }, this);
  } else {
    body = /* @__PURE__ */ jsxDEV("div", { className: status === "loading" ? "is-loading" : "", children: /* @__PURE__ */ jsxDEV(CareReportTimeline, { reports }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 86,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 85,
      columnNumber: 5
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-overlay", onClick: onClose, children: /* @__PURE__ */ jsxDEV("div", { className: "delete-modal care-report-modal care-reports-modal", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "care-reports-head", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "รายงานการดูแล" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
          lineNumber: 96,
          columnNumber: 13
        }, this),
        subtitle && /* @__PURE__ */ jsxDEV("p", { className: "care-report-sub", children: subtitle }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
          lineNumber: 97,
          columnNumber: 26
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 95,
        columnNumber: 11
      }, this),
      status === "success" && reports.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "care-report-count", children: [
        reports.length,
        " รายงาน"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 100,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 94,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "care-reports-body", children: body }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 104,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions", children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "delete-cancel-button", onClick: onClose, children: "ปิด" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 107,
        columnNumber: 11
      }, this),
      onRetry && status !== "error" && /* @__PURE__ */ jsxDEV("button", { type: "button", className: "delete-cancel-button", onClick: onRetry, disabled: status === "loading", children: "รีเฟรช" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this),
      canSubmit && /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-save-button", onClick: onAddReport, children: "+ ส่งรายงานใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
        lineNumber: 116,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
      lineNumber: 106,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
    lineNumber: 93,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx",
    lineNumber: 92,
    columnNumber: 5
  }, this);
}
_s(CareReportsModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = CareReportsModal;
var _c;
$RefreshReg$(_c, "CareReportsModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportsModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDWixTQUFTQSxpQkFBaUI7QUFDMUIsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU87QUFLUCx3QkFBd0JDLGlCQUFpQjtBQUFBLEVBQ3ZDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkMsZUFBZTtBQUFBLEVBQ2ZDLFNBQVM7QUFBQSxFQUNUQyxZQUFZO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQUFDLEtBQUE7QUFDRFosWUFBVSxNQUFNO0FBQ2QsVUFBTWEsWUFBWUEsQ0FBQ0MsTUFBTTtBQUN2QixVQUFJQSxFQUFFQyxRQUFRLFNBQVVKLFNBQVE7QUFBQSxJQUNsQztBQUNBSyxXQUFPQyxpQkFBaUIsV0FBV0osU0FBUztBQUM1QyxXQUFPLE1BQU1HLE9BQU9FLG9CQUFvQixXQUFXTCxTQUFTO0FBQUEsRUFDOUQsR0FBRyxDQUFDRixPQUFPLENBQUM7QUFFWixRQUFNUSxZQUNKWixXQUFXLFdBQ1AscURBQ0E7QUFFTixNQUFJYTtBQUNKLE1BQUloQixXQUFXLGFBQWFDLFFBQVFnQixXQUFXLEdBQUc7QUFDaERELFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixhQUFVLFFBQU8sY0FBVyxtQkFDL0QsV0FBQyxHQUFHLENBQUMsRUFBRUU7QUFBQUEsTUFBSSxDQUFDQyxNQUNYLHVCQUFDLFNBQVksV0FBVSw0QkFDckI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsOEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUMxQyx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGdFQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFVBQUssV0FBVSwrQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxVQUFLLFdBQVUsZ0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsYUFIOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FOUUEsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxJQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsRUFFSixXQUFXbkIsV0FBVyxTQUFTO0FBQzdCZ0IsV0FDRSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxPQUFHZCwwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxrQkFBaUIsU0FBU0csU0FBUSx1QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKLFdBQVdKLFFBQVFnQixXQUFXLEdBQUc7QUFDL0JELFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUEwQixlQUFZLFFBQU8sa0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUM5RCx1QkFBQyxPQUFHRCx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWM7QUFBQSxTQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKLE9BQU87QUFDTEMsV0FDRSx1QkFBQyxTQUFJLFdBQVdoQixXQUFXLFlBQVksZUFBZSxJQUNwRCxpQ0FBQyxzQkFBbUIsV0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0JBQXVCLFNBQVNPLFNBQzdDLGlDQUFDLFNBQUksV0FBVSxxREFBb0QsU0FBUyxDQUFDRyxNQUFNQSxFQUFFVSxnQkFBZ0IsR0FDbkc7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDaEJyQixZQUFZLHVCQUFDLE9BQUUsV0FBVSxtQkFBbUJBLHNCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsV0FGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQ0MsV0FBVyxhQUFhQyxRQUFRZ0IsU0FBUyxLQUN4Qyx1QkFBQyxVQUFLLFdBQVUscUJBQXFCaEI7QUFBQUEsZ0JBQVFnQjtBQUFBQSxRQUFPO0FBQUEsV0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLFNBTi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUFxQkQsa0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUV6Qyx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHdCQUF1QixTQUFTVCxTQUFRLG1CQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDRixXQUFXTCxXQUFXLFdBQ3JCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsd0JBQXVCLFNBQVNLLFNBQVMsVUFBVUwsV0FBVyxXQUFVLHNCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVESSxhQUNDLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsdUJBQXNCLFNBQVNFLGFBQVksK0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQSxLQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBQ0UsR0FqR3VCVixrQkFBZ0I7QUFBQSxLQUFoQkE7QUFBZ0IsSUFBQXVCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIkNhcmVSZXBvcnRUaW1lbGluZSIsIkNhcmVSZXBvcnRzTW9kYWwiLCJzdWJ0aXRsZSIsInN0YXR1cyIsInJlcG9ydHMiLCJlcnJvck1lc3NhZ2UiLCJ2aWV3ZXIiLCJjYW5TdWJtaXQiLCJvblJldHJ5Iiwib25BZGRSZXBvcnQiLCJvbkNsb3NlIiwiX3MiLCJoYW5kbGVLZXkiLCJlIiwia2V5Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJlbXB0eVRleHQiLCJib2R5IiwibGVuZ3RoIiwibWFwIiwiaSIsInN0b3BQcm9wYWdhdGlvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhcmVSZXBvcnRzTW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IENhcmVSZXBvcnRUaW1lbGluZSBmcm9tIFwiLi9DYXJlUmVwb3J0VGltZWxpbmUuanN4XCI7XG5pbXBvcnQgXCIuL2NhcmVSZXBvcnQuY3NzXCI7XG5cbi8vIENhcmVSZXBvcnRzTW9kYWwg4oCUIOC4q+C4meC5ieC4suC4leC5iOC4suC4h+C4lOC4ueC4o+C4suC4ouC4h+C4suC4meC4geC4suC4o+C4lOC4ueC5geC4peC4l+C4seC5ieC4h+C4q+C4oeC4lOC4guC4reC4h+C4geC4suC4o+C4iOC4reC4hyAoVVM3LTMsIFVJIG9ubHkpXG4vLyBzdGF0dXM6IFwibG9hZGluZ1wiIHwgXCJlcnJvclwiIHwgXCJzdWNjZXNzXCIg4oCUIHBhcmVudCDguYDguJvguYfguJnguITguJnguYLguKvguKXguJTguILguYnguK3guKHguLnguKXguYHguKXguYnguKfguKrguYjguIfguYDguILguYnguLLguKHguLJcbi8vIGNhblN1Ym1pdDogdHJ1ZSDguYDguInguJ7guLLguLDguJ7guLXguYjguYDguKXguLXguYnguKLguIfguJXguK3guJnguIfguLLguJnguYDguJvguYfguJkgaW5fcHJvZ3Jlc3Mg4oaSIOC5geC4quC4lOC4h+C4m+C4uOC5iOC4oSBcIuC4quC5iOC4h+C4o+C4suC4ouC4h+C4suC4meC5g+C4q+C4oeC5iFwiXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYXJlUmVwb3J0c01vZGFsKHtcbiAgc3VidGl0bGUsXG4gIHN0YXR1cyxcbiAgcmVwb3J0cyA9IFtdLFxuICBlcnJvck1lc3NhZ2UgPSBcIuC5guC4q+C4peC4lOC4o+C4suC4ouC4h+C4suC4meC5hOC4oeC5iOC4quC4s+C5gOC4o+C5h+C4iCDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIixcbiAgdmlld2VyID0gXCJvd25lclwiLFxuICBjYW5TdWJtaXQgPSBmYWxzZSxcbiAgb25SZXRyeSxcbiAgb25BZGRSZXBvcnQsXG4gIG9uQ2xvc2UsXG59KSB7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5ID0gKGUpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikgb25DbG9zZSgpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXkpO1xuICB9LCBbb25DbG9zZV0pO1xuXG4gIGNvbnN0IGVtcHR5VGV4dCA9XG4gICAgdmlld2VyID09PSBcInNpdHRlclwiXG4gICAgICA/IFwi4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14Lij4Liy4Lii4LiH4Liy4LiZIOC4quC5iOC4h+C4o+C4suC4ouC4h+C4suC4meC5geC4o+C4geC5gOC4nuC4t+C5iOC4reC5g+C4q+C5ieC5gOC4iOC5ieC4suC4guC4reC4h+C4reC4uOC5iOC4meC5g+C4iFwiXG4gICAgICA6IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4Liq4LmI4LiH4Lij4Liy4Lii4LiH4Liy4LiZIOC4o+C4suC4ouC4h+C4suC4meC4iOC4sOC5geC4quC4lOC4h+C4l+C4teC5iOC4meC4teC5iOC5gOC4oeC4t+C5iOC4reC5gOC4o+C4tOC5iOC4oeC4lOC4ueC5geC4peC4meC5ieC4reC4h1wiO1xuXG4gIGxldCBib2R5O1xuICBpZiAoc3RhdHVzID09PSBcImxvYWRpbmdcIiAmJiByZXBvcnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGJvZHkgPSAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LXNrZWxldG9uXCIgYXJpYS1idXN5PVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCLguIHguLPguKXguLHguIfguYLguKvguKXguJTguKPguLLguKLguIfguLLguJlcIj5cbiAgICAgICAge1swLCAxXS5tYXAoKGkpID0+IChcbiAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtc2tlbGV0b24tcm93XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1za2VsZXRvbi1kb3RcIiAvPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtc2tlbGV0b24tbGluZSBjYXJlLXJlcG9ydC1za2VsZXRvbi1saW5lLS1zaG9ydFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LXNrZWxldG9uLWxpbmVcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1za2VsZXRvbi1waG90b1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9IGVsc2UgaWYgKHN0YXR1cyA9PT0gXCJlcnJvclwiKSB7XG4gICAgYm9keSA9IChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1tb2RhbC1zdGF0ZSBwYXltZW50LW1vZGFsLXN0YXRlLS1lcnJvclwiPlxuICAgICAgICA8cD57ZXJyb3JNZXNzYWdlfTwvcD5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tc21hbGxcIiBvbkNsaWNrPXtvblJldHJ5fT5cbiAgICAgICAgICDguKXguK3guIfguYPguKvguKHguYhcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9IGVsc2UgaWYgKHJlcG9ydHMubGVuZ3RoID09PSAwKSB7XG4gICAgYm9keSA9IChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtZW1wdHlcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1lbXB0eS1lbW9qaVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPvCfk508L2Rpdj5cbiAgICAgICAgPHA+e2VtcHR5VGV4dH08L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9IGVsc2Uge1xuICAgIGJvZHkgPSAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3RhdHVzID09PSBcImxvYWRpbmdcIiA/IFwiaXMtbG9hZGluZ1wiIDogXCJcIn0+XG4gICAgICAgIDxDYXJlUmVwb3J0VGltZWxpbmUgcmVwb3J0cz17cmVwb3J0c30gLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsZXRlLW1vZGFsLW92ZXJsYXlcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsZXRlLW1vZGFsIGNhcmUtcmVwb3J0LW1vZGFsIGNhcmUtcmVwb3J0cy1tb2RhbFwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydHMtaGVhZFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDI+4Lij4Liy4Lii4LiH4Liy4LiZ4LiB4Liy4Lij4LiU4Li54LmB4LilPC9oMj5cbiAgICAgICAgICAgIHtzdWJ0aXRsZSAmJiA8cCBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1zdWJcIj57c3VidGl0bGV9PC9wPn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7c3RhdHVzID09PSBcInN1Y2Nlc3NcIiAmJiByZXBvcnRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtY291bnRcIj57cmVwb3J0cy5sZW5ndGh9IOC4o+C4suC4ouC4h+C4suC4mTwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0cy1ib2R5XCI+e2JvZHl9PC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtYWN0aW9uc1wiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImRlbGV0ZS1jYW5jZWwtYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICDguJvguLTguJRcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICB7b25SZXRyeSAmJiBzdGF0dXMgIT09IFwiZXJyb3JcIiAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkZWxldGUtY2FuY2VsLWJ1dHRvblwiIG9uQ2xpY2s9e29uUmV0cnl9IGRpc2FibGVkPXtzdGF0dXMgPT09IFwibG9hZGluZ1wifT5cbiAgICAgICAgICAgICAg4Lij4Li14LmA4Lif4Lij4LiKXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtjYW5TdWJtaXQgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1zYXZlLWJ1dHRvblwiIG9uQ2xpY2s9e29uQWRkUmVwb3J0fT5cbiAgICAgICAgICAgICAgKyDguKrguYjguIfguKPguLLguKLguIfguLLguJnguYPguKvguKHguYhcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9jYXJlUmVwb3J0L0NhcmVSZXBvcnRzTW9kYWwuanN4In0=