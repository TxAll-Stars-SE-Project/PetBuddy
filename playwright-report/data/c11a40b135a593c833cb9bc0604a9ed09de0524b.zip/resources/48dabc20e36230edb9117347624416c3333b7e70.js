import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/SitterBookingList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import SitterBookingCard from "/src/components/sitter/SitterBookingCard.tsx";
import BookingConfirmModal from "/src/components/sitter/BookingConfirmModal.tsx";
import {
  getSitterBookings,
  getSitterPaymentInfo,
  updateBookingStatus
} from "/src/services/booking.api.ts";
import { toast } from "/src/utils/toast.js";
import "/src/components/sitter/SitterBookingList.css";
const statusGroups = {
  pending: ["pending"],
  confirmed: ["waiting_payment", "waiting_final_payment"],
  completed: ["confirmed", "completed", "deposit_paid", "in_progress"],
  cancelled: ["rejected", "cancelled"]
};
const tabs = [
  { id: "ALL", label: "ทั้งหมด" },
  { id: "pending", label: "รอดำเนินการ" },
  { id: "confirmed", label: "ยืนยันแล้ว" },
  { id: "completed", label: "สำเร็จ" },
  { id: "cancelled", label: "ยกเลิก/ปฏิเสธ" }
];
export default function SitterBookingList() {
  _s();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);
  const [activeTab, setActiveTab] = useState("ALL");
  const [hasPaymentInfo, setHasPaymentInfo] = useState(null);
  const [confirmTarget, setConfirmTarget] = useState(null);
  const fetchBookingsAndPaymentInfo = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [list, paymentInfo] = await Promise.all(
        [
          getSitterBookings(),
          getSitterPaymentInfo().catch(() => null)
        ]
      );
      setBookings(Array.isArray(list) ? list : []);
      if (paymentInfo !== null) {
        setHasPaymentInfo(Boolean(paymentInfo.hasPaymentInfo));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "ไม่สามารถดึงข้อมูลการจองได้");
      setBookings([]);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void fetchBookingsAndPaymentInfo();
  }, [fetchBookingsAndPaymentInfo]);
  const safeBookings = useMemo(() => Array.isArray(bookings) ? bookings : [], [bookings]);
  const sortedBookings = useMemo(
    () => [...safeBookings].sort(
      (first, second) => Number(second?.bookingstatus === "pending") - Number(first?.bookingstatus === "pending")
    ),
    [safeBookings]
  );
  const filteredBookings = activeTab === "ALL" ? sortedBookings : sortedBookings.filter(
    (booking) => booking && statusGroups[activeTab]?.includes(booking.bookingstatus)
  );
  const countForTab = (tab) => tab === "ALL" ? safeBookings.length : safeBookings.filter(
    (booking) => booking && statusGroups[tab]?.includes(booking.bookingstatus)
  ).length;
  const handleRequestConfirm = (booking, action) => {
    if (action === "accept" && hasPaymentInfo === false) {
      toast(
        "กรุณาตั้งค่าชื่อบัญชีรับเงินและอัปโหลด QR Code ในหน้าโปรไฟล์ก่อนกดรับงาน",
        "error"
      );
      return;
    }
    setConfirmTarget({ booking, action });
  };
  const handleConfirmAction = async () => {
    if (!confirmTarget) return;
    const { booking, action } = confirmTarget;
    setUpdatingId(booking.bookingId);
    setError(null);
    try {
      await updateBookingStatus(booking.bookingId, action);
      const actionText = action === "accept" ? "รับงานคำขอจองเรียบร้อยแล้ว (สถานะ: รอชำระเงิน)" : action === "reject" ? "ปฏิเสธคำขอจองเรียบร้อยแล้ว" : "ส่งมอบงานเสร็จสิ้นเรียบร้อยแล้ว";
      toast(actionText, "success");
      setConfirmTarget(null);
      await fetchBookingsAndPaymentInfo();
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : "ไม่สามารถอัปเดตสถานะการจองได้";
      toast(errMsg, "error");
      setConfirmTarget(null);
    } finally {
      setUpdatingId(null);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-list", children: [
    hasPaymentInfo === false && /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-list__payment-warning", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-list__payment-warning-body", children: [
        /* @__PURE__ */ jsxDEV(
          "svg",
          {
            width: "22",
            height: "22",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            "aria-hidden": "true",
            children: [
              /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "10" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
                lineNumber: 169,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "8", x2: "12", y2: "12" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
                lineNumber: 170,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
                lineNumber: 171,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
            lineNumber: 158,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "คุณยังไม่ได้ตั้งค่าบัญชีรับเงินและ QR Code" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
            lineNumber: 174,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "จำเป็นต้องระบุชื่อบัญชีผู้รับเงินและอัปโหลดรูป QR Code ก่อน จึงจะสามารถกดรับงานคำขอจองได้" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
            lineNumber: 175,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
          lineNumber: 173,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
        lineNumber: 157,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/profile", className: "sitter-booking-list__payment-warning-btn", children: "ไปตั้งค่าที่หน้าโปรไฟล์" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
        lineNumber: 180,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "sitter-booking-list__tabs", "aria-label": "กรองรายการจองตามสถานะ", children: tabs.map(
      (tab) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: `sitter-booking-list__tab${activeTab === tab.id ? " is-active" : ""}`,
          type: "button",
          "aria-pressed": activeTab === tab.id,
          onClick: () => setActiveTab(tab.id),
          children: [
            tab.label,
            /* @__PURE__ */ jsxDEV("span", { className: "sitter-booking-list__count", children: countForTab(tab.id) }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
              lineNumber: 196,
              columnNumber: 13
            }, this)
          ]
        },
        tab.id,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
          lineNumber: 188,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 186,
      columnNumber: 7
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("p", { role: "status", children: "กำลังโหลดข้อมูล..." }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 202,
      columnNumber: 7
    }, this) : error ? /* @__PURE__ */ jsxDEV("div", { role: "alert", children: [
      /* @__PURE__ */ jsxDEV("p", { children: error }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
        lineNumber: 205,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => void fetchBookingsAndPaymentInfo(), children: "ลองใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
        lineNumber: 206,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 204,
      columnNumber: 7
    }, this) : bookings.length === 0 ? /* @__PURE__ */ jsxDEV("p", { children: "ยังไม่มีรายการคำขอการจอง" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 211,
      columnNumber: 7
    }, this) : filteredBookings.length === 0 ? /* @__PURE__ */ jsxDEV("p", { children: "ไม่มีรายการในสถานะนี้" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 213,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-list__items", children: filteredBookings.map(
      (booking) => /* @__PURE__ */ jsxDEV(
        SitterBookingCard,
        {
          booking,
          onRequestConfirm: handleRequestConfirm,
          isUpdating: updatingId === booking.bookingId
        },
        booking.bookingId,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
          lineNumber: 217,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
      lineNumber: 215,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      BookingConfirmModal,
      {
        isOpen: confirmTarget !== null,
        booking: confirmTarget?.booking ?? null,
        action: confirmTarget?.action ?? null,
        isSubmitting: updatingId !== null,
        onConfirm: () => void handleConfirmAction(),
        onCancel: () => setConfirmTarget(null)
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
        lineNumber: 227,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
}
_s(SitterBookingList, "mSVaZnk4mZGVgVfhLlcRe1lenAU=");
_c = SitterBookingList;
var _c;
$RefreshReg$(_c, "SitterBookingList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUpjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJKZCxTQUFTQSxhQUFhQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDMUQsU0FBU0MsWUFBWTtBQUNyQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MseUJBQXlCO0FBQ2hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWE7QUFFdEIsT0FBTztBQUlQLE1BQU1DLGVBQW9FO0FBQUEsRUFDeEVDLFNBQVMsQ0FBQyxTQUFTO0FBQUEsRUFDbkJDLFdBQVcsQ0FBQyxtQkFBbUIsdUJBQXVCO0FBQUEsRUFDdERDLFdBQVcsQ0FBQyxhQUFhLGFBQWEsZ0JBQWdCLGFBQWE7QUFBQSxFQUNuRUMsV0FBVyxDQUFDLFlBQVksV0FBVztBQUNyQztBQUVBLE1BQU1DLE9BQTRDO0FBQUEsRUFDaEQsRUFBRUMsSUFBSSxPQUFPQyxPQUFPLFVBQVU7QUFBQSxFQUM5QixFQUFFRCxJQUFJLFdBQVdDLE9BQU8sY0FBYztBQUFBLEVBQ3RDLEVBQUVELElBQUksYUFBYUMsT0FBTyxhQUFhO0FBQUEsRUFDdkMsRUFBRUQsSUFBSSxhQUFhQyxPQUFPLFNBQVM7QUFBQSxFQUNuQyxFQUFFRCxJQUFJLGFBQWFDLE9BQU8sZ0JBQWdCO0FBQUM7QUFHN0Msd0JBQXdCQyxvQkFBb0I7QUFBQUMsS0FBQTtBQUMxQyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSW5CLFNBQW9CLEVBQUU7QUFDdEQsUUFBTSxDQUFDb0IsU0FBU0MsVUFBVSxJQUFJckIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3NCLE9BQU9DLFFBQVEsSUFBSXZCLFNBQXdCLElBQUk7QUFDdEQsUUFBTSxDQUFDd0IsWUFBWUMsYUFBYSxJQUFJekIsU0FBd0IsSUFBSTtBQUNoRSxRQUFNLENBQUMwQixXQUFXQyxZQUFZLElBQUkzQixTQUFxQixLQUFLO0FBQzVELFFBQU0sQ0FBQzRCLGdCQUFnQkMsaUJBQWlCLElBQUk3QixTQUF5QixJQUFJO0FBQ3pFLFFBQU0sQ0FBQzhCLGVBQWVDLGdCQUFnQixJQUFJL0IsU0FHaEMsSUFBSTtBQUVkLFFBQU1nQyw4QkFBOEJuQyxZQUFZLFlBQVk7QUFDMUR3QixlQUFXLElBQUk7QUFDZkUsYUFBUyxJQUFJO0FBRWIsUUFBSTtBQUNGLFlBQU0sQ0FBQ1UsTUFBTUMsV0FBVyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUM1Q2hDLGtCQUFrQjtBQUFBLFVBQ2xCQyxxQkFBcUIsRUFBRWdDLE1BQU0sTUFBTSxJQUFJO0FBQUEsUUFBQztBQUFBLE1BQ3pDO0FBRURsQixrQkFBWW1CLE1BQU1DLFFBQVFOLElBQUksSUFBSUEsT0FBTyxFQUFFO0FBQzNDLFVBQUlDLGdCQUFnQixNQUFNO0FBQ3hCTCwwQkFBa0JXLFFBQVFOLFlBQVlOLGNBQWMsQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsSUFDRixTQUFTYSxLQUFLO0FBQ1psQixlQUFTa0IsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSw2QkFBNkI7QUFDM0V4QixrQkFBWSxFQUFFO0FBQUEsSUFDaEIsVUFBQztBQUNDRSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMdkIsWUFBVSxNQUFNO0FBQ2QsU0FBS2tDLDRCQUE0QjtBQUFBLEVBQ25DLEdBQUcsQ0FBQ0EsMkJBQTJCLENBQUM7QUFFaEMsUUFBTVksZUFBZTdDLFFBQVEsTUFBT3VDLE1BQU1DLFFBQVFyQixRQUFRLElBQUlBLFdBQVcsSUFBSyxDQUFDQSxRQUFRLENBQUM7QUFFeEYsUUFBTTJCLGlCQUFpQjlDO0FBQUFBLElBQ3JCLE1BQ0UsQ0FBQyxHQUFHNkMsWUFBWSxFQUFFRTtBQUFBQSxNQUNoQixDQUFDQyxPQUFPQyxXQUNOQyxPQUFPRCxRQUFRRSxrQkFBa0IsU0FBUyxJQUMxQ0QsT0FBT0YsT0FBT0csa0JBQWtCLFNBQVM7QUFBQSxJQUM3QztBQUFBLElBQ0YsQ0FBQ04sWUFBWTtBQUFBLEVBQ2Y7QUFFQSxRQUFNTyxtQkFDSnpCLGNBQWMsUUFDVm1CLGlCQUNBQSxlQUFlTztBQUFBQSxJQUFPLENBQUNDLFlBQ3JCQSxXQUFXN0MsYUFBYWtCLFNBQVMsR0FBRzRCLFNBQVNELFFBQVFILGFBQWE7QUFBQSxFQUNwRTtBQUVOLFFBQU1LLGNBQWNBLENBQUNDLFFBQ25CQSxRQUFRLFFBQ0paLGFBQWFhLFNBQ2JiLGFBQWFRO0FBQUFBLElBQU8sQ0FBQ0MsWUFDbkJBLFdBQVc3QyxhQUFhZ0QsR0FBRyxHQUFHRixTQUFTRCxRQUFRSCxhQUFhO0FBQUEsRUFDOUQsRUFBRU87QUFFUixRQUFNQyx1QkFBdUJBLENBQUNMLFNBQWtCTSxXQUEwQjtBQUV4RSxRQUFJQSxXQUFXLFlBQVkvQixtQkFBbUIsT0FBTztBQUNuRHJCO0FBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBO0FBQUEsSUFDRjtBQUNBd0IscUJBQWlCLEVBQUVzQixTQUFTTSxPQUFPLENBQUM7QUFBQSxFQUN0QztBQUVBLFFBQU1DLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUksQ0FBQzlCLGNBQWU7QUFFcEIsVUFBTSxFQUFFdUIsU0FBU00sT0FBTyxJQUFJN0I7QUFDNUJMLGtCQUFjNEIsUUFBUVEsU0FBUztBQUMvQnRDLGFBQVMsSUFBSTtBQUViLFFBQUk7QUFDRixZQUFNakIsb0JBQW9CK0MsUUFBUVEsV0FBV0YsTUFBTTtBQUNuRCxZQUFNRyxhQUNKSCxXQUFXLFdBQ1AsbURBQ0FBLFdBQVcsV0FDVCwrQkFDQTtBQUNScEQsWUFBTXVELFlBQVksU0FBUztBQUMzQi9CLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU1DLDRCQUE0QjtBQUFBLElBQ3BDLFNBQVNTLEtBQUs7QUFDWixZQUFNc0IsU0FBU3RCLGVBQWVDLFFBQVFELElBQUlFLFVBQVU7QUFDcERwQyxZQUFNd0QsUUFBUSxPQUFPO0FBQ3JCaEMsdUJBQWlCLElBQUk7QUFBQSxJQUN2QixVQUFDO0FBQ0NOLG9CQUFjLElBQUk7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDWkc7QUFBQUEsdUJBQW1CLFNBQ2xCLHVCQUFDLFNBQUksV0FBVSx3Q0FBdUMsTUFBSyxTQUN6RDtBQUFBLDZCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixRQUFPO0FBQUEsWUFDUCxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFDTCxRQUFPO0FBQUEsWUFDUCxhQUFZO0FBQUEsWUFDWixlQUFjO0FBQUEsWUFDZCxnQkFBZTtBQUFBLFlBQ2YsZUFBWTtBQUFBLFlBRVo7QUFBQSxxQ0FBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQ3BDLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFNBQVEsSUFBRyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBO0FBQUE7QUFBQSxVQWIxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFlBQU8sMERBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxPQUFDLHlHQUFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUNBLHVCQUFDLFFBQUssSUFBRyxZQUFXLFdBQVUsNENBQTBDLHVDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsSUFHRix1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLGNBQVcseUJBQ25EZixlQUFLbUQ7QUFBQUEsTUFBSSxDQUFDUixRQUNUO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFXLDJCQUEyQjlCLGNBQWM4QixJQUFJMUMsS0FBSyxlQUFlLEVBQUU7QUFBQSxVQUM5RSxNQUFLO0FBQUEsVUFDTCxnQkFBY1ksY0FBYzhCLElBQUkxQztBQUFBQSxVQUNoQyxTQUFTLE1BQU1hLGFBQWE2QixJQUFJMUMsRUFBRTtBQUFBLFVBRWpDMEM7QUFBQUEsZ0JBQUl6QztBQUFBQSxZQUNMLHVCQUFDLFVBQUssV0FBVSw4QkFBOEJ3QyxzQkFBWUMsSUFBSTFDLEVBQUUsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQTtBQUFBO0FBQUEsUUFQN0QwQyxJQUFJMUM7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0E7QUFBQSxJQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFFQ00sVUFDQyx1QkFBQyxPQUFFLE1BQUssVUFBUyxrQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQyxJQUNqQ0UsUUFDRix1QkFBQyxTQUFJLE1BQUssU0FDUjtBQUFBLDZCQUFDLE9BQUdBLG1CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVTtBQUFBLE1BQ1YsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNLEtBQUtVLDRCQUE0QixHQUFFLHVCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxJQUNFZCxTQUFTdUMsV0FBVyxJQUN0Qix1QkFBQyxPQUFFLHdDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkIsSUFDekJOLGlCQUFpQk0sV0FBVyxJQUM5Qix1QkFBQyxPQUFFLHFDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsSUFFeEIsdUJBQUMsU0FBSSxXQUFVLDhCQUNaTiwyQkFBaUJhO0FBQUFBLE1BQUksQ0FBQ1gsWUFDckI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDO0FBQUEsVUFDQSxrQkFBa0JLO0FBQUFBLFVBQ2xCLFlBQVlsQyxlQUFlNkIsUUFBUVE7QUFBQUE7QUFBQUEsUUFIOUJSLFFBQVFRO0FBQUFBLFFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUkrQztBQUFBLElBRWhELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFHRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUS9CLGtCQUFrQjtBQUFBLFFBQzFCLFNBQVNBLGVBQWV1QixXQUFXO0FBQUEsUUFDbkMsUUFBUXZCLGVBQWU2QixVQUFVO0FBQUEsUUFDakMsY0FBY25DLGVBQWU7QUFBQSxRQUM3QixXQUFXLE1BQU0sS0FBS29DLG9CQUFvQjtBQUFBLFFBQzFDLFVBQVUsTUFBTTdCLGlCQUFpQixJQUFJO0FBQUE7QUFBQSxNQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNeUM7QUFBQSxPQS9FM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlGQTtBQUVKO0FBQUNkLEdBM0x1QkQsbUJBQWlCO0FBQUEsS0FBakJBO0FBQWlCLElBQUFpRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIkxpbmsiLCJTaXR0ZXJCb29raW5nQ2FyZCIsIkJvb2tpbmdDb25maXJtTW9kYWwiLCJnZXRTaXR0ZXJCb29raW5ncyIsImdldFNpdHRlclBheW1lbnRJbmZvIiwidXBkYXRlQm9va2luZ1N0YXR1cyIsInRvYXN0Iiwic3RhdHVzR3JvdXBzIiwicGVuZGluZyIsImNvbmZpcm1lZCIsImNvbXBsZXRlZCIsImNhbmNlbGxlZCIsInRhYnMiLCJpZCIsImxhYmVsIiwiU2l0dGVyQm9va2luZ0xpc3QiLCJfcyIsImJvb2tpbmdzIiwic2V0Qm9va2luZ3MiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJ1cGRhdGluZ0lkIiwic2V0VXBkYXRpbmdJZCIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImhhc1BheW1lbnRJbmZvIiwic2V0SGFzUGF5bWVudEluZm8iLCJjb25maXJtVGFyZ2V0Iiwic2V0Q29uZmlybVRhcmdldCIsImZldGNoQm9va2luZ3NBbmRQYXltZW50SW5mbyIsImxpc3QiLCJwYXltZW50SW5mbyIsIlByb21pc2UiLCJhbGwiLCJjYXRjaCIsIkFycmF5IiwiaXNBcnJheSIsIkJvb2xlYW4iLCJlcnIiLCJFcnJvciIsIm1lc3NhZ2UiLCJzYWZlQm9va2luZ3MiLCJzb3J0ZWRCb29raW5ncyIsInNvcnQiLCJmaXJzdCIsInNlY29uZCIsIk51bWJlciIsImJvb2tpbmdzdGF0dXMiLCJmaWx0ZXJlZEJvb2tpbmdzIiwiZmlsdGVyIiwiYm9va2luZyIsImluY2x1ZGVzIiwiY291bnRGb3JUYWIiLCJ0YWIiLCJsZW5ndGgiLCJoYW5kbGVSZXF1ZXN0Q29uZmlybSIsImFjdGlvbiIsImhhbmRsZUNvbmZpcm1BY3Rpb24iLCJib29raW5nSWQiLCJhY3Rpb25UZXh0IiwiZXJyTXNnIiwibWFwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2l0dGVyQm9va2luZ0xpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IFNpdHRlckJvb2tpbmdDYXJkIGZyb20gJy4vU2l0dGVyQm9va2luZ0NhcmQnO1xuaW1wb3J0IEJvb2tpbmdDb25maXJtTW9kYWwgZnJvbSAnLi9Cb29raW5nQ29uZmlybU1vZGFsJztcbmltcG9ydCB7XG4gIGdldFNpdHRlckJvb2tpbmdzLFxuICBnZXRTaXR0ZXJQYXltZW50SW5mbyxcbiAgdXBkYXRlQm9va2luZ1N0YXR1cyxcbn0gZnJvbSAnLi4vLi4vc2VydmljZXMvYm9va2luZy5hcGknO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICcuLi8uLi91dGlscy90b2FzdCc7XG5pbXBvcnQgdHlwZSB7IEJvb2tpbmcsIEJvb2tpbmdBY3Rpb24sIEJvb2tpbmdTdGF0dXMgfSBmcm9tICcuLi8uLi90eXBlcy9ib29raW5nJztcbmltcG9ydCAnLi9TaXR0ZXJCb29raW5nTGlzdC5jc3MnO1xuXG50eXBlIEJvb2tpbmdUYWIgPSAnQUxMJyB8ICdwZW5kaW5nJyB8ICdjb25maXJtZWQnIHwgJ2NvbXBsZXRlZCcgfCAnY2FuY2VsbGVkJztcblxuY29uc3Qgc3RhdHVzR3JvdXBzOiBSZWNvcmQ8RXhjbHVkZTxCb29raW5nVGFiLCAnQUxMJz4sIEJvb2tpbmdTdGF0dXNbXT4gPSB7XG4gIHBlbmRpbmc6IFsncGVuZGluZyddLFxuICBjb25maXJtZWQ6IFsnd2FpdGluZ19wYXltZW50JywgJ3dhaXRpbmdfZmluYWxfcGF5bWVudCddLFxuICBjb21wbGV0ZWQ6IFsnY29uZmlybWVkJywgJ2NvbXBsZXRlZCcsICdkZXBvc2l0X3BhaWQnLCAnaW5fcHJvZ3Jlc3MnXSxcbiAgY2FuY2VsbGVkOiBbJ3JlamVjdGVkJywgJ2NhbmNlbGxlZCddLFxufTtcblxuY29uc3QgdGFiczogeyBpZDogQm9va2luZ1RhYjsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gIHsgaWQ6ICdBTEwnLCBsYWJlbDogJ+C4l+C4seC5ieC4h+C4q+C4oeC4lCcgfSxcbiAgeyBpZDogJ3BlbmRpbmcnLCBsYWJlbDogJ+C4o+C4reC4lOC4s+C5gOC4meC4tOC4meC4geC4suC4oycgfSxcbiAgeyBpZDogJ2NvbmZpcm1lZCcsIGxhYmVsOiAn4Lii4Li34LiZ4Lii4Lix4LiZ4LmB4Lil4LmJ4LinJyB9LFxuICB7IGlkOiAnY29tcGxldGVkJywgbGFiZWw6ICfguKrguLPguYDguKPguYfguIgnIH0sXG4gIHsgaWQ6ICdjYW5jZWxsZWQnLCBsYWJlbDogJ+C4ouC4geC5gOC4peC4tOC4gS/guJvguI/guLTguYDguKrguJgnIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaXR0ZXJCb29raW5nTGlzdCgpIHtcbiAgY29uc3QgW2Jvb2tpbmdzLCBzZXRCb29raW5nc10gPSB1c2VTdGF0ZTxCb29raW5nW10+KFtdKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt1cGRhdGluZ0lkLCBzZXRVcGRhdGluZ0lkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8Qm9va2luZ1RhYj4oJ0FMTCcpO1xuICBjb25zdCBbaGFzUGF5bWVudEluZm8sIHNldEhhc1BheW1lbnRJbmZvXSA9IHVzZVN0YXRlPGJvb2xlYW4gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2NvbmZpcm1UYXJnZXQsIHNldENvbmZpcm1UYXJnZXRdID0gdXNlU3RhdGU8e1xuICAgIGJvb2tpbmc6IEJvb2tpbmc7XG4gICAgYWN0aW9uOiBCb29raW5nQWN0aW9uO1xuICB9IHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgZmV0Y2hCb29raW5nc0FuZFBheW1lbnRJbmZvID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgW2xpc3QsIHBheW1lbnRJbmZvXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgZ2V0U2l0dGVyQm9va2luZ3MoKSxcbiAgICAgICAgZ2V0U2l0dGVyUGF5bWVudEluZm8oKS5jYXRjaCgoKSA9PiBudWxsKSxcbiAgICAgIF0pO1xuXG4gICAgICBzZXRCb29raW5ncyhBcnJheS5pc0FycmF5KGxpc3QpID8gbGlzdCA6IFtdKTtcbiAgICAgIGlmIChwYXltZW50SW5mbyAhPT0gbnVsbCkge1xuICAgICAgICBzZXRIYXNQYXltZW50SW5mbyhCb29sZWFuKHBheW1lbnRJbmZvLmhhc1BheW1lbnRJbmZvKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ+C5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4lOC4tuC4h+C4guC5ieC4reC4oeC4ueC4peC4geC4suC4o+C4iOC4reC4h+C5hOC4lOC5iScpO1xuICAgICAgc2V0Qm9va2luZ3MoW10pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZvaWQgZmV0Y2hCb29raW5nc0FuZFBheW1lbnRJbmZvKCk7XG4gIH0sIFtmZXRjaEJvb2tpbmdzQW5kUGF5bWVudEluZm9dKTtcblxuICBjb25zdCBzYWZlQm9va2luZ3MgPSB1c2VNZW1vKCgpID0+IChBcnJheS5pc0FycmF5KGJvb2tpbmdzKSA/IGJvb2tpbmdzIDogW10pLCBbYm9va2luZ3NdKTtcblxuICBjb25zdCBzb3J0ZWRCb29raW5ncyA9IHVzZU1lbW8oXG4gICAgKCkgPT5cbiAgICAgIFsuLi5zYWZlQm9va2luZ3NdLnNvcnQoXG4gICAgICAgIChmaXJzdCwgc2Vjb25kKSA9PlxuICAgICAgICAgIE51bWJlcihzZWNvbmQ/LmJvb2tpbmdzdGF0dXMgPT09ICdwZW5kaW5nJykgLVxuICAgICAgICAgIE51bWJlcihmaXJzdD8uYm9va2luZ3N0YXR1cyA9PT0gJ3BlbmRpbmcnKSxcbiAgICAgICksXG4gICAgW3NhZmVCb29raW5nc10sXG4gICk7XG5cbiAgY29uc3QgZmlsdGVyZWRCb29raW5ncyA9XG4gICAgYWN0aXZlVGFiID09PSAnQUxMJ1xuICAgICAgPyBzb3J0ZWRCb29raW5nc1xuICAgICAgOiBzb3J0ZWRCb29raW5ncy5maWx0ZXIoKGJvb2tpbmcpID0+XG4gICAgICAgICAgYm9va2luZyAmJiBzdGF0dXNHcm91cHNbYWN0aXZlVGFiXT8uaW5jbHVkZXMoYm9va2luZy5ib29raW5nc3RhdHVzKSxcbiAgICAgICAgKTtcblxuICBjb25zdCBjb3VudEZvclRhYiA9ICh0YWI6IEJvb2tpbmdUYWIpID0+XG4gICAgdGFiID09PSAnQUxMJ1xuICAgICAgPyBzYWZlQm9va2luZ3MubGVuZ3RoXG4gICAgICA6IHNhZmVCb29raW5ncy5maWx0ZXIoKGJvb2tpbmcpID0+XG4gICAgICAgICAgYm9va2luZyAmJiBzdGF0dXNHcm91cHNbdGFiXT8uaW5jbHVkZXMoYm9va2luZy5ib29raW5nc3RhdHVzKSxcbiAgICAgICAgKS5sZW5ndGg7XG5cbiAgY29uc3QgaGFuZGxlUmVxdWVzdENvbmZpcm0gPSAoYm9va2luZzogQm9va2luZywgYWN0aW9uOiBCb29raW5nQWN0aW9uKSA9PiB7XG4gICAgLy8g4Lia4Lix4LiH4LiE4Lix4Lia4LiV4LmJ4Lit4LiH4LiV4Lix4LmJ4LiH4LiE4LmI4Liy4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14Lij4Lix4Lia4LmA4LiH4Li04LiZ4LmB4Lil4LiwIFFSIENvZGUg4LiB4LmI4Lit4LiZ4LiB4LiU4Lij4Lix4Lia4LiH4Liy4LiZIChVUyAyLTIgJiBVUyA2LTIpXG4gICAgaWYgKGFjdGlvbiA9PT0gJ2FjY2VwdCcgJiYgaGFzUGF5bWVudEluZm8gPT09IGZhbHNlKSB7XG4gICAgICB0b2FzdChcbiAgICAgICAgJ+C4geC4o+C4uOC4k+C4suC4leC4seC5ieC4h+C4hOC5iOC4suC4iuC4t+C5iOC4reC4muC4seC4jeC4iuC4teC4o+C4seC4muC5gOC4h+C4tOC4meC5geC4peC4sOC4reC4seC4m+C5guC4q+C4peC4lCBRUiBDb2RlIOC5g+C4meC4q+C4meC5ieC4suC5guC4m+C4o+C5hOC4n+C4peC5jOC4geC5iOC4reC4meC4geC4lOC4o+C4seC4muC4h+C4suC4mScsXG4gICAgICAgICdlcnJvcicsXG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRDb25maXJtVGFyZ2V0KHsgYm9va2luZywgYWN0aW9uIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm1BY3Rpb24gPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFjb25maXJtVGFyZ2V0KSByZXR1cm47XG5cbiAgICBjb25zdCB7IGJvb2tpbmcsIGFjdGlvbiB9ID0gY29uZmlybVRhcmdldDtcbiAgICBzZXRVcGRhdGluZ0lkKGJvb2tpbmcuYm9va2luZ0lkKTtcbiAgICBzZXRFcnJvcihudWxsKTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB1cGRhdGVCb29raW5nU3RhdHVzKGJvb2tpbmcuYm9va2luZ0lkLCBhY3Rpb24pO1xuICAgICAgY29uc3QgYWN0aW9uVGV4dCA9XG4gICAgICAgIGFjdGlvbiA9PT0gJ2FjY2VwdCdcbiAgICAgICAgICA/ICfguKPguLHguJrguIfguLLguJnguITguLPguILguK3guIjguK3guIfguYDguKPguLXguKLguJrguKPguYnguK3guKLguYHguKXguYnguKcgKOC4quC4luC4suC4meC4sDog4Lij4Lit4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZKSdcbiAgICAgICAgICA6IGFjdGlvbiA9PT0gJ3JlamVjdCdcbiAgICAgICAgICAgID8gJ+C4m+C4j+C4tOC5gOC4quC4mOC4hOC4s+C4guC4reC4iOC4reC4h+C5gOC4o+C4teC4ouC4muC4o+C5ieC4reC4ouC5geC4peC5ieC4pydcbiAgICAgICAgICAgIDogJ+C4quC5iOC4h+C4oeC4reC4muC4h+C4suC4meC5gOC4quC4o+C5h+C4iOC4quC4tOC5ieC4meC5gOC4o+C4teC4ouC4muC4o+C5ieC4reC4ouC5geC4peC5ieC4pyc7XG4gICAgICB0b2FzdChhY3Rpb25UZXh0LCAnc3VjY2VzcycpO1xuICAgICAgc2V0Q29uZmlybVRhcmdldChudWxsKTtcbiAgICAgIGF3YWl0IGZldGNoQm9va2luZ3NBbmRQYXltZW50SW5mbygpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgZXJyTXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICfguYTguKHguYjguKrguLLguKHguLLguKPguJbguK3guLHguJvguYDguJTguJXguKrguJbguLLguJnguLDguIHguLLguKPguIjguK3guIfguYTguJTguYknO1xuICAgICAgdG9hc3QoZXJyTXNnLCAnZXJyb3InKTtcbiAgICAgIHNldENvbmZpcm1UYXJnZXQobnVsbCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFVwZGF0aW5nSWQobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1saXN0XCI+XG4gICAgICB7aGFzUGF5bWVudEluZm8gPT09IGZhbHNlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1saXN0X19wYXltZW50LXdhcm5pbmdcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWxpc3RfX3BheW1lbnQtd2FybmluZy1ib2R5XCI+XG4gICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgIHdpZHRoPVwiMjJcIlxuICAgICAgICAgICAgICBoZWlnaHQ9XCIyMlwiXG4gICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjEwXCIgLz5cbiAgICAgICAgICAgICAgPGxpbmUgeDE9XCIxMlwiIHkxPVwiOFwiIHgyPVwiMTJcIiB5Mj1cIjEyXCIgLz5cbiAgICAgICAgICAgICAgPGxpbmUgeDE9XCIxMlwiIHkxPVwiMTZcIiB4Mj1cIjEyLjAxXCIgeTI9XCIxNlwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzdHJvbmc+4LiE4Li44LiT4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4LiV4Lix4LmJ4LiH4LiE4LmI4Liy4Lia4Lix4LiN4LiK4Li14Lij4Lix4Lia4LmA4LiH4Li04LiZ4LmB4Lil4LiwIFFSIENvZGU8L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAg4LiI4Liz4LmA4Lib4LmH4LiZ4LiV4LmJ4Lit4LiH4Lij4Liw4Lia4Li44LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14Lic4Li54LmJ4Lij4Lix4Lia4LmA4LiH4Li04LiZ4LmB4Lil4Liw4Lit4Lix4Lib4LmC4Lir4Lil4LiU4Lij4Li54LibIFFSIENvZGUg4LiB4LmI4Lit4LiZIOC4iOC4tuC4h+C4iOC4sOC4quC4suC4oeC4suC4o+C4luC4geC4lOC4o+C4seC4muC4h+C4suC4meC4hOC4s+C4guC4reC4iOC4reC4h+C5hOC4lOC5iVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8TGluayB0bz1cIi9wcm9maWxlXCIgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctbGlzdF9fcGF5bWVudC13YXJuaW5nLWJ0blwiPlxuICAgICAgICAgICAg4LmE4Lib4LiV4Lix4LmJ4LiH4LiE4LmI4Liy4LiX4Li14LmI4Lir4LiZ4LmJ4Liy4LmC4Lib4Lij4LmE4Lif4Lil4LmMXG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctbGlzdF9fdGFic1wiIGFyaWEtbGFiZWw9XCLguIHguKPguK3guIfguKPguLLguKLguIHguLLguKPguIjguK3guIfguJXguLLguKHguKrguJbguLLguJnguLBcIj5cbiAgICAgICAge3RhYnMubWFwKCh0YWIpID0+IChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHNpdHRlci1ib29raW5nLWxpc3RfX3RhYiR7YWN0aXZlVGFiID09PSB0YWIuaWQgPyAnIGlzLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2FjdGl2ZVRhYiA9PT0gdGFiLmlkfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYi5pZCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3RhYi5sYWJlbH1cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWxpc3RfX2NvdW50XCI+e2NvdW50Rm9yVGFiKHRhYi5pZCl9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvbmF2PlxuXG4gICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgPHAgcm9sZT1cInN0YXR1c1wiPuC4geC4s+C4peC4seC4h+C5guC4q+C4peC4lOC4guC5ieC4reC4oeC4ueC4pS4uLjwvcD5cbiAgICAgICkgOiBlcnJvciA/IChcbiAgICAgICAgPGRpdiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICA8cD57ZXJyb3J9PC9wPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHZvaWQgZmV0Y2hCb29raW5nc0FuZFBheW1lbnRJbmZvKCl9PlxuICAgICAgICAgICAg4Lil4Lit4LiH4LmD4Lir4Lih4LmIXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IGJvb2tpbmdzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPHA+4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14Lij4Liy4Lii4LiB4Liy4Lij4LiE4Liz4LiC4Lit4LiB4Liy4Lij4LiI4Lit4LiHPC9wPlxuICAgICAgKSA6IGZpbHRlcmVkQm9va2luZ3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8cD7guYTguKHguYjguKHguLXguKPguLLguKLguIHguLLguKPguYPguJnguKrguJbguLLguJnguLDguJnguLXguYk8L3A+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWxpc3RfX2l0ZW1zXCI+XG4gICAgICAgICAge2ZpbHRlcmVkQm9va2luZ3MubWFwKChib29raW5nKSA9PiAoXG4gICAgICAgICAgICA8U2l0dGVyQm9va2luZ0NhcmRcbiAgICAgICAgICAgICAga2V5PXtib29raW5nLmJvb2tpbmdJZH1cbiAgICAgICAgICAgICAgYm9va2luZz17Ym9va2luZ31cbiAgICAgICAgICAgICAgb25SZXF1ZXN0Q29uZmlybT17aGFuZGxlUmVxdWVzdENvbmZpcm19XG4gICAgICAgICAgICAgIGlzVXBkYXRpbmc9e3VwZGF0aW5nSWQgPT09IGJvb2tpbmcuYm9va2luZ0lkfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8Qm9va2luZ0NvbmZpcm1Nb2RhbFxuICAgICAgICBpc09wZW49e2NvbmZpcm1UYXJnZXQgIT09IG51bGx9XG4gICAgICAgIGJvb2tpbmc9e2NvbmZpcm1UYXJnZXQ/LmJvb2tpbmcgPz8gbnVsbH1cbiAgICAgICAgYWN0aW9uPXtjb25maXJtVGFyZ2V0Py5hY3Rpb24gPz8gbnVsbH1cbiAgICAgICAgaXNTdWJtaXR0aW5nPXt1cGRhdGluZ0lkICE9PSBudWxsfVxuICAgICAgICBvbkNvbmZpcm09eygpID0+IHZvaWQgaGFuZGxlQ29uZmlybUFjdGlvbigpfVxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0Q29uZmlybVRhcmdldChudWxsKX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvU2l0dGVyQm9va2luZ0xpc3QudHN4In0=