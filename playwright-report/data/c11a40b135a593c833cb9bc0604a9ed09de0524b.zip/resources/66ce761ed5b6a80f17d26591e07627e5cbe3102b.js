import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PetModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { toast } from "/src/utils/toast.js";
import AlertBanner from "/src/components/ui/AlertBanner.jsx";
function PetModal({
  pet,
  mode,
  // "add", "edit", or "view"
  error,
  isSaving = false,
  isDeleting = false,
  onChange,
  onClose,
  onSave,
  onDelete,
  onSwitchToEdit
}) {
  _s();
  const isView = mode === "view";
  const isEdit = mode === "edit";
  const fileInputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  useEffect(() => {
    return () => {
      if (pet.photo && pet.photo.startsWith("blob:")) {
        URL.revokeObjectURL(pet.photo);
      }
    };
  }, [pet.photo]);
  const processFile = (file) => {
    if (!file) return;
    const validTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
    if (!validTypes.includes(file.type)) {
      toast("กรุณาเลือกไฟล์รูปภาพ (JPG, PNG หรือ WEBP)", "error");
      return;
    }
    const MAX_FILE_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      toast("ขนาดไฟล์ใหญ่เกินไป กรุณาอัปโหลดรูปภาพขนาดไม่เกิน 5MB", "error");
      return;
    }
    if (pet.photo && pet.photo.startsWith("blob:")) {
      URL.revokeObjectURL(pet.photo);
    }
    onChange("photoFile", file);
    onChange("photo", URL.createObjectURL(file));
  };
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
    if (e.target) {
      e.target.value = "";
    }
  };
  const handleRemovePhoto = () => {
    if (pet.photo && pet.photo.startsWith("blob:")) {
      URL.revokeObjectURL(pet.photo);
    }
    onChange("photoFile", null);
    onChange("photo", "");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-overlay", children: /* @__PURE__ */ jsxDEV("div", { className: "delete-modal pet-modal-container", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: isView ? `ข้อมูลของ ${pet.name || "สัตว์เลี้ยง"}` : isEdit ? "แก้ไขข้อมูลสัตว์เลี้ยง" : "เพิ่มสัตว์เลี้ยงใหม่" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
      lineNumber: 117,
      columnNumber: 9
    }, this),
    isView ? (
      /* โหมดดูข้อมูล (View) */
      /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-view-container", children: [
        pet.photo && /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-preview-wrapper", children: /* @__PURE__ */ jsxDEV("img", { src: pet.photo, alt: pet.name, className: "pet-modal-preview-img" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 130,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "ชื่อ:" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 133,
            columnNumber: 18
          }, this),
          " ",
          pet.name || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 133,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "สายพันธุ์ (Species):" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 134,
            columnNumber: 18
          }, this),
          " ",
          pet.species || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 134,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "พันธุ์ (Breed):" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 135,
            columnNumber: 18
          }, this),
          " ",
          pet.breed || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 135,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "เพศ (Gender):" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 136,
            columnNumber: 18
          }, this),
          " ",
          pet.gender || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 136,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "อายุ:" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 137,
            columnNumber: 18
          }, this),
          " ",
          pet.age || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 137,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "น้ำหนัก:" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 138,
            columnNumber: 18
          }, this),
          " ",
          pet.weight ? `${pet.weight} กก.` : "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 138,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("b", { children: "หมายเหตุ:" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 139,
            columnNumber: 18
          }, this),
          " ",
          pet.notes || "-"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 139,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ) : (
      /* โหมดกรอกข้อมูล (Add / Edit) */
      /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-full-width pet-modal-preview-wrapper", children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "pet-modal-avatar-clickable",
            onClick: () => fileInputRef.current?.click(),
            title: "คลิกเพื่อเลือกหรือเปลี่ยนรูปภาพ",
            children: [
              pet.photo ? /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: pet.photo,
                  alt: "Pet Preview",
                  className: "pet-modal-preview-img",
                  onError: (e) => {
                    e.target.src = "data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' style='background:%23eee;'%3E%3Ctext x='50%25' y='50%25' font-size='40' text-anchor='middle' dy='.35em'%3E%26%23128062%3B%3C/text%3E%3C/svg%3E";
                  }
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                  lineNumber: 152,
                  columnNumber: 15
                },
                this
              ) : /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-placeholder", children: "🐾" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                lineNumber: 159,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-avatar-badge", title: "อัปโหลดรูปภาพ", children: "📷" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                lineNumber: 161,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 146,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 145,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "ชื่อสัตว์เลี้ยง (Name)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 168,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "profile-input",
              placeholder: "เช่น บราวนี่",
              value: pet.name || "",
              onChange: (e) => onChange("name", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 169,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 167,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "สายพันธุ์สัตว์ (Species)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 178,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "profile-input",
              placeholder: "เช่น สุนัข, แมว",
              value: pet.species || "",
              onChange: (e) => onChange("species", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 179,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 177,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "พันธุ์ (Breed)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 189,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "profile-input",
              placeholder: "เช่น โกลเด้น รีทรีฟเวอร์",
              value: pet.breed || "",
              onChange: (e) => onChange("breed", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 190,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 188,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "เพศ (Gender)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 199,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "profile-input",
              placeholder: "เช่น ผู้, เมีย",
              value: pet.gender || "",
              onChange: (e) => onChange("gender", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 200,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 198,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "อายุ (Age)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 210,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "profile-input",
              placeholder: "เช่น 2 ปี",
              value: pet.age || "",
              onChange: (e) => onChange("age", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 211,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 209,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "น้ำหนัก (Weight - กก.)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 220,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              step: "0.1",
              className: "profile-input",
              placeholder: "เช่น 12.5",
              value: pet.weight || "",
              onChange: (e) => onChange("weight", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 221,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 219,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-full-width", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "6px", fontSize: "13px" }, children: "รูปภาพสัตว์เลี้ยง (Photo)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 232,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: "image/jpeg, image/png, image/jpg, image/webp",
              style: { display: "none" },
              onChange: handleFileChange
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 236,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `pet-file-upload-box ${isDragging ? "pet-file-upload-box--dragover" : ""}`,
              onClick: () => {
                if (!isSaving && !isDeleting) fileInputRef.current?.click();
              },
              onDragOver: handleDragOver,
              onDragLeave: handleDragLeave,
              onDrop: handleDrop,
              title: isSaving || isDeleting ? "กำลังประมวลผล..." : "คลิกหรือลากไฟล์รูปภาพมาวางที่นี่",
              style: {
                pointerEvents: isSaving || isDeleting ? "none" : "auto",
                opacity: isSaving || isDeleting ? 0.65 : 1
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "pet-file-upload-left", children: [
                  /* @__PURE__ */ jsxDEV("button", { type: "button", className: "pet-file-choose-btn", disabled: isSaving || isDeleting, children: [
                    /* @__PURE__ */ jsxDEV("svg", { width: "15", height: "15", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                      /* @__PURE__ */ jsxDEV("path", { d: "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" }, void 0, false, {
                        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                        lineNumber: 261,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "13", r: "4" }, void 0, false, {
                        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                        lineNumber: 262,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                      lineNumber: 260,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: pet.photo ? "เปลี่ยนรูปภาพ" : "เลือกรูปภาพ" }, void 0, false, {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                      lineNumber: 264,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 259,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "pet-file-info", children: pet.photoFile ? /* @__PURE__ */ jsxDEV("span", { className: "pet-file-name", title: pet.photoFile.name, children: [
                    "📎 ",
                    pet.photoFile.name,
                    /* @__PURE__ */ jsxDEV("span", { className: "pet-file-size", children: [
                      " ",
                      "(",
                      (pet.photoFile.size / (1024 * 1024)).toFixed(2),
                      " MB)"
                    ] }, void 0, true, {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                      lineNumber: 270,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 268,
                    columnNumber: 19
                  }, this) : pet.photo ? /* @__PURE__ */ jsxDEV("span", { className: "pet-file-status", children: [
                    "✓ มีรูปภาพแล้ว ",
                    /* @__PURE__ */ jsxDEV("span", { className: "pet-file-hint", children: "(คลิกเพื่อเปลี่ยน)" }, void 0, false, {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                      lineNumber: 276,
                      columnNumber: 40
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 275,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "pet-file-hint", children: "ยังไม่ได้เลือกไฟล์ (JPG, PNG ไม่เกิน 5MB)" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 279,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 266,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                  lineNumber: 258,
                  columnNumber: 17
                }, this),
                (pet.photoFile || pet.photo) && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "pet-file-remove-btn",
                    title: "ลบรูปภาพนี้",
                    disabled: isSaving || isDeleting,
                    onClick: (e) => {
                      e.stopPropagation();
                      if (!isSaving && !isDeleting) handleRemovePhoto();
                    },
                    children: "✕"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                    lineNumber: 287,
                    columnNumber: 15
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 244,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 231,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pet-modal-full-width", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "profile-label", style: { display: "block", marginBottom: "4px", fontSize: "13px" }, children: "หมายเหตุ (Notes)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 304,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              className: "profile-input",
              style: { height: "60px", resize: "vertical" },
              placeholder: "เช่น แพ้อาหาร",
              value: pet.notes || "",
              disabled: isSaving || isDeleting,
              onChange: (e) => onChange("notes", e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 305,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 303,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
        lineNumber: 143,
        columnNumber: 9
      }, this)
    ),
    error && /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "14px" }, children: /* @__PURE__ */ jsxDEV(AlertBanner, { type: "error", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
      lineNumber: 319,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
      lineNumber: 318,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions", style: { marginTop: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
      isEdit && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "profile-delete-button",
          style: { padding: "8px 14px", fontSize: "13px", flex: "none", display: "inline-flex", alignItems: "center", gap: "6px" },
          onClick: onDelete,
          disabled: isSaving || isDeleting,
          children: [
            isDeleting && /* @__PURE__ */ jsxDEV("span", { className: "spinner", "aria-hidden": "true" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 332,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: isDeleting ? "กำลังลบ…" : "ลบสัตว์เลี้ยง" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
              lineNumber: 333,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 325,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "8px", marginLeft: "auto" }, children: isView ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "delete-cancel-button", onClick: onClose, children: "ปิด" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 340,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-save-button", onClick: onSwitchToEdit, children: "แก้ไข" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
          lineNumber: 343,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
        lineNumber: 339,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "delete-cancel-button",
            onClick: onClose,
            disabled: isSaving || isDeleting,
            children: "ยกเลิก"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 349,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "profile-save-button",
            onClick: onSave,
            disabled: isSaving || isDeleting,
            style: { display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "8px", minWidth: "110px" },
            children: [
              isSaving && /* @__PURE__ */ jsxDEV("span", { className: "spinner", "aria-hidden": "true" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                lineNumber: 364,
                columnNumber: 32
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: isSaving ? "กำลังบันทึก…" : "บันทึก" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
                lineNumber: 365,
                columnNumber: 19
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
            lineNumber: 357,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
        lineNumber: 348,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
        lineNumber: 337,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
      lineNumber: 323,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
    lineNumber: 116,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx",
    lineNumber: 115,
    columnNumber: 5
  }, this);
}
_s(PetModal, "IBdIZkPJmlPBnwlje7rUmyYF9/Y=");
_c = PetModal;
export default PetModal;
var _c;
$RefreshReg$(_c, "PetModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/PetModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUdRLFNBOE5NLFVBOU5OOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpHUixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsYUFBYTtBQUN0QixPQUFPQyxpQkFBaUI7QUFFeEIsU0FBU0MsU0FBUztBQUFBLEVBQ2hCQztBQUFBQSxFQUNBQztBQUFBQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxXQUFXO0FBQUEsRUFDWEMsYUFBYTtBQUFBLEVBQ2JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsU0FBU1YsU0FBUztBQUN4QixRQUFNVyxTQUFTWCxTQUFTO0FBQ3hCLFFBQU1ZLGVBQWVsQixPQUFPLElBQUk7QUFDaEMsUUFBTSxDQUFDbUIsWUFBWUMsYUFBYSxJQUFJbkIsU0FBUyxLQUFLO0FBRWxERixZQUFVLE1BQU07QUFDZCxXQUFPLE1BQU07QUFDWCxVQUFJTSxJQUFJZ0IsU0FBU2hCLElBQUlnQixNQUFNQyxXQUFXLE9BQU8sR0FBRztBQUM5Q0MsWUFBSUMsZ0JBQWdCbkIsSUFBSWdCLEtBQUs7QUFBQSxNQUMvQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ2hCLElBQUlnQixLQUFLLENBQUM7QUFFZCxRQUFNSSxjQUFjQSxDQUFDQyxTQUFTO0FBQzVCLFFBQUksQ0FBQ0EsS0FBTTtBQUVYLFVBQU1DLGFBQWEsQ0FBQyxjQUFjLGFBQWEsYUFBYSxZQUFZO0FBQ3hFLFFBQUksQ0FBQ0EsV0FBV0MsU0FBU0YsS0FBS0csSUFBSSxHQUFHO0FBQ25DM0IsWUFBTSw2Q0FBNkMsT0FBTztBQUMxRDtBQUFBLElBQ0Y7QUFFQSxVQUFNNEIsZ0JBQWdCLElBQUksT0FBTztBQUNqQyxRQUFJSixLQUFLSyxPQUFPRCxlQUFlO0FBQzdCNUIsWUFBTSx3REFBd0QsT0FBTztBQUNyRTtBQUFBLElBQ0Y7QUFFQSxRQUFJRyxJQUFJZ0IsU0FBU2hCLElBQUlnQixNQUFNQyxXQUFXLE9BQU8sR0FBRztBQUM5Q0MsVUFBSUMsZ0JBQWdCbkIsSUFBSWdCLEtBQUs7QUFBQSxJQUMvQjtBQUNBWCxhQUFTLGFBQWFnQixJQUFJO0FBQzFCaEIsYUFBUyxTQUFTYSxJQUFJUyxnQkFBZ0JOLElBQUksQ0FBQztBQUFBLEVBQzdDO0FBRUEsUUFBTU8sbUJBQW1CQSxDQUFDQyxNQUFNO0FBQzlCLFVBQU1SLE9BQU9RLEVBQUVDLE9BQU9DLFFBQVEsQ0FBQztBQUMvQixRQUFJVixNQUFNO0FBQ1JELGtCQUFZQyxJQUFJO0FBQUEsSUFDbEI7QUFDQSxRQUFJUSxFQUFFQyxRQUFRO0FBQ1pELFFBQUVDLE9BQU9FLFFBQVE7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxvQkFBb0JBLE1BQU07QUFDOUIsUUFBSWpDLElBQUlnQixTQUFTaEIsSUFBSWdCLE1BQU1DLFdBQVcsT0FBTyxHQUFHO0FBQzlDQyxVQUFJQyxnQkFBZ0JuQixJQUFJZ0IsS0FBSztBQUFBLElBQy9CO0FBQ0FYLGFBQVMsYUFBYSxJQUFJO0FBQzFCQSxhQUFTLFNBQVMsRUFBRTtBQUNwQixRQUFJUSxhQUFhcUIsU0FBUztBQUN4QnJCLG1CQUFhcUIsUUFBUUYsUUFBUTtBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUVBLFFBQU1HLGlCQUFpQkEsQ0FBQ04sTUFBTTtBQUM1QkEsTUFBRU8sZUFBZTtBQUNqQlAsTUFBRVEsZ0JBQWdCO0FBQ2xCdEIsa0JBQWMsSUFBSTtBQUFBLEVBQ3BCO0FBRUEsUUFBTXVCLGtCQUFrQkEsQ0FBQ1QsTUFBTTtBQUM3QkEsTUFBRU8sZUFBZTtBQUNqQlAsTUFBRVEsZ0JBQWdCO0FBQ2xCdEIsa0JBQWMsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTXdCLGFBQWFBLENBQUNWLE1BQU07QUFDeEJBLE1BQUVPLGVBQWU7QUFDakJQLE1BQUVRLGdCQUFnQjtBQUNsQnRCLGtCQUFjLEtBQUs7QUFDbkIsVUFBTU0sT0FBT1EsRUFBRVcsYUFBYVQsUUFBUSxDQUFDO0FBQ3JDLFFBQUlWLE1BQU07QUFDUkQsa0JBQVlDLElBQUk7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx3QkFDYixpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwyQkFBQyxRQUNFVixtQkFDRyxhQUFhWCxJQUFJeUMsUUFBUSxhQUFhLEtBQ3RDN0IsU0FDQSwyQkFDQSwwQkFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVDRDtBQUFBQTtBQUFBQSxNQUVDLHVCQUFDLFNBQUksV0FBVSw0QkFDWlg7QUFBQUEsWUFBSWdCLFNBQ0gsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLFNBQUksS0FBS2hCLElBQUlnQixPQUFPLEtBQUtoQixJQUFJeUMsTUFBTSxXQUFVLDJCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFLEtBRHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUYsdUJBQUMsU0FBSTtBQUFBLGlDQUFDLE9BQUUscUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQUk7QUFBQSxVQUFFekMsSUFBSXlDLFFBQVE7QUFBQSxhQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsUUFDbkMsdUJBQUMsU0FBSTtBQUFBLGlDQUFDLE9BQUUsb0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFJO0FBQUEsVUFBRXpDLElBQUkwQyxXQUFXO0FBQUEsYUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxPQUFFLCtCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFBSTtBQUFBLFVBQUUxQyxJQUFJMkMsU0FBUztBQUFBLGFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsT0FBRSw2QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQUk7QUFBQSxVQUFFM0MsSUFBSTRDLFVBQVU7QUFBQSxhQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsU0FBSTtBQUFBLGlDQUFDLE9BQUUscUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQUk7QUFBQSxVQUFFNUMsSUFBSTZDLE9BQU87QUFBQSxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsU0FBSTtBQUFBLGlDQUFDLE9BQUUsd0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQUk7QUFBQSxVQUFFN0MsSUFBSThDLFNBQVMsR0FBRzlDLElBQUk4QyxNQUFNLFNBQVM7QUFBQSxhQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFDN0QsdUJBQUMsU0FBSTtBQUFBLGlDQUFDLE9BQUUseUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQUk7QUFBQSxVQUFFOUMsSUFBSStDLFNBQVM7QUFBQSxhQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsV0FaMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUE7QUFBQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1sQyxhQUFhcUIsU0FBU2MsTUFBTTtBQUFBLFlBQzNDLE9BQU07QUFBQSxZQUVMaEQ7QUFBQUEsa0JBQUlnQixRQUNIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEtBQUtoQixJQUFJZ0I7QUFBQUEsa0JBQ1QsS0FBSTtBQUFBLGtCQUNKLFdBQVU7QUFBQSxrQkFDVixTQUFTLENBQUNhLE1BQU07QUFBRUEsc0JBQUVDLE9BQU9tQixNQUFNO0FBQUEsa0JBQXNQO0FBQUE7QUFBQSxnQkFKelI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTJSLElBRzNSLHVCQUFDLFNBQUksV0FBVSx5QkFBd0Isa0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FFM0MsdUJBQUMsU0FBSSxXQUFVLDBCQUF5QixPQUFNLGlCQUFlLGtCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlCQUFnQixPQUFPLEVBQUVDLFNBQVMsU0FBU0MsY0FBYyxPQUFPQyxVQUFVLE9BQU8sR0FBRyxzQ0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQSxVQUMzSDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT3BELElBQUl5QyxRQUFRO0FBQUEsY0FDbkIsVUFBVSxDQUFDWixNQUFNeEIsU0FBUyxRQUFRd0IsRUFBRUMsT0FBT0UsS0FBSztBQUFBO0FBQUEsWUFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS29EO0FBQUEsYUFQdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlCQUFnQixPQUFPLEVBQUVrQixTQUFTLFNBQVNDLGNBQWMsT0FBT0MsVUFBVSxPQUFPLEdBQUcsd0NBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZIO0FBQUEsVUFDN0g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU9wRCxJQUFJMEMsV0FBVztBQUFBLGNBQ3RCLFVBQVUsQ0FBQ2IsTUFBTXhCLFNBQVMsV0FBV3dCLEVBQUVDLE9BQU9FLEtBQUs7QUFBQTtBQUFBLFlBTHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt1RDtBQUFBLGFBUHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxpQkFBZ0IsT0FBTyxFQUFFa0IsU0FBUyxTQUFTQyxjQUFjLE9BQU9DLFVBQVUsT0FBTyxHQUFHLDhCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLFVBQ25IO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFPcEQsSUFBSTJDLFNBQVM7QUFBQSxjQUNwQixVQUFVLENBQUNkLE1BQU14QixTQUFTLFNBQVN3QixFQUFFQyxPQUFPRSxLQUFLO0FBQUE7QUFBQSxZQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLcUQ7QUFBQSxhQVB2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWtCLFNBQVMsU0FBU0MsY0FBYyxPQUFPQyxVQUFVLE9BQU8sR0FBRyw0QkFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUg7QUFBQSxVQUNqSDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT3BELElBQUk0QyxVQUFVO0FBQUEsY0FDckIsVUFBVSxDQUFDZixNQUFNeEIsU0FBUyxVQUFVd0IsRUFBRUMsT0FBT0UsS0FBSztBQUFBO0FBQUEsWUFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3NEO0FBQUEsYUFQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlCQUFnQixPQUFPLEVBQUVrQixTQUFTLFNBQVNDLGNBQWMsT0FBT0MsVUFBVSxPQUFPLEdBQUcsMEJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStHO0FBQUEsVUFDL0c7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU9wRCxJQUFJNkMsT0FBTztBQUFBLGNBQ2xCLFVBQVUsQ0FBQ2hCLE1BQU14QixTQUFTLE9BQU93QixFQUFFQyxPQUFPRSxLQUFLO0FBQUE7QUFBQSxZQUxqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLbUQ7QUFBQSxhQVByRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWtCLFNBQVMsU0FBU0MsY0FBYyxPQUFPQyxVQUFVLE9BQU8sR0FBRyxzQ0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQSxVQUMzSDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT3BELElBQUk4QyxVQUFVO0FBQUEsY0FDckIsVUFBVSxDQUFDakIsTUFBTXhCLFNBQVMsVUFBVXdCLEVBQUVDLE9BQU9FLEtBQUs7QUFBQTtBQUFBLFlBTnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1zRDtBQUFBLGFBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlCQUFnQixPQUFPLEVBQUVrQixTQUFTLFNBQVNDLGNBQWMsT0FBT0MsVUFBVSxPQUFPLEdBQUUseUNBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxLQUFLdkM7QUFBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxPQUFPLEVBQUVxQyxTQUFTLE9BQU87QUFBQSxjQUN6QixVQUFVdEI7QUFBQUE7QUFBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLNkI7QUFBQSxVQUc3QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyx1QkFBdUJkLGFBQWEsa0NBQWtDLEVBQUU7QUFBQSxjQUNuRixTQUFTLE1BQU07QUFDYixvQkFBSSxDQUFDWCxZQUFZLENBQUNDLFdBQVlTLGNBQWFxQixTQUFTYyxNQUFNO0FBQUEsY0FDNUQ7QUFBQSxjQUNBLFlBQVliO0FBQUFBLGNBQ1osYUFBYUc7QUFBQUEsY0FDYixRQUFRQztBQUFBQSxjQUNSLE9BQU9wQyxZQUFZQyxhQUFhLHFCQUFxQjtBQUFBLGNBQ3JELE9BQU87QUFBQSxnQkFDTGlELGVBQWVsRCxZQUFZQyxhQUFhLFNBQVM7QUFBQSxnQkFDakRrRCxTQUFTbkQsWUFBWUMsYUFBYSxPQUFPO0FBQUEsY0FDM0M7QUFBQSxjQUVBO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSx1QkFBc0IsVUFBVUQsWUFBWUMsWUFDMUU7QUFBQSwyQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FDckk7QUFBQSw2Q0FBQyxVQUFLLEdBQUUsdUZBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMkY7QUFBQSxzQkFDM0YsdUJBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSx5QkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLFVBQU1KLGNBQUlnQixRQUFRLGtCQUFrQixpQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUQ7QUFBQSx1QkFMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWmhCLGNBQUl1RCxZQUNILHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsT0FBT3ZELElBQUl1RCxVQUFVZCxNQUFLO0FBQUE7QUFBQSxvQkFDcER6QyxJQUFJdUQsVUFBVWQ7QUFBQUEsb0JBQ2xCLHVCQUFDLFVBQUssV0FBVSxpQkFDYjtBQUFBO0FBQUEsc0JBQUk7QUFBQSx1QkFBR3pDLElBQUl1RCxVQUFVN0IsUUFBUSxPQUFPLE9BQU84QixRQUFRLENBQUM7QUFBQSxzQkFBRTtBQUFBLHlCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQSxJQUNFeEQsSUFBSWdCLFFBQ04sdUJBQUMsVUFBSyxXQUFVLG1CQUFpQjtBQUFBO0FBQUEsb0JBQ2hCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0Isa0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtEO0FBQUEsdUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsaUJBQWUseURBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLHFCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBCQTtBQUFBLGlCQUVFaEIsSUFBSXVELGFBQWF2RCxJQUFJZ0IsVUFDckI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBQ04sVUFBVWIsWUFBWUM7QUFBQUEsb0JBQ3RCLFNBQVMsQ0FBQ3lCLE1BQU07QUFDZEEsd0JBQUVRLGdCQUFnQjtBQUNsQiwwQkFBSSxDQUFDbEMsWUFBWSxDQUFDQyxXQUFZNkIsbUJBQWtCO0FBQUEsb0JBQ2xEO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQTtBQUFBO0FBQUE7QUFBQSxZQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF3REE7QUFBQSxhQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0VBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWlCLFNBQVMsU0FBU0MsY0FBYyxPQUFPQyxVQUFVLE9BQU8sR0FBRyxnQ0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUg7QUFBQSxVQUNySDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFSyxRQUFRLFFBQVFDLFFBQVEsV0FBVztBQUFBLGNBQzVDLGFBQVk7QUFBQSxjQUNaLE9BQU8xRCxJQUFJK0MsU0FBUztBQUFBLGNBQ3BCLFVBQVU1QyxZQUFZQztBQUFBQSxjQUN0QixVQUFVLENBQUN5QixNQUFNeEIsU0FBUyxTQUFTd0IsRUFBRUMsT0FBT0UsS0FBSztBQUFBO0FBQUEsWUFObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXFEO0FBQUEsYUFSdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0ExS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJLQTtBQUFBO0FBQUEsSUFHRDlCLFNBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUV5RCxXQUFXLE9BQU8sR0FDOUIsaUNBQUMsZUFBWSxNQUFLLFNBQVN6RCxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSx3QkFBdUIsT0FBTyxFQUFFeUQsV0FBVyxRQUFRVCxTQUFTLFFBQVFVLGdCQUFnQixpQkFBaUJDLFlBQVksU0FBUyxHQUN0SWpEO0FBQUFBLGdCQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixPQUFPLEVBQUVrRCxTQUFTLFlBQVlWLFVBQVUsUUFBUVcsTUFBTSxRQUFRYixTQUFTLGVBQWVXLFlBQVksVUFBVUcsS0FBSyxNQUFNO0FBQUEsVUFDdkgsU0FBU3hEO0FBQUFBLFVBQ1QsVUFBVUwsWUFBWUM7QUFBQUEsVUFFckJBO0FBQUFBLDBCQUFjLHVCQUFDLFVBQUssV0FBVSxXQUFVLGVBQVksVUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM1RCx1QkFBQyxVQUFNQSx1QkFBYSxhQUFhLG1CQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBO0FBQUE7QUFBQSxRQVJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLE1BR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUU4QyxTQUFTLFFBQVFjLEtBQUssT0FBT0MsWUFBWSxPQUFPLEdBQzNEdEQsbUJBQ0MsbUNBQ0U7QUFBQSwrQkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHdCQUF1QixTQUFTTCxTQUFRLG1CQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsdUJBQXNCLFNBQVNHLGdCQUFlLHFCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxJQUVBLG1DQUNFO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVNIO0FBQUFBLFlBQ1QsVUFBVUgsWUFBWUM7QUFBQUEsWUFBVztBQUFBO0FBQUEsVUFKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTRztBQUFBQSxZQUNULFVBQVVKLFlBQVlDO0FBQUFBLFlBQ3RCLE9BQU8sRUFBRThDLFNBQVMsZUFBZVcsWUFBWSxVQUFVRCxnQkFBZ0IsVUFBVUksS0FBSyxPQUFPRSxVQUFVLFFBQVE7QUFBQSxZQUU5Ry9EO0FBQUFBLDBCQUFZLHVCQUFDLFVBQUssV0FBVSxXQUFVLGVBQVksVUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxjQUMxRCx1QkFBQyxVQUFNQSxxQkFBVyxpQkFBaUIsWUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQTtBQUFBO0FBQUEsVUFSOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBLEtBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxTQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0NBO0FBQUEsT0E5UEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStQQSxLQWhRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaVFBO0FBRUo7QUFBQ08sR0E5VlFYLFVBQVE7QUFBQSxLQUFSQTtBQWdXVCxlQUFlQTtBQUFTLElBQUFvRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInRvYXN0IiwiQWxlcnRCYW5uZXIiLCJQZXRNb2RhbCIsInBldCIsIm1vZGUiLCJlcnJvciIsImlzU2F2aW5nIiwiaXNEZWxldGluZyIsIm9uQ2hhbmdlIiwib25DbG9zZSIsIm9uU2F2ZSIsIm9uRGVsZXRlIiwib25Td2l0Y2hUb0VkaXQiLCJfcyIsImlzVmlldyIsImlzRWRpdCIsImZpbGVJbnB1dFJlZiIsImlzRHJhZ2dpbmciLCJzZXRJc0RyYWdnaW5nIiwicGhvdG8iLCJzdGFydHNXaXRoIiwiVVJMIiwicmV2b2tlT2JqZWN0VVJMIiwicHJvY2Vzc0ZpbGUiLCJmaWxlIiwidmFsaWRUeXBlcyIsImluY2x1ZGVzIiwidHlwZSIsIk1BWF9GSUxFX1NJWkUiLCJzaXplIiwiY3JlYXRlT2JqZWN0VVJMIiwiaGFuZGxlRmlsZUNoYW5nZSIsImUiLCJ0YXJnZXQiLCJmaWxlcyIsInZhbHVlIiwiaGFuZGxlUmVtb3ZlUGhvdG8iLCJjdXJyZW50IiwiaGFuZGxlRHJhZ092ZXIiLCJwcmV2ZW50RGVmYXVsdCIsInN0b3BQcm9wYWdhdGlvbiIsImhhbmRsZURyYWdMZWF2ZSIsImhhbmRsZURyb3AiLCJkYXRhVHJhbnNmZXIiLCJuYW1lIiwic3BlY2llcyIsImJyZWVkIiwiZ2VuZGVyIiwiYWdlIiwid2VpZ2h0Iiwibm90ZXMiLCJjbGljayIsInNyYyIsImRpc3BsYXkiLCJtYXJnaW5Cb3R0b20iLCJmb250U2l6ZSIsInBvaW50ZXJFdmVudHMiLCJvcGFjaXR5IiwicGhvdG9GaWxlIiwidG9GaXhlZCIsImhlaWdodCIsInJlc2l6ZSIsIm1hcmdpblRvcCIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsInBhZGRpbmciLCJmbGV4IiwiZ2FwIiwibWFyZ2luTGVmdCIsIm1pbldpZHRoIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGV0TW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwiLi4vdXRpbHMvdG9hc3QuanNcIjtcbmltcG9ydCBBbGVydEJhbm5lciBmcm9tIFwiLi91aS9BbGVydEJhbm5lci5qc3hcIjtcblxuZnVuY3Rpb24gUGV0TW9kYWwoe1xuICBwZXQsXG4gIG1vZGUsIC8vIFwiYWRkXCIsIFwiZWRpdFwiLCBvciBcInZpZXdcIlxuICBlcnJvcixcbiAgaXNTYXZpbmcgPSBmYWxzZSxcbiAgaXNEZWxldGluZyA9IGZhbHNlLFxuICBvbkNoYW5nZSxcbiAgb25DbG9zZSxcbiAgb25TYXZlLFxuICBvbkRlbGV0ZSxcbiAgb25Td2l0Y2hUb0VkaXQsXG59KSB7XG4gIGNvbnN0IGlzVmlldyA9IG1vZGUgPT09IFwidmlld1wiO1xuICBjb25zdCBpc0VkaXQgPSBtb2RlID09PSBcImVkaXRcIjtcbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBbaXNEcmFnZ2luZywgc2V0SXNEcmFnZ2luZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKHBldC5waG90byAmJiBwZXQucGhvdG8uc3RhcnRzV2l0aChcImJsb2I6XCIpKSB7XG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwocGV0LnBob3RvKTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbcGV0LnBob3RvXSk7XG5cbiAgY29uc3QgcHJvY2Vzc0ZpbGUgPSAoZmlsZSkgPT4ge1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdmFsaWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIiwgXCJpbWFnZS93ZWJwXCJdO1xuICAgIGlmICghdmFsaWRUeXBlcy5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XG4gICAgICB0b2FzdChcIuC4geC4o+C4uOC4k+C4suC5gOC4peC4t+C4reC4geC5hOC4n+C4peC5jOC4o+C4ueC4m+C4oOC4suC4niAoSlBHLCBQTkcg4Lir4Lij4Li34LitIFdFQlApXCIsIFwiZXJyb3JcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgTUFYX0ZJTEVfU0laRSA9IDUgKiAxMDI0ICogMTAyNDtcbiAgICBpZiAoZmlsZS5zaXplID4gTUFYX0ZJTEVfU0laRSkge1xuICAgICAgdG9hc3QoXCLguILguJnguLLguJTguYTguJ/guKXguYzguYPguKvguI3guYjguYDguIHguLTguJnguYTguJsg4LiB4Lij4Li44LiT4Liy4Lit4Lix4Lib4LmC4Lir4Lil4LiU4Lij4Li54Lib4Lig4Liy4Lie4LiC4LiZ4Liy4LiU4LmE4Lih4LmI4LmA4LiB4Li04LiZIDVNQlwiLCBcImVycm9yXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChwZXQucGhvdG8gJiYgcGV0LnBob3RvLnN0YXJ0c1dpdGgoXCJibG9iOlwiKSkge1xuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChwZXQucGhvdG8pO1xuICAgIH1cbiAgICBvbkNoYW5nZShcInBob3RvRmlsZVwiLCBmaWxlKTtcbiAgICBvbkNoYW5nZShcInBob3RvXCIsIFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmIChmaWxlKSB7XG4gICAgICBwcm9jZXNzRmlsZShmaWxlKTtcbiAgICB9XG4gICAgaWYgKGUudGFyZ2V0KSB7XG4gICAgICBlLnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZVBob3RvID0gKCkgPT4ge1xuICAgIGlmIChwZXQucGhvdG8gJiYgcGV0LnBob3RvLnN0YXJ0c1dpdGgoXCJibG9iOlwiKSkge1xuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChwZXQucGhvdG8pO1xuICAgIH1cbiAgICBvbkNoYW5nZShcInBob3RvRmlsZVwiLCBudWxsKTtcbiAgICBvbkNoYW5nZShcInBob3RvXCIsIFwiXCIpO1xuICAgIGlmIChmaWxlSW5wdXRSZWYuY3VycmVudCkge1xuICAgICAgZmlsZUlucHV0UmVmLmN1cnJlbnQudmFsdWUgPSBcIlwiO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcmFnT3ZlciA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgc2V0SXNEcmFnZ2luZyh0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcmFnTGVhdmUgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIHNldElzRHJhZ2dpbmcoZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURyb3AgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIHNldElzRHJhZ2dpbmcoZmFsc2UpO1xuICAgIGNvbnN0IGZpbGUgPSBlLmRhdGFUcmFuc2Zlci5maWxlcz8uWzBdO1xuICAgIGlmIChmaWxlKSB7XG4gICAgICBwcm9jZXNzRmlsZShmaWxlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbC1vdmVybGF5XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbCBwZXQtbW9kYWwtY29udGFpbmVyXCI+XG4gICAgICAgIDxoMj5cbiAgICAgICAgICB7aXNWaWV3XG4gICAgICAgICAgICA/IGDguILguYnguK3guKHguLnguKXguILguK3guIcgJHtwZXQubmFtZSB8fCBcIuC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h1wifWBcbiAgICAgICAgICAgIDogaXNFZGl0XG4gICAgICAgICAgICA/IFwi4LmB4LiB4LmJ4LmE4LiC4LiC4LmJ4Lit4Lih4Li54Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJcbiAgICAgICAgICAgIDogXCLguYDguJ7guLTguYjguKHguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguYPguKvguKHguYhcIn1cbiAgICAgICAgPC9oMj5cblxuICAgICAgICB7aXNWaWV3ID8gKFxuICAgICAgICAgIC8qIOC5guC4q+C4oeC4lOC4lOC4ueC4guC5ieC4reC4oeC4ueC4pSAoVmlldykgKi9cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBldC1tb2RhbC12aWV3LWNvbnRhaW5lclwiPlxuICAgICAgICAgICAge3BldC5waG90byAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGV0LW1vZGFsLXByZXZpZXctd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtwZXQucGhvdG99IGFsdD17cGV0Lm5hbWV9IGNsYXNzTmFtZT1cInBldC1tb2RhbC1wcmV2aWV3LWltZ1wiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXY+PGI+4LiK4Li34LmI4LitOjwvYj4ge3BldC5uYW1lIHx8IFwiLVwifTwvZGl2PlxuICAgICAgICAgICAgPGRpdj48Yj7guKrguLLguKLguJ7guLHguJnguJjguLjguYwgKFNwZWNpZXMpOjwvYj4ge3BldC5zcGVjaWVzIHx8IFwiLVwifTwvZGl2PlxuICAgICAgICAgICAgPGRpdj48Yj7guJ7guLHguJnguJjguLjguYwgKEJyZWVkKTo8L2I+IHtwZXQuYnJlZWQgfHwgXCItXCJ9PC9kaXY+XG4gICAgICAgICAgICA8ZGl2PjxiPuC5gOC4nuC4qCAoR2VuZGVyKTo8L2I+IHtwZXQuZ2VuZGVyIHx8IFwiLVwifTwvZGl2PlxuICAgICAgICAgICAgPGRpdj48Yj7guK3guLLguKLguLg6PC9iPiB7cGV0LmFnZSB8fCBcIi1cIn08L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+PGI+4LiZ4LmJ4Liz4Lir4LiZ4Lix4LiBOjwvYj4ge3BldC53ZWlnaHQgPyBgJHtwZXQud2VpZ2h0fSDguIHguIEuYCA6IFwiLVwifTwvZGl2PlxuICAgICAgICAgICAgPGRpdj48Yj7guKvguKHguLLguKLguYDguKvguJXguLg6PC9iPiB7cGV0Lm5vdGVzIHx8IFwiLVwifTwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIC8qIOC5guC4q+C4oeC4lOC4geC4o+C4reC4geC4guC5ieC4reC4oeC4ueC4pSAoQWRkIC8gRWRpdCkgKi9cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBldC1tb2RhbC1ncmlkXCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGV0LW1vZGFsLWZ1bGwtd2lkdGggcGV0LW1vZGFsLXByZXZpZXctd3JhcHBlclwiPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGV0LW1vZGFsLWF2YXRhci1jbGlja2FibGVcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICAgICAgICAgIHRpdGxlPVwi4LiE4Lil4Li04LiB4LmA4Lie4Li34LmI4Lit4LmA4Lil4Li34Lit4LiB4Lir4Lij4Li34Lit4LmA4Lib4Lil4Li14LmI4Lii4LiZ4Lij4Li54Lib4Lig4Liy4LieXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtwZXQucGhvdG8gPyAoXG4gICAgICAgICAgICAgICAgICA8aW1nIFxuICAgICAgICAgICAgICAgICAgICBzcmM9e3BldC5waG90b30gXG4gICAgICAgICAgICAgICAgICAgIGFsdD1cIlBldCBQcmV2aWV3XCIgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBldC1tb2RhbC1wcmV2aWV3LWltZ1wiXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7IGUudGFyZ2V0LnNyYyA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2NoYXJzZXQ9VVRGLTgsJTNDc3ZnIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Zycgd2lkdGg9JzEwMCcgaGVpZ2h0PScxMDAnIHN0eWxlPSdiYWNrZ3JvdW5kOiUyM2VlZTsnJTNFJTNDdGV4dCB4PSc1MCUyNScgeT0nNTAlMjUnIGZvbnQtc2l6ZT0nNDAnIHRleHQtYW5jaG9yPSdtaWRkbGUnIGR5PScuMzVlbSclM0UlMjYlMjMxMjgwNjIlM0IlM0MvdGV4dCUzRSUzQy9zdmclM0VcIjsgfX0gXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBldC1tb2RhbC1wbGFjZWhvbGRlclwiPvCfkL48L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGV0LW1vZGFsLWF2YXRhci1iYWRnZVwiIHRpdGxlPVwi4Lit4Lix4Lib4LmC4Lir4Lil4LiU4Lij4Li54Lib4Lig4Liy4LieXCI+XG4gICAgICAgICAgICAgICAgICDwn5O3XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCIgc3R5bGU9e3sgZGlzcGxheTogXCJibG9ja1wiLCBtYXJnaW5Cb3R0b206IFwiNHB4XCIsIGZvbnRTaXplOiBcIjEzcHhcIiB9fT7guIrguLfguYjguK3guKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcgKE5hbWUpPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIOC4muC4o+C4suC4p+C4meC4teC5iFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3BldC5uYW1lIHx8IFwiXCJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShcIm5hbWVcIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZmlsZS1sYWJlbFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgbWFyZ2luQm90dG9tOiBcIjRweFwiLCBmb250U2l6ZTogXCIxM3B4XCIgfX0+4Liq4Liy4Lii4Lie4Lix4LiZ4LiY4Li44LmM4Liq4Lix4LiV4Lin4LmMIChTcGVjaWVzKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguKrguLjguJnguLHguIIsIOC5geC4oeC4p1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3BldC5zcGVjaWVzIHx8IFwiXCJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShcInNwZWNpZXNcIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCIgc3R5bGU9e3sgZGlzcGxheTogXCJibG9ja1wiLCBtYXJnaW5Cb3R0b206IFwiNHB4XCIsIGZvbnRTaXplOiBcIjEzcHhcIiB9fT7guJ7guLHguJnguJjguLjguYwgKEJyZWVkKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguYLguIHguKXguYDguJTguYnguJkg4Lij4Li14LiX4Lij4Li14Lif4LmA4Lin4Lit4Lij4LmMXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGV0LmJyZWVkIHx8IFwiXCJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShcImJyZWVkXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInByb2ZpbGUtbGFiZWxcIiBzdHlsZT17eyBkaXNwbGF5OiBcImJsb2NrXCIsIG1hcmdpbkJvdHRvbTogXCI0cHhcIiwgZm9udFNpemU6IFwiMTNweFwiIH19PuC5gOC4nuC4qCAoR2VuZGVyKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguJzguLnguYksIOC5gOC4oeC4teC4olwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3BldC5nZW5kZXIgfHwgXCJcIn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKFwiZ2VuZGVyXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZmlsZS1sYWJlbFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgbWFyZ2luQm90dG9tOiBcIjRweFwiLCBmb250U2l6ZTogXCIxM3B4XCIgfX0+4Lit4Liy4Lii4Li4IChBZ2UpPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIDIg4Lib4Li1XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGV0LmFnZSB8fCBcIlwifVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoXCJhZ2VcIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZmlsZS1sYWJlbFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgbWFyZ2luQm90dG9tOiBcIjRweFwiLCBmb250U2l6ZTogXCIxM3B4XCIgfX0+4LiZ4LmJ4Liz4Lir4LiZ4Lix4LiBIChXZWlnaHQgLSDguIHguIEuKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjFcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIDEyLjVcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtwZXQud2VpZ2h0IHx8IFwiXCJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShcIndlaWdodFwiLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXQtbW9kYWwtZnVsbC13aWR0aFwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZmlsZS1sYWJlbFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgbWFyZ2luQm90dG9tOiBcIjZweFwiLCBmb250U2l6ZTogXCIxM3B4XCIgfX0+XG4gICAgICAgICAgICAgICAg4Lij4Li54Lib4Lig4Liy4Lie4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHIChQaG90bylcbiAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvanBlZywgaW1hZ2UvcG5nLCBpbWFnZS9qcGcsIGltYWdlL3dlYnBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6IFwibm9uZVwiIH19XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwZXQtZmlsZS11cGxvYWQtYm94ICR7aXNEcmFnZ2luZyA/IFwicGV0LWZpbGUtdXBsb2FkLWJveC0tZHJhZ292ZXJcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoIWlzU2F2aW5nICYmICFpc0RlbGV0aW5nKSBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIG9uRHJhZ092ZXI9e2hhbmRsZURyYWdPdmVyfVxuICAgICAgICAgICAgICAgIG9uRHJhZ0xlYXZlPXtoYW5kbGVEcmFnTGVhdmV9XG4gICAgICAgICAgICAgICAgb25Ecm9wPXtoYW5kbGVEcm9wfVxuICAgICAgICAgICAgICAgIHRpdGxlPXtpc1NhdmluZyB8fCBpc0RlbGV0aW5nID8gXCLguIHguLPguKXguLHguIfguJvguKPguLDguKHguKfguKXguJzguKUuLi5cIiA6IFwi4LiE4Lil4Li04LiB4Lir4Lij4Li34Lit4Lil4Liy4LiB4LmE4Lif4Lil4LmM4Lij4Li54Lib4Lig4Liy4Lie4Lih4Liy4Lin4Liy4LiH4LiX4Li14LmI4LiZ4Li14LmIXCJ9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6IGlzU2F2aW5nIHx8IGlzRGVsZXRpbmcgPyBcIm5vbmVcIiA6IFwiYXV0b1wiLFxuICAgICAgICAgICAgICAgICAgb3BhY2l0eTogaXNTYXZpbmcgfHwgaXNEZWxldGluZyA/IDAuNjUgOiAxLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBldC1maWxlLXVwbG9hZC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwZXQtZmlsZS1jaG9vc2UtYnRuXCIgZGlzYWJsZWQ9e2lzU2F2aW5nIHx8IGlzRGVsZXRpbmd9PlxuICAgICAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMTVcIiBoZWlnaHQ9XCIxNVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIzIDE5YTIgMiAwIDAgMS0yIDJIM2EyIDIgMCAwIDEtMi0yVjhhMiAyIDAgMCAxIDItMmg0bDItM2g2bDIgM2g0YTIgMiAwIDAgMSAyIDJ6XCIvPlxuICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTNcIiByPVwiNFwiLz5cbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntwZXQucGhvdG8gPyBcIuC5gOC4m+C4peC4teC5iOC4ouC4meC4o+C4ueC4m+C4oOC4suC4nlwiIDogXCLguYDguKXguLfguK3guIHguKPguLnguJvguKDguLLguJ5cIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGV0LWZpbGUtaW5mb1wiPlxuICAgICAgICAgICAgICAgICAgICB7cGV0LnBob3RvRmlsZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwZXQtZmlsZS1uYW1lXCIgdGl0bGU9e3BldC5waG90b0ZpbGUubmFtZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICDwn5OOIHtwZXQucGhvdG9GaWxlLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwZXQtZmlsZS1zaXplXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn0oeyhwZXQucGhvdG9GaWxlLnNpemUgLyAoMTAyNCAqIDEwMjQpKS50b0ZpeGVkKDIpfSBNQilcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkgOiBwZXQucGhvdG8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGV0LWZpbGUtc3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDinJMg4Lih4Li14Lij4Li54Lib4Lig4Liy4Lie4LmB4Lil4LmJ4LinIDxzcGFuIGNsYXNzTmFtZT1cInBldC1maWxlLWhpbnRcIj4o4LiE4Lil4Li04LiB4LmA4Lie4Li34LmI4Lit4LmA4Lib4Lil4Li14LmI4Lii4LiZKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGV0LWZpbGUtaGludFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAg4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4LmA4Lil4Li34Lit4LiB4LmE4Lif4Lil4LmMIChKUEcsIFBORyDguYTguKHguYjguYDguIHguLTguJkgNU1CKVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgeyhwZXQucGhvdG9GaWxlIHx8IHBldC5waG90bykgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGV0LWZpbGUtcmVtb3ZlLWJ0blwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwi4Lil4Lia4Lij4Li54Lib4Lig4Liy4Lie4LiZ4Li14LmJXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nIHx8IGlzRGVsZXRpbmd9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzU2F2aW5nICYmICFpc0RlbGV0aW5nKSBoYW5kbGVSZW1vdmVQaG90bygpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGV0LW1vZGFsLWZ1bGwtd2lkdGhcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInByb2ZpbGUtbGFiZWxcIiBzdHlsZT17eyBkaXNwbGF5OiBcImJsb2NrXCIsIG1hcmdpbkJvdHRvbTogXCI0cHhcIiwgZm9udFNpemU6IFwiMTNweFwiIH19PuC4q+C4oeC4suC4ouC5gOC4q+C4leC4uCAoTm90ZXMpPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHRleHRhcmVhIFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtaW5wdXRcIiBcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNjBweFwiLCByZXNpemU6IFwidmVydGljYWxcIiB9fSBcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguYHguJ7guYnguK3guLLguKvguLLguKNcIiBcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGV0Lm5vdGVzIHx8IFwiXCJ9IFxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZyB8fCBpc0RlbGV0aW5nfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoXCJub3Rlc1wiLCBlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogXCIxNHB4XCIgfX0+XG4gICAgICAgICAgICA8QWxlcnRCYW5uZXIgdHlwZT1cImVycm9yXCI+e2Vycm9yfTwvQWxlcnRCYW5uZXI+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtYWN0aW9uc1wiIHN0eWxlPXt7IG1hcmdpblRvcDogXCIyNHB4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XG4gICAgICAgICAge2lzRWRpdCAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWRlbGV0ZS1idXR0b25cIlxuICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjhweCAxNHB4XCIsIGZvbnRTaXplOiBcIjEzcHhcIiwgZmxleDogXCJub25lXCIsIGRpc3BsYXk6IFwiaW5saW5lLWZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiBcIjZweFwiIH19XG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uRGVsZXRlfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmcgfHwgaXNEZWxldGluZ31cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2lzRGVsZXRpbmcgJiYgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvc3Bhbj59XG4gICAgICAgICAgICAgIDxzcGFuPntpc0RlbGV0aW5nID8gXCLguIHguLPguKXguLHguIfguKXguJrigKZcIiA6IFwi4Lil4Lia4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJ9PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogXCI4cHhcIiwgbWFyZ2luTGVmdDogXCJhdXRvXCIgfX0+XG4gICAgICAgICAgICB7aXNWaWV3ID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImRlbGV0ZS1jYW5jZWwtYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICAgICAgICDguJvguLTguJRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwcm9maWxlLXNhdmUtYnV0dG9uXCIgb25DbGljaz17b25Td2l0Y2hUb0VkaXR9PlxuICAgICAgICAgICAgICAgICAg4LmB4LiB4LmJ4LmE4LiCXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLWNhbmNlbC1idXR0b25cIiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmcgfHwgaXNEZWxldGluZ31cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDguKLguIHguYDguKXguLTguIFcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHJvZmlsZS1zYXZlLWJ1dHRvblwiIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17b25TYXZlfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nIHx8IGlzRGVsZXRpbmd9XG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiBcImlubGluZS1mbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLCBnYXA6IFwiOHB4XCIsIG1pbldpZHRoOiBcIjExMHB4XCIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNTYXZpbmcgJiYgPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57aXNTYXZpbmcgPyBcIuC4geC4s+C4peC4seC4h+C4muC4seC4meC4l+C4tuC4geKAplwiIDogXCLguJrguLHguJnguJfguLbguIFcIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgUGV0TW9kYWw7Il0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUGV0TW9kYWwuanN4In0=