import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Pagination.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const SIBLINGS = 1;
export function getPageItems(page, totalPages) {
  const wanted = /* @__PURE__ */ new Set([1, totalPages, page]);
  for (let d = 1; d <= SIBLINGS; d++) {
    wanted.add(page - d);
    wanted.add(page + d);
  }
  const pages = [...wanted].filter((p) => p >= 1 && p <= totalPages).sort((a, b) => a - b);
  const items = [];
  pages.forEach((p, i) => {
    const prev = pages[i - 1];
    if (prev !== void 0 && p - prev === 2) items.push(prev + 1);
    else if (prev !== void 0 && p - prev > 2) items.push(null);
    items.push(p);
  });
  return items;
}
export default function Pagination({ page, totalPages, disabled, onChange }) {
  if (totalPages <= 1) return null;
  const go = (p) => !disabled && p >= 1 && p <= totalPages && p !== page && onChange(p);
  return /* @__PURE__ */ jsxDEV("nav", { className: "pagination", "aria-label": "เปลี่ยนหน้า", children: [
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "page-btn", disabled: disabled || page <= 1, onClick: () => go(page - 1), children: "‹ ก่อนหน้า" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    getPageItems(page, totalPages).map(
      (p, i) => p === null ? /* @__PURE__ */ jsxDEV("span", { className: "page-gap", "aria-hidden": "true", children: "…" }, `gap-${i}`, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx",
        lineNumber: 52,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          disabled,
          className: `page-btn${p === page ? " active" : ""}`,
          "aria-label": `หน้า ${p}`,
          "aria-current": p === page ? "page" : void 0,
          onClick: () => go(p),
          children: p
        },
        p,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx",
          lineNumber: 54,
          columnNumber: 7
        },
        this
      )
    ),
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "page-btn", disabled: disabled || page >= totalPages, onClick: () => go(page + 1), children: "ถัดไป ›" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Pagination.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJOLE1BQU1BLFdBQVc7QUFHVixnQkFBU0MsYUFBYUMsTUFBTUMsWUFBWTtBQUM3QyxRQUFNQyxTQUFTLG9CQUFJQyxJQUFJLENBQUMsR0FBR0YsWUFBWUQsSUFBSSxDQUFDO0FBQzVDLFdBQVNJLElBQUksR0FBR0EsS0FBS04sVUFBVU0sS0FBSztBQUNsQ0YsV0FBT0csSUFBSUwsT0FBT0ksQ0FBQztBQUNuQkYsV0FBT0csSUFBSUwsT0FBT0ksQ0FBQztBQUFBLEVBQ3JCO0FBQ0EsUUFBTUUsUUFBUSxDQUFDLEdBQUdKLE1BQU0sRUFBRUssT0FBTyxDQUFDQyxNQUFNQSxLQUFLLEtBQUtBLEtBQUtQLFVBQVUsRUFBRVEsS0FBSyxDQUFDQyxHQUFHQyxNQUFNRCxJQUFJQyxDQUFDO0FBQ3ZGLFFBQU1DLFFBQVE7QUFDZE4sUUFBTU8sUUFBUSxDQUFDTCxHQUFHTSxNQUFNO0FBQ3RCLFVBQU1DLE9BQU9ULE1BQU1RLElBQUksQ0FBQztBQUN4QixRQUFJQyxTQUFTQyxVQUFhUixJQUFJTyxTQUFTLEVBQUdILE9BQU1LLEtBQUtGLE9BQU8sQ0FBQztBQUFBLGFBQ3BEQSxTQUFTQyxVQUFhUixJQUFJTyxPQUFPLEVBQUdILE9BQU1LLEtBQUssSUFBSTtBQUM1REwsVUFBTUssS0FBS1QsQ0FBQztBQUFBLEVBQ2QsQ0FBQztBQUNELFNBQU9JO0FBQ1Q7QUFFQSx3QkFBd0JNLFdBQVcsRUFBRWxCLE1BQU1DLFlBQVlrQixVQUFVQyxTQUFTLEdBQUc7QUFDM0UsTUFBSW5CLGNBQWMsRUFBRyxRQUFPO0FBQzVCLFFBQU1vQixLQUFLQSxDQUFDYixNQUFNLENBQUNXLFlBQVlYLEtBQUssS0FBS0EsS0FBS1AsY0FBY08sTUFBTVIsUUFBUW9CLFNBQVNaLENBQUM7QUFFcEYsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxjQUFXLGVBQ3JDO0FBQUEsMkJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxZQUFXLFVBQVVXLFlBQVluQixRQUFRLEdBQUcsU0FBUyxNQUFNcUIsR0FBR3JCLE9BQU8sQ0FBQyxHQUFFLDBCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDRCxhQUFhQyxNQUFNQyxVQUFVLEVBQUVxQjtBQUFBQSxNQUFJLENBQUNkLEdBQUdNLE1BQ3RDTixNQUFNLE9BQ0osdUJBQUMsVUFBc0IsV0FBVSxZQUFXLGVBQVksUUFBTyxpQkFBcEQsT0FBT00sQ0FBQyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFLElBRWhFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDUyxNQUFLO0FBQUEsVUFBUztBQUFBLFVBQ3RCLFdBQVcsV0FBV04sTUFBTVIsT0FBTyxZQUFZLEVBQUU7QUFBQSxVQUNqRCxjQUFZLFFBQVFRLENBQUM7QUFBQSxVQUFJLGdCQUFjQSxNQUFNUixPQUFPLFNBQVNnQjtBQUFBQSxVQUM3RCxTQUFTLE1BQU1LLEdBQUdiLENBQUM7QUFBQSxVQUVsQkE7QUFBQUE7QUFBQUEsUUFMSUE7QUFBQUEsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxJQUVKO0FBQUEsSUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLFlBQVcsVUFBVVcsWUFBWW5CLFFBQVFDLFlBQVksU0FBUyxNQUFNb0IsR0FBR3JCLE9BQU8sQ0FBQyxHQUFFLHVCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ3VCLEtBNUJ1Qkw7QUFBVSxJQUFBSztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTSUJMSU5HUyIsImdldFBhZ2VJdGVtcyIsInBhZ2UiLCJ0b3RhbFBhZ2VzIiwid2FudGVkIiwiU2V0IiwiZCIsImFkZCIsInBhZ2VzIiwiZmlsdGVyIiwicCIsInNvcnQiLCJhIiwiYiIsIml0ZW1zIiwiZm9yRWFjaCIsImkiLCJwcmV2IiwidW5kZWZpbmVkIiwicHVzaCIsIlBhZ2luYXRpb24iLCJkaXNhYmxlZCIsIm9uQ2hhbmdlIiwiZ28iLCJtYXAiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYWdpbmF0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyDguJvguLjguYjguKHguYDguJvguKXguLXguYjguKLguJnguKvguJnguYnguLI6IMKrIOC4geC5iOC4reC4meC4q+C4meC5ieC4siAxIOKApiA0IFs1XSA2IOKApiAyMCDguJbguLHguJTguYTguJsgwrtcbmNvbnN0IFNJQkxJTkdTID0gMTtcblxuLy8g4Lij4Liy4Lii4LiB4Liy4Lij4LmA4Lil4LiC4Lir4LiZ4LmJ4Liy4LiX4Li14LmI4LiI4Liw4LmB4Liq4LiU4LiHIChudWxsID0g4LiI4Li44LiU4LmE4LiC4LmI4Lib4Lil4LiyKSDguYDguIrguYjguJkgWzEsIG51bGwsIDQsIDUsIDYsIG51bGwsIDIwXVxuZXhwb3J0IGZ1bmN0aW9uIGdldFBhZ2VJdGVtcyhwYWdlLCB0b3RhbFBhZ2VzKSB7XG4gIGNvbnN0IHdhbnRlZCA9IG5ldyBTZXQoWzEsIHRvdGFsUGFnZXMsIHBhZ2VdKTtcbiAgZm9yIChsZXQgZCA9IDE7IGQgPD0gU0lCTElOR1M7IGQrKykge1xuICAgIHdhbnRlZC5hZGQocGFnZSAtIGQpO1xuICAgIHdhbnRlZC5hZGQocGFnZSArIGQpO1xuICB9XG4gIGNvbnN0IHBhZ2VzID0gWy4uLndhbnRlZF0uZmlsdGVyKChwKSA9PiBwID49IDEgJiYgcCA8PSB0b3RhbFBhZ2VzKS5zb3J0KChhLCBiKSA9PiBhIC0gYik7XG4gIGNvbnN0IGl0ZW1zID0gW107XG4gIHBhZ2VzLmZvckVhY2goKHAsIGkpID0+IHtcbiAgICBjb25zdCBwcmV2ID0gcGFnZXNbaSAtIDFdO1xuICAgIGlmIChwcmV2ICE9PSB1bmRlZmluZWQgJiYgcCAtIHByZXYgPT09IDIpIGl0ZW1zLnB1c2gocHJldiArIDEpOyAvLyDguYDguKfguYnguJnguYHguITguYjguKvguJnguYnguLLguYDguJTguLXguKLguKcg4LmB4Liq4LiU4LiH4LmA4Lil4LiC4LmB4LiX4LiZIOKAplxuICAgIGVsc2UgaWYgKHByZXYgIT09IHVuZGVmaW5lZCAmJiBwIC0gcHJldiA+IDIpIGl0ZW1zLnB1c2gobnVsbCk7XG4gICAgaXRlbXMucHVzaChwKTtcbiAgfSk7XG4gIHJldHVybiBpdGVtcztcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnaW5hdGlvbih7IHBhZ2UsIHRvdGFsUGFnZXMsIGRpc2FibGVkLCBvbkNoYW5nZSB9KSB7XG4gIGlmICh0b3RhbFBhZ2VzIDw9IDEpIHJldHVybiBudWxsO1xuICBjb25zdCBnbyA9IChwKSA9PiAhZGlzYWJsZWQgJiYgcCA+PSAxICYmIHAgPD0gdG90YWxQYWdlcyAmJiBwICE9PSBwYWdlICYmIG9uQ2hhbmdlKHApO1xuXG4gIHJldHVybiAoXG4gICAgPG5hdiBjbGFzc05hbWU9XCJwYWdpbmF0aW9uXCIgYXJpYS1sYWJlbD1cIuC5gOC4m+C4peC4teC5iOC4ouC4meC4q+C4meC5ieC4slwiPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicGFnZS1idG5cIiBkaXNhYmxlZD17ZGlzYWJsZWQgfHwgcGFnZSA8PSAxfSBvbkNsaWNrPXsoKSA9PiBnbyhwYWdlIC0gMSl9PlxuICAgICAgICDigLkg4LiB4LmI4Lit4LiZ4Lir4LiZ4LmJ4LiyXG4gICAgICA8L2J1dHRvbj5cbiAgICAgIHtnZXRQYWdlSXRlbXMocGFnZSwgdG90YWxQYWdlcykubWFwKChwLCBpKSA9PlxuICAgICAgICBwID09PSBudWxsID8gKFxuICAgICAgICAgIDxzcGFuIGtleT17YGdhcC0ke2l9YH0gY2xhc3NOYW1lPVwicGFnZS1nYXBcIiBhcmlhLWhpZGRlbj1cInRydWVcIj7igKY8L3NwYW4+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtwfSB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGFnZS1idG4ke3AgPT09IHBhZ2UgPyBcIiBhY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2DguKvguJnguYnguLIgJHtwfWB9IGFyaWEtY3VycmVudD17cCA9PT0gcGFnZSA/IFwicGFnZVwiIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZ28ocCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3B9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIClcbiAgICAgICl9XG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwYWdlLWJ0blwiIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBwYWdlID49IHRvdGFsUGFnZXN9IG9uQ2xpY2s9eygpID0+IGdvKHBhZ2UgKyAxKX0+XG4gICAgICAgIOC4luC4seC4lOC5hOC4myDigLpcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvbmF2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUGFnaW5hdGlvbi5qc3gifQ==