import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceFormFooter.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceFormFooter({
  onClose,
  isEditMode,
  showIncompleteWarning
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-slate-100 gap-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-[1.25rem] flex items-center", children: showIncompleteWarning && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-red-600 animate-pulse flex items-center gap-1", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          className: "w-3.5 h-3.5 text-red-500 inline shrink-0",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 2,
              d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
              lineNumber: 52,
              columnNumber: 15
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
          lineNumber: 46,
          columnNumber: 13
        },
        this
      ),
      "กรุณาใส่ข้อมูลให้ครบ"
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
      lineNumber: 45,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer",
          children: "ยกเลิก"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
          lineNumber: 66,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "px-5 py-2 text-xs font-bold text-white bg-[#F97316] hover:bg-[#EA580C] rounded-xl shadow-xs transition-colors cursor-pointer",
          children: isEditMode ? "บันทึกการแก้ไข" : "เผยแพร่บริการ"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
      lineNumber: 65,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_c = ServiceFormFooter;
var _c;
$RefreshReg$(_c, "ServiceFormFooter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormFooter.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NjOzs7Ozs7Ozs7Ozs7Ozs7O0FBaENkLE9BQU9BLFdBQVc7QUFlbEIsd0JBQXdCQyxrQkFBa0I7QUFBQSxFQUN4Q0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMEVBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUNBQ1pBLG1DQUNDLHVCQUFDLFVBQUssV0FBVSx3RUFDZDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixNQUFLO0FBQUEsVUFDTCxTQUFRO0FBQUEsVUFDUixRQUFPO0FBQUEsVUFFUDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsZUFBYztBQUFBLGNBQ2QsZ0JBQWU7QUFBQSxjQUNmLGFBQWE7QUFBQSxjQUNiLEdBQUU7QUFBQTtBQUFBLFlBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVEO0FBQUE7QUFBQSxRQVZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLE1BQUs7QUFBQSxTQWJQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQSxLQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0Y7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFBNkk7QUFBQTtBQUFBLFFBSHpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBRVRDLHVCQUFhLG1CQUFtQjtBQUFBO0FBQUEsUUFKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLE9BdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1Q0E7QUFFSjtBQUFDRSxLQS9DdUJKO0FBQWlCLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2VydmljZUZvcm1Gb290ZXIiLCJvbkNsb3NlIiwiaXNFZGl0TW9kZSIsInNob3dJbmNvbXBsZXRlV2FybmluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VGb3JtRm9vdGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogU2VydmljZUZvcm1Gb290ZXIgQ29tcG9uZW50XG4gKiBcbiAqIEJvdHRvbSBhY3Rpb24gYmFyIGZvciBTZXJ2aWNlRm9ybU1vZGFsOlxuICogLSBEaXNwbGF5cyBpbmNvbXBsZXRlIHdhcm5pbmcgbWVzc2FnZSBvbiBib3R0b20tbGVmdCB3aXRoIHB1bHNlIGljb25cbiAqIC0gQ2FuY2VsIGJ1dHRvblxuICogLSBTdWJtaXQvU2F2ZSBidXR0b24gKFwi4Lia4Lix4LiZ4LiX4Li24LiB4LiB4Liy4Lij4LmB4LiB4LmJ4LmE4LiCXCIgLyBcIuC5gOC4nOC4ouC5geC4nuC4o+C5iOC4muC4o+C4tOC4geC4suC4o1wiKVxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2xvc2UgLSBNb2RhbCBjbG9zZSBoYW5kbGVyLlxuICogQHBhcmFtIHtib29sZWFufSBwcm9wcy5pc0VkaXRNb2RlIC0gV2hldGhlciBtb2RhbCBpcyBpbiBlZGl0IG1vZGUuXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHByb3BzLnNob3dJbmNvbXBsZXRlV2FybmluZyAtIFdoZXRoZXIgdG8gc2hvdyB0aGUgaW5jb21wbGV0ZSB3YXJuaW5nLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlRm9ybUZvb3Rlcih7XG4gIG9uQ2xvc2UsXG4gIGlzRWRpdE1vZGUsXG4gIHNob3dJbmNvbXBsZXRlV2FybmluZyxcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZ2FwLTNcIj5cbiAgICAgIHsvKiBCb3R0b20gTGVmdCBJbmNvbXBsZXRlIE5vdGljZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtWzEuMjVyZW1dIGZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgIHtzaG93SW5jb21wbGV0ZVdhcm5pbmcgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcmVkLTYwMCBhbmltYXRlLXB1bHNlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcmVkLTUwMCBpbmxpbmUgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XG4gICAgICAgICAgICAgICAgZD1cIk0xMiA4djRtMCA0aC4wMU0yMSAxMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICDguIHguKPguLjguJPguLLguYPguKrguYjguILguYnguK3guKHguLnguKXguYPguKvguYnguITguKPguJpcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIOC4ouC4geC5gOC4peC4tOC4gVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLVsjRjk3MzE2XSBob3ZlcjpiZy1bI0VBNTgwQ10gcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAge2lzRWRpdE1vZGUgPyBcIuC4muC4seC4meC4l+C4tuC4geC4geC4suC4o+C5geC4geC5ieC5hOC4glwiIDogXCLguYDguJzguKLguYHguJ7guKPguYjguJrguKPguLTguIHguLLguKNcIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3NpdHRlci9zZXJ2aWNlRm9ybS9TZXJ2aWNlRm9ybUZvb3Rlci5qc3gifQ==