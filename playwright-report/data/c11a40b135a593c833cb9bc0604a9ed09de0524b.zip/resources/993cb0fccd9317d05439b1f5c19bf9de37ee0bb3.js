import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/payment/PaymentModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { uploadPaymentSlip } from "/src/services/payment.api.js";
import { toast } from "/src/utils/toast.js";
import { validateSlipFile } from "/src/utils/paymentValidation.js";
import PaymentSummary from "/src/components/payment/PaymentSummary.jsx";
import SlipUploadZone from "/src/components/payment/SlipUploadZone.jsx";
export default function PaymentModal({
  isOpen,
  onClose,
  booking,
  summary,
  isLoading = false,
  isError = false,
  onRetry,
  onSuccess
}) {
  _s();
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadValidationError, setUploadValidationError] = useState("");
  const bookingId = booking?.bookingId || booking?.id;
  const hasPendingPayment = Boolean(summary?.payments?.some(
    (payment) => payment.payment_status === "pending_verifying"
  ));
  const hasSitterPaymentInfo = Boolean(
    summary?.sitterPaymentInfo?.accountName && summary?.sitterPaymentInfo?.qrCodeUrl
  );
  useEffect(() => {
    if (!previewUrl) return void 0;
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);
  const clearSelectedFile = () => {
    setSelectedFile(null);
    setPreviewUrl("");
    setUploadValidationError("");
  };
  const handleFileSelect = (file) => {
    const validation = validateSlipFile(file);
    if (!validation.isValid) {
      clearSelectedFile();
      setUploadValidationError(validation.errorMsg);
      return;
    }
    setUploadValidationError("");
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };
  const handleClose = () => {
    if (isUploading) return;
    clearSelectedFile();
    onClose();
  };
  const handleUpload = async (event) => {
    event.preventDefault();
    if (!selectedFile || !summary || !bookingId || isLoading || hasPendingPayment || !hasSitterPaymentInfo) return;
    const paymentStage = summary.payment_stage || (summary.bookingstatus === "waiting_final_payment" ? "final" : summary.paymentplan === "deposit" ? "deposit" : "full");
    const amount = paymentStage === "final" ? Number(summary.remainingAmount) : paymentStage === "deposit" ? Number(summary.depositAmount) : Number(summary.totalPrice);
    if (!Number.isFinite(amount) || amount <= 0) {
      setUploadValidationError("ไม่พบยอดชำระเงินที่ถูกต้อง กรุณาลองโหลดข้อมูลใหม่");
      return;
    }
    setUploadValidationError("");
    const formData = new FormData();
    formData.append("bookingId", String(bookingId));
    formData.append("amount", String(amount));
    formData.append("payment_stage", paymentStage);
    formData.append("paymentType", "bank_transfer");
    formData.append("slip_image", selectedFile);
    setIsUploading(true);
    let responseData = null;
    try {
      responseData = await uploadPaymentSlip(formData);
    } catch (error) {
      setUploadValidationError(
        error.response?.data?.message || "ไม่สามารถอัปโหลดสลิปได้ กรุณาตรวจสอบสลิปอีกครั้ง"
      );
      return;
    } finally {
      setIsUploading(false);
    }
    clearSelectedFile();
    onClose();
    const paymentStatus = responseData?.data?.payment_status || responseData?.payment_status;
    if (paymentStatus === "verified") {
      toast("ตรวจสอบสลิปผ่านอัตโนมัติ ยืนยันการชำระเงินเรียบร้อยแล้ว", "success");
    } else {
      toast("แนบสลิปการโอนเงินสำเร็จ รอพี่เลี้ยงตรวจสอบ", "success");
    }
    onSuccess?.();
  };
  if (!isOpen || !booking) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-overlay", onClick: handleClose, children: /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "delete-modal payment-modal",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "payment-modal-title",
      onClick: (event) => event.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxDEV("h2", { id: "payment-modal-title", children: "แนบสลิปการชำระเงิน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 144,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "payment-modal-sub", children: [
          "การจอง #",
          bookingId
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 145,
          columnNumber: 9
        }, this),
        isLoading && /* @__PURE__ */ jsxDEV("p", { className: "payment-load-message", children: "กำลังโหลดข้อมูลการชำระเงิน..." }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 147,
          columnNumber: 23
        }, this),
        isError && /* @__PURE__ */ jsxDEV("div", { className: "payment-load-error", role: "alert", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "โหลดข้อมูลการชำระเงินไม่สำเร็จ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
            lineNumber: 150,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onRetry, children: "ลองโหลดอีกครั้ง" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
            lineNumber: 151,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 149,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(PaymentSummary, { summary, booking, isError }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 157,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleUpload, children: [
          /* @__PURE__ */ jsxDEV(
            SlipUploadZone,
            {
              selectedFile,
              previewUrl,
              onFileSelect: handleFileSelect,
              onRemoveFile: clearSelectedFile
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
              lineNumber: 160,
              columnNumber: 11
            },
            this
          ),
          uploadValidationError && /* @__PURE__ */ jsxDEV("div", { className: "payment-slip-error-alert", role: "alert", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                width: "20",
                height: "20",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "2.2",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                "aria-hidden": "true",
                children: [
                  /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "10" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                    lineNumber: 179,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "8", x2: "12", y2: "12" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                    lineNumber: 180,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                    lineNumber: 181,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                lineNumber: 168,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "payment-slip-error-content", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "ไม่สามารถยืนยันสลิปได้" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                lineNumber: 184,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: uploadValidationError }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                lineNumber: 185,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
              lineNumber: 183,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
            lineNumber: 167,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions payment-modal-actions", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "delete-cancel-button",
                onClick: handleClose,
                disabled: isUploading,
                children: "ปิด"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                lineNumber: 190,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "profile-save-button",
                disabled: !selectedFile || !summary || isLoading || isUploading || hasPendingPayment || !hasSitterPaymentInfo,
                children: isUploading ? "กำลังตรวจสอบสลิป..." : "ส่งสลิป"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
                lineNumber: 198,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
            lineNumber: 189,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
          lineNumber: 159,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
      lineNumber: 137,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx",
    lineNumber: 136,
    columnNumber: 5
  }, this);
}
_s(PaymentModal, "BDK9Y++OA4sr5xrqsMFxTjppKyc=");
_c = PaymentModal;
var _c;
$RefreshReg$(_c, "PaymentModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEhROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVIUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msd0JBQXdCO0FBQ2pDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxvQkFBb0I7QUFFM0Isd0JBQXdCQyxhQUFhO0FBQUEsRUFDbkNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVkM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSWpCLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNrQixZQUFZQyxhQUFhLElBQUluQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJckIsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3NCLHVCQUF1QkMsd0JBQXdCLElBQUl2QixTQUFTLEVBQUU7QUFFckUsUUFBTXdCLFlBQVlmLFNBQVNlLGFBQWFmLFNBQVNnQjtBQUNqRCxRQUFNQyxvQkFBb0JDLFFBQVFqQixTQUFTa0IsVUFBVUM7QUFBQUEsSUFDbkQsQ0FBQ0MsWUFBWUEsUUFBUUMsbUJBQW1CO0FBQUEsRUFDMUMsQ0FBQztBQUNELFFBQU1DLHVCQUF1Qkw7QUFBQUEsSUFDM0JqQixTQUFTdUIsbUJBQW1CQyxlQUFleEIsU0FBU3VCLG1CQUFtQkU7QUFBQUEsRUFDekU7QUFFQXBDLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ21CLFdBQVksUUFBT2tCO0FBQ3hCLFdBQU8sTUFBTUMsSUFBSUMsZ0JBQWdCcEIsVUFBVTtBQUFBLEVBQzdDLEdBQUcsQ0FBQ0EsVUFBVSxDQUFDO0FBRWYsUUFBTXFCLG9CQUFvQkEsTUFBTTtBQUM5QnRCLG9CQUFnQixJQUFJO0FBQ3BCRSxrQkFBYyxFQUFFO0FBQ2hCSSw2QkFBeUIsRUFBRTtBQUFBLEVBQzdCO0FBRUEsUUFBTWlCLG1CQUFtQkEsQ0FBQ0MsU0FBUztBQUNqQyxVQUFNQyxhQUFhdkMsaUJBQWlCc0MsSUFBSTtBQUN4QyxRQUFJLENBQUNDLFdBQVdDLFNBQVM7QUFDdkJKLHdCQUFrQjtBQUNsQmhCLCtCQUF5Qm1CLFdBQVdFLFFBQVE7QUFDNUM7QUFBQSxJQUNGO0FBRUFyQiw2QkFBeUIsRUFBRTtBQUMzQk4sb0JBQWdCd0IsSUFBSTtBQUNwQnRCLGtCQUFja0IsSUFBSVEsZ0JBQWdCSixJQUFJLENBQUM7QUFBQSxFQUN6QztBQUVBLFFBQU1LLGNBQWNBLE1BQU07QUFDeEIsUUFBSTFCLFlBQWE7QUFDakJtQixzQkFBa0I7QUFDbEIvQixZQUFRO0FBQUEsRUFDVjtBQUVBLFFBQU11QyxlQUFlLE9BQU9DLFVBQVU7QUFDcENBLFVBQU1DLGVBQWU7QUFDckIsUUFBSSxDQUFDakMsZ0JBQWdCLENBQUNOLFdBQVcsQ0FBQ2MsYUFBYWIsYUFBYWUscUJBQXFCLENBQUNNLHFCQUFzQjtBQUV4RyxVQUFNa0IsZUFBZXhDLFFBQVF5QyxrQkFDdkJ6QyxRQUFRMEMsa0JBQWtCLDBCQUMxQixVQUNBMUMsUUFBUTJDLGdCQUFnQixZQUN0QixZQUNBO0FBQ1IsVUFBTUMsU0FBU0osaUJBQWlCLFVBQzVCSyxPQUFPN0MsUUFBUThDLGVBQWUsSUFDOUJOLGlCQUFpQixZQUNmSyxPQUFPN0MsUUFBUStDLGFBQWEsSUFDNUJGLE9BQU83QyxRQUFRZ0QsVUFBVTtBQUUvQixRQUFJLENBQUNILE9BQU9JLFNBQVNMLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQzNDL0IsK0JBQXlCLG1EQUFtRDtBQUM1RTtBQUFBLElBQ0Y7QUFFQUEsNkJBQXlCLEVBQUU7QUFDM0IsVUFBTXFDLFdBQVcsSUFBSUMsU0FBUztBQUM5QkQsYUFBU0UsT0FBTyxhQUFhQyxPQUFPdkMsU0FBUyxDQUFDO0FBQzlDb0MsYUFBU0UsT0FBTyxVQUFVQyxPQUFPVCxNQUFNLENBQUM7QUFDeENNLGFBQVNFLE9BQU8saUJBQWlCWixZQUFZO0FBQzdDVSxhQUFTRSxPQUFPLGVBQWUsZUFBZTtBQUM5Q0YsYUFBU0UsT0FBTyxjQUFjOUMsWUFBWTtBQUUxQ0ssbUJBQWUsSUFBSTtBQUNuQixRQUFJMkMsZUFBZTtBQUNuQixRQUFJO0FBQ0ZBLHFCQUFlLE1BQU0vRCxrQkFBa0IyRCxRQUFRO0FBQUEsSUFDakQsU0FBU0ssT0FBTztBQUNkMUM7QUFBQUEsUUFDRTBDLE1BQU1DLFVBQVVDLE1BQU1DLFdBQVc7QUFBQSxNQUNuQztBQUNBO0FBQUEsSUFDRixVQUFDO0FBQ0MvQyxxQkFBZSxLQUFLO0FBQUEsSUFDdEI7QUFFQWtCLHNCQUFrQjtBQUNsQi9CLFlBQVE7QUFDUixVQUFNNkQsZ0JBQWdCTCxjQUFjRyxNQUFNcEMsa0JBQWtCaUMsY0FBY2pDO0FBQzFFLFFBQUlzQyxrQkFBa0IsWUFBWTtBQUNoQ25FLFlBQU0sMkRBQTJELFNBQVM7QUFBQSxJQUM1RSxPQUFPO0FBQ0xBLFlBQU0sOENBQThDLFNBQVM7QUFBQSxJQUMvRDtBQUNBWSxnQkFBWTtBQUFBLEVBQ2Q7QUFFQSxNQUFJLENBQUNQLFVBQVUsQ0FBQ0UsUUFBUyxRQUFPO0FBRWhDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixTQUFTcUMsYUFDN0M7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLE1BQUs7QUFBQSxNQUNMLGNBQVc7QUFBQSxNQUNYLG1CQUFnQjtBQUFBLE1BQ2hCLFNBQVMsQ0FBQ0UsVUFBVUEsTUFBTXNCLGdCQUFnQjtBQUFBLE1BRTFDO0FBQUEsK0JBQUMsUUFBRyxJQUFHLHVCQUFzQixrQ0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQy9DLHVCQUFDLE9BQUUsV0FBVSxxQkFBb0I7QUFBQTtBQUFBLFVBQVM5QztBQUFBQSxhQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFFbkRiLGFBQWEsdUJBQUMsT0FBRSxXQUFVLHdCQUF1Qiw2Q0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQzlFQyxXQUNDLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsTUFBSyxTQUN2QztBQUFBLGlDQUFDLFVBQUssOENBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxVQUNwQyx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTQyxTQUFRLCtCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdGLHVCQUFDLGtCQUFlLFNBQWtCLFNBQWtCLFdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUVyRSx1QkFBQyxVQUFLLFVBQVVrQyxjQUNkO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0EsY0FBY1A7QUFBQUEsY0FDZCxjQUFjRDtBQUFBQTtBQUFBQSxZQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJa0M7QUFBQSxVQUVqQ2pCLHlCQUNDLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsTUFBSyxTQUM3QztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLFFBQU87QUFBQSxnQkFDUCxTQUFRO0FBQUEsZ0JBQ1IsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxhQUFZO0FBQUEsZ0JBQ1osZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsZUFBWTtBQUFBLGdCQUVaO0FBQUEseUNBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFDOUIsdUJBQUMsVUFBSyxJQUFHLE1BQUssSUFBRyxLQUFJLElBQUcsTUFBSyxJQUFHLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ3BDLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFNBQVEsSUFBRyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QztBQUFBO0FBQUE7QUFBQSxjQWIxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEscUNBQUMsWUFBTyxzQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCLHVCQUFDLE9BQUdBLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsaUJBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUYsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVN3QjtBQUFBQSxnQkFDVCxVQUFVMUI7QUFBQUEsZ0JBQVk7QUFBQTtBQUFBLGNBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsVUFDRSxDQUFDSixnQkFDRCxDQUFDTixXQUNEQyxhQUNBUyxlQUNBTSxxQkFDQSxDQUFDTTtBQUFBQSxnQkFHRlosd0JBQWMsd0JBQXdCO0FBQUE7QUFBQSxjQVp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNEQTtBQUFBO0FBQUE7QUFBQSxJQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE2RUEsS0E5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStFQTtBQUVKO0FBQUNMLEdBOUx1QlQsY0FBWTtBQUFBLEtBQVpBO0FBQVksSUFBQWlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXBsb2FkUGF5bWVudFNsaXAiLCJ0b2FzdCIsInZhbGlkYXRlU2xpcEZpbGUiLCJQYXltZW50U3VtbWFyeSIsIlNsaXBVcGxvYWRab25lIiwiUGF5bWVudE1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsImJvb2tpbmciLCJzdW1tYXJ5IiwiaXNMb2FkaW5nIiwiaXNFcnJvciIsIm9uUmV0cnkiLCJvblN1Y2Nlc3MiLCJfcyIsInNlbGVjdGVkRmlsZSIsInNldFNlbGVjdGVkRmlsZSIsInByZXZpZXdVcmwiLCJzZXRQcmV2aWV3VXJsIiwiaXNVcGxvYWRpbmciLCJzZXRJc1VwbG9hZGluZyIsInVwbG9hZFZhbGlkYXRpb25FcnJvciIsInNldFVwbG9hZFZhbGlkYXRpb25FcnJvciIsImJvb2tpbmdJZCIsImlkIiwiaGFzUGVuZGluZ1BheW1lbnQiLCJCb29sZWFuIiwicGF5bWVudHMiLCJzb21lIiwicGF5bWVudCIsInBheW1lbnRfc3RhdHVzIiwiaGFzU2l0dGVyUGF5bWVudEluZm8iLCJzaXR0ZXJQYXltZW50SW5mbyIsImFjY291bnROYW1lIiwicXJDb2RlVXJsIiwidW5kZWZpbmVkIiwiVVJMIiwicmV2b2tlT2JqZWN0VVJMIiwiY2xlYXJTZWxlY3RlZEZpbGUiLCJoYW5kbGVGaWxlU2VsZWN0IiwiZmlsZSIsInZhbGlkYXRpb24iLCJpc1ZhbGlkIiwiZXJyb3JNc2ciLCJjcmVhdGVPYmplY3RVUkwiLCJoYW5kbGVDbG9zZSIsImhhbmRsZVVwbG9hZCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJwYXltZW50U3RhZ2UiLCJwYXltZW50X3N0YWdlIiwiYm9va2luZ3N0YXR1cyIsInBheW1lbnRwbGFuIiwiYW1vdW50IiwiTnVtYmVyIiwicmVtYWluaW5nQW1vdW50IiwiZGVwb3NpdEFtb3VudCIsInRvdGFsUHJpY2UiLCJpc0Zpbml0ZSIsImZvcm1EYXRhIiwiRm9ybURhdGEiLCJhcHBlbmQiLCJTdHJpbmciLCJyZXNwb25zZURhdGEiLCJlcnJvciIsInJlc3BvbnNlIiwiZGF0YSIsIm1lc3NhZ2UiLCJwYXltZW50U3RhdHVzIiwic3RvcFByb3BhZ2F0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5bWVudE1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1cGxvYWRQYXltZW50U2xpcCB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9wYXltZW50LmFwaS5qc1wiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwiLi4vLi4vdXRpbHMvdG9hc3QuanNcIjtcbmltcG9ydCB7IHZhbGlkYXRlU2xpcEZpbGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcGF5bWVudFZhbGlkYXRpb24uanNcIjtcbmltcG9ydCBQYXltZW50U3VtbWFyeSBmcm9tIFwiLi9QYXltZW50U3VtbWFyeS5qc3hcIjtcbmltcG9ydCBTbGlwVXBsb2FkWm9uZSBmcm9tIFwiLi9TbGlwVXBsb2FkWm9uZS5qc3hcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGF5bWVudE1vZGFsKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBib29raW5nLFxuICBzdW1tYXJ5LFxuICBpc0xvYWRpbmcgPSBmYWxzZSxcbiAgaXNFcnJvciA9IGZhbHNlLFxuICBvblJldHJ5LFxuICBvblN1Y2Nlc3MsXG59KSB7XG4gIGNvbnN0IFtzZWxlY3RlZEZpbGUsIHNldFNlbGVjdGVkRmlsZV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3ByZXZpZXdVcmwsIHNldFByZXZpZXdVcmxdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtpc1VwbG9hZGluZywgc2V0SXNVcGxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdXBsb2FkVmFsaWRhdGlvbkVycm9yLCBzZXRVcGxvYWRWYWxpZGF0aW9uRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgYm9va2luZ0lkID0gYm9va2luZz8uYm9va2luZ0lkIHx8IGJvb2tpbmc/LmlkO1xuICBjb25zdCBoYXNQZW5kaW5nUGF5bWVudCA9IEJvb2xlYW4oc3VtbWFyeT8ucGF5bWVudHM/LnNvbWUoXG4gICAgKHBheW1lbnQpID0+IHBheW1lbnQucGF5bWVudF9zdGF0dXMgPT09IFwicGVuZGluZ192ZXJpZnlpbmdcIixcbiAgKSk7XG4gIGNvbnN0IGhhc1NpdHRlclBheW1lbnRJbmZvID0gQm9vbGVhbihcbiAgICBzdW1tYXJ5Py5zaXR0ZXJQYXltZW50SW5mbz8uYWNjb3VudE5hbWUgJiYgc3VtbWFyeT8uc2l0dGVyUGF5bWVudEluZm8/LnFyQ29kZVVybCxcbiAgKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcHJldmlld1VybCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgfSwgW3ByZXZpZXdVcmxdKTtcblxuICBjb25zdCBjbGVhclNlbGVjdGVkRmlsZSA9ICgpID0+IHtcbiAgICBzZXRTZWxlY3RlZEZpbGUobnVsbCk7XG4gICAgc2V0UHJldmlld1VybChcIlwiKTtcbiAgICBzZXRVcGxvYWRWYWxpZGF0aW9uRXJyb3IoXCJcIik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRmlsZVNlbGVjdCA9IChmaWxlKSA9PiB7XG4gICAgY29uc3QgdmFsaWRhdGlvbiA9IHZhbGlkYXRlU2xpcEZpbGUoZmlsZSk7XG4gICAgaWYgKCF2YWxpZGF0aW9uLmlzVmFsaWQpIHtcbiAgICAgIGNsZWFyU2VsZWN0ZWRGaWxlKCk7XG4gICAgICBzZXRVcGxvYWRWYWxpZGF0aW9uRXJyb3IodmFsaWRhdGlvbi5lcnJvck1zZyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0VXBsb2FkVmFsaWRhdGlvbkVycm9yKFwiXCIpO1xuICAgIHNldFNlbGVjdGVkRmlsZShmaWxlKTtcbiAgICBzZXRQcmV2aWV3VXJsKFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsb3NlID0gKCkgPT4ge1xuICAgIGlmIChpc1VwbG9hZGluZykgcmV0dXJuO1xuICAgIGNsZWFyU2VsZWN0ZWRGaWxlKCk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVwbG9hZCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFzZWxlY3RlZEZpbGUgfHwgIXN1bW1hcnkgfHwgIWJvb2tpbmdJZCB8fCBpc0xvYWRpbmcgfHwgaGFzUGVuZGluZ1BheW1lbnQgfHwgIWhhc1NpdHRlclBheW1lbnRJbmZvKSByZXR1cm47XG5cbiAgICBjb25zdCBwYXltZW50U3RhZ2UgPSBzdW1tYXJ5LnBheW1lbnRfc3RhZ2VcbiAgICAgIHx8IChzdW1tYXJ5LmJvb2tpbmdzdGF0dXMgPT09IFwid2FpdGluZ19maW5hbF9wYXltZW50XCJcbiAgICAgICAgPyBcImZpbmFsXCJcbiAgICAgICAgOiBzdW1tYXJ5LnBheW1lbnRwbGFuID09PSBcImRlcG9zaXRcIlxuICAgICAgICAgID8gXCJkZXBvc2l0XCJcbiAgICAgICAgICA6IFwiZnVsbFwiKTtcbiAgICBjb25zdCBhbW91bnQgPSBwYXltZW50U3RhZ2UgPT09IFwiZmluYWxcIlxuICAgICAgPyBOdW1iZXIoc3VtbWFyeS5yZW1haW5pbmdBbW91bnQpXG4gICAgICA6IHBheW1lbnRTdGFnZSA9PT0gXCJkZXBvc2l0XCJcbiAgICAgICAgPyBOdW1iZXIoc3VtbWFyeS5kZXBvc2l0QW1vdW50KVxuICAgICAgICA6IE51bWJlcihzdW1tYXJ5LnRvdGFsUHJpY2UpO1xuXG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoYW1vdW50KSB8fCBhbW91bnQgPD0gMCkge1xuICAgICAgc2V0VXBsb2FkVmFsaWRhdGlvbkVycm9yKFwi4LmE4Lih4LmI4Lie4Lia4Lii4Lit4LiU4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZ4LiX4Li14LmI4LiW4Li54LiB4LiV4LmJ4Lit4LiHIOC4geC4o+C4uOC4k+C4suC4peC4reC4h+C5guC4q+C4peC4lOC4guC5ieC4reC4oeC4ueC4peC5g+C4q+C4oeC5iFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRVcGxvYWRWYWxpZGF0aW9uRXJyb3IoXCJcIik7XG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgICBmb3JtRGF0YS5hcHBlbmQoXCJib29raW5nSWRcIiwgU3RyaW5nKGJvb2tpbmdJZCkpO1xuICAgIGZvcm1EYXRhLmFwcGVuZChcImFtb3VudFwiLCBTdHJpbmcoYW1vdW50KSk7XG4gICAgZm9ybURhdGEuYXBwZW5kKFwicGF5bWVudF9zdGFnZVwiLCBwYXltZW50U3RhZ2UpO1xuICAgIGZvcm1EYXRhLmFwcGVuZChcInBheW1lbnRUeXBlXCIsIFwiYmFua190cmFuc2ZlclwiKTtcbiAgICBmb3JtRGF0YS5hcHBlbmQoXCJzbGlwX2ltYWdlXCIsIHNlbGVjdGVkRmlsZSk7XG5cbiAgICBzZXRJc1VwbG9hZGluZyh0cnVlKTtcbiAgICBsZXQgcmVzcG9uc2VEYXRhID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgcmVzcG9uc2VEYXRhID0gYXdhaXQgdXBsb2FkUGF5bWVudFNsaXAoZm9ybURhdGEpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBzZXRVcGxvYWRWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwi4LmE4Lih4LmI4Liq4Liy4Lih4Liy4Lij4LiW4Lit4Lix4Lib4LmC4Lir4Lil4LiU4Liq4Lil4Li04Lib4LmE4LiU4LmJIOC4geC4o+C4uOC4k+C4suC4leC4o+C4p+C4iOC4quC4reC4muC4quC4peC4tOC4m+C4reC4teC4geC4hOC4o+C4seC5ieC4h1wiLFxuICAgICAgKTtcbiAgICAgIHJldHVybjtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNVcGxvYWRpbmcoZmFsc2UpO1xuICAgIH1cblxuICAgIGNsZWFyU2VsZWN0ZWRGaWxlKCk7XG4gICAgb25DbG9zZSgpO1xuICAgIGNvbnN0IHBheW1lbnRTdGF0dXMgPSByZXNwb25zZURhdGE/LmRhdGE/LnBheW1lbnRfc3RhdHVzIHx8IHJlc3BvbnNlRGF0YT8ucGF5bWVudF9zdGF0dXM7XG4gICAgaWYgKHBheW1lbnRTdGF0dXMgPT09IFwidmVyaWZpZWRcIikge1xuICAgICAgdG9hc3QoXCLguJXguKPguKfguIjguKrguK3guJrguKrguKXguLTguJvguJzguYjguLLguJnguK3guLHguJXguYLguJnguKHguLHguJXguLQg4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZ4LmA4Lij4Li14Lii4Lia4Lij4LmJ4Lit4Lii4LmB4Lil4LmJ4LinXCIsIFwic3VjY2Vzc1wiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdG9hc3QoXCLguYHguJnguJrguKrguKXguLTguJvguIHguLLguKPguYLguK3guJnguYDguIfguLTguJnguKrguLPguYDguKPguYfguIgg4Lij4Lit4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiV4Lij4Lin4LiI4Liq4Lit4LiaXCIsIFwic3VjY2Vzc1wiKTtcbiAgICB9XG4gICAgb25TdWNjZXNzPy4oKTtcbiAgfTtcblxuICBpZiAoIWlzT3BlbiB8fCAhYm9va2luZykgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbC1vdmVybGF5XCIgb25DbGljaz17aGFuZGxlQ2xvc2V9PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwgcGF5bWVudC1tb2RhbFwiXG4gICAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICAgIGFyaWEtbGFiZWxsZWRieT1cInBheW1lbnQtbW9kYWwtdGl0bGVcIlxuICAgICAgICBvbkNsaWNrPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8aDIgaWQ9XCJwYXltZW50LW1vZGFsLXRpdGxlXCI+4LmB4LiZ4Lia4Liq4Lil4Li04Lib4LiB4Liy4Lij4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicGF5bWVudC1tb2RhbC1zdWJcIj7guIHguLLguKPguIjguK3guIcgI3tib29raW5nSWR9PC9wPlxuXG4gICAgICAgIHtpc0xvYWRpbmcgJiYgPHAgY2xhc3NOYW1lPVwicGF5bWVudC1sb2FkLW1lc3NhZ2VcIj7guIHguLPguKXguLHguIfguYLguKvguKXguJTguILguYnguK3guKHguLnguKXguIHguLLguKPguIrguLPguKPguLDguYDguIfguLTguJkuLi48L3A+fVxuICAgICAgICB7aXNFcnJvciAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LWxvYWQtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgIDxzcGFuPuC5guC4q+C4peC4lOC4guC5ieC4reC4oeC4ueC4peC4geC4suC4o+C4iuC4s+C4o+C4sOC5gOC4h+C4tOC4meC5hOC4oeC5iOC4quC4s+C5gOC4o+C5h+C4iDwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uUmV0cnl9PlxuICAgICAgICAgICAgICDguKXguK3guIfguYLguKvguKXguJTguK3guLXguIHguITguKPguLHguYnguIdcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxQYXltZW50U3VtbWFyeSBzdW1tYXJ5PXtzdW1tYXJ5fSBib29raW5nPXtib29raW5nfSBpc0Vycm9yPXtpc0Vycm9yfSAvPlxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVVcGxvYWR9PlxuICAgICAgICAgIDxTbGlwVXBsb2FkWm9uZVxuICAgICAgICAgICAgc2VsZWN0ZWRGaWxlPXtzZWxlY3RlZEZpbGV9XG4gICAgICAgICAgICBwcmV2aWV3VXJsPXtwcmV2aWV3VXJsfVxuICAgICAgICAgICAgb25GaWxlU2VsZWN0PXtoYW5kbGVGaWxlU2VsZWN0fVxuICAgICAgICAgICAgb25SZW1vdmVGaWxlPXtjbGVhclNlbGVjdGVkRmlsZX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIHt1cGxvYWRWYWxpZGF0aW9uRXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXNsaXAtZXJyb3ItYWxlcnRcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgPHN2Z1xuICAgICAgICAgICAgICAgIHdpZHRoPVwiMjBcIlxuICAgICAgICAgICAgICAgIGhlaWdodD1cIjIwXCJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjIuMlwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiIC8+XG4gICAgICAgICAgICAgICAgPGxpbmUgeDE9XCIxMlwiIHkxPVwiOFwiIHgyPVwiMTJcIiB5Mj1cIjEyXCIgLz5cbiAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjEyXCIgeTE9XCIxNlwiIHgyPVwiMTIuMDFcIiB5Mj1cIjE2XCIgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1zbGlwLWVycm9yLWNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPuC5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4ouC4t+C4meC4ouC4seC4meC4quC4peC4tOC4m+C5hOC4lOC5iTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDxwPnt1cGxvYWRWYWxpZGF0aW9uRXJyb3J9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtYWN0aW9ucyBwYXltZW50LW1vZGFsLWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRlbGV0ZS1jYW5jZWwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1VwbG9hZGluZ31cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg4Lib4Li04LiUXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtc2F2ZS1idXR0b25cIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17XG4gICAgICAgICAgICAgICAgIXNlbGVjdGVkRmlsZSB8fFxuICAgICAgICAgICAgICAgICFzdW1tYXJ5IHx8XG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nIHx8XG4gICAgICAgICAgICAgICAgaXNVcGxvYWRpbmcgfHxcbiAgICAgICAgICAgICAgICBoYXNQZW5kaW5nUGF5bWVudCB8fFxuICAgICAgICAgICAgICAgICFoYXNTaXR0ZXJQYXltZW50SW5mb1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc1VwbG9hZGluZyA/IFwi4LiB4Liz4Lil4Lix4LiH4LiV4Lij4Lin4LiI4Liq4Lit4Lia4Liq4Lil4Li04LibLi4uXCIgOiBcIuC4quC5iOC4h+C4quC4peC4tOC4m1wifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvcGF5bWVudC9QYXltZW50TW9kYWwuanN4In0=