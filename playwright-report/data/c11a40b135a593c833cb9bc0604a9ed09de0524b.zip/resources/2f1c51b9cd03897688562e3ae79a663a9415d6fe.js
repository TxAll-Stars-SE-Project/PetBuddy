import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function Button({ loading = false, disabled = false, children, ...rest }) {
  return /* @__PURE__ */ jsxDEV("button", { className: "btn", disabled: disabled || loading, ...rest, children: [
    loading && /* @__PURE__ */ jsxDEV("span", { className: "spinner", "aria-hidden": "true" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx",
      lineNumber: 23,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: loading ? "กำลังประมวลผล…" : children }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
}
_c = Button;
export default Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Button.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR2tCOzs7Ozs7Ozs7Ozs7Ozs7O0FBSGxCLFNBQVNBLE9BQU8sRUFBRUMsVUFBVSxPQUFPQyxXQUFXLE9BQU9DLFVBQVUsR0FBR0MsS0FBSyxHQUFHO0FBQ3hFLFNBQ0UsdUJBQUMsWUFBTyxXQUFVLE9BQU0sVUFBVUYsWUFBWUQsU0FBUyxHQUFJRyxNQUN4REg7QUFBQUEsZUFBVyx1QkFBQyxVQUFLLFdBQVUsV0FBVSxlQUFZLFVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxJQUN6RCx1QkFBQyxVQUFNQSxvQkFBVSxtQkFBbUJFLFlBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxPQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDRSxLQVBRTDtBQVFULGVBQWVBO0FBQU8sSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwibG9hZGluZyIsImRpc2FibGVkIiwiY2hpbGRyZW4iLCJyZXN0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnV0dG9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBCdXR0b24oeyBsb2FkaW5nID0gZmFsc2UsIGRpc2FibGVkID0gZmFsc2UsIGNoaWxkcmVuLCAuLi5yZXN0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0blwiIGRpc2FibGVkPXtkaXNhYmxlZCB8fCBsb2FkaW5nfSB7Li4ucmVzdH0+XG4gICAgICB7bG9hZGluZyAmJiA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9zcGFuPn1cbiAgICAgIDxzcGFuPntsb2FkaW5nID8gXCLguIHguLPguKXguLHguIfguJvguKPguLDguKHguKfguKXguJzguKXigKZcIiA6IGNoaWxkcmVufTwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cbmV4cG9ydCBkZWZhdWx0IEJ1dHRvbjsiXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9CdXR0b24uanN4In0=