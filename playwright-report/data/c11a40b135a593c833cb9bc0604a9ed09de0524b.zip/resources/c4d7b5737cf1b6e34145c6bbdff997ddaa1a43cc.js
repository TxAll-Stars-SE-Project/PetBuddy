import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFoundPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
export default function NotFoundPage() {
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card notfound", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "nf-num", children: "404" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
      lineNumber: 26,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { children: "ไม่พบหน้าที่คุณกำลังหาอยู่" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "muted", children: "หน้าที่คุณมองหาไม่มีอยู่ หรือถูกย้ายไปแล้ว" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
      lineNumber: 28,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--aslink", to: "/", children: "กลับหน้าหลัก" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
      lineNumber: 29,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
    lineNumber: 25,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx",
    lineNumber: 24,
    columnNumber: 5
  }, this);
}
_c = NotFoundPage;
var _c;
$RefreshReg$(_c, "NotFoundPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/NotFoundPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFOUixTQUFTQSxZQUFZO0FBRXJCLHdCQUF3QkMsZUFBZTtBQUNyQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxVQUFTLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsSUFDM0IsdUJBQUMsUUFBRywwQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCO0FBQUEsSUFDOUIsdUJBQUMsT0FBRSxXQUFVLFNBQVEsMERBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Q7QUFBQSxJQUMvRCx1QkFBQyxRQUFLLFdBQVUsbUJBQWtCLElBQUcsS0FBSSw0QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLE9BSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNDLEtBWHVCRDtBQUFZLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJOb3RGb3VuZFBhZ2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3RGb3VuZFBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOb3RGb3VuZFBhZ2UoKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhZ2VcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jYXJkIG5vdGZvdW5kXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmYtbnVtXCI+NDA0PC9kaXY+XG4gICAgICAgIDxoMT7guYTguKHguYjguJ7guJrguKvguJnguYnguLLguJfguLXguYjguITguLjguJPguIHguLPguKXguLHguIfguKvguLLguK3guKLguLnguYg8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdXRlZFwiPuC4q+C4meC5ieC4suC4l+C4teC5iOC4hOC4uOC4k+C4oeC4reC4h+C4q+C4suC5hOC4oeC5iOC4oeC4teC4reC4ouC4ueC5iCDguKvguKPguLfguK3guJbguLnguIHguKLguYnguLLguKLguYTguJvguYHguKXguYnguKc8L3A+XG4gICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tLWFzbGlua1wiIHRvPVwiL1wiPuC4geC4peC4seC4muC4q+C4meC5ieC4suC4q+C4peC4seC4gTwvTGluaz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9Ob3RGb3VuZFBhZ2UuanN4In0=