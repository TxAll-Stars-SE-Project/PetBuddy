import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SitterDashboardPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { useAuth } from "/src/context/AuthContext.jsx";
import Navbar from "/src/components/Navbar.jsx";
import ServiceFormModal from "/src/components/sitter/ServiceFormModal.jsx";
import DashboardHeader from "/src/components/sitter/dashboard/DashboardHeader.jsx";
import SitterProfileCard from "/src/components/sitter/dashboard/SitterProfileCard.jsx";
import RecentBookingsSection from "/src/components/sitter/dashboard/RecentBookingsSection.jsx";
import MyServicesSection from "/src/components/sitter/dashboard/MyServicesSection.jsx";
import ServiceFeedbackModal from "/src/components/sitter/dashboard/ServiceFeedbackModal.jsx";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import { toast } from "/src/utils/toast.js";
import {
  fetchSitterProfile,
  fetchSitterServices,
  createSitterService,
  updateSitterService,
  deleteSitterService
} from "/src/services/sitterService.js";
import { getSitterBookings } from "/src/services/booking.api.ts";
import {
  resolveInitialProfile,
  formatSitterAddress,
  addServiceItem,
  updateServiceItem,
  deleteServiceItem
} from "/src/utils/sitterDashboardLogic.js";
import {
  getCachedProfile,
  setCachedProfile,
  getCachedServices,
  setCachedServices,
  addCachedService,
  updateCachedService,
  removeCachedService,
  getCachedBookings,
  setCachedBookings
} from "/src/utils/cache/sitterCache.js";
export default function SitterDashboardPage() {
  _s();
  const navigate = useNavigate();
  const { user } = useAuth();
  const defaultProfile = {
    name: user?.username || "พี่เลี้ยงสัตว์เลี้ยง",
    username: user?.username || "sitter",
    tel: user?.tel || "",
    address: user?.address || "",
    experience: user?.experience || "",
    rating: 5,
    reviewCount: 0
  };
  const [sitterProfile, setSitterProfile] = useState(() => {
    const cached = getCachedProfile();
    if (cached) return cached;
    return resolveInitialProfile(user, defaultProfile);
  });
  const [isLoadingProfile, setIsLoadingProfile] = useState(() => !getCachedProfile());
  const [services, setServices] = useState(() => getCachedServices() || []);
  const [isLoadingServices, setIsLoadingServices] = useState(() => !getCachedServices());
  const [bookings, setBookings] = useState(() => getCachedBookings() || []);
  const [isLoadingBookings, setIsLoadingBookings] = useState(() => !getCachedBookings());
  const [editingService, setEditingService] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [serviceToDelete, setServiceToDelete] = useState(null);
  useEffect(() => {
    let isMounted = true;
    fetchSitterProfile().then((data) => {
      if (data && isMounted) {
        const fullAddress = formatSitterAddress(data);
        setSitterProfile((prev) => {
          const updated = {
            ...prev,
            name: data.username || prev.name,
            username: data.username || prev.username,
            tel: data.tel || prev.tel,
            address: fullAddress || prev.address,
            experience: data.experience || prev.experience
          };
          setCachedProfile(updated);
          return updated;
        });
      }
    }).catch(() => {
    }).finally(() => {
      if (isMounted) setIsLoadingProfile(false);
    });
    getSitterBookings().then((data) => {
      if (isMounted && Array.isArray(data)) {
        setBookings(data);
        setCachedBookings(data);
      }
    }).catch((err) => {
      console.warn("Notice: /api/sitter/bookings unreachable or offline:", err);
    }).finally(() => {
      if (isMounted) setIsLoadingBookings(false);
    });
    fetchSitterServices().then((data) => {
      if (isMounted && Array.isArray(data)) {
        setServices(data);
        setCachedServices(data);
      }
    }).catch((err) => {
      console.warn("Notice: /api/sitter/services/me unreachable or offline:", err);
    }).finally(() => {
      if (isMounted) setIsLoadingServices(false);
    });
    return () => {
      isMounted = false;
    };
  }, []);
  const handleSaveService = async (payload) => {
    const isEdit = Boolean(editingService?.serviceId || editingService?.serviceid);
    const targetId = editingService?.serviceId || editingService?.serviceid;
    setEditingService(null);
    if (isEdit) {
      try {
        const serverData = await updateSitterService(targetId, payload);
        const merged = { ...payload, ...serverData || {}, serviceId: targetId };
        setServices((prev) => updateServiceItem(prev, targetId, merged));
        updateCachedService(targetId, merged);
        setFeedback({ type: "edit", data: merged });
      } catch (err) {
        console.error("Failed to update service:", err);
        toast("เกิดข้อผิดพลาดในการแก้ไขบริการ กรุณาลองใหม่อีกครั้ง");
      }
    } else {
      try {
        const savedData = await createSitterService(payload);
        const newService = {
          ...payload,
          ...savedData || {},
          serviceId: savedData?.serviceId || Date.now()
        };
        setServices((prev) => addServiceItem(prev, newService));
        addCachedService(newService);
        setFeedback({ type: "create", data: newService });
      } catch (err) {
        console.error("Failed to create service:", err);
        toast("เกิดข้อผิดพลาดในการสร้างบริการ กรุณาลองใหม่อีกครั้ง");
      }
    }
  };
  const handleDeleteService = (serviceId) => {
    setServiceToDelete(serviceId);
  };
  const handleConfirmDelete = async () => {
    if (!serviceToDelete) return;
    const targetId = serviceToDelete;
    setServiceToDelete(null);
    try {
      await deleteSitterService(targetId);
      setServices((prev) => deleteServiceItem(prev, targetId));
      removeCachedService(targetId);
      toast("ลบบริการเรียบร้อยแล้ว", "success");
    } catch (err) {
      console.error("Failed to delete service:", err);
      toast("เกิดข้อผิดพลาดในการลบบริการ กรุณาลองใหม่อีกครั้ง", "error");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-[#FFF7EF] text-[#1F2937]", children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
      lineNumber: 230,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "max-w-5xl mx-auto space-y-6 p-4 sm:p-6 lg:p-8", children: [
      /* @__PURE__ */ jsxDEV(DashboardHeader, { username: sitterProfile.name }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
        lineNumber: 234,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        SitterProfileCard,
        {
          profile: sitterProfile,
          isLoading: isLoadingProfile,
          onEditProfile: () => navigate("/profile")
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
          lineNumber: 237,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        RecentBookingsSection,
        {
          bookings,
          isLoading: isLoadingBookings,
          onViewAll: () => navigate("/sitter/bookings")
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
          lineNumber: 244,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        MyServicesSection,
        {
          services,
          isLoading: isLoadingServices,
          onAddService: () => setEditingService({}),
          onEditService: (service) => setEditingService(service),
          onDeleteService: handleDeleteService
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
          lineNumber: 251,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
      lineNumber: 232,
      columnNumber: 7
    }, this),
    editingService && /* @__PURE__ */ jsxDEV(
      ServiceFormModal,
      {
        serviceToEdit: editingService.serviceId || editingService.serviceid ? editingService : null,
        onClose: () => setEditingService(null),
        onSave: handleSaveService
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
        lineNumber: 262,
        columnNumber: 7
      },
      this
    ),
    feedback && /* @__PURE__ */ jsxDEV(
      ServiceFeedbackModal,
      {
        type: feedback.type,
        serviceData: feedback.data,
        onClose: () => setFeedback(null)
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
        lineNumber: 275,
        columnNumber: 7
      },
      this
    ),
    serviceToDelete && /* @__PURE__ */ jsxDEV(
      ConfirmModal,
      {
        title: "ยืนยันการลบบริการ",
        message: "คุณแน่ใจหรือไม่ว่าต้องการลบบริการนี้? บริการจะถูกนำออกจากรายการของคุณ",
        confirmText: "ลบบริการ",
        cancelText: "ยกเลิก",
        isDanger: true,
        onConfirm: handleConfirmDelete,
        onCancel: () => setServiceToDelete(null)
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
        lineNumber: 284,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx",
    lineNumber: 228,
    columnNumber: 5
  }, this);
}
_s(SitterDashboardPage, "eWXzxwXp2LZfYZqMOFrGZ3xzsfQ=", false, function() {
  return [useNavigate, useAuth];
});
_c = SitterDashboardPage;
var _c;
$RefreshReg$(_c, "SitterDashboardPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDashboardPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa05NOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxOTixPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLDBCQUEwQjtBQUNqQyxPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyx5QkFBeUI7QUFDbEM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBYVAsd0JBQXdCQyxzQkFBc0I7QUFBQUMsS0FBQTtBQUM1QyxRQUFNQyxXQUFXakMsWUFBWTtBQUM3QixRQUFNLEVBQUVrQyxLQUFLLElBQUlqQyxRQUFRO0FBR3pCLFFBQU1rQyxpQkFBaUI7QUFBQSxJQUNyQkMsTUFBTUYsTUFBTUcsWUFBWTtBQUFBLElBQ3hCQSxVQUFVSCxNQUFNRyxZQUFZO0FBQUEsSUFDNUJDLEtBQUtKLE1BQU1JLE9BQU87QUFBQSxJQUNsQkMsU0FBU0wsTUFBTUssV0FBVztBQUFBLElBQzFCQyxZQUFZTixNQUFNTSxjQUFjO0FBQUEsSUFDaENDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsRUFDZjtBQUVBLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUk5QyxTQUFTLE1BQU07QUFDdkQsVUFBTStDLFNBQVN2QixpQkFBaUI7QUFDaEMsUUFBSXVCLE9BQVEsUUFBT0E7QUFDbkIsV0FBTzVCLHNCQUFzQmlCLE1BQU1DLGNBQWM7QUFBQSxFQUNuRCxDQUFDO0FBQ0QsUUFBTSxDQUFDVyxrQkFBa0JDLG1CQUFtQixJQUFJakQsU0FBUyxNQUFNLENBQUN3QixpQkFBaUIsQ0FBQztBQUdsRixRQUFNLENBQUMwQixVQUFVQyxXQUFXLElBQUluRCxTQUFTLE1BQU0wQixrQkFBa0IsS0FBSyxFQUFFO0FBQ3hFLFFBQU0sQ0FBQzBCLG1CQUFtQkMsb0JBQW9CLElBQUlyRCxTQUFTLE1BQU0sQ0FBQzBCLGtCQUFrQixDQUFDO0FBR3JGLFFBQU0sQ0FBQzRCLFVBQVVDLFdBQVcsSUFBSXZELFNBQVMsTUFBTStCLGtCQUFrQixLQUFLLEVBQUU7QUFDeEUsUUFBTSxDQUFDeUIsbUJBQW1CQyxvQkFBb0IsSUFBSXpELFNBQVMsTUFBTSxDQUFDK0Isa0JBQWtCLENBQUM7QUFJckYsUUFBTSxDQUFDMkIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNELFNBQVMsSUFBSTtBQUV6RCxRQUFNLENBQUM0RCxVQUFVQyxXQUFXLElBQUk3RCxTQUFTLElBQUk7QUFFN0MsUUFBTSxDQUFDOEQsaUJBQWlCQyxrQkFBa0IsSUFBSS9ELFNBQVMsSUFBSTtBQUczREMsWUFBVSxNQUFNO0FBQ2QsUUFBSStELFlBQVk7QUFHaEJuRCx1QkFBbUIsRUFDaEJvRCxLQUFLLENBQUNDLFNBQVM7QUFDZCxVQUFJQSxRQUFRRixXQUFXO0FBQ3JCLGNBQU1HLGNBQWMvQyxvQkFBb0I4QyxJQUFJO0FBQzVDcEIseUJBQWlCLENBQUNzQixTQUFTO0FBQ3pCLGdCQUFNQyxVQUFVO0FBQUEsWUFDZCxHQUFHRDtBQUFBQSxZQUNIOUIsTUFBTTRCLEtBQUszQixZQUFZNkIsS0FBSzlCO0FBQUFBLFlBQzVCQyxVQUFVMkIsS0FBSzNCLFlBQVk2QixLQUFLN0I7QUFBQUEsWUFDaENDLEtBQUswQixLQUFLMUIsT0FBTzRCLEtBQUs1QjtBQUFBQSxZQUN0QkMsU0FBUzBCLGVBQWVDLEtBQUszQjtBQUFBQSxZQUM3QkMsWUFBWXdCLEtBQUt4QixjQUFjMEIsS0FBSzFCO0FBQUFBLFVBQ3RDO0FBQ0FqQiwyQkFBaUI0QyxPQUFPO0FBQ3hCLGlCQUFPQTtBQUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDLEVBQ0FDLE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQyxFQUNkQyxRQUFRLE1BQU07QUFDYixVQUFJUCxVQUFXZixxQkFBb0IsS0FBSztBQUFBLElBQzFDLENBQUM7QUFHSC9CLHNCQUFrQixFQUNmK0MsS0FBSyxDQUFDQyxTQUFTO0FBQ2QsVUFBSUYsYUFBYVEsTUFBTUMsUUFBUVAsSUFBSSxHQUFHO0FBQ3BDWCxvQkFBWVcsSUFBSTtBQUNoQmxDLDBCQUFrQmtDLElBQUk7QUFBQSxNQUN4QjtBQUFBLElBQ0YsQ0FBQyxFQUNBSSxNQUFNLENBQUNJLFFBQVE7QUFDZEMsY0FBUUMsS0FBSyx3REFBd0RGLEdBQUc7QUFBQSxJQUMxRSxDQUFDLEVBQ0FILFFBQVEsTUFBTTtBQUNiLFVBQUlQLFVBQVdQLHNCQUFxQixLQUFLO0FBQUEsSUFDM0MsQ0FBQztBQUdIM0Msd0JBQW9CLEVBQ2pCbUQsS0FBSyxDQUFDQyxTQUFTO0FBQ2QsVUFBSUYsYUFBYVEsTUFBTUMsUUFBUVAsSUFBSSxHQUFHO0FBQ3BDZixvQkFBWWUsSUFBSTtBQUNoQnZDLDBCQUFrQnVDLElBQUk7QUFBQSxNQUN4QjtBQUFBLElBQ0YsQ0FBQyxFQUNBSSxNQUFNLENBQUNJLFFBQVE7QUFDZEMsY0FBUUMsS0FBSywyREFBMkRGLEdBQUc7QUFBQSxJQUM3RSxDQUFDLEVBQ0FILFFBQVEsTUFBTTtBQUNiLFVBQUlQLFVBQVdYLHNCQUFxQixLQUFLO0FBQUEsSUFDM0MsQ0FBQztBQUVILFdBQU8sTUFBTTtBQUNYVyxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUdMLFFBQU1hLG9CQUFvQixPQUFPQyxZQUFZO0FBQzNDLFVBQU1DLFNBQVNDLFFBQVF0QixnQkFBZ0J1QixhQUFhdkIsZ0JBQWdCd0IsU0FBUztBQUM3RSxVQUFNQyxXQUFXekIsZ0JBQWdCdUIsYUFBYXZCLGdCQUFnQndCO0FBRTlEdkIsc0JBQWtCLElBQUk7QUFFdEIsUUFBSW9CLFFBQVE7QUFDVixVQUFJO0FBQ0YsY0FBTUssYUFBYSxNQUFNcEUsb0JBQW9CbUUsVUFBVUwsT0FBTztBQUM5RCxjQUFNTyxTQUFTLEVBQUUsR0FBR1AsU0FBUyxHQUFJTSxjQUFjLENBQUMsR0FBSUgsV0FBV0UsU0FBUztBQUN4RWhDLG9CQUFZLENBQUNpQixTQUFTOUMsa0JBQWtCOEMsTUFBTWUsVUFBVUUsTUFBTSxDQUFDO0FBQy9EeEQsNEJBQW9Cc0QsVUFBVUUsTUFBTTtBQUNwQ3hCLG9CQUFZLEVBQUV5QixNQUFNLFFBQVFwQixNQUFNbUIsT0FBTyxDQUFDO0FBQUEsTUFDNUMsU0FBU1gsS0FBSztBQUNaQyxnQkFBUVksTUFBTSw2QkFBNkJiLEdBQUc7QUFDOUM5RCxjQUFNLHFEQUFxRDtBQUFBLE1BQzdEO0FBQUEsSUFDRixPQUFPO0FBQ0wsVUFBSTtBQUNGLGNBQU00RSxZQUFZLE1BQU16RSxvQkFBb0IrRCxPQUFPO0FBQ25ELGNBQU1XLGFBQWE7QUFBQSxVQUNqQixHQUFHWDtBQUFBQSxVQUNILEdBQUlVLGFBQWEsQ0FBQztBQUFBLFVBQ2xCUCxXQUFXTyxXQUFXUCxhQUFhUyxLQUFLQyxJQUFJO0FBQUEsUUFDOUM7QUFDQXhDLG9CQUFZLENBQUNpQixTQUFTL0MsZUFBZStDLE1BQU1xQixVQUFVLENBQUM7QUFDdEQ3RCx5QkFBaUI2RCxVQUFVO0FBQzNCNUIsb0JBQVksRUFBRXlCLE1BQU0sVUFBVXBCLE1BQU11QixXQUFXLENBQUM7QUFBQSxNQUNsRCxTQUFTZixLQUFLO0FBQ1pDLGdCQUFRWSxNQUFNLDZCQUE2QmIsR0FBRztBQUM5QzlELGNBQU0scURBQXFEO0FBQUEsTUFDN0Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1nRixzQkFBc0JBLENBQUNYLGNBQWM7QUFDekNsQix1QkFBbUJrQixTQUFTO0FBQUEsRUFDOUI7QUFFQSxRQUFNWSxzQkFBc0IsWUFBWTtBQUN0QyxRQUFJLENBQUMvQixnQkFBaUI7QUFDdEIsVUFBTXFCLFdBQVdyQjtBQUNqQkMsdUJBQW1CLElBQUk7QUFFdkIsUUFBSTtBQUNGLFlBQU05QyxvQkFBb0JrRSxRQUFRO0FBQ2xDaEMsa0JBQVksQ0FBQ2lCLFNBQVM3QyxrQkFBa0I2QyxNQUFNZSxRQUFRLENBQUM7QUFDdkRyRCwwQkFBb0JxRCxRQUFRO0FBQzVCdkUsWUFBTSx5QkFBeUIsU0FBUztBQUFBLElBQzFDLFNBQVM4RCxLQUFLO0FBQ1pDLGNBQVFZLE1BQU0sNkJBQTZCYixHQUFHO0FBQzlDOUQsWUFBTSxvREFBb0QsT0FBTztBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRDQUViO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUVQLHVCQUFDLFVBQUssV0FBVSxpREFFZDtBQUFBLDZCQUFDLG1CQUFnQixVQUFVaUMsY0FBY1AsUUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QztBQUFBLE1BRzlDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTTztBQUFBQSxVQUNULFdBQVdHO0FBQUFBLFVBQ1gsZUFBZSxNQUFNYixTQUFTLFVBQVU7QUFBQTtBQUFBLFFBSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc0QztBQUFBLE1BSTVDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsV0FBV3FCO0FBQUFBLFVBQ1gsV0FBVyxNQUFNckIsU0FBUyxrQkFBa0I7QUFBQTtBQUFBLFFBSDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdnRDtBQUFBLE1BSWhEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsV0FBV2lCO0FBQUFBLFVBQ1gsY0FBYyxNQUFNTyxrQkFBa0IsQ0FBQyxDQUFDO0FBQUEsVUFDeEMsZUFBZSxDQUFDbUMsWUFBWW5DLGtCQUFrQm1DLE9BQU87QUFBQSxVQUNyRCxpQkFBaUJGO0FBQUFBO0FBQUFBLFFBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUt1QztBQUFBLFNBeEJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFHQ2xDLGtCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxlQUNFQSxlQUFldUIsYUFBYXZCLGVBQWV3QixZQUN2Q3hCLGlCQUNBO0FBQUEsUUFFTixTQUFTLE1BQU1DLGtCQUFrQixJQUFJO0FBQUEsUUFDckMsUUFBUWtCO0FBQUFBO0FBQUFBLE1BUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTzRCO0FBQUEsSUFLN0JqQixZQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNQSxTQUFTMEI7QUFBQUEsUUFDZixhQUFhMUIsU0FBU007QUFBQUEsUUFDdEIsU0FBUyxNQUFNTCxZQUFZLElBQUk7QUFBQTtBQUFBLE1BSGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdtQztBQUFBLElBS3BDQyxtQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sU0FBUTtBQUFBLFFBQ1IsYUFBWTtBQUFBLFFBQ1osWUFBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLFFBQ1YsV0FBVytCO0FBQUFBLFFBQ1gsVUFBVSxNQUFNOUIsbUJBQW1CLElBQUk7QUFBQTtBQUFBLE1BUHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU8yQztBQUFBLE9BL0QvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0VBO0FBRUo7QUFBQzdCLEdBbE91QkQscUJBQW1CO0FBQUEsVUFDeEIvQixhQUNBQyxPQUFPO0FBQUE7QUFBQSxLQUZGOEI7QUFBbUIsSUFBQThEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJOYXZiYXIiLCJTZXJ2aWNlRm9ybU1vZGFsIiwiRGFzaGJvYXJkSGVhZGVyIiwiU2l0dGVyUHJvZmlsZUNhcmQiLCJSZWNlbnRCb29raW5nc1NlY3Rpb24iLCJNeVNlcnZpY2VzU2VjdGlvbiIsIlNlcnZpY2VGZWVkYmFja01vZGFsIiwiQ29uZmlybU1vZGFsIiwidG9hc3QiLCJmZXRjaFNpdHRlclByb2ZpbGUiLCJmZXRjaFNpdHRlclNlcnZpY2VzIiwiY3JlYXRlU2l0dGVyU2VydmljZSIsInVwZGF0ZVNpdHRlclNlcnZpY2UiLCJkZWxldGVTaXR0ZXJTZXJ2aWNlIiwiZ2V0U2l0dGVyQm9va2luZ3MiLCJyZXNvbHZlSW5pdGlhbFByb2ZpbGUiLCJmb3JtYXRTaXR0ZXJBZGRyZXNzIiwiYWRkU2VydmljZUl0ZW0iLCJ1cGRhdGVTZXJ2aWNlSXRlbSIsImRlbGV0ZVNlcnZpY2VJdGVtIiwiZ2V0Q2FjaGVkUHJvZmlsZSIsInNldENhY2hlZFByb2ZpbGUiLCJnZXRDYWNoZWRTZXJ2aWNlcyIsInNldENhY2hlZFNlcnZpY2VzIiwiYWRkQ2FjaGVkU2VydmljZSIsInVwZGF0ZUNhY2hlZFNlcnZpY2UiLCJyZW1vdmVDYWNoZWRTZXJ2aWNlIiwiZ2V0Q2FjaGVkQm9va2luZ3MiLCJzZXRDYWNoZWRCb29raW5ncyIsIlNpdHRlckRhc2hib2FyZFBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwidXNlciIsImRlZmF1bHRQcm9maWxlIiwibmFtZSIsInVzZXJuYW1lIiwidGVsIiwiYWRkcmVzcyIsImV4cGVyaWVuY2UiLCJyYXRpbmciLCJyZXZpZXdDb3VudCIsInNpdHRlclByb2ZpbGUiLCJzZXRTaXR0ZXJQcm9maWxlIiwiY2FjaGVkIiwiaXNMb2FkaW5nUHJvZmlsZSIsInNldElzTG9hZGluZ1Byb2ZpbGUiLCJzZXJ2aWNlcyIsInNldFNlcnZpY2VzIiwiaXNMb2FkaW5nU2VydmljZXMiLCJzZXRJc0xvYWRpbmdTZXJ2aWNlcyIsImJvb2tpbmdzIiwic2V0Qm9va2luZ3MiLCJpc0xvYWRpbmdCb29raW5ncyIsInNldElzTG9hZGluZ0Jvb2tpbmdzIiwiZWRpdGluZ1NlcnZpY2UiLCJzZXRFZGl0aW5nU2VydmljZSIsImZlZWRiYWNrIiwic2V0RmVlZGJhY2siLCJzZXJ2aWNlVG9EZWxldGUiLCJzZXRTZXJ2aWNlVG9EZWxldGUiLCJpc01vdW50ZWQiLCJ0aGVuIiwiZGF0YSIsImZ1bGxBZGRyZXNzIiwicHJldiIsInVwZGF0ZWQiLCJjYXRjaCIsImZpbmFsbHkiLCJBcnJheSIsImlzQXJyYXkiLCJlcnIiLCJjb25zb2xlIiwid2FybiIsImhhbmRsZVNhdmVTZXJ2aWNlIiwicGF5bG9hZCIsImlzRWRpdCIsIkJvb2xlYW4iLCJzZXJ2aWNlSWQiLCJzZXJ2aWNlaWQiLCJ0YXJnZXRJZCIsInNlcnZlckRhdGEiLCJtZXJnZWQiLCJ0eXBlIiwiZXJyb3IiLCJzYXZlZERhdGEiLCJuZXdTZXJ2aWNlIiwiRGF0ZSIsIm5vdyIsImhhbmRsZURlbGV0ZVNlcnZpY2UiLCJoYW5kbGVDb25maXJtRGVsZXRlIiwic2VydmljZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpdHRlckRhc2hib2FyZFBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHQvQXV0aENvbnRleHQuanN4XCI7XG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL05hdmJhci5qc3hcIjtcbmltcG9ydCBTZXJ2aWNlRm9ybU1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL3NpdHRlci9TZXJ2aWNlRm9ybU1vZGFsLmpzeFwiO1xuaW1wb3J0IERhc2hib2FyZEhlYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL0Rhc2hib2FyZEhlYWRlci5qc3hcIjtcbmltcG9ydCBTaXR0ZXJQcm9maWxlQ2FyZCBmcm9tIFwiLi4vY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL1NpdHRlclByb2ZpbGVDYXJkLmpzeFwiO1xuaW1wb3J0IFJlY2VudEJvb2tpbmdzU2VjdGlvbiBmcm9tIFwiLi4vY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL1JlY2VudEJvb2tpbmdzU2VjdGlvbi5qc3hcIjtcbmltcG9ydCBNeVNlcnZpY2VzU2VjdGlvbiBmcm9tIFwiLi4vY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL015U2VydmljZXNTZWN0aW9uLmpzeFwiO1xuaW1wb3J0IFNlcnZpY2VGZWVkYmFja01vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL3NpdHRlci9kYXNoYm9hcmQvU2VydmljZUZlZWRiYWNrTW9kYWwuanN4XCI7XG5pbXBvcnQgQ29uZmlybU1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0NvbmZpcm1Nb2RhbC5qc3hcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcIi4uL3V0aWxzL3RvYXN0LmpzXCI7XG5pbXBvcnQge1xuICBmZXRjaFNpdHRlclByb2ZpbGUsXG4gIGZldGNoU2l0dGVyU2VydmljZXMsXG4gIGNyZWF0ZVNpdHRlclNlcnZpY2UsXG4gIHVwZGF0ZVNpdHRlclNlcnZpY2UsXG4gIGRlbGV0ZVNpdHRlclNlcnZpY2UsXG59IGZyb20gXCIuLi9zZXJ2aWNlcy9zaXR0ZXJTZXJ2aWNlLmpzXCI7XG5pbXBvcnQgeyBnZXRTaXR0ZXJCb29raW5ncyB9IGZyb20gXCIuLi9zZXJ2aWNlcy9ib29raW5nLmFwaVwiO1xuaW1wb3J0IHtcbiAgcmVzb2x2ZUluaXRpYWxQcm9maWxlLFxuICBmb3JtYXRTaXR0ZXJBZGRyZXNzLFxuICBhZGRTZXJ2aWNlSXRlbSxcbiAgdXBkYXRlU2VydmljZUl0ZW0sXG4gIGRlbGV0ZVNlcnZpY2VJdGVtLFxufSBmcm9tIFwiLi4vdXRpbHMvc2l0dGVyRGFzaGJvYXJkTG9naWMuanNcIjtcbmltcG9ydCB7XG4gIGdldENhY2hlZFByb2ZpbGUsXG4gIHNldENhY2hlZFByb2ZpbGUsXG4gIGdldENhY2hlZFNlcnZpY2VzLFxuICBzZXRDYWNoZWRTZXJ2aWNlcyxcbiAgYWRkQ2FjaGVkU2VydmljZSxcbiAgdXBkYXRlQ2FjaGVkU2VydmljZSxcbiAgcmVtb3ZlQ2FjaGVkU2VydmljZSxcbiAgZ2V0Q2FjaGVkQm9va2luZ3MsXG4gIHNldENhY2hlZEJvb2tpbmdzLFxufSBmcm9tIFwiLi4vdXRpbHMvY2FjaGUvc2l0dGVyQ2FjaGUuanNcIjtcblxuLyoqXG4gKiBTaXR0ZXJEYXNoYm9hcmRQYWdlXG4gKlxuICogQ29tcG9uZW50LWRyaXZlbiBTaXR0ZXIgRGFzaGJvYXJkOlxuICogLSBTdGF0ZSBhbmQgTGlmZWN5Y2xlIGFyZSBjby1sb2NhdGVkIHJpZ2h0IGhlcmUgKHJlYWRhYmxlIGZyb20gdG9wIHRvIGJvdHRvbSkuXG4gKiAtIEluc3RhbnQgcGFnZSB0cmFuc2l0aW9ucyB1c2luZyBJbi1NZW1vcnkgQ2FjaGUgKDBtcyByZW5kZXIgb24gcmUtZW50cnkpLlxuICogLSBCYWNrZ3JvdW5kIHJldmFsaWRhdGlvbiB1cGRhdGVzIGNhY2hlIHNpbGVudGx5LlxuICogLSBSZWFsIEFQSSBjYWxscyBhcmUgaGFuZGxlZCB2aWEgYHNlcnZpY2VzL3NpdHRlclNlcnZpY2UuanNgIGFuZCBgc2VydmljZXMvYm9va2luZy5hcGkudHNgLlxuICogLSBQdXJlIGFycmF5IHRyYW5zZm9ybWF0aW9ucyBhcmUgaGFuZGxlZCB2aWEgYHV0aWxzL3NpdHRlckRhc2hib2FyZExvZ2ljLmpzYC5cbiAqIC0gUmVhZC1vbmx5IHBlbmRpbmcgYm9va2luZ3MgcHJldmlldyByZWRpcmVjdHMgdG8gYC9zaXR0ZXIvYm9va2luZ3NgIGZvciBhY3Rpb25zLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaXR0ZXJEYXNoYm9hcmRQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuXG4gIC8vIDEuIFNpdHRlciBQcm9maWxlIFN0YXRlIChJbml0aWFsaXplZCBmcm9tIGNhY2hlIGZvciBpbnN0YW50IDBtcyB0cmFuc2l0aW9ucylcbiAgY29uc3QgZGVmYXVsdFByb2ZpbGUgPSB7XG4gICAgbmFtZTogdXNlcj8udXNlcm5hbWUgfHwgXCLguJ7guLXguYjguYDguKXguLXguYnguKLguIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIdcIixcbiAgICB1c2VybmFtZTogdXNlcj8udXNlcm5hbWUgfHwgXCJzaXR0ZXJcIixcbiAgICB0ZWw6IHVzZXI/LnRlbCB8fCBcIlwiLFxuICAgIGFkZHJlc3M6IHVzZXI/LmFkZHJlc3MgfHwgXCJcIixcbiAgICBleHBlcmllbmNlOiB1c2VyPy5leHBlcmllbmNlIHx8IFwiXCIsXG4gICAgcmF0aW5nOiA1LjAsXG4gICAgcmV2aWV3Q291bnQ6IDAsXG4gIH07XG5cbiAgY29uc3QgW3NpdHRlclByb2ZpbGUsIHNldFNpdHRlclByb2ZpbGVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGNvbnN0IGNhY2hlZCA9IGdldENhY2hlZFByb2ZpbGUoKTtcbiAgICBpZiAoY2FjaGVkKSByZXR1cm4gY2FjaGVkO1xuICAgIHJldHVybiByZXNvbHZlSW5pdGlhbFByb2ZpbGUodXNlciwgZGVmYXVsdFByb2ZpbGUpO1xuICB9KTtcbiAgY29uc3QgW2lzTG9hZGluZ1Byb2ZpbGUsIHNldElzTG9hZGluZ1Byb2ZpbGVdID0gdXNlU3RhdGUoKCkgPT4gIWdldENhY2hlZFByb2ZpbGUoKSk7XG5cbiAgLy8gMi4gU2VydmljZXMgTGlzdCBTdGF0ZSAoSW5pdGlhbGl6ZWQgZnJvbSBjYWNoZSBmb3IgaW5zdGFudCAwbXMgdHJhbnNpdGlvbnMpXG4gIGNvbnN0IFtzZXJ2aWNlcywgc2V0U2VydmljZXNdID0gdXNlU3RhdGUoKCkgPT4gZ2V0Q2FjaGVkU2VydmljZXMoKSB8fCBbXSk7XG4gIGNvbnN0IFtpc0xvYWRpbmdTZXJ2aWNlcywgc2V0SXNMb2FkaW5nU2VydmljZXNdID0gdXNlU3RhdGUoKCkgPT4gIWdldENhY2hlZFNlcnZpY2VzKCkpO1xuXG4gIC8vIDMuIEJvb2tpbmdzIExpc3QgU3RhdGUgKEluaXRpYWxpemVkIGZyb20gY2FjaGUgZm9yIGluc3RhbnQgMG1zIHRyYW5zaXRpb25zKVxuICBjb25zdCBbYm9va2luZ3MsIHNldEJvb2tpbmdzXSA9IHVzZVN0YXRlKCgpID0+IGdldENhY2hlZEJvb2tpbmdzKCkgfHwgW10pO1xuICBjb25zdCBbaXNMb2FkaW5nQm9va2luZ3MsIHNldElzTG9hZGluZ0Jvb2tpbmdzXSA9IHVzZVN0YXRlKCgpID0+ICFnZXRDYWNoZWRCb29raW5ncygpKTtcblxuICAvLyA0LiBTZXJ2aWNlIE1vZGFscyBTdGF0ZSAoQ28tbG9jYXRlZCwgdW5pZmllZCBzdGF0ZXMg4oCUIG5vIGZsYWcgZXhwbG9zaW9uISlcbiAgLy8gbnVsbCA9IG1vZGFsIGNsb3NlZCwge30gPSBhZGQgbmV3LCB7IHNlcnZpY2VJZDogLi4uIH0gPSBlZGl0XG4gIGNvbnN0IFtlZGl0aW5nU2VydmljZSwgc2V0RWRpdGluZ1NlcnZpY2VdID0gdXNlU3RhdGUobnVsbCk7XG4gIC8vIG51bGwgPSBmZWVkYmFjayBjbG9zZWQsIHsgdHlwZTogJ2NyZWF0ZSd8J2VkaXQnLCBkYXRhOiAuLi4gfSA9IGZlZWRiYWNrIG9wZW5cbiAgY29uc3QgW2ZlZWRiYWNrLCBzZXRGZWVkYmFja10gPSB1c2VTdGF0ZShudWxsKTtcbiAgLy8gbnVsbCA9IGNvbmZpcm0gbW9kYWwgY2xvc2VkLCBzZXJ2aWNlSWQgPSBvcGVuIGRlbGV0ZSBjb25maXJtYXRpb25cbiAgY29uc3QgW3NlcnZpY2VUb0RlbGV0ZSwgc2V0U2VydmljZVRvRGVsZXRlXSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIC8vIDUuIEZldGNoIFByb2ZpbGUsIEJvb2tpbmdzICYgU2VydmljZXMgb24gTW91bnQgKEJhY2tncm91bmQgUmV2YWxpZGF0aW9uKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBpc01vdW50ZWQgPSB0cnVlO1xuXG4gICAgLy8gRmV0Y2ggcHJvZmlsZVxuICAgIGZldGNoU2l0dGVyUHJvZmlsZSgpXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICBpZiAoZGF0YSAmJiBpc01vdW50ZWQpIHtcbiAgICAgICAgICBjb25zdCBmdWxsQWRkcmVzcyA9IGZvcm1hdFNpdHRlckFkZHJlc3MoZGF0YSk7XG4gICAgICAgICAgc2V0U2l0dGVyUHJvZmlsZSgocHJldikgPT4ge1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgbmFtZTogZGF0YS51c2VybmFtZSB8fCBwcmV2Lm5hbWUsXG4gICAgICAgICAgICAgIHVzZXJuYW1lOiBkYXRhLnVzZXJuYW1lIHx8IHByZXYudXNlcm5hbWUsXG4gICAgICAgICAgICAgIHRlbDogZGF0YS50ZWwgfHwgcHJldi50ZWwsXG4gICAgICAgICAgICAgIGFkZHJlc3M6IGZ1bGxBZGRyZXNzIHx8IHByZXYuYWRkcmVzcyxcbiAgICAgICAgICAgICAgZXhwZXJpZW5jZTogZGF0YS5leHBlcmllbmNlIHx8IHByZXYuZXhwZXJpZW5jZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzZXRDYWNoZWRQcm9maWxlKHVwZGF0ZWQpO1xuICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge30pXG4gICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgIGlmIChpc01vdW50ZWQpIHNldElzTG9hZGluZ1Byb2ZpbGUoZmFsc2UpO1xuICAgICAgfSk7XG5cbiAgICAvLyBGZXRjaCBib29raW5ncyAoR0VUIC9hcGkvc2l0dGVyL2Jvb2tpbmdzKVxuICAgIGdldFNpdHRlckJvb2tpbmdzKClcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgIGlmIChpc01vdW50ZWQgJiYgQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgICAgICAgIHNldEJvb2tpbmdzKGRhdGEpO1xuICAgICAgICAgIHNldENhY2hlZEJvb2tpbmdzKGRhdGEpO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS53YXJuKFwiTm90aWNlOiAvYXBpL3NpdHRlci9ib29raW5ncyB1bnJlYWNoYWJsZSBvciBvZmZsaW5lOlwiLCBlcnIpO1xuICAgICAgfSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgaWYgKGlzTW91bnRlZCkgc2V0SXNMb2FkaW5nQm9va2luZ3MoZmFsc2UpO1xuICAgICAgfSk7XG5cbiAgICAvLyBGZXRjaCBzZXJ2aWNlcyAoR0VUIC9hcGkvc2l0dGVyL3NlcnZpY2VzL21lKVxuICAgIGZldGNoU2l0dGVyU2VydmljZXMoKVxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgaWYgKGlzTW91bnRlZCAmJiBBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgc2V0U2VydmljZXMoZGF0YSk7XG4gICAgICAgICAgc2V0Q2FjaGVkU2VydmljZXMoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLndhcm4oXCJOb3RpY2U6IC9hcGkvc2l0dGVyL3NlcnZpY2VzL21lIHVucmVhY2hhYmxlIG9yIG9mZmxpbmU6XCIsIGVycik7XG4gICAgICB9KVxuICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICBpZiAoaXNNb3VudGVkKSBzZXRJc0xvYWRpbmdTZXJ2aWNlcyhmYWxzZSk7XG4gICAgICB9KTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpc01vdW50ZWQgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgLy8gNi4gU2VydmljZSBDUlVEIEhhbmRsZXJzXG4gIGNvbnN0IGhhbmRsZVNhdmVTZXJ2aWNlID0gYXN5bmMgKHBheWxvYWQpID0+IHtcbiAgICBjb25zdCBpc0VkaXQgPSBCb29sZWFuKGVkaXRpbmdTZXJ2aWNlPy5zZXJ2aWNlSWQgfHwgZWRpdGluZ1NlcnZpY2U/LnNlcnZpY2VpZCk7XG4gICAgY29uc3QgdGFyZ2V0SWQgPSBlZGl0aW5nU2VydmljZT8uc2VydmljZUlkIHx8IGVkaXRpbmdTZXJ2aWNlPy5zZXJ2aWNlaWQ7XG5cbiAgICBzZXRFZGl0aW5nU2VydmljZShudWxsKTsgLy8gQ2xvc2UgZm9ybSBtb2RhbCBpbW1lZGlhdGVseVxuXG4gICAgaWYgKGlzRWRpdCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc2VydmVyRGF0YSA9IGF3YWl0IHVwZGF0ZVNpdHRlclNlcnZpY2UodGFyZ2V0SWQsIHBheWxvYWQpO1xuICAgICAgICBjb25zdCBtZXJnZWQgPSB7IC4uLnBheWxvYWQsIC4uLihzZXJ2ZXJEYXRhIHx8IHt9KSwgc2VydmljZUlkOiB0YXJnZXRJZCB9O1xuICAgICAgICBzZXRTZXJ2aWNlcygocHJldikgPT4gdXBkYXRlU2VydmljZUl0ZW0ocHJldiwgdGFyZ2V0SWQsIG1lcmdlZCkpO1xuICAgICAgICB1cGRhdGVDYWNoZWRTZXJ2aWNlKHRhcmdldElkLCBtZXJnZWQpO1xuICAgICAgICBzZXRGZWVkYmFjayh7IHR5cGU6IFwiZWRpdFwiLCBkYXRhOiBtZXJnZWQgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgc2VydmljZTpcIiwgZXJyKTtcbiAgICAgICAgdG9hc3QoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJTguYPguJnguIHguLLguKPguYHguIHguYnguYTguILguJrguKPguLTguIHguLLguKMg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBzYXZlZERhdGEgPSBhd2FpdCBjcmVhdGVTaXR0ZXJTZXJ2aWNlKHBheWxvYWQpO1xuICAgICAgICBjb25zdCBuZXdTZXJ2aWNlID0ge1xuICAgICAgICAgIC4uLnBheWxvYWQsXG4gICAgICAgICAgLi4uKHNhdmVkRGF0YSB8fCB7fSksXG4gICAgICAgICAgc2VydmljZUlkOiBzYXZlZERhdGE/LnNlcnZpY2VJZCB8fCBEYXRlLm5vdygpLFxuICAgICAgICB9O1xuICAgICAgICBzZXRTZXJ2aWNlcygocHJldikgPT4gYWRkU2VydmljZUl0ZW0ocHJldiwgbmV3U2VydmljZSkpO1xuICAgICAgICBhZGRDYWNoZWRTZXJ2aWNlKG5ld1NlcnZpY2UpO1xuICAgICAgICBzZXRGZWVkYmFjayh7IHR5cGU6IFwiY3JlYXRlXCIsIGRhdGE6IG5ld1NlcnZpY2UgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBjcmVhdGUgc2VydmljZTpcIiwgZXJyKTtcbiAgICAgICAgdG9hc3QoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJTguYPguJnguIHguLLguKPguKrguKPguYnguLLguIfguJrguKPguLTguIHguLLguKMg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVTZXJ2aWNlID0gKHNlcnZpY2VJZCkgPT4ge1xuICAgIHNldFNlcnZpY2VUb0RlbGV0ZShzZXJ2aWNlSWQpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm1EZWxldGUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZXJ2aWNlVG9EZWxldGUpIHJldHVybjtcbiAgICBjb25zdCB0YXJnZXRJZCA9IHNlcnZpY2VUb0RlbGV0ZTtcbiAgICBzZXRTZXJ2aWNlVG9EZWxldGUobnVsbCk7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgZGVsZXRlU2l0dGVyU2VydmljZSh0YXJnZXRJZCk7XG4gICAgICBzZXRTZXJ2aWNlcygocHJldikgPT4gZGVsZXRlU2VydmljZUl0ZW0ocHJldiwgdGFyZ2V0SWQpKTtcbiAgICAgIHJlbW92ZUNhY2hlZFNlcnZpY2UodGFyZ2V0SWQpO1xuICAgICAgdG9hc3QoXCLguKXguJrguJrguKPguLTguIHguLLguKPguYDguKPguLXguKLguJrguKPguYnguK3guKLguYHguKXguYnguKdcIiwgXCJzdWNjZXNzXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBkZWxldGUgc2VydmljZTpcIiwgZXJyKTtcbiAgICAgIHRvYXN0KFwi4LmA4LiB4Li04LiU4LiC4LmJ4Lit4Lic4Li04LiU4Lie4Lil4Liy4LiU4LmD4LiZ4LiB4Liy4Lij4Lil4Lia4Lia4Lij4Li04LiB4Liy4LijIOC4geC4o+C4uOC4k+C4suC4peC4reC4h+C5g+C4q+C4oeC5iOC4reC4teC4geC4hOC4o+C4seC5ieC4h1wiLCBcImVycm9yXCIpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLVsjRkZGN0VGXSB0ZXh0LVsjMUYyOTM3XVwiPlxuICAgICAgey8qIFRvcCBNYWluIE5hdmlnYXRpb24gKi99XG4gICAgICA8TmF2YmFyIC8+XG5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cIm1heC13LTV4bCBteC1hdXRvIHNwYWNlLXktNiBwLTQgc206cC02IGxnOnAtOFwiPlxuICAgICAgICB7LyogVG9wIEhlYWRlciAvIFN1Yi1iYW5uZXIgKi99XG4gICAgICAgIDxEYXNoYm9hcmRIZWFkZXIgdXNlcm5hbWU9e3NpdHRlclByb2ZpbGUubmFtZX0gLz5cblxuICAgICAgICB7LyogU2VjdGlvbiAxOiBTaXR0ZXIgUHJvZmlsZSBDYXJkICovfVxuICAgICAgICA8U2l0dGVyUHJvZmlsZUNhcmRcbiAgICAgICAgICBwcm9maWxlPXtzaXR0ZXJQcm9maWxlfVxuICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nUHJvZmlsZX1cbiAgICAgICAgICBvbkVkaXRQcm9maWxlPXsoKSA9PiBuYXZpZ2F0ZShcIi9wcm9maWxlXCIpfVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBTZWN0aW9uIDI6IFJlY2VudCBQZW5kaW5nIEJvb2tpbmdzIFByZXZpZXcgU2VjdGlvbiAoUmVhZC1Pbmx5KSAqL31cbiAgICAgICAgPFJlY2VudEJvb2tpbmdzU2VjdGlvblxuICAgICAgICAgIGJvb2tpbmdzPXtib29raW5nc31cbiAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ0Jvb2tpbmdzfVxuICAgICAgICAgIG9uVmlld0FsbD17KCkgPT4gbmF2aWdhdGUoXCIvc2l0dGVyL2Jvb2tpbmdzXCIpfVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBTZWN0aW9uIDM6IE15IFNlcnZpY2VzIFNlY3Rpb24gKi99XG4gICAgICAgIDxNeVNlcnZpY2VzU2VjdGlvblxuICAgICAgICAgIHNlcnZpY2VzPXtzZXJ2aWNlc31cbiAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ1NlcnZpY2VzfVxuICAgICAgICAgIG9uQWRkU2VydmljZT17KCkgPT4gc2V0RWRpdGluZ1NlcnZpY2Uoe30pfVxuICAgICAgICAgIG9uRWRpdFNlcnZpY2U9eyhzZXJ2aWNlKSA9PiBzZXRFZGl0aW5nU2VydmljZShzZXJ2aWNlKX1cbiAgICAgICAgICBvbkRlbGV0ZVNlcnZpY2U9e2hhbmRsZURlbGV0ZVNlcnZpY2V9XG4gICAgICAgIC8+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBTZXJ2aWNlIEZvcm0gTW9kYWwgKFJlbmRlcmVkIG9ubHkgd2hlbiBlZGl0aW5nU2VydmljZSBpcyBub3QgbnVsbCkgKi99XG4gICAgICB7ZWRpdGluZ1NlcnZpY2UgJiYgKFxuICAgICAgICA8U2VydmljZUZvcm1Nb2RhbFxuICAgICAgICAgIHNlcnZpY2VUb0VkaXQ9e1xuICAgICAgICAgICAgZWRpdGluZ1NlcnZpY2Uuc2VydmljZUlkIHx8IGVkaXRpbmdTZXJ2aWNlLnNlcnZpY2VpZFxuICAgICAgICAgICAgICA/IGVkaXRpbmdTZXJ2aWNlXG4gICAgICAgICAgICAgIDogbnVsbFxuICAgICAgICAgIH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRFZGl0aW5nU2VydmljZShudWxsKX1cbiAgICAgICAgICBvblNhdmU9e2hhbmRsZVNhdmVTZXJ2aWNlfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFNlcnZpY2UgRmVlZGJhY2sgTW9kYWwgKFJlbmRlcmVkIG9ubHkgd2hlbiBmZWVkYmFjayBpcyBub3QgbnVsbCkgKi99XG4gICAgICB7ZmVlZGJhY2sgJiYgKFxuICAgICAgICA8U2VydmljZUZlZWRiYWNrTW9kYWxcbiAgICAgICAgICB0eXBlPXtmZWVkYmFjay50eXBlfVxuICAgICAgICAgIHNlcnZpY2VEYXRhPXtmZWVkYmFjay5kYXRhfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEZlZWRiYWNrKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIENvbmZpcm0gRGVsZXRlIE1vZGFsICovfVxuICAgICAge3NlcnZpY2VUb0RlbGV0ZSAmJiAoXG4gICAgICAgIDxDb25maXJtTW9kYWxcbiAgICAgICAgICB0aXRsZT1cIuC4ouC4t+C4meC4ouC4seC4meC4geC4suC4o+C4peC4muC4muC4o+C4tOC4geC4suC4o1wiXG4gICAgICAgICAgbWVzc2FnZT1cIuC4hOC4uOC4k+C5geC4meC5iOC5g+C4iOC4q+C4o+C4t+C4reC5hOC4oeC5iOC4p+C5iOC4suC4leC5ieC4reC4h+C4geC4suC4o+C4peC4muC4muC4o+C4tOC4geC4suC4o+C4meC4teC5iT8g4Lia4Lij4Li04LiB4Liy4Lij4LiI4Liw4LiW4Li54LiB4LiZ4Liz4Lit4Lit4LiB4LiI4Liy4LiB4Lij4Liy4Lii4LiB4Liy4Lij4LiC4Lit4LiH4LiE4Li44LiTXCJcbiAgICAgICAgICBjb25maXJtVGV4dD1cIuC4peC4muC4muC4o+C4tOC4geC4suC4o1wiXG4gICAgICAgICAgY2FuY2VsVGV4dD1cIuC4ouC4geC5gOC4peC4tOC4gVwiXG4gICAgICAgICAgaXNEYW5nZXI9e3RydWV9XG4gICAgICAgICAgb25Db25maXJtPXtoYW5kbGVDb25maXJtRGVsZXRlfVxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTZXJ2aWNlVG9EZWxldGUobnVsbCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL3BhZ2VzL1NpdHRlckRhc2hib2FyZFBhZ2UuanN4In0=