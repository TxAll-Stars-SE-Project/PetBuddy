import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ForgotPasswordPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { api } from "/src/services/api.js";
import Logo from "/src/components/ui/Logo.jsx";
import TextInput from "/src/components/ui/TextInput.jsx";
import Button from "/src/components/ui/Button.jsx";
import AlertBanner from "/src/components/ui/AlertBanner.jsx";
export default function ForgotPasswordPage() {
  _s();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const onSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) {
      setError("กรุณากรอกอีเมล");
      return;
    }
    setError("");
    setStatus("submitting");
    try {
      await api.post("/auth/forgot-password", { email });
      setSent(true);
    } catch (err) {
      const statusCode = err.response?.status;
      if (statusCode >= 500) {
        setError("เกิดข้อผิดพลาดจากเซิร์ฟเวอร์ กรุณาลองใหม่อีกครั้ง");
      } else {
        setError("เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง");
      }
    } finally {
      setStatus("idle");
    }
  };
  if (sent) {
    return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
      /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "ตรวจสอบอีเมลของคุณ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 63,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AlertBanner, { type: "success", children: "หากอีเมลนี้มีอยู่ในระบบ ลิงก์รีเซ็ตรหัสผ่านจะถูกส่งไปยังอีเมลของคุณ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 64,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "muted", style: { fontSize: 14, marginTop: 12 }, children: "กรุณาตรวจสอบกล่องจดหมาย (และโฟลเดอร์สแปม) แล้วคลิกลิงก์เพื่อตั้งรหัสผ่านใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 16 }, children: /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--aslink", to: "/login", children: "กลับหน้าเข้าสู่ระบบ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 71,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 70,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 60,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
    /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 81,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "ลืมรหัสผ่าน?" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 82,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-sub", children: "กรอกอีเมลของคุณ เราจะส่งลิงก์รีเซ็ตรหัสผ่านให้" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 83,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV(AlertBanner, { type: "error", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 85,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit, noValidate: true, children: [
      /* @__PURE__ */ jsxDEV(
        TextInput,
        {
          label: "อีเมล",
          placeholder: "you@example.com",
          value: email,
          onChange: (e) => setEmail(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
          lineNumber: 88,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", loading: status === "submitting", children: "ส่งลิงก์รีเซ็ตรหัสผ่าน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
        lineNumber: 94,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 87,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-links", children: /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: "กลับสู่หน้าเข้าสู่ระบบ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 100,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
      lineNumber: 99,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
    lineNumber: 80,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s(ForgotPasswordPage, "YBD8tEKMBhlloy+hcjHVDo94MQs=");
_c = ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ForgotPasswordPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFDVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxXQUFXO0FBQ3BCLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGlCQUFpQjtBQUV4Qix3QkFBd0JDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQzNDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJVixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDVyxRQUFRQyxTQUFTLElBQUlaLFNBQVMsTUFBTTtBQUMzQyxRQUFNLENBQUNhLE1BQU1DLE9BQU8sSUFBSWQsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ2UsT0FBT0MsUUFBUSxJQUFJaEIsU0FBUyxFQUFFO0FBRXJDLFFBQU1pQixXQUFXLE9BQU9DLE1BQU07QUFDNUJBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDVixNQUFNVyxLQUFLLEdBQUc7QUFDakJKLGVBQVMsZ0JBQWdCO0FBQ3pCO0FBQUEsSUFDRjtBQUNBQSxhQUFTLEVBQUU7QUFDWEosY0FBVSxZQUFZO0FBRXRCLFFBQUk7QUFDRixZQUFNVixJQUFJbUIsS0FBSyx5QkFBeUIsRUFBRVosTUFBTSxDQUFDO0FBQ2pESyxjQUFRLElBQUk7QUFBQSxJQUNkLFNBQVNRLEtBQUs7QUFDWixZQUFNQyxhQUFhRCxJQUFJRSxVQUFVYjtBQUNqQyxVQUFJWSxjQUFjLEtBQUs7QUFDckJQLGlCQUFTLG1EQUFtRDtBQUFBLE1BQzlELE9BQU87QUFDTEEsaUJBQVMscUNBQXFDO0FBQUEsTUFDaEQ7QUFBQSxJQUNGLFVBQUM7QUFDQ0osZ0JBQVUsTUFBTTtBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLE1BQUlDLE1BQU07QUFDUixXQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUs7QUFBQSxNQUNMLHVCQUFDLFFBQUcsV0FBVSxjQUFhLGtDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDO0FBQUEsTUFDN0MsdUJBQUMsZUFBWSxNQUFLLFdBQVMsbUZBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLFNBQVEsT0FBTyxFQUFFWSxVQUFVLElBQUlDLFdBQVcsR0FBRyxHQUFFLDRGQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFQSxXQUFXLEdBQUcsR0FDMUIsaUNBQUMsUUFBSyxXQUFVLG1CQUFrQixJQUFHLFVBQVMsbUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUUsS0FEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsSUFDTCx1QkFBQyxRQUFHLFdBQVUsY0FBYSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3ZDLHVCQUFDLE9BQUUsV0FBVSxZQUFXLDhEQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNFO0FBQUEsSUFFckVYLFNBQVMsdUJBQUMsZUFBWSxNQUFLLFNBQVNBLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFFM0MsdUJBQUMsVUFBSyxVQUFvQixZQUFVLE1BQ2xDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLGFBQVk7QUFBQSxVQUNaLE9BQU9OO0FBQUFBLFVBQ1AsVUFBVSxDQUFDUyxNQUFNUixTQUFTUSxFQUFFUyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNEM7QUFBQSxNQUU1Qyx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFTakIsV0FBVyxjQUFhLHNDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsUUFBSyxJQUFHLFVBQVMsc0NBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRUo7QUFBQ0gsR0E3RXVCRCxvQkFBa0I7QUFBQSxLQUFsQkE7QUFBa0IsSUFBQXNCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsImFwaSIsIkxvZ28iLCJUZXh0SW5wdXQiLCJCdXR0b24iLCJBbGVydEJhbm5lciIsIkZvcmdvdFBhc3N3b3JkUGFnZSIsIl9zIiwiZW1haWwiLCJzZXRFbWFpbCIsInN0YXR1cyIsInNldFN0YXR1cyIsInNlbnQiLCJzZXRTZW50IiwiZXJyb3IiLCJzZXRFcnJvciIsIm9uU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsInBvc3QiLCJlcnIiLCJzdGF0dXNDb2RlIiwicmVzcG9uc2UiLCJmb250U2l6ZSIsIm1hcmdpblRvcCIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRm9yZ290UGFzc3dvcmRQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpLmpzXCI7XG5pbXBvcnQgTG9nbyBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9Mb2dvLmpzeFwiO1xuaW1wb3J0IFRleHRJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9UZXh0SW5wdXQuanN4XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0J1dHRvbi5qc3hcIjtcbmltcG9ydCBBbGVydEJhbm5lciBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9BbGVydEJhbm5lci5qc3hcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9yZ290UGFzc3dvcmRQYWdlKCkge1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoXCJpZGxlXCIpO1xuICBjb25zdCBbc2VudCwgc2V0U2VudF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWVtYWlsLnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3IoXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguK3guLXguYDguKHguKVcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEVycm9yKFwiXCIpO1xuICAgIHNldFN0YXR1cyhcInN1Ym1pdHRpbmdcIik7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvYXV0aC9mb3Jnb3QtcGFzc3dvcmRcIiwgeyBlbWFpbCB9KTtcbiAgICAgIHNldFNlbnQodHJ1ZSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBzdGF0dXNDb2RlID0gZXJyLnJlc3BvbnNlPy5zdGF0dXM7XG4gICAgICBpZiAoc3RhdHVzQ29kZSA+PSA1MDApIHtcbiAgICAgICAgc2V0RXJyb3IoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJTguIjguLLguIHguYDguIvguLTguKPguYzguJ/guYDguKfguK3guKPguYwg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0RXJyb3IoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJQg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdGF0dXMoXCJpZGxlXCIpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoc2VudCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtcGFnZVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtY2FyZFwiPlxuICAgICAgICAgIDxMb2dvIC8+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImF1dGgtdGl0bGVcIj7guJXguKPguKfguIjguKrguK3guJrguK3guLXguYDguKHguKXguILguK3guIfguITguLjguJM8L2gxPlxuICAgICAgICAgIDxBbGVydEJhbm5lciB0eXBlPVwic3VjY2Vzc1wiPlxuICAgICAgICAgICAg4Lir4Liy4LiB4Lit4Li14LmA4Lih4Lil4LiZ4Li14LmJ4Lih4Li14Lit4Lii4Li54LmI4LmD4LiZ4Lij4Liw4Lia4LiaIOC4peC4tOC4h+C4geC5jOC4o+C4teC5gOC4i+C5h+C4leC4o+C4q+C4seC4quC4nOC5iOC4suC4meC4iOC4sOC4luC4ueC4geC4quC5iOC4h+C5hOC4m+C4ouC4seC4h+C4reC4teC5gOC4oeC4peC4guC4reC4h+C4hOC4uOC4k1xuICAgICAgICAgIDwvQWxlcnRCYW5uZXI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXV0ZWRcIiBzdHlsZT17eyBmb250U2l6ZTogMTQsIG1hcmdpblRvcDogMTIgfX0+XG4gICAgICAgICAgICDguIHguKPguLjguJPguLLguJXguKPguKfguIjguKrguK3guJrguIHguKXguYjguK3guIfguIjguJTguKvguKHguLLguKIgKOC5geC4peC4sOC5guC4n+C4peC5gOC4lOC4reC4o+C5jOC4quC5geC4m+C4oSkg4LmB4Lil4LmJ4Lin4LiE4Lil4Li04LiB4Lil4Li04LiH4LiB4LmM4LmA4Lie4Li34LmI4Lit4LiV4Lix4LmJ4LiH4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4LmD4Lir4Lih4LmIXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAxNiB9fT5cbiAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tLWFzbGlua1wiIHRvPVwiL2xvZ2luXCI+4LiB4Lil4Lix4Lia4Lir4LiZ4LmJ4Liy4LmA4LiC4LmJ4Liy4Liq4Li54LmI4Lij4Liw4Lia4LiaPC9MaW5rPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1wYWdlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtY2FyZFwiPlxuICAgICAgICA8TG9nbyAvPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiYXV0aC10aXRsZVwiPuC4peC4t+C4oeC4o+C4q+C4seC4quC4nOC5iOC4suC4mT88L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN1YlwiPuC4geC4o+C4reC4geC4reC4teC5gOC4oeC4peC4guC4reC4h+C4hOC4uOC4kyDguYDguKPguLLguIjguLDguKrguYjguIfguKXguLTguIfguIHguYzguKPguLXguYDguIvguYfguJXguKPguKvguLHguKrguJzguYjguLLguJnguYPguKvguYk8L3A+XG5cbiAgICAgICAge2Vycm9yICYmIDxBbGVydEJhbm5lciB0eXBlPVwiZXJyb3JcIj57ZXJyb3J9PC9BbGVydEJhbm5lcj59XG5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e29uU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICAgIDxUZXh0SW5wdXRcbiAgICAgICAgICAgIGxhYmVsPVwi4Lit4Li14LmA4Lih4LilXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwieW91QGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgbG9hZGluZz17c3RhdHVzID09PSBcInN1Ym1pdHRpbmdcIn0+XG4gICAgICAgICAgICDguKrguYjguIfguKXguLTguIfguIHguYzguKPguLXguYDguIvguYfguJXguKPguKvguLHguKrguJzguYjguLLguJlcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1saW5rc1wiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCI+4LiB4Lil4Lix4Lia4Liq4Li54LmI4Lir4LiZ4LmJ4Liy4LmA4LiC4LmJ4Liy4Liq4Li54LmI4Lij4Liw4Lia4LiaPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9Gb3Jnb3RQYXNzd29yZFBhZ2UuanN4In0=