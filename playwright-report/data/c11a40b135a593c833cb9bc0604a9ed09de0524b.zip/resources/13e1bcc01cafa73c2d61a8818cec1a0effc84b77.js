import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ConfirmModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ConfirmModal({
  title = "ยืนยันการลบ",
  message = "คุณต้องการดำเนินการนี้ใช่หรือไม่?",
  confirmText = "ยืนยัน",
  cancelText = "ยกเลิก",
  isDanger = true,
  isLoading = false,
  onConfirm,
  onCancel,
  children
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs",
      onClick: onCancel,
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "confirm-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-white rounded-2xl max-w-sm sm:max-w-md w-full p-5 sm:p-6 space-y-4 shadow-2xl border border-slate-200",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3.5", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `w-11 h-11 rounded-xl flex-shrink-0 flex items-center justify-center ${isDanger ? "bg-rose-50 text-rose-600 border border-rose-200" : "bg-amber-50 text-amber-600 border border-amber-200"}`,
                  children: isDanger ? /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                      lineNumber: 73,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                    lineNumber: 72,
                    columnNumber: 13
                  }, this) : /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                      lineNumber: 82,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                    lineNumber: 81,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                  lineNumber: 64,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 flex-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { id: "confirm-modal-title", className: "text-base sm:text-lg font-bold text-slate-900 leading-snug", children: title }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                  lineNumber: 93,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs sm:text-sm text-slate-600 leading-relaxed", children: message }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                  lineNumber: 96,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                lineNumber: 92,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
              lineNumber: 63,
              columnNumber: 9
            }, this),
            children,
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onCancel,
                  disabled: isLoading,
                  className: "px-4 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-bold transition-all cursor-pointer disabled:opacity-50",
                  children: cancelText
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                  lineNumber: 106,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onConfirm,
                  disabled: isLoading,
                  className: `px-4 py-2.5 rounded-xl text-white text-xs sm:text-sm font-bold transition-all shadow-xs cursor-pointer disabled:opacity-50 flex items-center gap-1.5 ${isDanger ? "bg-rose-600 hover:bg-rose-700" : "bg-[#0F766E] hover:bg-[#115E59]"}`,
                  children: isLoading ? "กำลังดำเนินการ..." : confirmText
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
                  lineNumber: 114,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
              lineNumber: 105,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
          lineNumber: 58,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
}
_c = ConfirmModal;
var _c;
$RefreshReg$(_c, "ConfirmModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ConfirmModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURnQjs7Ozs7Ozs7Ozs7Ozs7OztBQXJEaEIsT0FBT0EsV0FBVztBQW1CbEIsd0JBQXdCQyxhQUFhO0FBQUEsRUFDbkNDLFFBQVE7QUFBQSxFQUNSQyxVQUFVO0FBQUEsRUFDVkMsY0FBYztBQUFBLEVBQ2RDLGFBQWE7QUFBQSxFQUNiQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLFNBQVNEO0FBQUFBLE1BQ1QsTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsbUJBQWdCO0FBQUEsTUFFaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsQ0FBQ0UsTUFBTUEsRUFBRUMsZ0JBQWdCO0FBQUEsVUFHbEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHVFQUNUTixXQUNJLG9EQUNBLG9EQUFvRDtBQUFBLGtCQUd6REEscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxlQUFjO0FBQUEsc0JBQ2QsZ0JBQWU7QUFBQSxzQkFDZixhQUFZO0FBQUEsc0JBQ1osR0FBRTtBQUFBO0FBQUEsb0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlrSSxLQUxwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BLElBRUEsdUJBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxlQUFjO0FBQUEsc0JBQ2QsZ0JBQWU7QUFBQSxzQkFDZixhQUFZO0FBQUEsc0JBQ1osR0FBRTtBQUFBO0FBQUEsb0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUkwSSxLQUw1STtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUE7QUFBQSxnQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMEJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSx1Q0FBQyxRQUFHLElBQUcsdUJBQXNCLFdBQVUsOERBQ3BDSixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHFEQUNWQyxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFDQTtBQUFBLFlBRUNPO0FBQUFBLFlBR0QsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVNEO0FBQUFBLGtCQUNULFVBQVVGO0FBQUFBLGtCQUNWLFdBQVU7QUFBQSxrQkFFVEY7QUFBQUE7QUFBQUEsZ0JBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTRztBQUFBQSxrQkFDVCxVQUFVRDtBQUFBQSxrQkFDVixXQUFXLHdKQUNURCxXQUNJLGtDQUNBLGlDQUFpQztBQUFBLGtCQUd0Q0Msc0JBQVksc0JBQXNCSDtBQUFBQTtBQUFBQSxnQkFWckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQTtBQUFBO0FBQUEsUUFwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUVBO0FBQUE7QUFBQSxJQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE2RUE7QUFFSjtBQUFDUyxLQTNGdUJaO0FBQVksSUFBQVk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJDb25maXJtTW9kYWwiLCJ0aXRsZSIsIm1lc3NhZ2UiLCJjb25maXJtVGV4dCIsImNhbmNlbFRleHQiLCJpc0RhbmdlciIsImlzTG9hZGluZyIsIm9uQ29uZmlybSIsIm9uQ2FuY2VsIiwiY2hpbGRyZW4iLCJlIiwic3RvcFByb3BhZ2F0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29uZmlybU1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogQ29uZmlybU1vZGFsIENvbXBvbmVudFxuICogXG4gKiBSZXVzYWJsZSBtb2RhbCBkaWFsb2cgZm9yIGNvbmZpcm1pbmcgY3JpdGljYWwgYWN0aW9ucyAoZS5nLiBEZWxldGUpLlxuICogUmVwbGFjZXMgbmF0aXZlIGJyb3dzZXIgd2luZG93LmNvbmZpcm0gd2l0aCBhIG1vZGVybiwgUGV0QnVkZHktc3R5bGVkIGRpYWxvZy5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLnRpdGxlPVwi4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4Lil4LiaXCJdIC0gTW9kYWwgdGl0bGUuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLm1lc3NhZ2U9XCLguITguLjguJPguJXguYnguK3guIfguIHguLLguKPguJTguLPguYDguJnguLTguJnguIHguLLguKPguJnguLXguYnguYPguIrguYjguKvguKPguLfguK3guYTguKHguYg/XCJdIC0gQ29uZmlybWF0aW9uIG1lc3NhZ2UuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmNvbmZpcm1UZXh0PVwi4Lii4Li34LiZ4Lii4Lix4LiZXCJdIC0gQ29uZmlybSBidXR0b24gbGFiZWwuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmNhbmNlbFRleHQ9XCLguKLguIHguYDguKXguLTguIFcIl0gLSBDYW5jZWwgYnV0dG9uIGxhYmVsLlxuICogQHBhcmFtIHtib29sZWFufSBbcHJvcHMuaXNEYW5nZXI9dHJ1ZV0gLSBXaGV0aGVyIHRoaXMgaXMgYSBkZXN0cnVjdGl2ZSBhY3Rpb24gKHJlbmRlcnMgcmVkIGNvbmZpcm0gYnV0dG9uKS5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW3Byb3BzLmlzTG9hZGluZz1mYWxzZV0gLSBXaGV0aGVyIGNvbmZpcm1hdGlvbiBpcyBjdXJyZW50bHkgcHJvY2Vzc2luZy5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ29uZmlybSAtIENhbGxiYWNrIHdoZW4gdXNlciBjb25maXJtcy5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2FuY2VsIC0gQ2FsbGJhY2sgd2hlbiB1c2VyIGNhbmNlbHMgb3IgY2xvc2VzLlxuICogQHBhcmFtIHtSZWFjdC5SZWFjdE5vZGV9IFtwcm9wcy5jaGlsZHJlbl0gLSBPcHRpb25hbCBleHRyYSBjb250ZW50IChlLmcuIGEgc3VtbWFyeSBvciBub3RpY2UpIHNob3duIGJldHdlZW4gdGhlIG1lc3NhZ2UgYW5kIHRoZSBidXR0b25zLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb25maXJtTW9kYWwoe1xuICB0aXRsZSA9IFwi4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4Lil4LiaXCIsXG4gIG1lc3NhZ2UgPSBcIuC4hOC4uOC4k+C4leC5ieC4reC4h+C4geC4suC4o+C4lOC4s+C5gOC4meC4tOC4meC4geC4suC4o+C4meC4teC5ieC5g+C4iuC5iOC4q+C4o+C4t+C4reC5hOC4oeC5iD9cIixcbiAgY29uZmlybVRleHQgPSBcIuC4ouC4t+C4meC4ouC4seC4mVwiLFxuICBjYW5jZWxUZXh0ID0gXCLguKLguIHguYDguKXguLTguIFcIixcbiAgaXNEYW5nZXIgPSB0cnVlLFxuICBpc0xvYWRpbmcgPSBmYWxzZSxcbiAgb25Db25maXJtLFxuICBvbkNhbmNlbCxcbiAgY2hpbGRyZW4sXG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1zbGF0ZS05MDAvNTAgYmFja2Ryb3AtYmx1ci14c1wiXG4gICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cbiAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwiY29uZmlybS1tb2RhbC10aXRsZVwiXG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBtYXgtdy1zbSBzbTptYXgtdy1tZCB3LWZ1bGwgcC01IHNtOnAtNiBzcGFjZS15LTQgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICB7LyogSGVhZGVyIHdpdGggSWNvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zLjVcIj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LTExIGgtMTEgcm91bmRlZC14bCBmbGV4LXNocmluay0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICR7XG4gICAgICAgICAgICAgIGlzRGFuZ2VyXG4gICAgICAgICAgICAgICAgPyBcImJnLXJvc2UtNTAgdGV4dC1yb3NlLTYwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwXCJcbiAgICAgICAgICAgICAgICA6IFwiYmctYW1iZXItNTAgdGV4dC1hbWJlci02MDAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDBcIlxuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2lzRGFuZ2VyID8gKFxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNMTkgN2wtLjg2NyAxMi4xNDJBMiAyIDAgMDExNi4xMzggMjFINy44NjJhMiAyIDAgMDEtMS45OTUtMS44NThMNSA3bTUgNHY2bTQtNnY2bTEtMTBWNGExIDEgMCAwMC0xLTFoLTRhMSAxIDAgMDAtMSAxdjNNNCA3aDE2XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgICAgICAgICAgZD1cIk0xMiA5djJtMCA0aC4wMW0tNi45MzggNGgxMy44NTZjMS41NCAwIDIuNTAyLTEuNjY3IDEuNzMyLTNMMTMuNzMyIDRjLS43Ny0xLjMzMy0yLjY5NC0xLjMzMy0zLjQ2NCAwTDMuMzQgMTZjLS43NyAxLjMzMy4xOTIgMyAxLjczMiAzelwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgZmxleC0xXCI+XG4gICAgICAgICAgICA8aDMgaWQ9XCJjb25maXJtLW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGxlYWRpbmctc251Z1wiPlxuICAgICAgICAgICAgICB7dGl0bGV9XG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2NoaWxkcmVufVxuXG4gICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMi41IHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25DYW5jZWx9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBiZy13aGl0ZSBob3ZlcjpiZy1zbGF0ZS01MCB0ZXh0LXNsYXRlLTcwMCB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtjYW5jZWxUZXh0fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25Db25maXJtfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMi41IHJvdW5kZWQteGwgdGV4dC13aGl0ZSB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHNoYWRvdy14cyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcbiAgICAgICAgICAgICAgaXNEYW5nZXJcbiAgICAgICAgICAgICAgICA/IFwiYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS03MDBcIlxuICAgICAgICAgICAgICAgIDogXCJiZy1bIzBGNzY2RV0gaG92ZXI6YmctWyMxMTVFNTldXCJcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc0xvYWRpbmcgPyBcIuC4geC4s+C4peC4seC4h+C4lOC4s+C5gOC4meC4tOC4meC4geC4suC4oy4uLlwiIDogY29uZmlybVRleHR9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9Db25maXJtTW9kYWwuanN4In0=