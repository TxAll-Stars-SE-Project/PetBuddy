import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/payment/SlipUploadZone.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
export default function SlipUploadZone({
  selectedFile,
  previewUrl,
  onFileSelect,
  onRemoveFile
}) {
  _s();
  const fileInputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const selectFile = (file) => {
    if (file) onFileSelect(file);
  };
  const handleFileChange = (event) => {
    selectFile(event.target.files?.[0]);
    event.target.value = "";
  };
  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    selectFile(event.dataTransfer.files?.[0]);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "payment-slip-zone", children: [
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: fileInputRef,
        className: "payment-file-input",
        type: "file",
        accept: "image/jpeg,image/png,image/webp",
        onChange: handleFileChange,
        "aria-label": "เลือกรูปสลิปการชำระเงิน"
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
        lineNumber: 49,
        columnNumber: 7
      },
      this
    ),
    selectedFile && previewUrl ? /* @__PURE__ */ jsxDEV("div", { className: "payment-slip-preview", children: [
      /* @__PURE__ */ jsxDEV("img", { src: previewUrl, alt: "ตัวอย่างสลิปการชำระเงิน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
        lineNumber: 59,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "payment-slip-actions", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "payment-secondary-button",
            onClick: () => fileInputRef.current?.click(),
            children: "เปลี่ยนรูป"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
            lineNumber: 61,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "payment-remove-button", onClick: onRemoveFile, children: "ลบรูป" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
          lineNumber: 68,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
        lineNumber: 60,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
      lineNumber: 58,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: `payment-dropzone${isDragging ? " payment-dropzone--dragging" : ""}`,
        onClick: () => fileInputRef.current?.click(),
        onDragOver: (event) => {
          event.preventDefault();
          setIsDragging(true);
        },
        onDragLeave: (event) => {
          event.preventDefault();
          setIsDragging(false);
        },
        onDrop: handleDrop,
        children: [
          /* @__PURE__ */ jsxDEV("span", { children: "ลากรูปสลิปมาวางที่นี่ หรือคลิกเพื่อเลือกไฟล์" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
            lineNumber: 88,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "รองรับ JPEG, PNG, WEBP ขนาดไม่เกิน 5MB" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
            lineNumber: 89,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
        lineNumber: 74,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
_s(SlipUploadZone, "UVwffXkjAZ0sCTsG+piCKVVmsLQ=");
_c = SlipUploadZone;
var _c;
$RefreshReg$(_c, "SlipUploadZone");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/SlipUploadZone.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCTixTQUFTQSxRQUFRQyxnQkFBZ0I7QUFFakMsd0JBQXdCQyxlQUFlO0FBQUEsRUFDckNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsZUFBZVIsT0FBTyxJQUFJO0FBQ2hDLFFBQU0sQ0FBQ1MsWUFBWUMsYUFBYSxJQUFJVCxTQUFTLEtBQUs7QUFFbEQsUUFBTVUsYUFBYUEsQ0FBQ0MsU0FBUztBQUMzQixRQUFJQSxLQUFNUCxjQUFhTyxJQUFJO0FBQUEsRUFDN0I7QUFFQSxRQUFNQyxtQkFBbUJBLENBQUNDLFVBQVU7QUFDbENILGVBQVdHLE1BQU1DLE9BQU9DLFFBQVEsQ0FBQyxDQUFDO0FBQ2xDRixVQUFNQyxPQUFPRSxRQUFRO0FBQUEsRUFDdkI7QUFFQSxRQUFNQyxhQUFhQSxDQUFDSixVQUFVO0FBQzVCQSxVQUFNSyxlQUFlO0FBQ3JCTCxVQUFNTSxnQkFBZ0I7QUFDdEJWLGtCQUFjLEtBQUs7QUFDbkJDLGVBQVdHLE1BQU1PLGFBQWFMLFFBQVEsQ0FBQyxDQUFDO0FBQUEsRUFDMUM7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxLQUFLUjtBQUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLE1BQUs7QUFBQSxRQUNMLFFBQU87QUFBQSxRQUNQLFVBQVVLO0FBQUFBLFFBQ1YsY0FBVztBQUFBO0FBQUEsTUFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNc0M7QUFBQSxJQUVyQ1YsZ0JBQWdCQyxhQUNmLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDZCQUFDLFNBQUksS0FBS0EsWUFBWSxLQUFJLDZCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFDbkQsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUksYUFBYWMsU0FBU0MsTUFBTTtBQUFBLFlBQUU7QUFBQTtBQUFBLFVBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHlCQUF3QixTQUFTakIsY0FBYSxxQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxXQUFXLG1CQUFtQkcsYUFBYSxnQ0FBZ0MsRUFBRTtBQUFBLFFBQzdFLFNBQVMsTUFBTUQsYUFBYWMsU0FBU0MsTUFBTTtBQUFBLFFBQzNDLFlBQVksQ0FBQ1QsVUFBVTtBQUNyQkEsZ0JBQU1LLGVBQWU7QUFDckJULHdCQUFjLElBQUk7QUFBQSxRQUNwQjtBQUFBLFFBQ0EsYUFBYSxDQUFDSSxVQUFVO0FBQ3RCQSxnQkFBTUssZUFBZTtBQUNyQlQsd0JBQWMsS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxRQUFRUTtBQUFBQSxRQUVSO0FBQUEsaUNBQUMsVUFBSyw0REFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFdBQU0sc0RBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQTtBQUFBO0FBQUEsTUFmL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0JBO0FBQUEsT0ExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQTtBQUVKO0FBQUNYLEdBeEV1QkwsZ0JBQWM7QUFBQSxLQUFkQTtBQUFjLElBQUFzQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIlNsaXBVcGxvYWRab25lIiwic2VsZWN0ZWRGaWxlIiwicHJldmlld1VybCIsIm9uRmlsZVNlbGVjdCIsIm9uUmVtb3ZlRmlsZSIsIl9zIiwiZmlsZUlucHV0UmVmIiwiaXNEcmFnZ2luZyIsInNldElzRHJhZ2dpbmciLCJzZWxlY3RGaWxlIiwiZmlsZSIsImhhbmRsZUZpbGVDaGFuZ2UiLCJldmVudCIsInRhcmdldCIsImZpbGVzIiwidmFsdWUiLCJoYW5kbGVEcm9wIiwicHJldmVudERlZmF1bHQiLCJzdG9wUHJvcGFnYXRpb24iLCJkYXRhVHJhbnNmZXIiLCJjdXJyZW50IiwiY2xpY2siLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTbGlwVXBsb2FkWm9uZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTbGlwVXBsb2FkWm9uZSh7XG4gIHNlbGVjdGVkRmlsZSxcbiAgcHJldmlld1VybCxcbiAgb25GaWxlU2VsZWN0LFxuICBvblJlbW92ZUZpbGUsXG59KSB7XG4gIGNvbnN0IGZpbGVJbnB1dFJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgW2lzRHJhZ2dpbmcsIHNldElzRHJhZ2dpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IHNlbGVjdEZpbGUgPSAoZmlsZSkgPT4ge1xuICAgIGlmIChmaWxlKSBvbkZpbGVTZWxlY3QoZmlsZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChldmVudCkgPT4ge1xuICAgIHNlbGVjdEZpbGUoZXZlbnQudGFyZ2V0LmZpbGVzPy5bMF0pO1xuICAgIGV2ZW50LnRhcmdldC52YWx1ZSA9IFwiXCI7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRHJvcCA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XG4gICAgc2VsZWN0RmlsZShldmVudC5kYXRhVHJhbnNmZXIuZmlsZXM/LlswXSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc2xpcC16b25lXCI+XG4gICAgICA8aW5wdXRcbiAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XG4gICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtZmlsZS1pbnB1dFwiXG4gICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgYWNjZXB0PVwiaW1hZ2UvanBlZyxpbWFnZS9wbmcsaW1hZ2Uvd2VicFwiXG4gICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlQ2hhbmdlfVxuICAgICAgICBhcmlhLWxhYmVsPVwi4LmA4Lil4Li34Lit4LiB4Lij4Li54Lib4Liq4Lil4Li04Lib4LiB4Liy4Lij4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXCJcbiAgICAgIC8+XG4gICAgICB7c2VsZWN0ZWRGaWxlICYmIHByZXZpZXdVcmwgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1zbGlwLXByZXZpZXdcIj5cbiAgICAgICAgICA8aW1nIHNyYz17cHJldmlld1VybH0gYWx0PVwi4LiV4Lix4Lin4Lit4Lii4LmI4Liy4LiH4Liq4Lil4Li04Lib4LiB4Liy4Lij4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtc2xpcC1hY3Rpb25zXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwYXltZW50LXNlY29uZGFyeS1idXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg4LmA4Lib4Lil4Li14LmI4Lii4LiZ4Lij4Li54LibXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInBheW1lbnQtcmVtb3ZlLWJ1dHRvblwiIG9uQ2xpY2s9e29uUmVtb3ZlRmlsZX0+XG4gICAgICAgICAgICAgIOC4peC4muC4o+C4ueC4m1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT17YHBheW1lbnQtZHJvcHpvbmUke2lzRHJhZ2dpbmcgPyBcIiBwYXltZW50LWRyb3B6b25lLS1kcmFnZ2luZ1wiIDogXCJcIn1gfVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICAgIG9uRHJhZ092ZXI9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIHNldElzRHJhZ2dpbmcodHJ1ZSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbkRyYWdMZWF2ZT17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbkRyb3A9e2hhbmRsZURyb3B9XG4gICAgICAgID5cbiAgICAgICAgICA8c3Bhbj7guKXguLLguIHguKPguLnguJvguKrguKXguLTguJvguKHguLLguKfguLLguIfguJfguLXguYjguJnguLXguYgg4Lir4Lij4Li34Lit4LiE4Lil4Li04LiB4LmA4Lie4Li34LmI4Lit4LmA4Lil4Li34Lit4LiB4LmE4Lif4Lil4LmMPC9zcGFuPlxuICAgICAgICAgIDxzbWFsbD7guKPguK3guIfguKPguLHguJogSlBFRywgUE5HLCBXRUJQIOC4guC4meC4suC4lOC5hOC4oeC5iOC5gOC4geC4tOC4mSA1TUI8L3NtYWxsPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9wYXltZW50L1NsaXBVcGxvYWRab25lLmpzeCJ9