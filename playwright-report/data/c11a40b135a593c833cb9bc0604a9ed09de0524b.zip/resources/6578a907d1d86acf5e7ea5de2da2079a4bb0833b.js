import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BookingModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { api } from "/src/services/api.js";
import { toast } from "/src/utils/toast.js";
const SPECIES_THAI_MAP = {
  dog: "สุนัข",
  cat: "แมว",
  bird: "นก",
  exotic: "สัตว์แปลก",
  rabbit: "กระต่าย",
  fish: "ปลา",
  rodent: "สัตว์ฟันแทะ"
};
const formatSpeciesThai = (speciesInput) => {
  if (!speciesInput) return "สัตว์เลี้ยงทุกชนิด";
  const list = Array.isArray(speciesInput) ? speciesInput : [speciesInput];
  return list.map((item) => SPECIES_THAI_MAP[String(item).toLowerCase()] || item).join(", ");
};
const normalizeSpecies = (speciesInput) => {
  if (!speciesInput) return "";
  const str = String(speciesInput).trim().toLowerCase();
  const thaiToEng = {
    "สุนัข": "dog",
    "หมา": "dog",
    "แมว": "cat",
    "นก": "bird",
    "สัตว์แปลก": "exotic",
    "กระต่าย": "rabbit",
    "ปลา": "fish",
    "สัตว์ฟันแทะ": "rodent"
  };
  return thaiToEng[str] || str;
};
const getPetId = (pet) => pet?.petId || pet?.petid || pet?.id || pet?.pet_id || pet?.userPetId || pet?._id;
export default function BookingModal({
  isOpen,
  onClose,
  sitter,
  selectedService,
  onSuccess
}) {
  _s();
  const [userPets, setUserPets] = useState([]);
  const [selectedPetIds, setSelectedPetIds] = useState([]);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const tomorrow = new Date(Date.now() + 864e5).toISOString().split("T")[0];
  const [startDate, setStartDate] = useState(today);
  const [startTime, setStartTime] = useState("09:00");
  const [endDate, setEndDate] = useState(tomorrow);
  const [endTime, setEndTime] = useState("18:00");
  const [paymentOption, setPaymentOption] = useState("full");
  const [note, setNote] = useState("");
  const [loadingPets, setLoadingPets] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [bookingError, setBookingError] = useState("");
  const serviceUnitStr = String(
    selectedService?.unit || selectedService?.priceUnit || selectedService?.serviceType || selectedService?.type || selectedService?.category || ""
  ).toLowerCase();
  const isDailyService = serviceUnitStr.includes("day") || serviceUnitStr.includes("daily") || serviceUnitStr.includes("วัน");
  const isPetCompatible = (pet, service) => {
    if (!service || !service.species) return true;
    const serviceSpeciesList = Array.isArray(service.species) ? service.species : [service.species];
    const targetSpecies = serviceSpeciesList.map((s) => normalizeSpecies(s));
    const petSpecies = normalizeSpecies(pet?.species);
    return targetSpecies.includes(petSpecies);
  };
  const fetchPets = useCallback(async () => {
    setLoadingPets(true);
    setBookingError("");
    try {
      const res = await api.get("/users/me");
      const petsList = res.data?.data?.pets || res.data?.pets || [];
      setUserPets(petsList);
      if (petsList.length > 0) {
        const compatiblePet = petsList.find(
          (p) => isPetCompatible(p, selectedService)
        );
        const initialId = compatiblePet ? getPetId(compatiblePet) : null;
        setSelectedPetIds(initialId ? [String(initialId)] : []);
      } else {
        setSelectedPetIds([]);
      }
    } catch (err) {
      console.error("Failed to fetch pets:", err);
      setBookingError("ไม่สามารถดึงข้อมูลสัตว์เลี้ยงได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setLoadingPets(false);
    }
  }, [selectedService]);
  useEffect(() => {
    if (isOpen) {
      fetchPets();
    }
  }, [isOpen, fetchPets]);
  if (!isOpen) return null;
  const handleTogglePet = (petIdStr) => {
    setSelectedPetIds(
      (prev) => prev.includes(petIdStr) ? prev.filter((id) => id !== petIdStr) : [...prev, petIdStr]
    );
  };
  const servicePrice = Number(selectedService?.price || 0);
  const startDateTimeObj = /* @__PURE__ */ new Date(`${startDate}T${startTime}:00`);
  const endDateTimeObj = /* @__PURE__ */ new Date(`${endDate}T${endTime}:00`);
  let durationCount = 1;
  let unitLabel = isDailyService ? "วัน" : "ชั่วโมง";
  if (!isNaN(startDateTimeObj.getTime()) && !isNaN(endDateTimeObj.getTime())) {
    const diffMs = endDateTimeObj.getTime() - startDateTimeObj.getTime();
    if (diffMs > 0) {
      if (isDailyService) {
        durationCount = Math.max(1, Math.ceil(diffMs / (1e3 * 60 * 60 * 24)));
      } else {
        durationCount = Math.max(1, Math.ceil(diffMs / (1e3 * 60 * 60)));
      }
    }
  }
  const totalPrice = servicePrice * durationCount;
  const paymentAmount = paymentOption === "deposit" ? totalPrice * 0.3 : totalPrice;
  const handleConfirmBooking = async () => {
    setBookingError("");
    setSubmitting(true);
    try {
      const selectedPets = userPets.filter(
        (p) => selectedPetIds.includes(String(getPetId(p)))
      );
      if (selectedPets.length === 0) {
        setBookingError("กรุณาเลือกสัตว์เลี้ยงที่ต้องการจองบริการ");
        setSubmitting(false);
        return;
      }
      const incompatiblePet = selectedPets.find(
        (p) => !isPetCompatible(p, selectedService)
      );
      if (incompatiblePet) {
        setBookingError(
          `สัตว์เลี้ยง (${formatSpeciesThai(incompatiblePet.species)}) ไม่ตรงกับประเภทที่บริการรับฝาก (${formatSpeciesThai(selectedService?.species)})`
        );
        setSubmitting(false);
        return;
      }
      const formattedPets = [];
      for (const pet of selectedPets) {
        const validPetId = Number(getPetId(pet));
        if (!validPetId || Number.isNaN(validPetId) || validPetId <= 0) {
          setBookingError("ไม่พบรหัสสัตว์เลี้ยงที่ถูกต้อง");
          setSubmitting(false);
          return;
        }
        formattedPets.push({
          petId: validPetId,
          ...note.trim() ? { petNote: note.trim() } : {}
        });
      }
      const startIso = (/* @__PURE__ */ new Date(`${startDate}T${startTime}:00`)).toISOString();
      const endIso = (/* @__PURE__ */ new Date(`${endDate}T${endTime}:00`)).toISOString();
      const bookingPayload = {
        sitterId: Number(sitter?.sitterId || sitter?.id || sitter?.userId),
        serviceId: Number(selectedService?.serviceId || selectedService?.id),
        starttime: startIso,
        endtime: endIso,
        paymentplan: paymentOption === "deposit" ? "deposit" : "full",
        ...note.trim() ? { note: note.trim() } : {},
        pets: formattedPets
      };
      const res = await api.post("/bookings", bookingPayload);
      if (res.status === 200 || res.status === 201 || res.data?.status === "success") {
        toast("จองบริการสำเร็จเรียบร้อยแล้ว!", "success");
        if (onSuccess) onSuccess();
        onClose();
      }
    } catch (err) {
      console.error("Booking failed:", err);
      const serverMessage = err.response?.data?.message || err.response?.data?.error || "ไม่สามารถทำรายการจองได้ กรุณาตรวจสอบข้อมูล";
      setBookingError(serverMessage);
    } finally {
      setSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl relative", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 mb-4 text-center", children: "ยืนยันการจองบริการ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 267,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-xl mb-4 border border-gray-100", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-lg text-gray-900", children: selectedService?.serviceName || selectedService?.name || "บริการฝากเลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 274,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-orange-100 text-orange-700 px-2.5 py-1 rounded-full font-medium", children: [
          "฿",
          servicePrice.toLocaleString(),
          " / ",
          unitLabel
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 277,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 273,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 mt-1", children: [
        "พี่เลี้ยง: ",
        sitter?.sitterName || sitter?.name || sitter?.sittername || "Positter"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 281,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-orange-600 mt-1 font-medium", children: [
        "รับฝากประเภท: ",
        formatSpeciesThai(selectedService?.species)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 284,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 272,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "เลือกสัตว์เลี้ยง (Pet)" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 291,
        columnNumber: 11
      }, this),
      loadingPets ? /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 py-2", children: "กำลังโหลดสัตว์เลี้ยง..." }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 295,
        columnNumber: 11
      }, this) : userPets.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-red-500 py-2", children: "ไม่พบสัตว์เลี้ยงของคุณ กรุณาเพิ่มสัตว์เลี้ยงในโปรไฟล์ก่อนจอง" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 297,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 max-h-40 overflow-y-auto", children: userPets.map((pet) => {
        const petIdStr = String(getPetId(pet));
        const isSelected = selectedPetIds.includes(petIdStr);
        const compatible = isPetCompatible(pet, selectedService);
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => {
              if (compatible) handleTogglePet(petIdStr);
            },
            className: `p-3 rounded-xl border transition flex justify-between items-center ${!compatible ? "opacity-50 cursor-not-allowed bg-gray-100 border-gray-200" : isSelected ? "border-orange-500 bg-orange-50/50 text-orange-900 font-medium cursor-pointer" : "border-gray-200 hover:border-gray-300 bg-white cursor-pointer"}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-sm", children: [
                  "🐾 ",
                  pet.name,
                  " ",
                  !compatible && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-500 font-normal ml-1", children: "(ประเภทไม่ตรงกับบริการ)" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
                    lineNumber: 325,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
                  lineNumber: 322,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: [
                  "ประเภท: ",
                  formatSpeciesThai(pet.species),
                  " ",
                  pet.breed ? `(${pet.breed})` : ""
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
                  lineNumber: 330,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
                lineNumber: 321,
                columnNumber: 21
              }, this),
              isSelected && compatible && /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 font-bold text-sm", children: "✓" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
                lineNumber: 336,
                columnNumber: 19
              }, this)
            ]
          },
          petIdStr,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
            lineNumber: 308,
            columnNumber: 17
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 301,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 290,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 mb-1", children: "วันที่เริ่มบริการ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 348,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: startDate,
            onChange: (e) => setStartDate(e.target.value),
            className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
            lineNumber: 351,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 347,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 mb-1", children: [
          "เวลาเริ่มบริการ ",
          isDailyService ? "(ระบุเวลาฝาก)" : ""
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 359,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "time",
            value: startTime,
            onChange: (e) => setStartTime(e.target.value),
            className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
            lineNumber: 362,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 358,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 mb-1", children: "วันที่สิ้นสุดบริการ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 370,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: endDate,
            onChange: (e) => setEndDate(e.target.value),
            className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
            lineNumber: 373,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 369,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 mb-1", children: [
          "เวลาสิ้นสุดบริการ ",
          isDailyService ? "(ระบุเวลารับ)" : ""
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 381,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "time",
            value: endTime,
            onChange: (e) => setEndTime(e.target.value),
            className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
            lineNumber: 384,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 380,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 346,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-3 rounded-lg text-xs text-gray-600 mb-4 flex justify-between items-center", children: [
      /* @__PURE__ */ jsxDEV("span", { children: "⏱️ ระยะเวลาทั้งหมด:" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 395,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm text-gray-800", children: [
        durationCount,
        " ",
        unitLabel
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 396,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 394,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "รูปแบบการชำระเงิน (Payment Option)" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 403,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "select",
        {
          value: paymentOption,
          onChange: (e) => setPaymentOption(e.target.value),
          className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none bg-white",
          children: [
            /* @__PURE__ */ jsxDEV("option", { value: "full", children: [
              "ชำระเต็มจำนวน 100% (฿",
              totalPrice.toLocaleString(),
              ")"
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
              lineNumber: 411,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "deposit", children: [
              "ชำระมัดจำ 30% (฿",
              (totalPrice * 0.3).toLocaleString(),
              ")"
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
              lineNumber: 412,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 406,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 402,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "หมายเหตุเพิ่มเติมถึงพี่เลี้ยง" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 418,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          rows: "2",
          value: note,
          onChange: (e) => setNote(e.target.value),
          placeholder: "เช่น คำแนะนำการให้อาหาร หรือจุดนัดพบ",
          className: "w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none resize-none"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 421,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 417,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t pt-3 mb-4 space-y-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-sm text-gray-600", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "ราคายอดรวมทั้งหมด (",
          durationCount,
          " ",
          unitLabel,
          "):"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 433,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "฿",
          totalPrice.toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 436,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 432,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-base font-bold text-orange-600", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "ยอดชำระทันที (",
          paymentOption === "deposit" ? "มัดจำ 30%" : "เต็มจำนวน 100%",
          "):"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 439,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "฿",
          paymentAmount.toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 440,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
        lineNumber: 438,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 431,
      columnNumber: 9
    }, this),
    bookingError && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg flex items-center gap-2", children: [
      "⚠️ ",
      bookingError
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 446,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onClose,
          disabled: submitting,
          className: "flex-1 py-2.5 border border-gray-300 rounded-xl text-gray-700 font-medium hover:bg-gray-50 transition text-sm",
          children: "ยกเลิก"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 453,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleConfirmBooking,
          disabled: submitting || selectedPetIds.length === 0,
          className: "flex-1 py-2.5 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50 text-sm shadow-md",
          children: submitting ? "กำลังดำเนินการ..." : "ยืนยันการจอง"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
          lineNumber: 461,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
      lineNumber: 452,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
    lineNumber: 266,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx",
    lineNumber: 265,
    columnNumber: 5
  }, this);
}
_s(BookingModal, "xxT4kMFi8N2Nv0UXSBx/CDIpCpM=");
_c = BookingModal;
var _c;
$RefreshReg$(_c, "BookingModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/BookingModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdVBROzs7Ozs7Ozs7Ozs7Ozs7OztBQXZQUixPQUFPQSxTQUFTQyxVQUFVQyxXQUFXQyxtQkFBbUI7QUFDeEQsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxhQUFhO0FBR3RCLE1BQU1DLG1CQUFtQjtBQUFBLEVBQ3ZCQyxLQUFLO0FBQUEsRUFDTEMsS0FBSztBQUFBLEVBQ0xDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsUUFBUTtBQUFBLEVBQ1JDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQ1Y7QUFHQSxNQUFNQyxvQkFBb0JBLENBQUNDLGlCQUFpQjtBQUMxQyxNQUFJLENBQUNBLGFBQWMsUUFBTztBQUMxQixRQUFNQyxPQUFPQyxNQUFNQyxRQUFRSCxZQUFZLElBQUlBLGVBQWUsQ0FBQ0EsWUFBWTtBQUN2RSxTQUFPQyxLQUNKRyxJQUFJLENBQUNDLFNBQVNkLGlCQUFpQmUsT0FBT0QsSUFBSSxFQUFFRSxZQUFZLENBQUMsS0FBS0YsSUFBSSxFQUNsRUcsS0FBSyxJQUFJO0FBQ2Q7QUFHQSxNQUFNQyxtQkFBbUJBLENBQUNULGlCQUFpQjtBQUN6QyxNQUFJLENBQUNBLGFBQWMsUUFBTztBQUMxQixRQUFNVSxNQUFNSixPQUFPTixZQUFZLEVBQUVXLEtBQUssRUFBRUosWUFBWTtBQUVwRCxRQUFNSyxZQUFZO0FBQUEsSUFDaEIsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sYUFBYTtBQUFBLElBQ2IsV0FBVztBQUFBLElBQ1gsT0FBTztBQUFBLElBQ1AsZUFBZTtBQUFBLEVBQ2pCO0FBRUEsU0FBT0EsVUFBVUYsR0FBRyxLQUFLQTtBQUMzQjtBQUdBLE1BQU1HLFdBQVdBLENBQUNDLFFBQ2hCQSxLQUFLQyxTQUFTRCxLQUFLRSxTQUFTRixLQUFLRyxNQUFNSCxLQUFLSSxVQUFVSixLQUFLSyxhQUFhTCxLQUFLTTtBQUUvRSx3QkFBd0JDLGFBQWE7QUFBQSxFQUNuQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSTNDLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUM0QyxnQkFBZ0JDLGlCQUFpQixJQUFJN0MsU0FBUyxFQUFFO0FBRXZELFFBQU04QyxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNuRCxRQUFNQyxXQUFXLElBQUlILEtBQUtBLEtBQUtJLElBQUksSUFBSSxLQUFRLEVBQUVILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUUzRSxRQUFNLENBQUNHLFdBQVdDLFlBQVksSUFBSXJELFNBQVM4QyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ1EsV0FBV0MsWUFBWSxJQUFJdkQsU0FBUyxPQUFPO0FBQ2xELFFBQU0sQ0FBQ3dELFNBQVNDLFVBQVUsSUFBSXpELFNBQVNrRCxRQUFRO0FBQy9DLFFBQU0sQ0FBQ1EsU0FBU0MsVUFBVSxJQUFJM0QsU0FBUyxPQUFPO0FBRTlDLFFBQU0sQ0FBQzRELGVBQWVDLGdCQUFnQixJQUFJN0QsU0FBUyxNQUFNO0FBQ3pELFFBQU0sQ0FBQzhELE1BQU1DLE9BQU8sSUFBSS9ELFNBQVMsRUFBRTtBQUVuQyxRQUFNLENBQUNnRSxhQUFhQyxjQUFjLElBQUlqRSxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDa0UsWUFBWUMsYUFBYSxJQUFJbkUsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ29FLGNBQWNDLGVBQWUsSUFBSXJFLFNBQVMsRUFBRTtBQUduRCxRQUFNc0UsaUJBQWlCbEQ7QUFBQUEsSUFDckJtQixpQkFBaUJnQyxRQUNqQmhDLGlCQUFpQmlDLGFBQ2pCakMsaUJBQWlCa0MsZUFDakJsQyxpQkFBaUJtQyxRQUNqQm5DLGlCQUFpQm9DLFlBQ2pCO0FBQUEsRUFDRixFQUFFdEQsWUFBWTtBQUVkLFFBQU11RCxpQkFDSk4sZUFBZU8sU0FBUyxLQUFLLEtBQzdCUCxlQUFlTyxTQUFTLE9BQU8sS0FDL0JQLGVBQWVPLFNBQVMsS0FBSztBQUcvQixRQUFNQyxrQkFBa0JBLENBQUNsRCxLQUFLbUQsWUFBWTtBQUN4QyxRQUFJLENBQUNBLFdBQVcsQ0FBQ0EsUUFBUUMsUUFBUyxRQUFPO0FBRXpDLFVBQU1DLHFCQUFxQmpFLE1BQU1DLFFBQVE4RCxRQUFRQyxPQUFPLElBQ3BERCxRQUFRQyxVQUNSLENBQUNELFFBQVFDLE9BQU87QUFFcEIsVUFBTUUsZ0JBQWdCRCxtQkFBbUIvRCxJQUFJLENBQUNpRSxNQUFNNUQsaUJBQWlCNEQsQ0FBQyxDQUFDO0FBQ3ZFLFVBQU1DLGFBQWE3RCxpQkFBaUJLLEtBQUtvRCxPQUFPO0FBRWhELFdBQU9FLGNBQWNMLFNBQVNPLFVBQVU7QUFBQSxFQUMxQztBQUdBLFFBQU1DLFlBQVluRixZQUFZLFlBQVk7QUFDeEMrRCxtQkFBZSxJQUFJO0FBQ25CSSxvQkFBZ0IsRUFBRTtBQUNsQixRQUFJO0FBQ0YsWUFBTWlCLE1BQU0sTUFBTW5GLElBQUlvRixJQUFJLFdBQVc7QUFDckMsWUFBTUMsV0FBV0YsSUFBSUcsTUFBTUEsTUFBTUMsUUFBUUosSUFBSUcsTUFBTUMsUUFBUTtBQUMzRC9DLGtCQUFZNkMsUUFBUTtBQUVwQixVQUFJQSxTQUFTRyxTQUFTLEdBQUc7QUFDdkIsY0FBTUMsZ0JBQWdCSixTQUFTSztBQUFBQSxVQUFLLENBQUNDLE1BQ25DaEIsZ0JBQWdCZ0IsR0FBR3ZELGVBQWU7QUFBQSxRQUNwQztBQUNBLGNBQU13RCxZQUFZSCxnQkFBZ0JqRSxTQUFTaUUsYUFBYSxJQUFJO0FBQzVEL0MsMEJBQWtCa0QsWUFBWSxDQUFDM0UsT0FBTzJFLFNBQVMsQ0FBQyxJQUFJLEVBQUU7QUFBQSxNQUN4RCxPQUFPO0FBQ0xsRCwwQkFBa0IsRUFBRTtBQUFBLE1BQ3RCO0FBQUEsSUFDRixTQUFTbUQsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUMxQzNCLHNCQUFnQix1REFBdUQ7QUFBQSxJQUN6RSxVQUFDO0FBQ0NKLHFCQUFlLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0YsR0FBRyxDQUFDMUIsZUFBZSxDQUFDO0FBRXBCdEMsWUFBVSxNQUFNO0FBQ2QsUUFBSW1DLFFBQVE7QUFDVmlELGdCQUFVO0FBQUEsSUFDWjtBQUFBLEVBQ0YsR0FBRyxDQUFDakQsUUFBUWlELFNBQVMsQ0FBQztBQUV0QixNQUFJLENBQUNqRCxPQUFRLFFBQU87QUFHcEIsUUFBTStELGtCQUFrQkEsQ0FBQ0MsYUFBYTtBQUNwQ3ZEO0FBQUFBLE1BQWtCLENBQUN3RCxTQUNqQkEsS0FBS3hCLFNBQVN1QixRQUFRLElBQ2xCQyxLQUFLQyxPQUFPLENBQUN2RSxPQUFPQSxPQUFPcUUsUUFBUSxJQUNuQyxDQUFDLEdBQUdDLE1BQU1ELFFBQVE7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNRyxlQUFlQyxPQUFPakUsaUJBQWlCa0UsU0FBUyxDQUFDO0FBQ3ZELFFBQU1DLG1CQUFtQixvQkFBSTNELEtBQUssR0FBR0ssU0FBUyxJQUFJRSxTQUFTLEtBQUs7QUFDaEUsUUFBTXFELGlCQUFpQixvQkFBSTVELEtBQUssR0FBR1MsT0FBTyxJQUFJRSxPQUFPLEtBQUs7QUFFMUQsTUFBSWtELGdCQUFnQjtBQUNwQixNQUFJQyxZQUFZakMsaUJBQWlCLFFBQVE7QUFFekMsTUFBSSxDQUFDa0MsTUFBTUosaUJBQWlCSyxRQUFRLENBQUMsS0FBSyxDQUFDRCxNQUFNSCxlQUFlSSxRQUFRLENBQUMsR0FBRztBQUMxRSxVQUFNQyxTQUFTTCxlQUFlSSxRQUFRLElBQUlMLGlCQUFpQkssUUFBUTtBQUNuRSxRQUFJQyxTQUFTLEdBQUc7QUFDZCxVQUFJcEMsZ0JBQWdCO0FBQ2xCZ0Msd0JBQWdCSyxLQUFLQyxJQUFJLEdBQUdELEtBQUtFLEtBQUtILFVBQVUsTUFBTyxLQUFLLEtBQUssR0FBRyxDQUFDO0FBQUEsTUFDdkUsT0FBTztBQUNMSix3QkFBZ0JLLEtBQUtDLElBQUksR0FBR0QsS0FBS0UsS0FBS0gsVUFBVSxNQUFPLEtBQUssR0FBRyxDQUFDO0FBQUEsTUFDbEU7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1JLGFBQWFiLGVBQWVLO0FBQ2xDLFFBQU1TLGdCQUNKekQsa0JBQWtCLFlBQVl3RCxhQUFhLE1BQU1BO0FBR25ELFFBQU1FLHVCQUF1QixZQUFZO0FBQ3ZDakQsb0JBQWdCLEVBQUU7QUFDbEJGLGtCQUFjLElBQUk7QUFFbEIsUUFBSTtBQUNGLFlBQU1vRCxlQUFlN0UsU0FBUzREO0FBQUFBLFFBQU8sQ0FBQ1IsTUFDcENsRCxlQUFlaUMsU0FBU3pELE9BQU9PLFNBQVNtRSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzdDO0FBRUEsVUFBSXlCLGFBQWE1QixXQUFXLEdBQUc7QUFDN0J0Qix3QkFBZ0IsMENBQTBDO0FBQzFERixzQkFBYyxLQUFLO0FBQ25CO0FBQUEsTUFDRjtBQUVBLFlBQU1xRCxrQkFBa0JELGFBQWExQjtBQUFBQSxRQUNuQyxDQUFDQyxNQUFNLENBQUNoQixnQkFBZ0JnQixHQUFHdkQsZUFBZTtBQUFBLE1BQzVDO0FBQ0EsVUFBSWlGLGlCQUFpQjtBQUNuQm5EO0FBQUFBLFVBQ0UsZ0JBQWdCeEQsa0JBQWtCMkcsZ0JBQWdCeEMsT0FBTyxDQUFDLHFDQUFxQ25FLGtCQUFrQjBCLGlCQUFpQnlDLE9BQU8sQ0FBQztBQUFBLFFBQzVJO0FBQ0FiLHNCQUFjLEtBQUs7QUFDbkI7QUFBQSxNQUNGO0FBRUEsWUFBTXNELGdCQUFnQjtBQUN0QixpQkFBVzdGLE9BQU8yRixjQUFjO0FBQzlCLGNBQU1HLGFBQWFsQixPQUFPN0UsU0FBU0MsR0FBRyxDQUFDO0FBQ3ZDLFlBQUksQ0FBQzhGLGNBQWNsQixPQUFPTSxNQUFNWSxVQUFVLEtBQUtBLGNBQWMsR0FBRztBQUM5RHJELDBCQUFnQixnQ0FBZ0M7QUFDaERGLHdCQUFjLEtBQUs7QUFDbkI7QUFBQSxRQUNGO0FBQ0FzRCxzQkFBY0UsS0FBSztBQUFBLFVBQ2pCOUYsT0FBTzZGO0FBQUFBLFVBQ1AsR0FBSTVELEtBQUtyQyxLQUFLLElBQUksRUFBRW1HLFNBQVM5RCxLQUFLckMsS0FBSyxFQUFFLElBQUksQ0FBQztBQUFBLFFBQ2hELENBQUM7QUFBQSxNQUNIO0FBRUEsWUFBTW9HLFlBQVcsb0JBQUk5RSxLQUFLLEdBQUdLLFNBQVMsSUFBSUUsU0FBUyxLQUFLLEdBQUVOLFlBQVk7QUFDdEUsWUFBTThFLFVBQVMsb0JBQUkvRSxLQUFLLEdBQUdTLE9BQU8sSUFBSUUsT0FBTyxLQUFLLEdBQUVWLFlBQVk7QUFFaEUsWUFBTStFLGlCQUFpQjtBQUFBLFFBQ3JCQyxVQUFVeEIsT0FBT2xFLFFBQVEwRixZQUFZMUYsUUFBUVAsTUFBTU8sUUFBUTJGLE1BQU07QUFBQSxRQUNqRUMsV0FBVzFCLE9BQU9qRSxpQkFBaUIyRixhQUFhM0YsaUJBQWlCUixFQUFFO0FBQUEsUUFDbkVvRyxXQUFXTjtBQUFBQSxRQUNYTyxTQUFTTjtBQUFBQSxRQUNUTyxhQUFhekUsa0JBQWtCLFlBQVksWUFBWTtBQUFBLFFBQ3ZELEdBQUlFLEtBQUtyQyxLQUFLLElBQUksRUFBRXFDLE1BQU1BLEtBQUtyQyxLQUFLLEVBQUUsSUFBSSxDQUFDO0FBQUEsUUFDM0NpRSxNQUFNK0I7QUFBQUEsTUFDUjtBQUVBLFlBQU1uQyxNQUFNLE1BQU1uRixJQUFJbUksS0FBSyxhQUFhUCxjQUFjO0FBRXRELFVBQ0V6QyxJQUFJaUQsV0FBVyxPQUNmakQsSUFBSWlELFdBQVcsT0FDZmpELElBQUlHLE1BQU04QyxXQUFXLFdBQ3JCO0FBQ0FuSSxjQUFNLGlDQUFpQyxTQUFTO0FBQ2hELFlBQUlvQyxVQUFXQSxXQUFVO0FBQ3pCSCxnQkFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGLFNBQVMyRCxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sbUJBQW1CRixHQUFHO0FBQ3BDLFlBQU13QyxnQkFDSnhDLElBQUl5QyxVQUFVaEQsTUFBTWlELFdBQ3BCMUMsSUFBSXlDLFVBQVVoRCxNQUFNUyxTQUNwQjtBQUNGN0Isc0JBQWdCbUUsYUFBYTtBQUFBLElBQy9CLFVBQUM7QUFDQ3JFLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx1RkFDYixpQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsb0RBQWtELGtDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1Q0FDWDVCLDJCQUFpQm9HLGVBQWVwRyxpQkFBaUJxRyxRQUFRLHFCQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSw4RUFBNEU7QUFBQTtBQUFBLFVBQ3hGckMsYUFBYXNDLGVBQWU7QUFBQSxVQUFFO0FBQUEsVUFBSWhDO0FBQUFBLGFBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTRCO0FBQUE7QUFBQSxRQUMzQnZFLFFBQVF3RyxjQUFjeEcsUUFBUXNHLFFBQVF0RyxRQUFReUcsY0FBYztBQUFBLFdBRDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUEwQztBQUFBO0FBQUEsUUFDeENsSSxrQkFBa0IwQixpQkFBaUJ5QyxPQUFPO0FBQUEsV0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGtEQUFnRCxzQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ2hCLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLDhCQUE2Qix1Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRSxJQUNqRXRCLFNBQVNpRCxXQUFXLElBQ3RCLHVCQUFDLFNBQUksV0FBVSw2QkFBMkIsNEVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FDWmpELG1CQUFTeEIsSUFBSSxDQUFDVSxRQUFRO0FBQ3JCLGNBQU13RSxXQUFXaEYsT0FBT08sU0FBU0MsR0FBRyxDQUFDO0FBQ3JDLGNBQU1vSCxhQUFhcEcsZUFBZWlDLFNBQVN1QixRQUFRO0FBQ25ELGNBQU02QyxhQUFhbkUsZ0JBQWdCbEQsS0FBS1csZUFBZTtBQUV2RCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU07QUFDYixrQkFBSTBHLFdBQVk5QyxpQkFBZ0JDLFFBQVE7QUFBQSxZQUMxQztBQUFBLFlBQ0EsV0FBVyxzRUFDVCxDQUFDNkMsYUFDRyw4REFDQUQsYUFDQSxpRkFDQSwrREFBK0Q7QUFBQSxZQUdyRTtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsdUJBQXFCO0FBQUE7QUFBQSxrQkFDOUJwSCxJQUFJZ0g7QUFBQUEsa0JBQU07QUFBQSxrQkFDYixDQUFDSyxjQUNBLHVCQUFDLFVBQUssV0FBVSx5Q0FBdUMsdUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUF1QjtBQUFBO0FBQUEsa0JBQzNCcEksa0JBQWtCZSxJQUFJb0QsT0FBTztBQUFBLGtCQUFHO0FBQUEsa0JBQ3hDcEQsSUFBSXNILFFBQVEsSUFBSXRILElBQUlzSCxLQUFLLE1BQU07QUFBQSxxQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxjQUNDRixjQUFjQyxjQUNiLHVCQUFDLFVBQUssV0FBVSxxQ0FBb0MsaUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUE7QUFBQTtBQUFBLFVBM0JsRDdDO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQThCQTtBQUFBLE1BRUosQ0FBQyxLQXZDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0NBO0FBQUEsU0FuREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSxrREFBZ0QsaUNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9oRDtBQUFBQSxZQUNQLFVBQVUsQ0FBQytGLE1BQU05RixhQUFhOEYsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFlBQzVDLFdBQVU7QUFBQTtBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWtIO0FBQUEsV0FScEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGtEQUFnRDtBQUFBO0FBQUEsVUFDOUN6RSxpQkFBaUIsa0JBQWtCO0FBQUEsYUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT3RCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDNkYsTUFBTTVGLGFBQWE0RixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDNUMsV0FBVTtBQUFBO0FBQUEsVUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJa0g7QUFBQSxXQVJwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFdBQVUsa0RBQWdELG1DQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPN0Y7QUFBQUEsWUFDUCxVQUFVLENBQUMyRixNQUFNMUYsV0FBVzBGLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUMxQyxXQUFVO0FBQUE7QUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlrSDtBQUFBLFdBUnBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSxrREFBZ0Q7QUFBQTtBQUFBLFVBQzVDekUsaUJBQWlCLGtCQUFrQjtBQUFBLGFBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9sQjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3lGLE1BQU14RixXQUFXd0YsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFlBQzFDLFdBQVU7QUFBQTtBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWtIO0FBQUEsV0FScEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsNkJBQUMsVUFBSyxtQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsVUFBSyxXQUFVLHVDQUNiekM7QUFBQUE7QUFBQUEsUUFBYztBQUFBLFFBQUVDO0FBQUFBLFdBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSxrREFBZ0Qsa0RBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9qRDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3VGLE1BQU10RixpQkFBaUJzRixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsVUFDaEQsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sUUFBTztBQUFBO0FBQUEsY0FBc0JqQyxXQUFXeUIsZUFBZTtBQUFBLGNBQUU7QUFBQSxpQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RSx1QkFBQyxZQUFPLE9BQU0sV0FBVTtBQUFBO0FBQUEsZUFBa0J6QixhQUFhLEtBQUt5QixlQUFlO0FBQUEsY0FBRTtBQUFBLGlCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBO0FBQUE7QUFBQSxRQU5oRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSxrREFBZ0QsNkNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU8vRTtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3FGLE1BQU1wRixRQUFRb0YsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFVBQ3ZDLGFBQVk7QUFBQSxVQUNaLFdBQVU7QUFBQTtBQUFBLFFBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUM7QUFBQSxTQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsVUFBSTtBQUFBO0FBQUEsVUFDaUJ6QztBQUFBQSxVQUFjO0FBQUEsVUFBRUM7QUFBQUEsVUFBVTtBQUFBLGFBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBRU8sV0FBV3lCLGVBQWU7QUFBQSxhQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsV0FKdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSwrQkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFlakYsa0JBQWtCLFlBQVksY0FBYztBQUFBLFVBQWlCO0FBQUEsYUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQUV5RCxjQUFjd0IsZUFBZTtBQUFBLGFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxXQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0N6RSxnQkFDQyx1QkFBQyxTQUFJLFdBQVUsb0dBQWtHO0FBQUE7QUFBQSxNQUMzR0E7QUFBQUEsU0FETjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMvQjtBQUFBQSxVQUNULFVBQVU2QjtBQUFBQSxVQUNWLFdBQVU7QUFBQSxVQUErRztBQUFBO0FBQUEsUUFKM0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTb0Q7QUFBQUEsVUFDVCxVQUFVcEQsY0FBY3RCLGVBQWUrQyxXQUFXO0FBQUEsVUFDbEQsV0FBVTtBQUFBLFVBRVR6Qix1QkFBYSxzQkFBc0I7QUFBQTtBQUFBLFFBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BM01GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0TUEsS0E3TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThNQTtBQUVKO0FBQUN6QixHQXRadUJOLGNBQVk7QUFBQSxLQUFaQTtBQUFZLElBQUFtSDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQ2FsbGJhY2siLCJhcGkiLCJ0b2FzdCIsIlNQRUNJRVNfVEhBSV9NQVAiLCJkb2ciLCJjYXQiLCJiaXJkIiwiZXhvdGljIiwicmFiYml0IiwiZmlzaCIsInJvZGVudCIsImZvcm1hdFNwZWNpZXNUaGFpIiwic3BlY2llc0lucHV0IiwibGlzdCIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsIml0ZW0iLCJTdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImpvaW4iLCJub3JtYWxpemVTcGVjaWVzIiwic3RyIiwidHJpbSIsInRoYWlUb0VuZyIsImdldFBldElkIiwicGV0IiwicGV0SWQiLCJwZXRpZCIsImlkIiwicGV0X2lkIiwidXNlclBldElkIiwiX2lkIiwiQm9va2luZ01vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsInNpdHRlciIsInNlbGVjdGVkU2VydmljZSIsIm9uU3VjY2VzcyIsIl9zIiwidXNlclBldHMiLCJzZXRVc2VyUGV0cyIsInNlbGVjdGVkUGV0SWRzIiwic2V0U2VsZWN0ZWRQZXRJZHMiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwidG9tb3Jyb3ciLCJub3ciLCJzdGFydERhdGUiLCJzZXRTdGFydERhdGUiLCJzdGFydFRpbWUiLCJzZXRTdGFydFRpbWUiLCJlbmREYXRlIiwic2V0RW5kRGF0ZSIsImVuZFRpbWUiLCJzZXRFbmRUaW1lIiwicGF5bWVudE9wdGlvbiIsInNldFBheW1lbnRPcHRpb24iLCJub3RlIiwic2V0Tm90ZSIsImxvYWRpbmdQZXRzIiwic2V0TG9hZGluZ1BldHMiLCJzdWJtaXR0aW5nIiwic2V0U3VibWl0dGluZyIsImJvb2tpbmdFcnJvciIsInNldEJvb2tpbmdFcnJvciIsInNlcnZpY2VVbml0U3RyIiwidW5pdCIsInByaWNlVW5pdCIsInNlcnZpY2VUeXBlIiwidHlwZSIsImNhdGVnb3J5IiwiaXNEYWlseVNlcnZpY2UiLCJpbmNsdWRlcyIsImlzUGV0Q29tcGF0aWJsZSIsInNlcnZpY2UiLCJzcGVjaWVzIiwic2VydmljZVNwZWNpZXNMaXN0IiwidGFyZ2V0U3BlY2llcyIsInMiLCJwZXRTcGVjaWVzIiwiZmV0Y2hQZXRzIiwicmVzIiwiZ2V0IiwicGV0c0xpc3QiLCJkYXRhIiwicGV0cyIsImxlbmd0aCIsImNvbXBhdGlibGVQZXQiLCJmaW5kIiwicCIsImluaXRpYWxJZCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZVRvZ2dsZVBldCIsInBldElkU3RyIiwicHJldiIsImZpbHRlciIsInNlcnZpY2VQcmljZSIsIk51bWJlciIsInByaWNlIiwic3RhcnREYXRlVGltZU9iaiIsImVuZERhdGVUaW1lT2JqIiwiZHVyYXRpb25Db3VudCIsInVuaXRMYWJlbCIsImlzTmFOIiwiZ2V0VGltZSIsImRpZmZNcyIsIk1hdGgiLCJtYXgiLCJjZWlsIiwidG90YWxQcmljZSIsInBheW1lbnRBbW91bnQiLCJoYW5kbGVDb25maXJtQm9va2luZyIsInNlbGVjdGVkUGV0cyIsImluY29tcGF0aWJsZVBldCIsImZvcm1hdHRlZFBldHMiLCJ2YWxpZFBldElkIiwicHVzaCIsInBldE5vdGUiLCJzdGFydElzbyIsImVuZElzbyIsImJvb2tpbmdQYXlsb2FkIiwic2l0dGVySWQiLCJ1c2VySWQiLCJzZXJ2aWNlSWQiLCJzdGFydHRpbWUiLCJlbmR0aW1lIiwicGF5bWVudHBsYW4iLCJwb3N0Iiwic3RhdHVzIiwic2VydmVyTWVzc2FnZSIsInJlc3BvbnNlIiwibWVzc2FnZSIsInNlcnZpY2VOYW1lIiwibmFtZSIsInRvTG9jYWxlU3RyaW5nIiwic2l0dGVyTmFtZSIsInNpdHRlcm5hbWUiLCJpc1NlbGVjdGVkIiwiY29tcGF0aWJsZSIsImJyZWVkIiwiZSIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQm9va2luZ01vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGlcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcIi4uL3V0aWxzL3RvYXN0XCI7XG5cbi8vIDEuIOC4leC4suC4o+C4suC4h+C5geC4m+C4peC4h+C4iuC4t+C5iOC4reC4m+C4o+C4sOC5gOC4oOC4l+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C5gOC4m+C5h+C4meC4oOC4suC4qeC4suC5hOC4l+C4olxuY29uc3QgU1BFQ0lFU19USEFJX01BUCA9IHtcbiAgZG9nOiBcIuC4quC4uOC4meC4seC4glwiLFxuICBjYXQ6IFwi4LmB4Lih4LinXCIsXG4gIGJpcmQ6IFwi4LiZ4LiBXCIsXG4gIGV4b3RpYzogXCLguKrguLHguJXguKfguYzguYHguJvguKXguIFcIixcbiAgcmFiYml0OiBcIuC4geC4o+C4sOC4leC5iOC4suC4olwiLFxuICBmaXNoOiBcIuC4m+C4peC4slwiLFxuICByb2RlbnQ6IFwi4Liq4Lix4LiV4Lin4LmM4Lif4Lix4LiZ4LmB4LiX4LiwXCIsXG59O1xuXG4vLyBIZWxwZXI6IOC4n+C4seC4h+C4geC5jOC4iuC4seC4meC5geC4m+C4peC4h+C4m+C4o+C4sOC5gOC4oOC4l+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C5gOC4m+C5h+C4meC4oOC4suC4qeC4suC5hOC4l+C4olxuY29uc3QgZm9ybWF0U3BlY2llc1RoYWkgPSAoc3BlY2llc0lucHV0KSA9PiB7XG4gIGlmICghc3BlY2llc0lucHV0KSByZXR1cm4gXCLguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJfguLjguIHguIrguJnguLTguJRcIjtcbiAgY29uc3QgbGlzdCA9IEFycmF5LmlzQXJyYXkoc3BlY2llc0lucHV0KSA/IHNwZWNpZXNJbnB1dCA6IFtzcGVjaWVzSW5wdXRdO1xuICByZXR1cm4gbGlzdFxuICAgIC5tYXAoKGl0ZW0pID0+IFNQRUNJRVNfVEhBSV9NQVBbU3RyaW5nKGl0ZW0pLnRvTG93ZXJDYXNlKCldIHx8IGl0ZW0pXG4gICAgLmpvaW4oXCIsIFwiKTtcbn07XG5cbi8vIEhlbHBlcjog4LmB4Lib4Lil4LiH4LiK4Li34LmI4Lit4Lib4Lij4Liw4LmA4Lig4LiX4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Lix4LmJ4LiHIOC5hOC4l+C4oi/guK3guLHguIfguIHguKTguKkg4LmA4Lib4LmH4LiZIEtleSDguKHguLLguJXguKPguJDguLLguJlcbmNvbnN0IG5vcm1hbGl6ZVNwZWNpZXMgPSAoc3BlY2llc0lucHV0KSA9PiB7XG4gIGlmICghc3BlY2llc0lucHV0KSByZXR1cm4gXCJcIjtcbiAgY29uc3Qgc3RyID0gU3RyaW5nKHNwZWNpZXNJbnB1dCkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG5cbiAgY29uc3QgdGhhaVRvRW5nID0ge1xuICAgIFwi4Liq4Li44LiZ4Lix4LiCXCI6IFwiZG9nXCIsXG4gICAgXCLguKvguKHguLJcIjogXCJkb2dcIixcbiAgICBcIuC5geC4oeC4p1wiOiBcImNhdFwiLFxuICAgIFwi4LiZ4LiBXCI6IFwiYmlyZFwiLFxuICAgIFwi4Liq4Lix4LiV4Lin4LmM4LmB4Lib4Lil4LiBXCI6IFwiZXhvdGljXCIsXG4gICAgXCLguIHguKPguLDguJXguYjguLLguKJcIjogXCJyYWJiaXRcIixcbiAgICBcIuC4m+C4peC4slwiOiBcImZpc2hcIixcbiAgICBcIuC4quC4seC4leC4p+C5jOC4n+C4seC4meC5geC4l+C4sFwiOiBcInJvZGVudFwiLFxuICB9O1xuXG4gIHJldHVybiB0aGFpVG9Fbmdbc3RyXSB8fCBzdHI7XG59O1xuXG4vLyBIZWxwZXI6IOC5geC4geC4sCBQZXQgSUQg4Lij4Lit4LiH4Lij4Lix4Lia4LiX4Li44LiB4Lij4Li54Lib4LmB4Lia4Lia4LiK4Li34LmI4Lit4LiE4Li14Lii4LmMIChwZXRpZCwgcGV0SWQsIGlkLCBwZXRfaWQpXG5jb25zdCBnZXRQZXRJZCA9IChwZXQpID0+XG4gIHBldD8ucGV0SWQgfHwgcGV0Py5wZXRpZCB8fCBwZXQ/LmlkIHx8IHBldD8ucGV0X2lkIHx8IHBldD8udXNlclBldElkIHx8IHBldD8uX2lkO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCb29raW5nTW9kYWwoe1xuICBpc09wZW4sXG4gIG9uQ2xvc2UsXG4gIHNpdHRlcixcbiAgc2VsZWN0ZWRTZXJ2aWNlLFxuICBvblN1Y2Nlc3MsXG59KSB7XG4gIGNvbnN0IFt1c2VyUGV0cywgc2V0VXNlclBldHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbc2VsZWN0ZWRQZXRJZHMsIHNldFNlbGVjdGVkUGV0SWRzXSA9IHVzZVN0YXRlKFtdKTtcblxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XG4gIGNvbnN0IHRvbW9ycm93ID0gbmV3IERhdGUoRGF0ZS5ub3coKSArIDg2NDAwMDAwKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcblxuICBjb25zdCBbc3RhcnREYXRlLCBzZXRTdGFydERhdGVdID0gdXNlU3RhdGUodG9kYXkpO1xuICBjb25zdCBbc3RhcnRUaW1lLCBzZXRTdGFydFRpbWVdID0gdXNlU3RhdGUoXCIwOTowMFwiKTtcbiAgY29uc3QgW2VuZERhdGUsIHNldEVuZERhdGVdID0gdXNlU3RhdGUodG9tb3Jyb3cpO1xuICBjb25zdCBbZW5kVGltZSwgc2V0RW5kVGltZV0gPSB1c2VTdGF0ZShcIjE4OjAwXCIpO1xuXG4gIGNvbnN0IFtwYXltZW50T3B0aW9uLCBzZXRQYXltZW50T3B0aW9uXSA9IHVzZVN0YXRlKFwiZnVsbFwiKTtcbiAgY29uc3QgW25vdGUsIHNldE5vdGVdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgW2xvYWRpbmdQZXRzLCBzZXRMb2FkaW5nUGV0c10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzdWJtaXR0aW5nLCBzZXRTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Jvb2tpbmdFcnJvciwgc2V0Qm9va2luZ0Vycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIC8vIOC5gOC4iuC5h+C4geC4m+C4o+C4sOC5gOC4oOC4l+C4muC4o+C4tOC4geC4suC4oyAo4Lij4Liy4Lii4Lin4Lix4LiZIHZzIOC4o+C4suC4ouC4iuC4seC5iOC4p+C5guC4oeC4hylcbiAgY29uc3Qgc2VydmljZVVuaXRTdHIgPSBTdHJpbmcoXG4gICAgc2VsZWN0ZWRTZXJ2aWNlPy51bml0IHx8XG4gICAgc2VsZWN0ZWRTZXJ2aWNlPy5wcmljZVVuaXQgfHxcbiAgICBzZWxlY3RlZFNlcnZpY2U/LnNlcnZpY2VUeXBlIHx8XG4gICAgc2VsZWN0ZWRTZXJ2aWNlPy50eXBlIHx8XG4gICAgc2VsZWN0ZWRTZXJ2aWNlPy5jYXRlZ29yeSB8fFxuICAgIFwiXCJcbiAgKS50b0xvd2VyQ2FzZSgpO1xuXG4gIGNvbnN0IGlzRGFpbHlTZXJ2aWNlID1cbiAgICBzZXJ2aWNlVW5pdFN0ci5pbmNsdWRlcyhcImRheVwiKSB8fFxuICAgIHNlcnZpY2VVbml0U3RyLmluY2x1ZGVzKFwiZGFpbHlcIikgfHxcbiAgICBzZXJ2aWNlVW5pdFN0ci5pbmNsdWRlcyhcIuC4p+C4seC4mVwiKTtcblxuICAvLyDguJ/guLHguIfguIHguYzguIrguLHguJnguYDguIrguYfguIHguKfguYjguLLguJvguKPguLDguYDguKDguJfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJXguKPguIfguIHguLHguJrguJrguKPguLTguIHguLLguKPguKvguKPguLfguK3guYTguKHguYggKOC4o+C4reC4h+C4o+C4seC4muC4l+C4seC5ieC4h+C4oOC4suC4qeC4suC5hOC4l+C4ouC5geC4peC4sOC4reC4seC4h+C4geC4pOC4qSlcbiAgY29uc3QgaXNQZXRDb21wYXRpYmxlID0gKHBldCwgc2VydmljZSkgPT4ge1xuICAgIGlmICghc2VydmljZSB8fCAhc2VydmljZS5zcGVjaWVzKSByZXR1cm4gdHJ1ZTtcblxuICAgIGNvbnN0IHNlcnZpY2VTcGVjaWVzTGlzdCA9IEFycmF5LmlzQXJyYXkoc2VydmljZS5zcGVjaWVzKVxuICAgICAgPyBzZXJ2aWNlLnNwZWNpZXNcbiAgICAgIDogW3NlcnZpY2Uuc3BlY2llc107XG5cbiAgICBjb25zdCB0YXJnZXRTcGVjaWVzID0gc2VydmljZVNwZWNpZXNMaXN0Lm1hcCgocykgPT4gbm9ybWFsaXplU3BlY2llcyhzKSk7XG4gICAgY29uc3QgcGV0U3BlY2llcyA9IG5vcm1hbGl6ZVNwZWNpZXMocGV0Py5zcGVjaWVzKTtcblxuICAgIHJldHVybiB0YXJnZXRTcGVjaWVzLmluY2x1ZGVzKHBldFNwZWNpZXMpO1xuICB9O1xuXG4gIC8vIOC4lOC4tuC4h+C4guC5ieC4reC4oeC4ueC4peC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4iOC4suC4gSAvdXNlcnMvbWVcbiAgY29uc3QgZmV0Y2hQZXRzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHNldExvYWRpbmdQZXRzKHRydWUpO1xuICAgIHNldEJvb2tpbmdFcnJvcihcIlwiKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi91c2Vycy9tZVwiKTtcbiAgICAgIGNvbnN0IHBldHNMaXN0ID0gcmVzLmRhdGE/LmRhdGE/LnBldHMgfHwgcmVzLmRhdGE/LnBldHMgfHwgW107XG4gICAgICBzZXRVc2VyUGV0cyhwZXRzTGlzdCk7XG5cbiAgICAgIGlmIChwZXRzTGlzdC5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IGNvbXBhdGlibGVQZXQgPSBwZXRzTGlzdC5maW5kKChwKSA9PlxuICAgICAgICAgIGlzUGV0Q29tcGF0aWJsZShwLCBzZWxlY3RlZFNlcnZpY2UpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGluaXRpYWxJZCA9IGNvbXBhdGlibGVQZXQgPyBnZXRQZXRJZChjb21wYXRpYmxlUGV0KSA6IG51bGw7XG4gICAgICAgIHNldFNlbGVjdGVkUGV0SWRzKGluaXRpYWxJZCA/IFtTdHJpbmcoaW5pdGlhbElkKV0gOiBbXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRTZWxlY3RlZFBldElkcyhbXSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHBldHM6XCIsIGVycik7XG4gICAgICBzZXRCb29raW5nRXJyb3IoXCLguYTguKHguYjguKrguLLguKHguLLguKPguJbguJTguLbguIfguILguYnguK3guKHguLnguKXguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguYTguJTguYkg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nUGV0cyhmYWxzZSk7XG4gICAgfVxuICB9LCBbc2VsZWN0ZWRTZXJ2aWNlXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNPcGVuKSB7XG4gICAgICBmZXRjaFBldHMoKTtcbiAgICB9XG4gIH0sIFtpc09wZW4sIGZldGNoUGV0c10pO1xuXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICAvLyBUb2dnbGUg4LmA4Lil4Li34Lit4LiBL+C4ouC4geC5gOC4peC4tOC4geC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4q+C4peC4suC4ouC4leC4seC4p1xuICBjb25zdCBoYW5kbGVUb2dnbGVQZXQgPSAocGV0SWRTdHIpID0+IHtcbiAgICBzZXRTZWxlY3RlZFBldElkcygocHJldikgPT5cbiAgICAgIHByZXYuaW5jbHVkZXMocGV0SWRTdHIpXG4gICAgICAgID8gcHJldi5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gcGV0SWRTdHIpXG4gICAgICAgIDogWy4uLnByZXYsIHBldElkU3RyXVxuICAgICk7XG4gIH07XG5cbiAgLy8g4LiE4Liz4LiZ4Lin4LiT4Lij4Liw4Lii4Liw4LmA4Lin4Lil4Liy4LmB4Lil4Liw4Lij4Liy4LiE4Liy4Lij4Lin4LihXG4gIGNvbnN0IHNlcnZpY2VQcmljZSA9IE51bWJlcihzZWxlY3RlZFNlcnZpY2U/LnByaWNlIHx8IDApO1xuICBjb25zdCBzdGFydERhdGVUaW1lT2JqID0gbmV3IERhdGUoYCR7c3RhcnREYXRlfVQke3N0YXJ0VGltZX06MDBgKTtcbiAgY29uc3QgZW5kRGF0ZVRpbWVPYmogPSBuZXcgRGF0ZShgJHtlbmREYXRlfVQke2VuZFRpbWV9OjAwYCk7XG5cbiAgbGV0IGR1cmF0aW9uQ291bnQgPSAxO1xuICBsZXQgdW5pdExhYmVsID0gaXNEYWlseVNlcnZpY2UgPyBcIuC4p+C4seC4mVwiIDogXCLguIrguLHguYjguKfguYLguKHguIdcIjtcblxuICBpZiAoIWlzTmFOKHN0YXJ0RGF0ZVRpbWVPYmouZ2V0VGltZSgpKSAmJiAhaXNOYU4oZW5kRGF0ZVRpbWVPYmouZ2V0VGltZSgpKSkge1xuICAgIGNvbnN0IGRpZmZNcyA9IGVuZERhdGVUaW1lT2JqLmdldFRpbWUoKSAtIHN0YXJ0RGF0ZVRpbWVPYmouZ2V0VGltZSgpO1xuICAgIGlmIChkaWZmTXMgPiAwKSB7XG4gICAgICBpZiAoaXNEYWlseVNlcnZpY2UpIHtcbiAgICAgICAgZHVyYXRpb25Db3VudCA9IE1hdGgubWF4KDEsIE1hdGguY2VpbChkaWZmTXMgLyAoMTAwMCAqIDYwICogNjAgKiAyNCkpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGR1cmF0aW9uQ291bnQgPSBNYXRoLm1heCgxLCBNYXRoLmNlaWwoZGlmZk1zIC8gKDEwMDAgKiA2MCAqIDYwKSkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRvdGFsUHJpY2UgPSBzZXJ2aWNlUHJpY2UgKiBkdXJhdGlvbkNvdW50O1xuICBjb25zdCBwYXltZW50QW1vdW50ID1cbiAgICBwYXltZW50T3B0aW9uID09PSBcImRlcG9zaXRcIiA/IHRvdGFsUHJpY2UgKiAwLjMgOiB0b3RhbFByaWNlO1xuXG4gIC8vIOC4n+C4seC4h+C4geC5jOC4iuC4seC4meC4geC4lOC4ouC4t+C4meC4ouC4seC4meC4geC4suC4o+C4iOC4reC4h1xuICBjb25zdCBoYW5kbGVDb25maXJtQm9va2luZyA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRCb29raW5nRXJyb3IoXCJcIik7XG4gICAgc2V0U3VibWl0dGluZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBzZWxlY3RlZFBldHMgPSB1c2VyUGV0cy5maWx0ZXIoKHApID0+XG4gICAgICAgIHNlbGVjdGVkUGV0SWRzLmluY2x1ZGVzKFN0cmluZyhnZXRQZXRJZChwKSkpXG4gICAgICApO1xuXG4gICAgICBpZiAoc2VsZWN0ZWRQZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBzZXRCb29raW5nRXJyb3IoXCLguIHguKPguLjguJPguLLguYDguKXguLfguK3guIHguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJfguLXguYjguJXguYnguK3guIfguIHguLLguKPguIjguK3guIfguJrguKPguLTguIHguLLguKNcIik7XG4gICAgICAgIHNldFN1Ym1pdHRpbmcoZmFsc2UpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGluY29tcGF0aWJsZVBldCA9IHNlbGVjdGVkUGV0cy5maW5kKFxuICAgICAgICAocCkgPT4gIWlzUGV0Q29tcGF0aWJsZShwLCBzZWxlY3RlZFNlcnZpY2UpXG4gICAgICApO1xuICAgICAgaWYgKGluY29tcGF0aWJsZVBldCkge1xuICAgICAgICBzZXRCb29raW5nRXJyb3IoXG4gICAgICAgICAgYOC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyAoJHtmb3JtYXRTcGVjaWVzVGhhaShpbmNvbXBhdGlibGVQZXQuc3BlY2llcyl9KSDguYTguKHguYjguJXguKPguIfguIHguLHguJrguJvguKPguLDguYDguKDguJfguJfguLXguYjguJrguKPguLTguIHguLLguKPguKPguLHguJrguJ3guLLguIEgKCR7Zm9ybWF0U3BlY2llc1RoYWkoc2VsZWN0ZWRTZXJ2aWNlPy5zcGVjaWVzKX0pYFxuICAgICAgICApO1xuICAgICAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBmb3JtYXR0ZWRQZXRzID0gW107XG4gICAgICBmb3IgKGNvbnN0IHBldCBvZiBzZWxlY3RlZFBldHMpIHtcbiAgICAgICAgY29uc3QgdmFsaWRQZXRJZCA9IE51bWJlcihnZXRQZXRJZChwZXQpKTtcbiAgICAgICAgaWYgKCF2YWxpZFBldElkIHx8IE51bWJlci5pc05hTih2YWxpZFBldElkKSB8fCB2YWxpZFBldElkIDw9IDApIHtcbiAgICAgICAgICBzZXRCb29raW5nRXJyb3IoXCLguYTguKHguYjguJ7guJrguKPguKvguLHguKrguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJfguLXguYjguJbguLnguIHguJXguYnguK3guIdcIik7XG4gICAgICAgICAgc2V0U3VibWl0dGluZyhmYWxzZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGZvcm1hdHRlZFBldHMucHVzaCh7XG4gICAgICAgICAgcGV0SWQ6IHZhbGlkUGV0SWQsXG4gICAgICAgICAgLi4uKG5vdGUudHJpbSgpID8geyBwZXROb3RlOiBub3RlLnRyaW0oKSB9IDoge30pLFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc3RhcnRJc28gPSBuZXcgRGF0ZShgJHtzdGFydERhdGV9VCR7c3RhcnRUaW1lfTowMGApLnRvSVNPU3RyaW5nKCk7XG4gICAgICBjb25zdCBlbmRJc28gPSBuZXcgRGF0ZShgJHtlbmREYXRlfVQke2VuZFRpbWV9OjAwYCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgY29uc3QgYm9va2luZ1BheWxvYWQgPSB7XG4gICAgICAgIHNpdHRlcklkOiBOdW1iZXIoc2l0dGVyPy5zaXR0ZXJJZCB8fCBzaXR0ZXI/LmlkIHx8IHNpdHRlcj8udXNlcklkKSxcbiAgICAgICAgc2VydmljZUlkOiBOdW1iZXIoc2VsZWN0ZWRTZXJ2aWNlPy5zZXJ2aWNlSWQgfHwgc2VsZWN0ZWRTZXJ2aWNlPy5pZCksXG4gICAgICAgIHN0YXJ0dGltZTogc3RhcnRJc28sXG4gICAgICAgIGVuZHRpbWU6IGVuZElzbyxcbiAgICAgICAgcGF5bWVudHBsYW46IHBheW1lbnRPcHRpb24gPT09IFwiZGVwb3NpdFwiID8gXCJkZXBvc2l0XCIgOiBcImZ1bGxcIixcbiAgICAgICAgLi4uKG5vdGUudHJpbSgpID8geyBub3RlOiBub3RlLnRyaW0oKSB9IDoge30pLFxuICAgICAgICBwZXRzOiBmb3JtYXR0ZWRQZXRzLFxuICAgICAgfTtcblxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvYm9va2luZ3NcIiwgYm9va2luZ1BheWxvYWQpO1xuXG4gICAgICBpZiAoXG4gICAgICAgIHJlcy5zdGF0dXMgPT09IDIwMCB8fFxuICAgICAgICByZXMuc3RhdHVzID09PSAyMDEgfHxcbiAgICAgICAgcmVzLmRhdGE/LnN0YXR1cyA9PT0gXCJzdWNjZXNzXCJcbiAgICAgICkge1xuICAgICAgICB0b2FzdChcIuC4iOC4reC4h+C4muC4o+C4tOC4geC4suC4o+C4quC4s+C5gOC4o+C5h+C4iOC5gOC4o+C4teC4ouC4muC4o+C5ieC4reC4ouC5geC4peC5ieC4pyFcIiwgXCJzdWNjZXNzXCIpO1xuICAgICAgICBpZiAob25TdWNjZXNzKSBvblN1Y2Nlc3MoKTtcbiAgICAgICAgb25DbG9zZSgpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkJvb2tpbmcgZmFpbGVkOlwiLCBlcnIpO1xuICAgICAgY29uc3Qgc2VydmVyTWVzc2FnZSA9XG4gICAgICAgIGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fFxuICAgICAgICBlcnIucmVzcG9uc2U/LmRhdGE/LmVycm9yIHx8XG4gICAgICAgIFwi4LmE4Lih4LmI4Liq4Liy4Lih4Liy4Lij4LiW4LiX4Liz4Lij4Liy4Lii4LiB4Liy4Lij4LiI4Lit4LiH4LmE4LiU4LmJIOC4geC4o+C4uOC4k+C4suC4leC4o+C4p+C4iOC4quC4reC4muC4guC5ieC4reC4oeC4ueC4pVwiO1xuICAgICAgc2V0Qm9va2luZ0Vycm9yKHNlcnZlck1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay81MCBwLTQgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIG1heC13LWxnIHctZnVsbCBwLTYgc2hhZG93LXhsIHJlbGF0aXZlXCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICDguKLguLfguJnguKLguLHguJnguIHguLLguKPguIjguK3guIfguJrguKPguLTguIHguLLguKNcbiAgICAgICAgPC9oMj5cblxuICAgICAgICB7Lyog4LiC4LmJ4Lit4Lih4Li54Lil4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LmB4Lil4Liw4Lia4Lij4Li04LiB4Liy4LijICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC00IHJvdW5kZWQteGwgbWItNCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1sZyB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgIHtzZWxlY3RlZFNlcnZpY2U/LnNlcnZpY2VOYW1lIHx8IHNlbGVjdGVkU2VydmljZT8ubmFtZSB8fCBcIuC4muC4o+C4tOC4geC4suC4o+C4neC4suC4geC5gOC4peC4teC5ieC4ouC4h1wifVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgYmctb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS03MDAgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgIOC4v3tzZXJ2aWNlUHJpY2UudG9Mb2NhbGVTdHJpbmcoKX0gLyB7dW5pdExhYmVsfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0xXCI+XG4gICAgICAgICAgICDguJ7guLXguYjguYDguKXguLXguYnguKLguIc6IHtzaXR0ZXI/LnNpdHRlck5hbWUgfHwgc2l0dGVyPy5uYW1lIHx8IHNpdHRlcj8uc2l0dGVybmFtZSB8fCBcIlBvc2l0dGVyXCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW9yYW5nZS02MDAgbXQtMSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAg4Lij4Lix4Lia4Lid4Liy4LiB4Lib4Lij4Liw4LmA4Lig4LiXOiB7Zm9ybWF0U3BlY2llc1RoYWkoc2VsZWN0ZWRTZXJ2aWNlPy5zcGVjaWVzKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4leC4seC4p+C5gOC4peC4t+C4reC4geC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cbiAgICAgICAgICAgIOC5gOC4peC4t+C4reC4geC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyAoUGV0KVxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAge2xvYWRpbmdQZXRzID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgcHktMlwiPuC4geC4s+C4peC4seC4h+C5guC4q+C4peC4lOC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hy4uLjwvZGl2PlxuICAgICAgICAgICkgOiB1c2VyUGV0cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1yZWQtNTAwIHB5LTJcIj5cbiAgICAgICAgICAgICAg4LmE4Lih4LmI4Lie4Lia4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiC4Lit4LiH4LiE4Li44LiTIOC4geC4o+C4uOC4k+C4suC5gOC4nuC4tOC5iOC4oeC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C5g+C4meC5guC4m+C4o+C5hOC4n+C4peC5jOC4geC5iOC4reC4meC4iOC4reC4h1xuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLTQwIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICB7dXNlclBldHMubWFwKChwZXQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBwZXRJZFN0ciA9IFN0cmluZyhnZXRQZXRJZChwZXQpKTtcbiAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRQZXRJZHMuaW5jbHVkZXMocGV0SWRTdHIpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbXBhdGlibGUgPSBpc1BldENvbXBhdGlibGUocGV0LCBzZWxlY3RlZFNlcnZpY2UpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAga2V5PXtwZXRJZFN0cn1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChjb21wYXRpYmxlKSBoYW5kbGVUb2dnbGVQZXQocGV0SWRTdHIpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAhY29tcGF0aWJsZVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIm9wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkIGJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTIwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItb3JhbmdlLTUwMCBiZy1vcmFuZ2UtNTAvNTAgdGV4dC1vcmFuZ2UtOTAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItZ3JheS0yMDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDwn5C+IHtwZXQubmFtZX17XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICB7IWNvbXBhdGlibGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTUwMCBmb250LW5vcm1hbCBtbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKOC4m+C4o+C4sOC5gOC4oOC4l+C5hOC4oeC5iOC4leC4o+C4h+C4geC4seC4muC4muC4o+C4tOC4geC4suC4oylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAg4Lib4Lij4Liw4LmA4Lig4LiXOiB7Zm9ybWF0U3BlY2llc1RoYWkocGV0LnNwZWNpZXMpfXtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXQuYnJlZWQgPyBgKCR7cGV0LmJyZWVkfSlgIDogXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkICYmIGNvbXBhdGlibGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCBmb250LWJvbGQgdGV4dC1zbVwiPuKckzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4p+C4seC4meC4l+C4teC5iOC5geC4peC4sOC5gOC4p+C4peC4siAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIG1iLTRcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1iLTFcIj5cbiAgICAgICAgICAgICAg4Lin4Lix4LiZ4LiX4Li14LmI4LmA4Lij4Li04LmI4Lih4Lia4Lij4Li04LiB4Liy4LijXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3N0YXJ0RGF0ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGFydERhdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXNtIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9yYW5nZS01MDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIOC5gOC4p+C4peC4suC5gOC4o+C4tOC5iOC4oeC4muC4o+C4tOC4geC4suC4oyB7aXNEYWlseVNlcnZpY2UgPyBcIijguKPguLDguJrguLjguYDguKfguKXguLLguJ3guLLguIEpXCIgOiBcIlwifVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGltZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzdGFydFRpbWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3RhcnRUaW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTIgdGV4dC1zbSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vcmFuZ2UtNTAwIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWItMVwiPlxuICAgICAgICAgICAgICDguKfguLHguJnguJfguLXguYjguKrguLTguYnguJnguKrguLjguJTguJrguKPguLTguIHguLLguKNcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZW5kRGF0ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbmREYXRlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTIgdGV4dC1zbSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vcmFuZ2UtNTAwIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWItMVwiPlxuICAgICAgICAgICAgICDguYDguKfguKXguLLguKrguLTguYnguJnguKrguLjguJTguJrguKPguLTguIHguLLguKMge2lzRGFpbHlTZXJ2aWNlID8gXCIo4Lij4Liw4Lia4Li44LmA4Lin4Lil4Liy4Lij4Lix4LiaKVwiIDogXCJcIn1cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZW5kVGltZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbmRUaW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTIgdGV4dC1zbSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1vcmFuZ2UtNTAwIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7Lyog4Lij4Liw4Lii4Liw4LmA4Lin4Lil4LiyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC0zIHJvdW5kZWQtbGcgdGV4dC14cyB0ZXh0LWdyYXktNjAwIG1iLTQgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPHNwYW4+4o+x77iPIOC4o+C4sOC4ouC4sOC5gOC4p+C4peC4suC4l+C4seC5ieC4h+C4q+C4oeC4lDo8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj5cbiAgICAgICAgICAgIHtkdXJhdGlvbkNvdW50fSB7dW5pdExhYmVsfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4o+C4ueC4m+C5geC4muC4muC4geC4suC4o+C4iuC4s+C4o+C4sOC5gOC4h+C4tOC4mSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cbiAgICAgICAgICAgIOC4o+C4ueC4m+C5geC4muC4muC4geC4suC4o+C4iuC4s+C4o+C4sOC5gOC4h+C4tOC4mSAoUGF5bWVudCBPcHRpb24pXG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICB2YWx1ZT17cGF5bWVudE9wdGlvbn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF5bWVudE9wdGlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXNtIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9yYW5nZS01MDAgb3V0bGluZS1ub25lIGJnLXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZnVsbFwiPuC4iuC4s+C4o+C4sOC5gOC4leC5h+C4oeC4iOC4s+C4meC4p+C4mSAxMDAlICjguL97dG90YWxQcmljZS50b0xvY2FsZVN0cmluZygpfSk8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkZXBvc2l0XCI+4LiK4Liz4Lij4Liw4Lih4Lix4LiU4LiI4LizIDMwJSAo4Li/eyh0b3RhbFByaWNlICogMC4zKS50b0xvY2FsZVN0cmluZygpfSk8L29wdGlvbj5cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4q+C4oeC4suC4ouC5gOC4q+C4leC4uCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cbiAgICAgICAgICAgIOC4q+C4oeC4suC4ouC5gOC4q+C4leC4uOC5gOC4nuC4tOC5iOC4oeC5gOC4leC4tOC4oeC4luC4tuC4h+C4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h1xuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICByb3dzPVwiMlwiXG4gICAgICAgICAgICB2YWx1ZT17bm90ZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguITguLPguYHguJnguLDguJnguLPguIHguLLguKPguYPguKvguYnguK3guLLguKvguLLguKMg4Lir4Lij4Li34Lit4LiI4Li44LiU4LiZ4Lix4LiU4Lie4LiaXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC0yIHRleHQtc20gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctb3JhbmdlLTUwMCBvdXRsaW5lLW5vbmUgcmVzaXplLW5vbmVcIlxuICAgICAgICAgID48L3RleHRhcmVhPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7Lyog4Liq4Lij4Li44Lib4Lij4Liy4LiE4LiyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IHB0LTMgbWItNCBzcGFjZS15LTFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxuICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgIOC4o+C4suC4hOC4suC4ouC4reC4lOC4o+C4p+C4oeC4l+C4seC5ieC4h+C4q+C4oeC4lCAoe2R1cmF0aW9uQ291bnR9IHt1bml0TGFiZWx9KTpcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPuC4v3t0b3RhbFByaWNlLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cbiAgICAgICAgICAgIDxzcGFuPuC4ouC4reC4lOC4iuC4s+C4o+C4sOC4l+C4seC4meC4l+C4tSAoe3BheW1lbnRPcHRpb24gPT09IFwiZGVwb3NpdFwiID8gXCLguKHguLHguJTguIjguLMgMzAlXCIgOiBcIuC5gOC4leC5h+C4oeC4iOC4s+C4meC4p+C4mSAxMDAlXCJ9KTo8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj7guL97cGF5bWVudEFtb3VudC50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4guC5ieC4reC4hOC4p+C4suC4oeC5geC4quC4lOC4hyBFcnJvciAqL31cbiAgICAgICAge2Jvb2tpbmdFcnJvciAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtMyBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHRleHQtcmVkLTYwMCB0ZXh0LXhzIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIOKaoO+4jyB7Ym9va2luZ0Vycm9yfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiDguJvguLjguYjguKEgYWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0dGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uIHRleHQtc21cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOC4ouC4geC5gOC4peC4tOC4gVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29uZmlybUJvb2tpbmd9XG4gICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0dGluZyB8fCBzZWxlY3RlZFBldElkcy5sZW5ndGggPT09IDB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IGJnLW9yYW5nZS01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIGZvbnQtc2VtaWJvbGQgaG92ZXI6Ymctb3JhbmdlLTYwMCB0cmFuc2l0aW9uIGRpc2FibGVkOm9wYWNpdHktNTAgdGV4dC1zbSBzaGFkb3ctbWRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtzdWJtaXR0aW5nID8gXCLguIHguLPguKXguLHguIfguJTguLPguYDguJnguLTguJnguIHguLLguKMuLi5cIiA6IFwi4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4LiI4Lit4LiHXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59Il0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQm9va2luZ01vZGFsLmpzeCJ9