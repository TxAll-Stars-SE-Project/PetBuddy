import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SitterCard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { PET_TYPES, SERVICE_TYPES } from "/src/utils/sitterOptions.js";
function Stars({ rating }) {
  return /* @__PURE__ */ jsxDEV("span", { className: "stars", "aria-hidden": "true", children: [1, 2, 3, 4, 5].map(
    (i) => i <= Math.round(rating) ? "★" : /* @__PURE__ */ jsxDEV("span", { className: "off", children: "★" }, i, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 27,
      columnNumber: 39
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
    lineNumber: 25,
    columnNumber: 5
  }, this);
}
_c = Stars;
export default function SitterCard({ sitter }) {
  const { sitterId, username, province, district, services, minPrice, rating, reviewCount } = sitter;
  const serviceTypes = [...new Set(services.map((s) => s.serviceType))];
  const petTypes = [...new Set(services.flatMap((s) => s.species))];
  return /* @__PURE__ */ jsxDEV("article", { className: "sitter-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "sitter-top", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-avatar", children: username.charAt(0).toUpperCase() }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "sitter-name", children: username }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "sitter-area", children: [
          "📍 ",
          [province, district].filter(Boolean).join(" · ")
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 45,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rating-row", children: rating === null ? /* @__PURE__ */ jsxDEV("span", { className: "no-review", children: "ยังไม่มีรีวิว" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 51,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Stars, { rating }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "rating-num", children: Number(rating).toFixed(1) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 55,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "rating-count", children: [
        "(",
        reviewCount,
        " รีวิว)"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 56,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 53,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "row-label", children: "บริการ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 62,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "tags", children: serviceTypes.map(
        (t) => /* @__PURE__ */ jsxDEV("span", { className: "tag tag--service", children: SERVICE_TYPES[t] ?? t }, t, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 65,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "row-label", children: "สัตว์เลี้ยงที่รับ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "tags", children: petTypes.map(
        (p) => /* @__PURE__ */ jsxDEV("span", { className: "tag", children: PET_TYPES[p] ?? p }, p, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 72,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "sitter-foot", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-price", children: [
        /* @__PURE__ */ jsxDEV("small", { children: "เริ่มต้น" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: [
          "฿",
          minPrice.toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 82,
          columnNumber: 11
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: "บาท" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 82,
          columnNumber: 57
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          className: "btn btn--small",
          to: `/sitters/${sitterId}`,
          state: { sitter },
          children: "ดูโปรไฟล์"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 86,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_c2 = SitterCard;
export function SitterCardSkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { className: "sitter-card", "aria-hidden": "true", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "sitter-top", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "skel skel--avatar" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 16, width: "55%", marginBottom: 8 } }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 104,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 12, width: "40%" } }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
          lineNumber: 105,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 14, width: "45%" } }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 24, width: "80%" } }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 24, width: "60%" } }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "sitter-foot", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 28, width: 90 } }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "skel", style: { height: 36, width: 100, borderRadius: 12 } }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
}
_c3 = SitterCardSkeleton;
var _c, _c2, _c3;
$RefreshReg$(_c, "Stars");
$RefreshReg$(_c2, "SitterCard");
$RefreshReg$(_c3, "SitterCardSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT3dDLFNBMEI5QixVQTFCOEI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQeEMsU0FBU0EsWUFBWTtBQUNyQixTQUFTQyxXQUFXQyxxQkFBcUI7QUFFekMsU0FBU0MsTUFBTSxFQUFFQyxPQUFPLEdBQUc7QUFDekIsU0FDRSx1QkFBQyxVQUFLLFdBQVUsU0FBUSxlQUFZLFFBQ2pDLFdBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUVDO0FBQUFBLElBQUksQ0FBQ0MsTUFDcEJBLEtBQUtDLEtBQUtDLE1BQU1KLE1BQU0sSUFBSSxNQUFNLHVCQUFDLFVBQWEsV0FBVSxPQUFNLGlCQUFuQkUsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsRUFDakUsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDRyxLQVJRTjtBQVVULHdCQUF3Qk8sV0FBVyxFQUFFQyxPQUFPLEdBQUc7QUFDN0MsUUFBTSxFQUFFQyxVQUFVQyxVQUFVQyxVQUFVQyxVQUFVQyxVQUFVQyxVQUFVYixRQUFRYyxZQUFZLElBQUlQO0FBRTVGLFFBQU1RLGVBQWUsQ0FBQyxHQUFHLElBQUlDLElBQUlKLFNBQVNYLElBQUksQ0FBQ2dCLE1BQU1BLEVBQUVDLFdBQVcsQ0FBQyxDQUFDO0FBQ3BFLFFBQU1DLFdBQVcsQ0FBQyxHQUFHLElBQUlILElBQUlKLFNBQVNRLFFBQVEsQ0FBQ0gsTUFBTUEsRUFBRUksT0FBTyxDQUFDLENBQUM7QUFFaEUsU0FDRSx1QkFBQyxhQUFRLFdBQVUsZUFDakI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFBaUJaLG1CQUFTYSxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxlQUFlZCxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLE9BQUUsV0FBVSxlQUFjO0FBQUE7QUFBQSxVQUFJLENBQUNDLFVBQVVDLFFBQVEsRUFBRWEsT0FBT0MsT0FBTyxFQUFFQyxLQUFLLEtBQUs7QUFBQSxhQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsV0FGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNaMUIscUJBQVcsT0FDVix1QkFBQyxVQUFLLFdBQVUsYUFBWSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QyxJQUV6QyxtQ0FDRTtBQUFBLDZCQUFDLFNBQU0sVUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFDdEIsdUJBQUMsVUFBSyxXQUFVLGNBQWMyQixpQkFBTzNCLE1BQU0sRUFBRTRCLFFBQVEsQ0FBQyxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlO0FBQUE7QUFBQSxRQUFFZDtBQUFBQSxRQUFZO0FBQUEsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLFNBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUFZLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsU0FBSSxXQUFVLFFBQ1pDLHVCQUFhZDtBQUFBQSxRQUFJLENBQUM0QixNQUNqQix1QkFBQyxVQUFhLFdBQVUsb0JBQW9CL0Isd0JBQWMrQixDQUFDLEtBQUtBLEtBQXJEQSxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxNQUNuRSxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQVksaUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxNQUM1Qyx1QkFBQyxTQUFJLFdBQVUsUUFDWlYsbUJBQVNsQjtBQUFBQSxRQUFJLENBQUM2QixNQUNiLHVCQUFDLFVBQWEsV0FBVSxPQUFPakMsb0JBQVVpQyxDQUFDLEtBQUtBLEtBQXBDQSxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxNQUNsRCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFdBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFDZix1QkFBQyxZQUFPO0FBQUE7QUFBQSxVQUFFakIsU0FBU2tCLGVBQWU7QUFBQSxhQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFBUztBQUFBLFFBQUMsdUJBQUMsVUFBSyxtQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVM7QUFBQSxXQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixJQUFJLFlBQVl2QixRQUFRO0FBQUEsVUFDeEIsT0FBTyxFQUFFRCxPQUFPO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFIcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLE9BckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzREE7QUFFSjtBQUFDeUIsTUEvRHVCMUI7QUFpRWpCLGdCQUFTMkIscUJBQXFCO0FBQ25DLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGVBQWMsZUFBWSxRQUN2QztBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUNsQyx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsTUFBTSxFQUFFLEdBQ3BCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFQyxRQUFRLElBQUlDLE9BQU8sT0FBT0MsY0FBYyxFQUFFLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVGLFFBQVEsSUFBSUMsT0FBTyxNQUFNLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxXQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFRCxRQUFRLElBQUlDLE9BQU8sTUFBTSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFRCxRQUFRLElBQUlDLE9BQU8sTUFBTSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBTyxFQUFFRCxRQUFRLElBQUlDLE9BQU8sTUFBTSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVELFFBQVEsSUFBSUMsT0FBTyxHQUFHLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUN2RCx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPLEVBQUVELFFBQVEsSUFBSUMsT0FBTyxLQUFLRSxjQUFjLEdBQUcsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLFNBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ0MsTUFuQmVOO0FBQWtCLElBQUE1QixJQUFBMkIsS0FBQU87QUFBQSxhQUFBbEMsSUFBQTtBQUFBLGFBQUEyQixLQUFBO0FBQUEsYUFBQU8sS0FBQSIsIm5hbWVzIjpbIkxpbmsiLCJQRVRfVFlQRVMiLCJTRVJWSUNFX1RZUEVTIiwiU3RhcnMiLCJyYXRpbmciLCJtYXAiLCJpIiwiTWF0aCIsInJvdW5kIiwiX2MiLCJTaXR0ZXJDYXJkIiwic2l0dGVyIiwic2l0dGVySWQiLCJ1c2VybmFtZSIsInByb3ZpbmNlIiwiZGlzdHJpY3QiLCJzZXJ2aWNlcyIsIm1pblByaWNlIiwicmV2aWV3Q291bnQiLCJzZXJ2aWNlVHlwZXMiLCJTZXQiLCJzIiwic2VydmljZVR5cGUiLCJwZXRUeXBlcyIsImZsYXRNYXAiLCJzcGVjaWVzIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsIk51bWJlciIsInRvRml4ZWQiLCJ0IiwicCIsInRvTG9jYWxlU3RyaW5nIiwiX2MyIiwiU2l0dGVyQ2FyZFNrZWxldG9uIiwiZmxleCIsImhlaWdodCIsIndpZHRoIiwibWFyZ2luQm90dG9tIiwiYm9yZGVyUmFkaXVzIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpdHRlckNhcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgUEVUX1RZUEVTLCBTRVJWSUNFX1RZUEVTIH0gZnJvbSBcIi4uL3V0aWxzL3NpdHRlck9wdGlvbnMuanNcIjtcblxuZnVuY3Rpb24gU3RhcnMoeyByYXRpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInN0YXJzXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICB7WzEsIDIsIDMsIDQsIDVdLm1hcCgoaSkgPT5cbiAgICAgICAgaSA8PSBNYXRoLnJvdW5kKHJhdGluZykgPyBcIuKYhVwiIDogPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJvZmZcIj7imIU8L3NwYW4+XG4gICAgICApfVxuICAgIDwvc3Bhbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2l0dGVyQ2FyZCh7IHNpdHRlciB9KSB7XG4gIGNvbnN0IHsgc2l0dGVySWQsIHVzZXJuYW1lLCBwcm92aW5jZSwgZGlzdHJpY3QsIHNlcnZpY2VzLCBtaW5QcmljZSwgcmF0aW5nLCByZXZpZXdDb3VudCB9ID0gc2l0dGVyO1xuICBcbiAgY29uc3Qgc2VydmljZVR5cGVzID0gWy4uLm5ldyBTZXQoc2VydmljZXMubWFwKChzKSA9PiBzLnNlcnZpY2VUeXBlKSldO1xuICBjb25zdCBwZXRUeXBlcyA9IFsuLi5uZXcgU2V0KHNlcnZpY2VzLmZsYXRNYXAoKHMpID0+IHMuc3BlY2llcykpXTtcblxuICByZXR1cm4gKFxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInNpdHRlci1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci10b3BcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYXZhdGFyXCI+e3VzZXJuYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfTwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzaXR0ZXItbmFtZVwiPnt1c2VybmFtZX08L2gzPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpdHRlci1hcmVhXCI+8J+TjSB7W3Byb3ZpbmNlLCBkaXN0cmljdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgwrcgXCIpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRpbmctcm93XCI+XG4gICAgICAgIHtyYXRpbmcgPT09IG51bGwgPyAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibm8tcmV2aWV3XCI+4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14Lij4Li14Lin4Li04LinPC9zcGFuPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8U3RhcnMgcmF0aW5nPXtyYXRpbmd9IC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyYXRpbmctbnVtXCI+e051bWJlcihyYXRpbmcpLnRvRml4ZWQoMSl9PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmF0aW5nLWNvdW50XCI+KHtyZXZpZXdDb3VudH0g4Lij4Li14Lin4Li04LinKTwvc3Bhbj5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdy1sYWJlbFwiPuC4muC4o+C4tOC4geC4suC4ozwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhZ3NcIj5cbiAgICAgICAgICB7c2VydmljZVR5cGVzLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXt0fSBjbGFzc05hbWU9XCJ0YWcgdGFnLS1zZXJ2aWNlXCI+e1NFUlZJQ0VfVFlQRVNbdF0gPz8gdH08L3NwYW4+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93LWxhYmVsXCI+4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4Lij4Lix4LiaPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFnc1wiPlxuICAgICAgICAgIHtwZXRUeXBlcy5tYXAoKHApID0+IChcbiAgICAgICAgICAgIDxzcGFuIGtleT17cH0gY2xhc3NOYW1lPVwidGFnXCI+e1BFVF9UWVBFU1twXSA/PyBwfTwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItZm9vdFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1wcmljZVwiPlxuICAgICAgICAgIDxzbWFsbD7guYDguKPguLTguYjguKHguJXguYnguJk8L3NtYWxsPlxuICAgICAgICAgIDxzdHJvbmc+4Li/e21pblByaWNlLnRvTG9jYWxlU3RyaW5nKCl9PC9zdHJvbmc+IDxzcGFuPuC4muC4suC4lzwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIPCfkYgg4Liq4LmI4LiHIHN0YXRlIHt7IHNpdHRlciB9fSDguYDguJ7guLTguYjguKHguYDguJXguLTguKHguJXguKPguIfguJnguLXguYkgKi99XG4gICAgICAgIDxMaW5rIFxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tLXNtYWxsXCIgXG4gICAgICAgICAgdG89e2Avc2l0dGVycy8ke3NpdHRlcklkfWB9XG4gICAgICAgICAgc3RhdGU9e3sgc2l0dGVyIH19XG4gICAgICAgID5cbiAgICAgICAgICDguJTguLnguYLguJvguKPguYTguJ/guKXguYxcbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gU2l0dGVyQ2FyZFNrZWxldG9uKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLWNhcmRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLXRvcFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWwgc2tlbC0tYXZhdGFyXCIgLz5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tlbFwiIHN0eWxlPXt7IGhlaWdodDogMTYsIHdpZHRoOiBcIjU1JVwiLCBtYXJnaW5Cb3R0b206IDggfX0gLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxcIiBzdHlsZT17eyBoZWlnaHQ6IDEyLCB3aWR0aDogXCI0MCVcIiB9fSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsXCIgc3R5bGU9e3sgaGVpZ2h0OiAxNCwgd2lkdGg6IFwiNDUlXCIgfX0gLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tlbFwiIHN0eWxlPXt7IGhlaWdodDogMjQsIHdpZHRoOiBcIjgwJVwiIH19IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxcIiBzdHlsZT17eyBoZWlnaHQ6IDI0LCB3aWR0aDogXCI2MCVcIiB9fSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItZm9vdFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrZWxcIiBzdHlsZT17eyBoZWlnaHQ6IDI4LCB3aWR0aDogOTAgfX0gLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsXCIgc3R5bGU9e3sgaGVpZ2h0OiAzNiwgd2lkdGg6IDEwMCwgYm9yZGVyUmFkaXVzOiAxMiB9fSAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59Il0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU2l0dGVyQ2FyZC5qc3gifQ==