import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/sitter/SitterBookingsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Navbar from "/src/components/Navbar.jsx";
import SitterBookingList from "/src/components/sitter/SitterBookingList.tsx";
import { useAuth } from "/src/context/AuthContext.jsx";
export default function SitterBookingsPage() {
  _s();
  const { user } = useAuth();
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "home-main", children: /* @__PURE__ */ jsxDEV("section", { className: "home-card", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "24px",
            flexWrap: "wrap",
            gap: "12px"
          },
          children: [
            /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "24px", color: "var(--text, #1f2937)", margin: 0 }, children: "รายการคำขอการจอง (Sitter Bookings)" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
              lineNumber: 42,
              columnNumber: 13
            }, this),
            user?.username && /* @__PURE__ */ jsxDEV(
              "span",
              {
                style: {
                  fontSize: "13.5px",
                  color: "#4b5563",
                  backgroundColor: "#fff7ef",
                  border: "1px solid #ffedd5",
                  padding: "6px 14px",
                  borderRadius: "20px"
                },
                children: [
                  "พี่เลี้ยง: ",
                  /* @__PURE__ */ jsxDEV("strong", { style: { color: "#ea580c" }, children: user.username }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
                    lineNumber: 56,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
                lineNumber: 46,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
          lineNumber: 32,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(SitterBookingList, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
        lineNumber: 60,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
      lineNumber: 31,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
}
_s(SitterBookingsPage, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c = SitterBookingsPage;
var _c;
$RefreshReg$(_c, "SitterBookingsPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/sitter/SitterBookingsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVE4sT0FBT0EsWUFBWTtBQUNuQixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQzNDLFFBQU0sRUFBRUMsS0FBSyxJQUFJSCxRQUFRO0FBRXpCLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxVQUFLLFdBQVUsYUFDZCxpQ0FBQyxhQUFRLFdBQVUsYUFDakI7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTztBQUFBLFlBQ0xJLFNBQVM7QUFBQSxZQUNUQyxnQkFBZ0I7QUFBQSxZQUNoQkMsWUFBWTtBQUFBLFlBQ1pDLGNBQWM7QUFBQSxZQUNkQyxVQUFVO0FBQUEsWUFDVkMsS0FBSztBQUFBLFVBQ1A7QUFBQSxVQUVBO0FBQUEsbUNBQUMsUUFBRyxPQUFPLEVBQUVDLFVBQVUsUUFBUUMsT0FBTyx3QkFBd0JDLFFBQVEsRUFBRSxHQUFFLGtEQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ1QsTUFBTVUsWUFDTDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU87QUFBQSxrQkFDTEgsVUFBVTtBQUFBLGtCQUNWQyxPQUFPO0FBQUEsa0JBQ1BHLGlCQUFpQjtBQUFBLGtCQUNqQkMsUUFBUTtBQUFBLGtCQUNSQyxTQUFTO0FBQUEsa0JBQ1RDLGNBQWM7QUFBQSxnQkFDaEI7QUFBQSxnQkFBRTtBQUFBO0FBQUEsa0JBRVMsdUJBQUMsWUFBTyxPQUFPLEVBQUVOLE9BQU8sVUFBVSxHQUFJUixlQUFLVSxZQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBO0FBQUE7QUFBQSxjQVZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBO0FBQUE7QUFBQSxRQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEyQkE7QUFBQSxNQUNBLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0I7QUFBQSxTQTdCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsT0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUNYLEdBekN1QkQsb0JBQWtCO0FBQUEsVUFDdkJELE9BQU87QUFBQTtBQUFBLEtBREZDO0FBQWtCLElBQUFpQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZiYXIiLCJTaXR0ZXJCb29raW5nTGlzdCIsInVzZUF1dGgiLCJTaXR0ZXJCb29raW5nc1BhZ2UiLCJfcyIsInVzZXIiLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwibWFyZ2luQm90dG9tIiwiZmxleFdyYXAiLCJnYXAiLCJmb250U2l6ZSIsImNvbG9yIiwibWFyZ2luIiwidXNlcm5hbWUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXIiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2l0dGVyQm9va2luZ3NQYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTmF2YmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTmF2YmFyJztcbmltcG9ydCBTaXR0ZXJCb29raW5nTGlzdCBmcm9tICcuLi8uLi9jb21wb25lbnRzL3NpdHRlci9TaXR0ZXJCb29raW5nTGlzdCc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpdHRlckJvb2tpbmdzUGFnZSgpIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPE5hdmJhciAvPlxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiaG9tZS1tYWluXCI+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhvbWUtY2FyZFwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzI0cHgnLFxuICAgICAgICAgICAgICBmbGV4V3JhcDogJ3dyYXAnLFxuICAgICAgICAgICAgICBnYXA6ICcxMnB4JyxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGgxIHN0eWxlPXt7IGZvbnRTaXplOiAnMjRweCcsIGNvbG9yOiAndmFyKC0tdGV4dCwgIzFmMjkzNyknLCBtYXJnaW46IDAgfX0+XG4gICAgICAgICAgICAgIOC4o+C4suC4ouC4geC4suC4o+C4hOC4s+C4guC4reC4geC4suC4o+C4iOC4reC4hyAoU2l0dGVyIEJvb2tpbmdzKVxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIHt1c2VyPy51c2VybmFtZSAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTMuNXB4JyxcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiAnIzRiNTU2MycsXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmN2VmJyxcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCAjZmZlZGQ1JyxcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICc2cHggMTRweCcsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcyMHB4JyxcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiHOiA8c3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAnI2VhNTgwYycgfX0+e3VzZXIudXNlcm5hbWV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPFNpdHRlckJvb2tpbmdMaXN0IC8+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9zaXR0ZXIvU2l0dGVyQm9va2luZ3NQYWdlLnRzeCJ9