import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useLocation, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { useAuth } from "/src/context/AuthContext.jsx";
import Logo from "/src/components/ui/Logo.jsx";
export default function Navbar() {
  _s();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const isSitter = user?.role === "sitter";
  const homePath = isSitter ? "/sitter/dashboard" : "/";
  const { pathname } = useLocation();
  const showSearch = !isSitter && pathname === "/";
  const [searchParams] = useSearchParams();
  const currentQ = searchParams.get("q") ?? "";
  const handleSearch = (e) => {
    e.preventDefault();
    const q = new FormData(e.currentTarget).get("q").trim();
    navigate(q ? `/?q=${encodeURIComponent(q)}` : "/");
  };
  return /* @__PURE__ */ jsxDEV("header", { className: "navbar", children: /* @__PURE__ */ jsxDEV("div", { className: "navbar-inner", children: [
    /* @__PURE__ */ jsxDEV(Link, { to: homePath, className: "navbar-logo-link", "aria-label": "กลับหน้าหลัก", children: /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
      lineNumber: 49,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
      lineNumber: 48,
      columnNumber: 9
    }, this),
    showSearch && /* @__PURE__ */ jsxDEV("form", { className: "navbar-search-form", role: "search", onSubmit: handleSearch, children: /* @__PURE__ */ jsxDEV(
      "input",
      {
        name: "q",
        type: "search",
        className: "input navbar-search",
        placeholder: "ค้นหาพี่เลี้ยงด้วยชื่อ…",
        "aria-label": "ค้นหาพี่เลี้ยงด้วยชื่อ",
        maxLength: 100,
        defaultValue: currentQ
      },
      currentQ,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
        lineNumber: 54,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
      lineNumber: 53,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "navbar-user", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "avatar-btn", onClick: () => setOpen((o) => !o), children: [
        /* @__PURE__ */ jsxDEV("span", { className: "avatar", children: (user?.username || "U").charAt(0).toUpperCase() }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
          lineNumber: 63,
          columnNumber: 13
        }, this),
        user?.username,
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "caret", children: "▾" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
          lineNumber: 64,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this),
      open && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "overlay", onClick: () => setOpen(false) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
          lineNumber: 68,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "dropdown", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "dropdown-item",
              onClick: () => {
                setOpen(false);
                navigate(homePath);
              },
              children: "กลับหน้าหลัก"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
              lineNumber: 70,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "dropdown-item",
              onClick: () => {
                setOpen(false);
                navigate("/profile");
              },
              children: "โปรไฟล์ของฉัน"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
              lineNumber: 79,
              columnNumber: 17
            },
            this
          ),
          isSitter ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "dropdown-item",
              onClick: () => {
                setOpen(false);
                navigate("/sitter/bookings");
              },
              children: "คำขอจองบริการ (Booking Requests)"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
              lineNumber: 90,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "dropdown-item",
              onClick: () => {
                setOpen(false);
                navigate("/bookings");
              },
              children: "การจองของฉัน"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
              lineNumber: 100,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "dropdown-divider" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
            lineNumber: 110,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "dropdown-item dropdown-item--danger",
              onClick: () => {
                setOpen(false);
                logout();
              },
              children: "ออกจากระบบ"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
              lineNumber: 111,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
          lineNumber: 69,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
    lineNumber: 47,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(Navbar, "6pCAHwcRpFXmItobKD+R3FynVMk=", false, function() {
  return [useNavigate, useAuth, useLocation, useSearchParams];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Navbar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJVLFNBa0JFLFVBbEJGOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsYUFBYUMsYUFBYUMsdUJBQXVCO0FBQ2hFLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsVUFBVTtBQUVqQix3QkFBd0JDLFNBQVM7QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxXQUFXTixZQUFZO0FBQzdCLFFBQU0sRUFBRU8sTUFBTUMsT0FBTyxJQUFJTixRQUFRO0FBQ2pDLFFBQU0sQ0FBQ08sTUFBTUMsT0FBTyxJQUFJYixTQUFTLEtBQUs7QUFDdEMsUUFBTWMsV0FBV0osTUFBTUssU0FBUztBQUVoQyxRQUFNQyxXQUFXRixXQUFXLHNCQUFzQjtBQUNsRCxRQUFNLEVBQUVHLFNBQVMsSUFBSWYsWUFBWTtBQUVqQyxRQUFNZ0IsYUFBYSxDQUFDSixZQUFZRyxhQUFhO0FBRTdDLFFBQU0sQ0FBQ0UsWUFBWSxJQUFJZixnQkFBZ0I7QUFDdkMsUUFBTWdCLFdBQVdELGFBQWFFLElBQUksR0FBRyxLQUFLO0FBRTFDLFFBQU1DLGVBQWVBLENBQUNDLE1BQU07QUFDMUJBLE1BQUVDLGVBQWU7QUFDakIsVUFBTUMsSUFBSSxJQUFJQyxTQUFTSCxFQUFFSSxhQUFhLEVBQUVOLElBQUksR0FBRyxFQUFFTyxLQUFLO0FBQ3REbkIsYUFBU2dCLElBQUksT0FBT0ksbUJBQW1CSixDQUFDLENBQUMsS0FBSyxHQUFHO0FBQUEsRUFDbkQ7QUFFQSxTQUNFLHVCQUFDLFlBQU8sV0FBVSxVQUNoQixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwyQkFBQyxRQUFLLElBQUlULFVBQVUsV0FBVSxvQkFBbUIsY0FBVyxnQkFDMUQsaUNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUssS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVDRSxjQUNDLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsTUFBSyxVQUFTLFVBQVVJLGNBQzNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDZ0IsTUFBSztBQUFBLFFBQUksTUFBSztBQUFBLFFBQVMsV0FBVTtBQUFBLFFBQ2hELGFBQVk7QUFBQSxRQUEwQixjQUFXO0FBQUEsUUFDakQsV0FBVztBQUFBLFFBQUssY0FBY0Y7QUFBQUE7QUFBQUEsTUFGekJBO0FBQUFBLE1BRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUd5QyxLQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVGLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsWUFBTyxXQUFVLGNBQWEsU0FBUyxNQUFNUCxRQUFRLENBQUNpQixNQUFNLENBQUNBLENBQUMsR0FDN0Q7QUFBQSwrQkFBQyxVQUFLLFdBQVUsVUFBV3BCLGlCQUFNcUIsWUFBWSxLQUFLQyxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDekV2QixNQUFNcUI7QUFBQUEsUUFBUztBQUFBLFFBQUMsdUJBQUMsVUFBSyxXQUFVLFNBQVEsaUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxXQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNDbkIsUUFDQyxtQ0FDRTtBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFVLFNBQVMsTUFBTUMsUUFBUSxLQUFLLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQ7QUFBQSxRQUN2RCx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU07QUFDYkEsd0JBQVEsS0FBSztBQUNiSix5QkFBU08sUUFBUTtBQUFBLGNBQ25CO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTTtBQUNiSCx3QkFBUSxLQUFLO0FBQ2JKLHlCQUFTLFVBQVU7QUFBQSxjQUNyQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUVDSyxXQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU07QUFDYkQsd0JBQVEsS0FBSztBQUNiSix5QkFBUyxrQkFBa0I7QUFBQSxjQUM3QjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsSUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNO0FBQ2JJLHdCQUFRLEtBQUs7QUFDYkoseUJBQVMsV0FBVztBQUFBLGNBQ3RCO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBRUYsdUJBQUMsU0FBSSxXQUFVLHNCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFDakM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTTtBQUNiSSx3QkFBUSxLQUFLO0FBQ2JGLHVCQUFPO0FBQUEsY0FDVDtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbURBO0FBQUEsV0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNEQTtBQUFBLFNBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4REE7QUFBQSxPQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkVBLEtBOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFSjtBQUFDSCxHQXRHdUJELFFBQU07QUFBQSxVQUNYSixhQUNRRSxTQUtKSCxhQUlFRSxlQUFlO0FBQUE7QUFBQSxLQVhoQkc7QUFBTSxJQUFBMkI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVNlYXJjaFBhcmFtcyIsInVzZUF1dGgiLCJMb2dvIiwiTmF2YmFyIiwiX3MiLCJuYXZpZ2F0ZSIsInVzZXIiLCJsb2dvdXQiLCJvcGVuIiwic2V0T3BlbiIsImlzU2l0dGVyIiwicm9sZSIsImhvbWVQYXRoIiwicGF0aG5hbWUiLCJzaG93U2VhcmNoIiwic2VhcmNoUGFyYW1zIiwiY3VycmVudFEiLCJnZXQiLCJoYW5kbGVTZWFyY2giLCJlIiwicHJldmVudERlZmF1bHQiLCJxIiwiRm9ybURhdGEiLCJjdXJyZW50VGFyZ2V0IiwidHJpbSIsImVuY29kZVVSSUNvbXBvbmVudCIsIm8iLCJ1c2VybmFtZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmF2YmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeFwiO1xuaW1wb3J0IExvZ28gZnJvbSBcIi4vdWkvTG9nby5qc3hcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTmF2YmFyKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgdXNlciwgbG9nb3V0IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgaXNTaXR0ZXIgPSB1c2VyPy5yb2xlID09PSBcInNpdHRlclwiO1xuICAvLyDguKvguJnguYnguLLguKvguKXguLHguIHguILguK3guIfguJ7guLXguYjguYDguKXguLXguYnguKLguIfguITguLfguK0gZGFzaGJvYXJkICjguJXguKPguIfguIHguLHguJrguJfguLXguYggSG9tZVJvdXRlIOC4quC5iOC4h+C5hOC4mylcbiAgY29uc3QgaG9tZVBhdGggPSBpc1NpdHRlciA/IFwiL3NpdHRlci9kYXNoYm9hcmRcIiA6IFwiL1wiO1xuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpO1xuICAvLyDguIrguYjguK3guIfguITguYnguJnguKvguLLguYHguKrguJTguIfguYDguInguJ7guLLguLDguKvguJnguYnguLLguYHguKPguIHguILguK3guIfguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIdcbiAgY29uc3Qgc2hvd1NlYXJjaCA9ICFpc1NpdHRlciAmJiBwYXRobmFtZSA9PT0gXCIvXCI7XG4gIC8vIOC4hOC5iOC4suC5g+C4meC4iuC5iOC4reC4h+C4hOC5ieC4meC4q+C4suC4leC4suC4oeC4nuC4suC4o+C4suC4oeC4tOC5gOC4leC4reC4o+C5jCA/cT0g4Lib4Lix4LiI4LiI4Li44Lia4Lix4LiZIChrZXkg4LiU4LmJ4Liy4LiZ4Lil4LmI4Liy4LiH4LiX4Liz4LmD4Lir4LmJ4LiK4LmI4Lit4LiH4Lij4Li14LmA4LiL4LmH4LiV4LmA4Lih4Li34LmI4LitIHEg4LiW4Li54LiB4Lil4LmJ4Liy4LiH4LiI4Liy4LiB4Lir4LiZ4LmJ4Liy4Lit4Li34LmI4LiZKVxuICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICBjb25zdCBjdXJyZW50USA9IHNlYXJjaFBhcmFtcy5nZXQoXCJxXCIpID8/IFwiXCI7XG5cbiAgY29uc3QgaGFuZGxlU2VhcmNoID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgcSA9IG5ldyBGb3JtRGF0YShlLmN1cnJlbnRUYXJnZXQpLmdldChcInFcIikudHJpbSgpO1xuICAgIG5hdmlnYXRlKHEgPyBgLz9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHEpfWAgOiBcIi9cIik7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cIm5hdmJhclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXZiYXItaW5uZXJcIj5cbiAgICAgICAgPExpbmsgdG89e2hvbWVQYXRofSBjbGFzc05hbWU9XCJuYXZiYXItbG9nby1saW5rXCIgYXJpYS1sYWJlbD1cIuC4geC4peC4seC4muC4q+C4meC5ieC4suC4q+C4peC4seC4gVwiPlxuICAgICAgICAgIDxMb2dvIC8+XG4gICAgICAgIDwvTGluaz5cbiAgICAgICAgey8qIOC4q+C4meC5ieC4suC4hOC5ieC4meC4q+C4suC5gOC4m+C5h+C4meC4guC4reC4h+C5gOC4iOC5ieC4suC4guC4reC4h+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyDigJQg4LmB4Liq4LiU4LiH4LmA4LiJ4Lie4Liy4Liw4Lir4LiZ4LmJ4Liy4LmB4Lij4LiBICjguJ7guLXguYjguYDguKXguLXguYnguKLguIfguYTguKHguYjguYDguKvguYfguJnguIrguYjguK3guIfguJnguLXguYkpICovfVxuICAgICAgICB7c2hvd1NlYXJjaCAmJiAoXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwibmF2YmFyLXNlYXJjaC1mb3JtXCIgcm9sZT1cInNlYXJjaFwiIG9uU3VibWl0PXtoYW5kbGVTZWFyY2h9PlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGtleT17Y3VycmVudFF9IG5hbWU9XCJxXCIgdHlwZT1cInNlYXJjaFwiIGNsYXNzTmFtZT1cImlucHV0IG5hdmJhci1zZWFyY2hcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC4hOC5ieC4meC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4lOC5ieC4p+C4ouC4iuC4t+C5iOC4reKAplwiIGFyaWEtbGFiZWw9XCLguITguYnguJnguKvguLLguJ7guLXguYjguYDguKXguLXguYnguKLguIfguJTguYnguKfguKLguIrguLfguYjguK1cIlxuICAgICAgICAgICAgICBtYXhMZW5ndGg9ezEwMH0gZGVmYXVsdFZhbHVlPXtjdXJyZW50UX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICApfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdmJhci11c2VyXCI+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdmF0YXItYnRuXCIgb25DbGljaz17KCkgPT4gc2V0T3BlbigobykgPT4gIW8pfT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImF2YXRhclwiPnsodXNlcj8udXNlcm5hbWUgfHwgXCJVXCIpLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfTwvc3Bhbj5cbiAgICAgICAgICAgIHt1c2VyPy51c2VybmFtZX0gPHNwYW4gY2xhc3NOYW1lPVwiY2FyZXRcIj7ilr48L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAge29wZW4gJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVybGF5XCIgb25DbGljaz17KCkgPT4gc2V0T3BlbihmYWxzZSl9IC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHJvcGRvd25cIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkcm9wZG93bi1pdGVtXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKGhvbWVQYXRoKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg4LiB4Lil4Lix4Lia4Lir4LiZ4LmJ4Liy4Lir4Lil4Lix4LiBXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZHJvcGRvd24taXRlbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShcIi9wcm9maWxlXCIpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDguYLguJvguKPguYTguJ/guKXguYzguILguK3guIfguInguLHguJlcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIHtpc1NpdHRlciA/IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZHJvcGRvd24taXRlbVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShcIi9zaXR0ZXIvYm9va2luZ3NcIik7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOC4hOC4s+C4guC4reC4iOC4reC4h+C4muC4o+C4tOC4geC4suC4oyAoQm9va2luZyBSZXF1ZXN0cylcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRyb3Bkb3duLWl0ZW1cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdGUoXCIvYm9va2luZ3NcIik7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOC4geC4suC4o+C4iOC4reC4h+C4guC4reC4h+C4ieC4seC4mVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRyb3Bkb3duLWRpdmlkZXJcIiAvPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRyb3Bkb3duLWl0ZW0gZHJvcGRvd24taXRlbS0tZGFuZ2VyXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIGxvZ291dCgpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDguK3guK3guIHguIjguLLguIHguKPguLDguJrguJpcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL05hdmJhci5qc3gifQ==