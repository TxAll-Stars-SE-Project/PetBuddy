import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/SpeciesChipSelector.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export const SPECIES_OPTIONS = [
  { id: "dog", label: "สุนัข" },
  { id: "cat", label: "แมว" },
  { id: "bird", label: "นก" },
  { id: "exotic", label: "สัตว์มหัศจรรย์" }
];
export default function SpeciesChipSelector({
  value,
  selectedSpecies,
  onChange,
  error = ""
}) {
  const currentList = Array.isArray(value) ? value : Array.isArray(selectedSpecies) ? selectedSpecies : [];
  const handleToggle = (speciesId) => {
    const nextList = currentList.includes(speciesId) ? currentList.filter((id) => id !== speciesId) : [...currentList, speciesId];
    if (onChange) onChange(nextList);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1.5", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-slate-700", children: [
        "ชนิดสัตว์เลี้ยงที่รับดูแล ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
          lineNumber: 72,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-slate-500", children: "(เลือกได้มากกว่า 1 ชนิด)" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2", children: SPECIES_OPTIONS.map((item) => {
      const isSelected = currentList.includes(item.id);
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => handleToggle(item.id),
          className: `p-2.5 rounded-xl border-2 text-center transition-all cursor-pointer flex items-center justify-center gap-1.5 text-xs select-none ${isSelected ? "border-[#F97316] bg-[#FFF3E8] text-[#EA580C] font-bold shadow-xs scale-[1.01]" : "border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50 font-medium"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
              lineNumber: 94,
              columnNumber: 15
            }, this),
            isSelected && /* @__PURE__ */ jsxDEV("span", { className: "text-[#EA580C] font-bold text-xs", children: "✓" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
              lineNumber: 96,
              columnNumber: 15
            }, this)
          ]
        },
        item.id,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
          lineNumber: 84,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-500 mt-1 block", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
      lineNumber: 104,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
}
_c = SpeciesChipSelector;
var _c;
$RefreshReg$(_c, "SpeciesChipSelector");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/SpeciesChipSelector.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RvQzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEcEMsT0FBT0EsV0FBVztBQU1YLGFBQU1DLGtCQUFrQjtBQUFBLEVBQzdCLEVBQUVDLElBQUksT0FBT0MsT0FBTyxRQUFRO0FBQUEsRUFDNUIsRUFBRUQsSUFBSSxPQUFPQyxPQUFPLE1BQU07QUFBQSxFQUMxQixFQUFFRCxJQUFJLFFBQVFDLE9BQU8sS0FBSztBQUFBLEVBQzFCLEVBQUVELElBQUksVUFBVUMsT0FBTyxpQkFBaUI7QUFBQztBQWdCM0Msd0JBQXdCQyxvQkFBb0I7QUFBQSxFQUMxQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsUUFBUTtBQUNWLEdBQUc7QUFFRCxRQUFNQyxjQUFjQyxNQUFNQyxRQUFRTixLQUFLLElBQ25DQSxRQUNBSyxNQUFNQyxRQUFRTCxlQUFlLElBQzdCQSxrQkFDQTtBQUdKLFFBQU1NLGVBQWVBLENBQUNDLGNBQWM7QUFDbEMsVUFBTUMsV0FBV0wsWUFBWU0sU0FBU0YsU0FBUyxJQUMzQ0osWUFBWU8sT0FBTyxDQUFDZCxPQUFPQSxPQUFPVyxTQUFTLElBQzNDLENBQUMsR0FBR0osYUFBYUksU0FBUztBQUU5QixRQUFJTixTQUFVQSxVQUFTTyxRQUFRO0FBQUEsRUFDakM7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsd0NBQXNDO0FBQUE7QUFBQSxRQUMzQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxXQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFBNEIsd0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1piLDBCQUFnQmdCLElBQUksQ0FBQ0MsU0FBUztBQUM3QixZQUFNQyxhQUFhVixZQUFZTSxTQUFTRyxLQUFLaEIsRUFBRTtBQUMvQyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1VLGFBQWFNLEtBQUtoQixFQUFFO0FBQUEsVUFDbkMsV0FBVyxvSUFDVGlCLGFBQ0ksa0ZBQ0EsK0ZBQStGO0FBQUEsVUFHckc7QUFBQSxtQ0FBQyxVQUFNRCxlQUFLZixTQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsWUFDakJnQixjQUNDLHVCQUFDLFVBQUssV0FBVSxvQ0FBbUMsaUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUE7QUFBQTtBQUFBLFFBWGpERCxLQUFLaEI7QUFBQUEsUUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0E7QUFBQSxJQUVKLENBQUMsS0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBRUNNLFNBQ0MsdUJBQUMsVUFBSyxXQUFVLG1DQUNiQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBQ1ksS0FoRXVCaEI7QUFBbUIsSUFBQWdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU1BFQ0lFU19PUFRJT05TIiwiaWQiLCJsYWJlbCIsIlNwZWNpZXNDaGlwU2VsZWN0b3IiLCJ2YWx1ZSIsInNlbGVjdGVkU3BlY2llcyIsIm9uQ2hhbmdlIiwiZXJyb3IiLCJjdXJyZW50TGlzdCIsIkFycmF5IiwiaXNBcnJheSIsImhhbmRsZVRvZ2dsZSIsInNwZWNpZXNJZCIsIm5leHRMaXN0IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJtYXAiLCJpdGVtIiwiaXNTZWxlY3RlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNwZWNpZXNDaGlwU2VsZWN0b3IuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBBdmFpbGFibGUgc3BlY2llcyBvcHRpb25zXG4gKiAoU3RyaWN0IFVJIFJ1bGU6IE5vIGNoZWNrYm94ZXMsIHVzZSBjbGlja2FibGUgQnV0dG9uIENoaXAgVGlsZXMpXG4gKi9cbmV4cG9ydCBjb25zdCBTUEVDSUVTX09QVElPTlMgPSBbXG4gIHsgaWQ6IFwiZG9nXCIsIGxhYmVsOiBcIuC4quC4uOC4meC4seC4glwiIH0sXG4gIHsgaWQ6IFwiY2F0XCIsIGxhYmVsOiBcIuC5geC4oeC4p1wiIH0sXG4gIHsgaWQ6IFwiYmlyZFwiLCBsYWJlbDogXCLguJnguIFcIiB9LFxuICB7IGlkOiBcImV4b3RpY1wiLCBsYWJlbDogXCLguKrguLHguJXguKfguYzguKHguKvguLHguKjguIjguKPguKPguKLguYxcIiB9LFxuXTtcblxuLyoqXG4gKiBTcGVjaWVzQ2hpcFNlbGVjdG9yIENvbXBvbmVudFxuICogXG4gKiBTZWxmLWNvbnRhaW5lZCBNdWx0aS1TZWxlY3QgQnV0dG9uIENoaXAgVGlsZXM6XG4gKiAtIEVuY2Fwc3VsYXRlcyBhcnJheSB0b2dnbGUgbG9naWMgaW50ZXJuYWxseS5cbiAqIC0gUGFyZW50IG9ubHkgc3VwcGxpZXMgYHZhbHVlYCBhbmQgYSBzaW5nbGUgYG9uQ2hhbmdlKG5ld1NwZWNpZXNBcnJheSlgIGNhbGxiYWNrLlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7c3RyaW5nW119IFtwcm9wcy52YWx1ZV0gLSBBcnJheSBvZiBjdXJyZW50bHkgc2VsZWN0ZWQgc3BlY2llcyBJRHMuXG4gKiBAcGFyYW0ge3N0cmluZ1tdfSBbcHJvcHMuc2VsZWN0ZWRTcGVjaWVzXSAtIEFsaWFzIGZvciB2YWx1ZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2hhbmdlIC0gQ2FsbGJhY2sgcmV0dXJuaW5nIHRoZSB1cGRhdGVkIGFycmF5IG9mIHNlbGVjdGVkIHNwZWNpZXMuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmVycm9yXSAtIFZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZSBpZiBub25lIHNlbGVjdGVkLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTcGVjaWVzQ2hpcFNlbGVjdG9yKHtcbiAgdmFsdWUsXG4gIHNlbGVjdGVkU3BlY2llcyxcbiAgb25DaGFuZ2UsXG4gIGVycm9yID0gXCJcIixcbn0pIHtcbiAgLy8gU3VwcG9ydCBib3RoIGB2YWx1ZWAgYW5kIGBzZWxlY3RlZFNwZWNpZXNgIHByb3AgbmFtZXMgc2VhbWxlc3NseVxuICBjb25zdCBjdXJyZW50TGlzdCA9IEFycmF5LmlzQXJyYXkodmFsdWUpXG4gICAgPyB2YWx1ZVxuICAgIDogQXJyYXkuaXNBcnJheShzZWxlY3RlZFNwZWNpZXMpXG4gICAgPyBzZWxlY3RlZFNwZWNpZXNcbiAgICA6IFtdO1xuXG4gIC8vIEludGVybmFsIFRvZ2dsZSBIYW5kbGVyOiBjYWxjdWxhdGVzIG5ldyBhcnJheSBhbmQgaW5mb3JtcyBwYXJlbnQgdmlhIG9uQ2hhbmdlXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZSA9IChzcGVjaWVzSWQpID0+IHtcbiAgICBjb25zdCBuZXh0TGlzdCA9IGN1cnJlbnRMaXN0LmluY2x1ZGVzKHNwZWNpZXNJZClcbiAgICAgID8gY3VycmVudExpc3QuZmlsdGVyKChpZCkgPT4gaWQgIT09IHNwZWNpZXNJZClcbiAgICAgIDogWy4uLmN1cnJlbnRMaXN0LCBzcGVjaWVzSWRdO1xuXG4gICAgaWYgKG9uQ2hhbmdlKSBvbkNoYW5nZShuZXh0TGlzdCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMS41XCI+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICDguIrguJnguLTguJTguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJfguLXguYjguKPguLHguJrguJTguLnguYHguKUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAo4LmA4Lil4Li34Lit4LiB4LmE4LiU4LmJ4Lih4Liy4LiB4LiB4Lin4LmI4LiyIDEg4LiK4LiZ4Li04LiUKVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEdyaWQgb2YgQ2xpY2thYmxlIEJ1dHRvbiBDaGlwIFRpbGVzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgIHtTUEVDSUVTX09QVElPTlMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGN1cnJlbnRMaXN0LmluY2x1ZGVzKGl0ZW0uaWQpO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRvZ2dsZShpdGVtLmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBib3JkZXItMiB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHRleHQteHMgc2VsZWN0LW5vbmUgJHtcbiAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLVsjRjk3MzE2XSBiZy1bI0ZGRjNFOF0gdGV4dC1bI0VBNTgwQ10gZm9udC1ib2xkIHNoYWRvdy14cyBzY2FsZS1bMS4wMV1cIlxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS01MCBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgIHtpc1NlbGVjdGVkICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjRUE1ODBDXSBmb250LWJvbGQgdGV4dC14c1wiPuKckzwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yZWQtNTAwIG10LTEgYmxvY2tcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvc2VydmljZUZvcm0vU3BlY2llc0NoaXBTZWxlY3Rvci5qc3gifQ==