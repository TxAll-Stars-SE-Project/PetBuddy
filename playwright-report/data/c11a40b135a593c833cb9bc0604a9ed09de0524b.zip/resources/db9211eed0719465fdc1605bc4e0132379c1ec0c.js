import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/RolePills.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function RolePills({ value, onChange }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "pills", role: "radiogroup", "aria-label": "เลือกบทบาท", children: [
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "pill" + (value === "owner" ? " pill--active" : ""), onClick: () => onChange("owner"), children: "เจ้าของสัตว์เลี้ยง" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "pill" + (value === "sitter" ? " pill--active" : ""), onClick: () => onChange("sitter"), children: "พี่เลี้ยงสัตว์" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
}
_c = RolePills;
export default RolePills;
var _c;
$RefreshReg$(_c, "RolePills");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/RolePills.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR007Ozs7Ozs7Ozs7Ozs7Ozs7QUFITixTQUFTQSxVQUFVLEVBQUVDLE9BQU9DLFNBQVMsR0FBRztBQUN0QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxTQUFRLE1BQUssY0FBYSxjQUFXLGNBQ2xEO0FBQUEsMkJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVyxVQUFVRCxVQUFVLFVBQVUsa0JBQWtCLEtBQUssU0FBUyxNQUFNQyxTQUFTLE9BQU8sR0FBRSxrQ0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFXLFVBQVVELFVBQVUsV0FBVyxrQkFBa0IsS0FBSyxTQUFTLE1BQU1DLFNBQVMsUUFBUSxHQUFFLDhCQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNDLEtBWFFIO0FBYVQsZUFBZUE7QUFBVSxJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSb2xlUGlsbHMiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUm9sZVBpbGxzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBSb2xlUGlsbHMoeyB2YWx1ZSwgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGlsbHNcIiByb2xlPVwicmFkaW9ncm91cFwiIGFyaWEtbGFiZWw9XCLguYDguKXguLfguK3guIHguJrguJfguJrguLLguJdcIj5cbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17XCJwaWxsXCIgKyAodmFsdWUgPT09IFwib3duZXJcIiA/IFwiIHBpbGwtLWFjdGl2ZVwiIDogXCJcIil9IG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKFwib3duZXJcIil9PlxuICAgICAgICDguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIdcbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtcInBpbGxcIiArICh2YWx1ZSA9PT0gXCJzaXR0ZXJcIiA/IFwiIHBpbGwtLWFjdGl2ZVwiIDogXCJcIil9IG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKFwic2l0dGVyXCIpfT5cbiAgICAgICAg4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmMXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgUm9sZVBpbGxzOyJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3VpL1JvbGVQaWxscy5qc3gifQ==