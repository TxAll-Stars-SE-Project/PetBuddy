import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SitterQrUpload.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { toast } from "/src/utils/toast.js";
const VALID_TYPES = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
const MAX_FILE_SIZE = 5 * 1024 * 1024;
const formatSize = (bytes) => bytes < 1024 * 1024 ? `${Math.round(bytes / 1024)} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
function SitterQrUpload({ qrCodeUrl, isEditing, file, error: formError, onSelectFile, onRemove }) {
  _s();
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [fileError, setFileError] = useState("");
  const [showLightbox, setShowLightbox] = useState(false);
  const [previewUrl, setPreviewUrl] = useState("");
  useEffect(() => {
    if (!file) {
      setPreviewUrl("");
      return void 0;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  useEffect(() => {
    if (!isEditing) setFileError("");
  }, [isEditing]);
  const error = fileError || formError;
  const processFile = (picked) => {
    if (!picked) return;
    if (!VALID_TYPES.includes(picked.type)) {
      setFileError("รองรับเฉพาะไฟล์ JPG, PNG หรือ WEBP เท่านั้น");
      return;
    }
    if (picked.size > MAX_FILE_SIZE) {
      setFileError(`ไฟล์ใหญ่เกิน 5 MB (${formatSize(picked.size)})`);
      toast("ขนาดไฟล์ใหญ่เกินไป กรุณาอัปโหลดรูปภาพขนาดไม่เกิน 5MB", "error");
      return;
    }
    setFileError("");
    onSelectFile(picked);
  };
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    processFile(e.dataTransfer.files?.[0]);
  };
  const currentUrl = file ? previewUrl : qrCodeUrl || "";
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "QR Code รับชำระเงิน" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    !isEditing ? /* @__PURE__ */ jsxDEV("div", { className: "qr-value", children: qrCodeUrl ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "img",
        {
          className: "qr-thumb",
          src: qrCodeUrl,
          alt: "QR Code รับชำระเงิน",
          title: "คลิกเพื่อดูภาพขยาย",
          onClick: () => setShowLightbox(true)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
          lineNumber: 88,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("span", { className: "qr-hint-link", children: "คลิกที่รูปเพื่อขยาย" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 95,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 87,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "qr-empty", children: "ยังไม่ได้อัปโหลด" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 98,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 85,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "profile-field-container", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          ref: inputRef,
          type: "file",
          accept: "image/jpeg, image/png, image/jpg, image/webp",
          hidden: true,
          onChange: (e) => {
            processFile(e.target.files?.[0]);
            e.target.value = "";
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
          lineNumber: 103,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `pet-file-upload-box qr-upload-box${isDragging ? " pet-file-upload-box--dragover" : ""}${error ? " qr-upload-box--error" : ""}`,
          onClick: () => inputRef.current?.click(),
          onDragOver: (e) => {
            e.preventDefault();
            setIsDragging(true);
          },
          onDragLeave: () => setIsDragging(false),
          onDrop: handleDrop,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "pet-file-upload-left", children: [
              currentUrl ? /* @__PURE__ */ jsxDEV("img", { className: "qr-preview", src: currentUrl, alt: "ตัวอย่าง QR Code" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 122,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "qr-placeholder", children: "▦" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 124,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "qr-info", children: currentUrl ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "pet-file-name", children: file ? file.name : "QR Code ปัจจุบัน" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                  lineNumber: 129,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "pet-file-status", children: file ? `✓ เลือกแล้ว · ${formatSize(file.size)} (ยังไม่ได้บันทึก)` : "✓ มีรูปอยู่แล้ว" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                  lineNumber: 130,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 128,
                columnNumber: 15
              }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "pet-file-name", children: "ลากรูปมาวาง หรือกดเลือกรูป" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                  lineNumber: 136,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "pet-file-hint", children: "JPG / PNG / WEBP ไม่เกิน 5 MB" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                  lineNumber: 137,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 135,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 126,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
              lineNumber: 120,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "pet-file-choose-btn",
                onClick: (e) => {
                  e.stopPropagation();
                  inputRef.current?.click();
                },
                children: currentUrl ? "เปลี่ยนรูป" : "เลือกรูปภาพ"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 142,
                columnNumber: 13
              },
              this
            ),
            file && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "pet-file-remove-btn",
                title: "ยกเลิกรูปที่เลือก",
                onClick: (e) => {
                  e.stopPropagation();
                  setFileError("");
                  onRemove();
                },
                children: "✕"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
                lineNumber: 150,
                columnNumber: 11
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
          lineNumber: 113,
          columnNumber: 11
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("div", { className: "qr-error", children: error }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 160,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "qr-edit-note", children: "ใช้สำหรับให้เจ้าของสัตว์เลี้ยงสแกนชำระเงิน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 161,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    showLightbox && qrCodeUrl && /* @__PURE__ */ jsxDEV("div", { className: "qr-lightbox", onClick: () => setShowLightbox(false), children: /* @__PURE__ */ jsxDEV("div", { className: "qr-lightbox-box", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "qr-lightbox-close", "aria-label": "ปิด", onClick: () => setShowLightbox(false), children: "✕" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 168,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("img", { src: qrCodeUrl, alt: "QR Code รับชำระเงิน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 169,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "QR Code รับชำระเงิน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
        lineNumber: 170,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 167,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
      lineNumber: 166,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
}
_s(SitterQrUpload, "Ca2oGTospbLYR7F8td5blfOc4hI=");
_c = SitterQrUpload;
export default SitterQrUpload;
var _c;
$RefreshReg$(_c, "SitterQrUpload");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterQrUpload.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERNLFNBS00sVUFMTjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE5RE4sU0FBU0EsVUFBVUMsV0FBV0MsY0FBYztBQUM1QyxTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLGNBQWMsQ0FBQyxjQUFjLGFBQWEsYUFBYSxZQUFZO0FBQ3pFLE1BQU1DLGdCQUFnQixJQUFJLE9BQU87QUFFakMsTUFBTUMsYUFBYUEsQ0FBQ0MsVUFDbEJBLFFBQVEsT0FBTyxPQUFPLEdBQUdDLEtBQUtDLE1BQU1GLFFBQVEsSUFBSSxDQUFDLFFBQVEsSUFBSUEsU0FBUyxPQUFPLE9BQU9HLFFBQVEsQ0FBQyxDQUFDO0FBU2hHLFNBQVNDLGVBQWUsRUFBRUMsV0FBV0MsV0FBV0MsTUFBTUMsT0FBT0MsV0FBV0MsY0FBY0MsU0FBUyxHQUFHO0FBQUFDLEtBQUE7QUFDaEcsUUFBTUMsV0FBV2xCLE9BQU8sSUFBSTtBQUM1QixRQUFNLENBQUNtQixZQUFZQyxhQUFhLElBQUl0QixTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDdUIsV0FBV0MsWUFBWSxJQUFJeEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lCLGNBQWNDLGVBQWUsSUFBSTFCLFNBQVMsS0FBSztBQUV0RCxRQUFNLENBQUMyQixZQUFZQyxhQUFhLElBQUk1QixTQUFTLEVBQUU7QUFDL0NDLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ2EsTUFBTTtBQUNUYyxvQkFBYyxFQUFFO0FBQ2hCLGFBQU9DO0FBQUFBLElBQ1Q7QUFDQSxVQUFNQyxNQUFNQyxJQUFJQyxnQkFBZ0JsQixJQUFJO0FBQ3BDYyxrQkFBY0UsR0FBRztBQUNqQixXQUFPLE1BQU1DLElBQUlFLGdCQUFnQkgsR0FBRztBQUFBLEVBQ3RDLEdBQUcsQ0FBQ2hCLElBQUksQ0FBQztBQUVUYixZQUFVLE1BQU07QUFBRSxRQUFJLENBQUNZLFVBQVdXLGNBQWEsRUFBRTtBQUFBLEVBQUcsR0FBRyxDQUFDWCxTQUFTLENBQUM7QUFFbEUsUUFBTUUsUUFBUVEsYUFBYVA7QUFFM0IsUUFBTWtCLGNBQWNBLENBQUNDLFdBQVc7QUFDOUIsUUFBSSxDQUFDQSxPQUFRO0FBQ2IsUUFBSSxDQUFDL0IsWUFBWWdDLFNBQVNELE9BQU9FLElBQUksR0FBRztBQUN0Q2IsbUJBQWEsNkNBQTZDO0FBQzFEO0FBQUEsSUFDRjtBQUNBLFFBQUlXLE9BQU9HLE9BQU9qQyxlQUFlO0FBQy9CbUIsbUJBQWEsc0JBQXNCbEIsV0FBVzZCLE9BQU9HLElBQUksQ0FBQyxHQUFHO0FBQzdEbkMsWUFBTSx3REFBd0QsT0FBTztBQUNyRTtBQUFBLElBQ0Y7QUFDQXFCLGlCQUFhLEVBQUU7QUFDZlAsaUJBQWFrQixNQUFNO0FBQUEsRUFDckI7QUFFQSxRQUFNSSxhQUFhQSxDQUFDQyxNQUFNO0FBQ3hCQSxNQUFFQyxlQUFlO0FBQ2pCbkIsa0JBQWMsS0FBSztBQUNuQlksZ0JBQVlNLEVBQUVFLGFBQWFDLFFBQVEsQ0FBQyxDQUFDO0FBQUEsRUFDdkM7QUFFQSxRQUFNQyxhQUFhOUIsT0FBT2EsYUFBYWYsYUFBYTtBQUVwRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsMkJBQUMsVUFBSyxXQUFVLGlCQUFnQixtQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRDtBQUFBLElBRWxELENBQUNDLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ1pELHNCQUNDLG1DQUNFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLEtBQUtBO0FBQUFBLFVBQ0wsS0FBSTtBQUFBLFVBQ0osT0FBTTtBQUFBLFVBQ04sU0FBUyxNQUFNYyxnQkFBZ0IsSUFBSTtBQUFBO0FBQUEsUUFMckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3VDO0FBQUEsTUFFdkMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLG1DQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsU0FScEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLElBRUEsdUJBQUMsVUFBSyxXQUFVLFlBQVcsZ0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkMsS0FiL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUtOO0FBQUFBLFVBQ0wsTUFBSztBQUFBLFVBQ0wsUUFBTztBQUFBLFVBQ1A7QUFBQSxVQUNBLFVBQVUsQ0FBQ29CLE1BQU07QUFDZk4sd0JBQVlNLEVBQUVLLE9BQU9GLFFBQVEsQ0FBQyxDQUFDO0FBQy9CSCxjQUFFSyxPQUFPQyxRQUFRO0FBQUEsVUFDbkI7QUFBQTtBQUFBLFFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUk7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXLG9DQUFvQ3pCLGFBQWEsbUNBQW1DLEVBQUUsR0FBR04sUUFBUSwwQkFBMEIsRUFBRTtBQUFBLFVBQ3hJLFNBQVMsTUFBTUssU0FBUzJCLFNBQVNDLE1BQU07QUFBQSxVQUN2QyxZQUFZLENBQUNSLE1BQU07QUFBRUEsY0FBRUMsZUFBZTtBQUFHbkIsMEJBQWMsSUFBSTtBQUFBLFVBQUc7QUFBQSxVQUM5RCxhQUFhLE1BQU1BLGNBQWMsS0FBSztBQUFBLFVBQ3RDLFFBQVFpQjtBQUFBQSxVQUVSO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUNaSztBQUFBQSwyQkFDQyx1QkFBQyxTQUFJLFdBQVUsY0FBYSxLQUFLQSxZQUFZLEtBQUksc0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1FLElBRW5FLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FFbkMsdUJBQUMsU0FBSSxXQUFVLFdBQ1pBLHVCQUNDLG1DQUNFO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGlCQUFpQjlCLGlCQUFPQSxLQUFLbUMsT0FBTyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkUsdUJBQUMsVUFBSyxXQUFVLG1CQUNibkMsaUJBQU8saUJBQWlCUixXQUFXUSxLQUFLd0IsSUFBSSxDQUFDLHVCQUF1QixxQkFEdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0EsSUFFQSxtQ0FDRTtBQUFBLHVDQUFDLFVBQUssV0FBVSxpQkFBZ0IsMENBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBEO0FBQUEsZ0JBQzFELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsbUJBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0EsS0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxDQUFDRSxNQUFNO0FBQUVBLG9CQUFFVSxnQkFBZ0I7QUFBRzlCLDJCQUFTMkIsU0FBU0MsTUFBTTtBQUFBLGdCQUFHO0FBQUEsZ0JBRWpFSix1QkFBYSxlQUFlO0FBQUE7QUFBQSxjQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0M5QixRQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBQ04sU0FBUyxDQUFDMEIsTUFBTTtBQUFFQSxvQkFBRVUsZ0JBQWdCO0FBQUcxQiwrQkFBYSxFQUFFO0FBQUdOLDJCQUFTO0FBQUEsZ0JBQUc7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FKekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQTtBQUFBO0FBQUEsUUE1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BOENBO0FBQUEsTUFDQ0gsU0FBUyx1QkFBQyxTQUFJLFdBQVUsWUFBWUEsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUMzQyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsMERBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxTQTNEMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTREQTtBQUFBLElBR0RVLGdCQUFnQmIsYUFDZix1QkFBQyxTQUFJLFdBQVUsZUFBYyxTQUFTLE1BQU1jLGdCQUFnQixLQUFLLEdBQy9ELGlDQUFDLFNBQUksV0FBVSxtQkFBa0IsU0FBUyxDQUFDYyxNQUFNQSxFQUFFVSxnQkFBZ0IsR0FDakU7QUFBQSw2QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHFCQUFvQixjQUFXLE9BQU0sU0FBUyxNQUFNeEIsZ0JBQWdCLEtBQUssR0FBRyxpQkFBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RztBQUFBLE1BQzdHLHVCQUFDLFNBQUksS0FBS2QsV0FBVyxLQUFJLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsTUFDOUMsdUJBQUMsT0FBRSxtQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsU0FIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsT0EzRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZGQTtBQUVKO0FBQUNPLEdBNUlRUixnQkFBYztBQUFBLEtBQWRBO0FBOElULGVBQWVBO0FBQWUsSUFBQXdDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidG9hc3QiLCJWQUxJRF9UWVBFUyIsIk1BWF9GSUxFX1NJWkUiLCJmb3JtYXRTaXplIiwiYnl0ZXMiLCJNYXRoIiwicm91bmQiLCJ0b0ZpeGVkIiwiU2l0dGVyUXJVcGxvYWQiLCJxckNvZGVVcmwiLCJpc0VkaXRpbmciLCJmaWxlIiwiZXJyb3IiLCJmb3JtRXJyb3IiLCJvblNlbGVjdEZpbGUiLCJvblJlbW92ZSIsIl9zIiwiaW5wdXRSZWYiLCJpc0RyYWdnaW5nIiwic2V0SXNEcmFnZ2luZyIsImZpbGVFcnJvciIsInNldEZpbGVFcnJvciIsInNob3dMaWdodGJveCIsInNldFNob3dMaWdodGJveCIsInByZXZpZXdVcmwiLCJzZXRQcmV2aWV3VXJsIiwidW5kZWZpbmVkIiwidXJsIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwicmV2b2tlT2JqZWN0VVJMIiwicHJvY2Vzc0ZpbGUiLCJwaWNrZWQiLCJpbmNsdWRlcyIsInR5cGUiLCJzaXplIiwiaGFuZGxlRHJvcCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImRhdGFUcmFuc2ZlciIsImZpbGVzIiwiY3VycmVudFVybCIsInRhcmdldCIsInZhbHVlIiwiY3VycmVudCIsImNsaWNrIiwibmFtZSIsInN0b3BQcm9wYWdhdGlvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpdHRlclFyVXBsb2FkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcIi4uL3V0aWxzL3RvYXN0LmpzXCI7XG5cbmNvbnN0IFZBTElEX1RZUEVTID0gW1wiaW1hZ2UvanBlZ1wiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL2pwZ1wiLCBcImltYWdlL3dlYnBcIl07XG5jb25zdCBNQVhfRklMRV9TSVpFID0gNSAqIDEwMjQgKiAxMDI0O1xuXG5jb25zdCBmb3JtYXRTaXplID0gKGJ5dGVzKSA9PlxuICBieXRlcyA8IDEwMjQgKiAxMDI0ID8gYCR7TWF0aC5yb3VuZChieXRlcyAvIDEwMjQpfSBLQmAgOiBgJHsoYnl0ZXMgLyAoMTAyNCAqIDEwMjQpKS50b0ZpeGVkKDEpfSBNQmA7XG5cbi8qKlxuICogUm93IFwiUVIgQ29kZSDguKPguLHguJrguIrguLPguKPguLDguYDguIfguLTguJlcIiDguYPguJnguKvguJnguYnguLLguYLguJvguKPguYTguJ/guKXguYzguILguK3guIcgUGV0IFNpdHRlclxuICogLSB2aWV3IG1vZGU6IOC5geC4quC4lOC4hyB0aHVtYm5haWwgKOC4geC4lOC5gOC4nuC4t+C5iOC4reC4guC4ouC4suC4oikg4Lir4Lij4Li34Lit4LiC4LmJ4Lit4LiE4Lin4Liy4Lih4Lin4LmI4Liy4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4Lit4Lix4Lib4LmC4Lir4Lil4LiUXG4gKiAtIGVkaXQgbW9kZTog4LmA4Lil4Li34Lit4LiBL+C4peC4suC4geC5hOC4n+C4peC5jOC5g+C4q+C4oeC5iCAo4Lii4Lix4LiH4LmE4Lih4LmI4Liq4LmI4LiH4LiC4Li24LmJ4LiZIHNlcnZlciDguIjguJnguIHguKfguYjguLLguIjguLDguIHguJTguJrguLHguJnguJfguLbguIHguILguK3guIcgc2VjdGlvbilcbiAqICAg4LiB4LiUIOKclSDguYTguJTguYnguYDguInguJ7guLLguLDguYTguJ/guKXguYzguJfguLXguYjguYDguJ7guLTguYjguIfguYDguKXguLfguK3guIEgKOC4ouC4geC5gOC4peC4tOC4geC4geC4peC4seC4muC5hOC4m+C5g+C4iuC5ieC4o+C4ueC4m+C5gOC4lOC4tOC4oSkg4oCUIEFQSSDguKLguLHguIfguYTguKHguYjguKHguLUgZW5kcG9pbnQg4Lil4LiaIFFSXG4gKiAtIGVycm9yOiDguILguYnguK3guITguKfguLLguKEgZXJyb3Ig4LiI4Liy4LiB4Lid4Lix4LmI4LiH4Lif4Lit4Lij4LmM4LihICjguYDguIrguYjguJkg4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4LmA4Lil4Li34Lit4LiBIFFSIOC4leC4reC4meC4quC4o+C5ieC4suC4h+C4hOC4o+C4seC5ieC4h+C5geC4o+C4gSlcbiAqL1xuZnVuY3Rpb24gU2l0dGVyUXJVcGxvYWQoeyBxckNvZGVVcmwsIGlzRWRpdGluZywgZmlsZSwgZXJyb3I6IGZvcm1FcnJvciwgb25TZWxlY3RGaWxlLCBvblJlbW92ZSB9KSB7XG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBbaXNEcmFnZ2luZywgc2V0SXNEcmFnZ2luZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtmaWxlRXJyb3IsIHNldEZpbGVFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Nob3dMaWdodGJveCwgc2V0U2hvd0xpZ2h0Ym94XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBbcHJldmlld1VybCwgc2V0UHJldmlld1VybF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWZpbGUpIHtcbiAgICAgIHNldFByZXZpZXdVcmwoXCJcIik7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xuICAgIHNldFByZXZpZXdVcmwodXJsKTtcbiAgICByZXR1cm4gKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICB9LCBbZmlsZV0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7IGlmICghaXNFZGl0aW5nKSBzZXRGaWxlRXJyb3IoXCJcIik7IH0sIFtpc0VkaXRpbmddKTtcblxuICBjb25zdCBlcnJvciA9IGZpbGVFcnJvciB8fCBmb3JtRXJyb3I7XG5cbiAgY29uc3QgcHJvY2Vzc0ZpbGUgPSAocGlja2VkKSA9PiB7XG4gICAgaWYgKCFwaWNrZWQpIHJldHVybjtcbiAgICBpZiAoIVZBTElEX1RZUEVTLmluY2x1ZGVzKHBpY2tlZC50eXBlKSkge1xuICAgICAgc2V0RmlsZUVycm9yKFwi4Lij4Lit4LiH4Lij4Lix4Lia4LmA4LiJ4Lie4Liy4Liw4LmE4Lif4Lil4LmMIEpQRywgUE5HIOC4q+C4o+C4t+C4rSBXRUJQIOC5gOC4l+C5iOC4suC4meC4seC5ieC4mVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHBpY2tlZC5zaXplID4gTUFYX0ZJTEVfU0laRSkge1xuICAgICAgc2V0RmlsZUVycm9yKGDguYTguJ/guKXguYzguYPguKvguI3guYjguYDguIHguLTguJkgNSBNQiAoJHtmb3JtYXRTaXplKHBpY2tlZC5zaXplKX0pYCk7XG4gICAgICB0b2FzdChcIuC4guC4meC4suC4lOC5hOC4n+C4peC5jOC5g+C4q+C4jeC5iOC5gOC4geC4tOC4meC5hOC4myDguIHguKPguLjguJPguLLguK3guLHguJvguYLguKvguKXguJTguKPguLnguJvguKDguLLguJ7guILguJnguLLguJTguYTguKHguYjguYDguIHguLTguJkgNU1CXCIsIFwiZXJyb3JcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEZpbGVFcnJvcihcIlwiKTtcbiAgICBvblNlbGVjdEZpbGUocGlja2VkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcm9wID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XG4gICAgcHJvY2Vzc0ZpbGUoZS5kYXRhVHJhbnNmZXIuZmlsZXM/LlswXSk7XG4gIH07XG5cbiAgY29uc3QgY3VycmVudFVybCA9IGZpbGUgPyBwcmV2aWV3VXJsIDogcXJDb2RlVXJsIHx8IFwiXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCI+UVIgQ29kZSDguKPguLHguJrguIrguLPguKPguLDguYDguIfguLTguJk8L3NwYW4+XG5cbiAgICAgIHshaXNFZGl0aW5nID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInFyLXZhbHVlXCI+XG4gICAgICAgICAge3FyQ29kZVVybCA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJxci10aHVtYlwiXG4gICAgICAgICAgICAgICAgc3JjPXtxckNvZGVVcmx9XG4gICAgICAgICAgICAgICAgYWx0PVwiUVIgQ29kZSDguKPguLHguJrguIrguLPguKPguLDguYDguIfguLTguJlcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwi4LiE4Lil4Li04LiB4LmA4Lie4Li34LmI4Lit4LiU4Li54Lig4Liy4Lie4LiC4Lii4Liy4LiiXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TGlnaHRib3godHJ1ZSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInFyLWhpbnQtbGlua1wiPuC4hOC4peC4tOC4geC4l+C4teC5iOC4o+C4ueC4m+C5gOC4nuC4t+C5iOC4reC4guC4ouC4suC4ojwvc3Bhbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxci1lbXB0eVwiPuC4ouC4seC4h+C5hOC4oeC5iOC5hOC4lOC5ieC4reC4seC4m+C5guC4q+C4peC4lDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1maWVsZC1jb250YWluZXJcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHJlZj17aW5wdXRSZWZ9XG4gICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS9qcGVnLCBpbWFnZS9wbmcsIGltYWdlL2pwZywgaW1hZ2Uvd2VicFwiXG4gICAgICAgICAgICBoaWRkZW5cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICBwcm9jZXNzRmlsZShlLnRhcmdldC5maWxlcz8uWzBdKTtcbiAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPSBcIlwiO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHBldC1maWxlLXVwbG9hZC1ib3ggcXItdXBsb2FkLWJveCR7aXNEcmFnZ2luZyA/IFwiIHBldC1maWxlLXVwbG9hZC1ib3gtLWRyYWdvdmVyXCIgOiBcIlwifSR7ZXJyb3IgPyBcIiBxci11cGxvYWQtYm94LS1lcnJvclwiIDogXCJcIn1gfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgIG9uRHJhZ092ZXI9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0SXNEcmFnZ2luZyh0cnVlKTsgfX1cbiAgICAgICAgICAgIG9uRHJhZ0xlYXZlPXsoKSA9PiBzZXRJc0RyYWdnaW5nKGZhbHNlKX1cbiAgICAgICAgICAgIG9uRHJvcD17aGFuZGxlRHJvcH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBldC1maWxlLXVwbG9hZC1sZWZ0XCI+XG4gICAgICAgICAgICAgIHtjdXJyZW50VXJsID8gKFxuICAgICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwicXItcHJldmlld1wiIHNyYz17Y3VycmVudFVybH0gYWx0PVwi4LiV4Lix4Lin4Lit4Lii4LmI4Liy4LiHIFFSIENvZGVcIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXItcGxhY2Vob2xkZXJcIj7ilqY8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxci1pbmZvXCI+XG4gICAgICAgICAgICAgICAge2N1cnJlbnRVcmwgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwZXQtZmlsZS1uYW1lXCI+e2ZpbGUgPyBmaWxlLm5hbWUgOiBcIlFSIENvZGUg4Lib4Lix4LiI4LiI4Li44Lia4Lix4LiZXCJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwZXQtZmlsZS1zdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsZSA/IGDinJMg4LmA4Lil4Li34Lit4LiB4LmB4Lil4LmJ4LinIMK3ICR7Zm9ybWF0U2l6ZShmaWxlLnNpemUpfSAo4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4Lia4Lix4LiZ4LiX4Li24LiBKWAgOiBcIuKckyDguKHguLXguKPguLnguJvguK3guKLguLnguYjguYHguKXguYnguKdcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBldC1maWxlLW5hbWVcIj7guKXguLLguIHguKPguLnguJvguKHguLLguKfguLLguIcg4Lir4Lij4Li34Lit4LiB4LiU4LmA4Lil4Li34Lit4LiB4Lij4Li54LibPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwZXQtZmlsZS1oaW50XCI+SlBHIC8gUE5HIC8gV0VCUCDguYTguKHguYjguYDguIHguLTguJkgNSBNQjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwZXQtZmlsZS1jaG9vc2UtYnRuXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgaW5wdXRSZWYuY3VycmVudD8uY2xpY2soKTsgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2N1cnJlbnRVcmwgPyBcIuC5gOC4m+C4peC4teC5iOC4ouC4meC4o+C4ueC4m1wiIDogXCLguYDguKXguLfguK3guIHguKPguLnguJvguKDguLLguJ5cIn1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAge2ZpbGUgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGV0LWZpbGUtcmVtb3ZlLWJ0blwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCLguKLguIHguYDguKXguLTguIHguKPguLnguJvguJfguLXguYjguYDguKXguLfguK3guIFcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IHNldEZpbGVFcnJvcihcIlwiKTsgb25SZW1vdmUoKTsgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwicXItZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXItZWRpdC1ub3RlXCI+4LmD4LiK4LmJ4Liq4Liz4Lir4Lij4Lix4Lia4LmD4Lir4LmJ4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4Liq4LmB4LiB4LiZ4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge3Nob3dMaWdodGJveCAmJiBxckNvZGVVcmwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInFyLWxpZ2h0Ym94XCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0xpZ2h0Ym94KGZhbHNlKX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxci1saWdodGJveC1ib3hcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJxci1saWdodGJveC1jbG9zZVwiIGFyaWEtbGFiZWw9XCLguJvguLTguJRcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TGlnaHRib3goZmFsc2UpfT7inJU8L2J1dHRvbj5cbiAgICAgICAgICAgIDxpbWcgc3JjPXtxckNvZGVVcmx9IGFsdD1cIlFSIENvZGUg4Lij4Lix4Lia4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXCIgLz5cbiAgICAgICAgICAgIDxwPlFSIENvZGUg4Lij4Lix4Lia4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNpdHRlclFyVXBsb2FkO1xuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU2l0dGVyUXJVcGxvYWQuanN4In0=