import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SitterFilters.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import ThaiAddressSelects from "/src/components/ThaiAddressSelects.jsx";
import { PET_TYPES, SERVICE_TYPES, SORT_OPTIONS } from "/src/utils/sitterOptions.js";
function ChipGroup({ options, value, onChange }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "chip-row", children: [
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: `chip-btn${value === "" ? " active" : ""}`, onClick: () => onChange(""), children: "ทั้งหมด" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    Object.entries(options).map(
      ([key, label]) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: `chip-btn${value === key ? " active" : ""}`,
          onClick: () => onChange(key),
          children: label
        },
        key,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 30,
          columnNumber: 7
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
    lineNumber: 25,
    columnNumber: 5
  }, this);
}
_c = ChipGroup;
export default function SitterFilters({ filters, priceError, resetKey, onChange, onAreaChange, onReset }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "filter-card", "aria-label": "ตัวกรอง", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "filter-grid", children: [
      /* @__PURE__ */ jsxDEV(ThaiAddressSelects, { mode: "filter", value: filters, onChange: onAreaChange }, resetKey, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "ราคา (บาท)" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "price-row", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              className: "input",
              type: "number",
              min: "0",
              inputMode: "numeric",
              placeholder: "ต่ำสุด",
              "aria-label": "ราคาต่ำสุด",
              value: filters.min,
              onChange: (e) => onChange({ min: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
              lineNumber: 53,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "–" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
            lineNumber: 57,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              className: "input",
              type: "number",
              min: "0",
              inputMode: "numeric",
              placeholder: "สูงสุด",
              "aria-label": "ราคาสูงสุด",
              value: filters.max,
              onChange: (e) => onChange({ max: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
              lineNumber: 58,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        priceError && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: priceError }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 63,
          columnNumber: 26
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "คะแนนขั้นต่ำ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 67,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "star-select", children: [
          [1, 2, 3, 4, 5].map(
            (i) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                "aria-label": `${i} ดาวขึ้นไป`,
                className: `star-btn${i <= filters.rating ? " on" : ""}`,
                onClick: () => onChange({ rating: filters.rating === i ? 0 : i }),
                children: "★"
              },
              i,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
                lineNumber: 70,
                columnNumber: 13
              },
              this
            )
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "star-hint", children: filters.rating ? `${filters.rating} ดาวขึ้นไป` : "ทั้งหมด" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
            lineNumber: 79,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 68,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field filter-wide", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "ประเภทสัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 84,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChipGroup, { options: PET_TYPES, value: filters.pet, onChange: (pet) => onChange({ pet }) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 85,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "filter-field filter-wide", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "ประเภทบริการ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 89,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChipGroup, { options: SERVICE_TYPES, value: filters.service, onChange: (service) => onChange({ service }) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 90,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "filter-actions", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sort-wrap", children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "filter-sort", children: "เรียงตาม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 96,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("select", { id: "filter-sort", className: "input", value: filters.sort, onChange: (e) => onChange({ sort: e.target.value }), children: SORT_OPTIONS.map((o) => /* @__PURE__ */ jsxDEV("option", { value: o.value, children: o.label }, o.value, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 98,
          columnNumber: 38
        }, this)) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
          lineNumber: 97,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn--ghost btn--small", onClick: onReset, children: "ล้างตัวกรอง" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
        lineNumber: 101,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
}
_c2 = SitterFilters;
var _c, _c2;
$RefreshReg$(_c, "ChipGroup");
$RefreshReg$(_c2, "SitterFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/SitterFilters.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFOTixPQUFPQSx3QkFBd0I7QUFDL0IsU0FBU0MsV0FBV0MsZUFBZUMsb0JBQW9CO0FBRXZELFNBQVNDLFVBQVUsRUFBRUMsU0FBU0MsT0FBT0MsU0FBUyxHQUFHO0FBQy9DLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSwyQkFBQyxZQUFPLE1BQUssVUFBUyxXQUFXLFdBQVdELFVBQVUsS0FBSyxZQUFZLEVBQUUsSUFBSSxTQUFTLE1BQU1DLFNBQVMsRUFBRSxHQUFFLHVCQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDQyxPQUFPQyxRQUFRSixPQUFPLEVBQUVLO0FBQUFBLE1BQUksQ0FBQyxDQUFDQyxLQUFLQyxLQUFLLE1BQ3ZDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxXQUFXLFdBQVdOLFVBQVVLLE1BQU0sWUFBWSxFQUFFO0FBQUEsVUFDcEQsU0FBUyxNQUFNSixTQUFTSSxHQUFHO0FBQUEsVUFFMUJDO0FBQUFBO0FBQUFBLFFBTElEO0FBQUFBLFFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsSUFDRDtBQUFBLE9BYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBRUo7QUFBQ0UsS0FsQlFUO0FBb0JULHdCQUF3QlUsY0FBYyxFQUFFQyxTQUFTQyxZQUFZQyxVQUFVVixVQUFVVyxjQUFjQyxRQUFRLEdBQUc7QUFDeEcsU0FDRSx1QkFBQyxhQUFRLFdBQVUsZUFBYyxjQUFXLFdBQzFDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGVBRWI7QUFBQSw2QkFBQyxzQkFBa0MsTUFBSyxVQUFTLE9BQU9KLFNBQVMsVUFBVUcsZ0JBQWxERCxVQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdGO0FBQUEsTUFFeEYsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsMEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FBUSxNQUFLO0FBQUEsY0FBUyxLQUFJO0FBQUEsY0FBSSxXQUFVO0FBQUEsY0FBVSxhQUFZO0FBQUEsY0FDeEUsY0FBVztBQUFBLGNBQWEsT0FBT0YsUUFBUUs7QUFBQUEsY0FBSyxVQUFVLENBQUNDLE1BQU1kLFNBQVMsRUFBRWEsS0FBS0MsRUFBRUMsT0FBT2hCLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRWlHO0FBQUEsVUFFakcsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFDUDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQVEsTUFBSztBQUFBLGNBQVMsS0FBSTtBQUFBLGNBQUksV0FBVTtBQUFBLGNBQVUsYUFBWTtBQUFBLGNBQ3hFLGNBQVc7QUFBQSxjQUFhLE9BQU9TLFFBQVFRO0FBQUFBLGNBQUssVUFBVSxDQUFDRixNQUFNZCxTQUFTLEVBQUVnQixLQUFLRixFQUFFQyxPQUFPaEIsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFaUc7QUFBQSxhQVJuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNDVSxjQUFjLHVCQUFDLFNBQUksV0FBVSxlQUFlQSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFdBYjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNwQyx1QkFBQyxTQUFJLFdBQVUsZUFDWjtBQUFBLFdBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUVOO0FBQUFBLFlBQUksQ0FBQ2MsTUFDcEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDUyxNQUFLO0FBQUEsZ0JBQVMsY0FBWSxHQUFHQSxDQUFDO0FBQUEsZ0JBQ3RDLFdBQVcsV0FBV0EsS0FBS1QsUUFBUVUsU0FBUyxRQUFRLEVBQUU7QUFBQSxnQkFFdEQsU0FBUyxNQUFNbEIsU0FBUyxFQUFFa0IsUUFBUVYsUUFBUVUsV0FBV0QsSUFBSSxJQUFJQSxFQUFFLENBQUM7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FIN0RBO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsVUFDRDtBQUFBLFVBQ0QsdUJBQUMsVUFBSyxXQUFVLGFBQWFULGtCQUFRVSxTQUFTLEdBQUdWLFFBQVFVLE1BQU0sZUFBZSxhQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLGFBWDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSxpQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQ3pDLHVCQUFDLGFBQVUsU0FBU3hCLFdBQVcsT0FBT2MsUUFBUVcsS0FBSyxVQUFVLENBQUNBLFFBQVFuQixTQUFTLEVBQUVtQixJQUFJLENBQUMsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFdBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNwQyx1QkFBQyxhQUFVLFNBQVN4QixlQUFlLE9BQU9hLFFBQVFZLFNBQVMsVUFBVSxDQUFDQSxZQUFZcEIsU0FBUyxFQUFFb0IsUUFBUSxDQUFDLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxXQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQU0sU0FBUSxlQUFjLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsWUFBTyxJQUFHLGVBQWMsV0FBVSxTQUFRLE9BQU9aLFFBQVFhLE1BQU0sVUFBVSxDQUFDUCxNQUFNZCxTQUFTLEVBQUVxQixNQUFNUCxFQUFFQyxPQUFPaEIsTUFBTSxDQUFDLEdBQy9HSCx1QkFBYU8sSUFBSSxDQUFDbUIsTUFBTSx1QkFBQyxZQUFxQixPQUFPQSxFQUFFdkIsT0FBUXVCLFlBQUVqQixTQUE1QmlCLEVBQUV2QixPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0MsQ0FBUyxLQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSw2QkFBNEIsU0FBU2EsU0FBUywyQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RjtBQUFBLFNBUDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwREE7QUFFSjtBQUFDVyxNQTlEdUJoQjtBQUFhLElBQUFELElBQUFpQjtBQUFBLGFBQUFqQixJQUFBO0FBQUEsYUFBQWlCLEtBQUEiLCJuYW1lcyI6WyJUaGFpQWRkcmVzc1NlbGVjdHMiLCJQRVRfVFlQRVMiLCJTRVJWSUNFX1RZUEVTIiwiU09SVF9PUFRJT05TIiwiQ2hpcEdyb3VwIiwib3B0aW9ucyIsInZhbHVlIiwib25DaGFuZ2UiLCJPYmplY3QiLCJlbnRyaWVzIiwibWFwIiwia2V5IiwibGFiZWwiLCJfYyIsIlNpdHRlckZpbHRlcnMiLCJmaWx0ZXJzIiwicHJpY2VFcnJvciIsInJlc2V0S2V5Iiwib25BcmVhQ2hhbmdlIiwib25SZXNldCIsIm1pbiIsImUiLCJ0YXJnZXQiLCJtYXgiLCJpIiwicmF0aW5nIiwicGV0Iiwic2VydmljZSIsInNvcnQiLCJvIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpdHRlckZpbHRlcnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBUaGFpQWRkcmVzc1NlbGVjdHMgZnJvbSBcIi4vVGhhaUFkZHJlc3NTZWxlY3RzLmpzeFwiO1xuaW1wb3J0IHsgUEVUX1RZUEVTLCBTRVJWSUNFX1RZUEVTLCBTT1JUX09QVElPTlMgfSBmcm9tIFwiLi4vdXRpbHMvc2l0dGVyT3B0aW9ucy5qc1wiO1xuXG5mdW5jdGlvbiBDaGlwR3JvdXAoeyBvcHRpb25zLCB2YWx1ZSwgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hpcC1yb3dcIj5cbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17YGNoaXAtYnRuJHt2YWx1ZSA9PT0gXCJcIiA/IFwiIGFjdGl2ZVwiIDogXCJcIn1gfSBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZShcIlwiKX0+XG4gICAgICAgIOC4l+C4seC5ieC4h+C4q+C4oeC4lFxuICAgICAgPC9idXR0b24+XG4gICAgICB7T2JqZWN0LmVudHJpZXMob3B0aW9ucykubWFwKChba2V5LCBsYWJlbF0pID0+IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGtleT17a2V5fVxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT17YGNoaXAtYnRuJHt2YWx1ZSA9PT0ga2V5ID8gXCIgYWN0aXZlXCIgOiBcIlwifWB9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2Uoa2V5KX1cbiAgICAgICAgPlxuICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2l0dGVyRmlsdGVycyh7IGZpbHRlcnMsIHByaWNlRXJyb3IsIHJlc2V0S2V5LCBvbkNoYW5nZSwgb25BcmVhQ2hhbmdlLCBvblJlc2V0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmaWx0ZXItY2FyZFwiIGFyaWEtbGFiZWw9XCLguJXguLHguKfguIHguKPguK3guIdcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWdyaWRcIj5cbiAgICAgICAgey8qIGtleSDguYDguJvguKXguLXguYjguKLguJnguJXguK3guJnguKXguYnguLLguIfguJXguLHguKfguIHguKPguK3guIcg4LmA4Lie4Lij4Liy4LiwIFRoYWlBZGRyZXNzU2VsZWN0cyDguYDguIHguYfguJogaWQg4LiX4Li14LmI4LmA4Lil4Li34Lit4LiB4LmE4Lin4LmJ4LmD4LiZIHN0YXRlIOC4guC4reC4h+C4leC4seC4p+C5gOC4reC4hyAqL31cbiAgICAgICAgPFRoYWlBZGRyZXNzU2VsZWN0cyBrZXk9e3Jlc2V0S2V5fSBtb2RlPVwiZmlsdGVyXCIgdmFsdWU9e2ZpbHRlcnN9IG9uQ2hhbmdlPXtvbkFyZWFDaGFuZ2V9IC8+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItZmllbGRcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPuC4o+C4suC4hOC4siAo4Lia4Liy4LiXKTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByaWNlLXJvd1wiPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0XCIgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBpbnB1dE1vZGU9XCJudW1lcmljXCIgcGxhY2Vob2xkZXI9XCLguJXguYjguLPguKrguLjguJRcIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwi4Lij4Liy4LiE4Liy4LiV4LmI4Liz4Liq4Li44LiUXCIgdmFsdWU9e2ZpbHRlcnMubWlufSBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHsgbWluOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3Bhbj7igJM8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXRcIiB0eXBlPVwibnVtYmVyXCIgbWluPVwiMFwiIGlucHV0TW9kZT1cIm51bWVyaWNcIiBwbGFjZWhvbGRlcj1cIuC4quC4ueC4h+C4quC4uOC4lFwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLguKPguLLguITguLLguKrguLnguIfguKrguLjguJRcIiB2YWx1ZT17ZmlsdGVycy5tYXh9IG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoeyBtYXg6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7cHJpY2VFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e3ByaWNlRXJyb3J9PC9kaXY+fVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1maWVsZFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhYmVsXCI+4LiE4Liw4LmB4LiZ4LiZ4LiC4Lix4LmJ4LiZ4LiV4LmI4LizPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Rhci1zZWxlY3RcIj5cbiAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNV0ubWFwKChpKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e2l9IHR5cGU9XCJidXR0b25cIiBhcmlhLWxhYmVsPXtgJHtpfSDguJTguLLguKfguILguLbguYnguJnguYTguJtgfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHN0YXItYnRuJHtpIDw9IGZpbHRlcnMucmF0aW5nID8gXCIgb25cIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAvLyDguIHguJTguIvguYnguLPguJfguLXguYjguITguYjguLLguYDguJTguLTguKHguYDguJ7guLfguYjguK3guKXguYnguLLguIfguJXguLHguKfguIHguKPguK3guIfguITguLDguYHguJnguJlcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSh7IHJhdGluZzogZmlsdGVycy5yYXRpbmcgPT09IGkgPyAwIDogaSB9KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIOKYhVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Rhci1oaW50XCI+e2ZpbHRlcnMucmF0aW5nID8gYCR7ZmlsdGVycy5yYXRpbmd9IOC4lOC4suC4p+C4guC4tuC5ieC4meC5hOC4m2AgOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwifTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItZmllbGQgZmlsdGVyLXdpZGVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPuC4m+C4o+C4sOC5gOC4oOC4l+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hzwvc3Bhbj5cbiAgICAgICAgICA8Q2hpcEdyb3VwIG9wdGlvbnM9e1BFVF9UWVBFU30gdmFsdWU9e2ZpbHRlcnMucGV0fSBvbkNoYW5nZT17KHBldCkgPT4gb25DaGFuZ2UoeyBwZXQgfSl9IC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWZpZWxkIGZpbHRlci13aWRlXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj7guJvguKPguLDguYDguKDguJfguJrguKPguLTguIHguLLguKM8L3NwYW4+XG4gICAgICAgICAgPENoaXBHcm91cCBvcHRpb25zPXtTRVJWSUNFX1RZUEVTfSB2YWx1ZT17ZmlsdGVycy5zZXJ2aWNlfSBvbkNoYW5nZT17KHNlcnZpY2UpID0+IG9uQ2hhbmdlKHsgc2VydmljZSB9KX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItYWN0aW9uc1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvcnQtd3JhcFwiPlxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZmlsdGVyLXNvcnRcIj7guYDguKPguLXguKLguIfguJXguLLguKE8L2xhYmVsPlxuICAgICAgICAgIDxzZWxlY3QgaWQ9XCJmaWx0ZXItc29ydFwiIGNsYXNzTmFtZT1cImlucHV0XCIgdmFsdWU9e2ZpbHRlcnMuc29ydH0gb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZSh7IHNvcnQ6IGUudGFyZ2V0LnZhbHVlIH0pfT5cbiAgICAgICAgICAgIHtTT1JUX09QVElPTlMubWFwKChvKSA9PiA8b3B0aW9uIGtleT17by52YWx1ZX0gdmFsdWU9e28udmFsdWV9PntvLmxhYmVsfTwvb3B0aW9uPil9XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLS1naG9zdCBidG4tLXNtYWxsXCIgb25DbGljaz17b25SZXNldH0+4Lil4LmJ4Liy4LiH4LiV4Lix4Lin4LiB4Lij4Lit4LiHPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9TaXR0ZXJGaWx0ZXJzLmpzeCJ9