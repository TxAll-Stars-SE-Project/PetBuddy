import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/DashboardHeader.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function DashboardHeader({ username }) {
  return /* @__PURE__ */ jsxDEV("header", { className: "pt-2", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl sm:text-3xl font-bold text-slate-900", children: [
      "สวัสดี, ",
      username || "พี่เลี้ยง"
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1", children: "จัดการบริการและคำขอจองของคุณ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_c = DashboardHeader;
var _c;
$RefreshReg$(_c, "DashboardHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/DashboardHeader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFmTixPQUFPQSxXQUFXO0FBWWxCLHdCQUF3QkMsZ0JBQWdCLEVBQUVDLFNBQVMsR0FBRztBQUNwRCxTQUNFLHVCQUFDLFlBQU8sV0FBVSxRQUNoQjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxpREFBK0M7QUFBQTtBQUFBLE1BQ2xEQSxZQUFZO0FBQUEsU0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQTZCLDRDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNDLEtBWHVCRjtBQUFlLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiRGFzaGJvYXJkSGVhZGVyIiwidXNlcm5hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmRIZWFkZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBEYXNoYm9hcmRIZWFkZXIgQ29tcG9uZW50XG4gKiBcbiAqIE1pbmltYWwgcGFnZSBoZWFkaW5nIGZvciBTaXR0ZXIgRGFzaGJvYXJkOlxuICogLSBObyBjYXJkL2JvcmRlciAoTmF2YmFyIGFscmVhZHkgY2FycmllcyB0aGUgUGV0QnVkZHkgYnJhbmRpbmcpLlxuICogLSBQZXJzb25hbCBncmVldGluZyB3aXRoIHRoZSBzaXR0ZXIncyB1c2VybmFtZSArIG11dGVkIHN1YnRpdGxlLlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7c3RyaW5nfSBbcHJvcHMudXNlcm5hbWVdIC0gRGlzcGxheSBuYW1lIG9mIHRoZSBsb2dnZWQtaW4gc2l0dGVyLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXNoYm9hcmRIZWFkZXIoeyB1c2VybmFtZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJwdC0yXCI+XG4gICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC0zeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgIOC4quC4p+C4seC4quC4lOC4tSwge3VzZXJuYW1lIHx8IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiHXCJ9XG4gICAgICA8L2gxPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+XG4gICAgICAgIOC4iOC4seC4lOC4geC4suC4o+C4muC4o+C4tOC4geC4suC4o+C5geC4peC4sOC4hOC4s+C4guC4reC4iOC4reC4h+C4guC4reC4h+C4hOC4uOC4k1xuICAgICAgPC9wPlxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL2Rhc2hib2FyZC9EYXNoYm9hcmRIZWFkZXIuanN4In0=