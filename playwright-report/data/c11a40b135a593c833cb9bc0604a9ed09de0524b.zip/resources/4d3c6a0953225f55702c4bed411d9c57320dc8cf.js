import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Toast.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
export default function Toast() {
  _s();
  const [item, setItem] = useState(null);
  useEffect(() => {
    let timer;
    const onToast = (e) => {
      setItem(e.detail);
      clearTimeout(timer);
      timer = setTimeout(() => setItem(null), 3500);
    };
    window.addEventListener("pb:toast", onToast);
    return () => {
      window.removeEventListener("pb:toast", onToast);
      clearTimeout(timer);
    };
  }, []);
  if (!item) return null;
  const isError = item.type === "error";
  const isInfo = item.type === "info";
  const isWarning = item.type === "warning";
  return /* @__PURE__ */ jsxDEV(
    "aside",
    {
      "aria-label": "Notification",
      className: "fixed top-5 right-5 z-[10050] max-w-sm w-[calc(100vw-40px)] pointer-events-auto",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `bg-white rounded-2xl p-4 shadow-xl border flex items-start gap-3 transition-all ${isError ? "border-rose-200 shadow-rose-500/10" : isWarning ? "border-amber-200 shadow-amber-500/10" : isInfo ? "border-teal-200 shadow-teal-500/10" : "border-emerald-200 shadow-emerald-500/10"}`,
          role: "status",
          "aria-live": "polite",
          children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-sm ${isError ? "bg-rose-50 text-rose-600 border border-rose-200" : isWarning ? "bg-amber-50 text-amber-600 border border-amber-200" : isInfo ? "bg-teal-50 text-teal-600 border border-teal-200" : "bg-emerald-50 text-emerald-600 border border-emerald-200"}`,
                children: isError ? "✕" : isWarning ? "⚠" : isInfo ? "ℹ" : "✓"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
                lineNumber: 72,
                columnNumber: 9
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 pt-1", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs sm:text-sm font-bold text-slate-800 leading-snug", children: item.message }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
              lineNumber: 88,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
              lineNumber: 87,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setItem(null),
                className: "text-slate-400 hover:text-slate-600 text-xs p-1 rounded-lg transition-colors cursor-pointer",
                "aria-label": "ปิดการแจ้งเตือน",
                children: "✕"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
                lineNumber: 94,
                columnNumber: 9
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
          lineNumber: 58,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx",
      lineNumber: 54,
      columnNumber: 5
    },
    this
  );
}
_s(Toast, "J5MFcpuA8so9sJ2d7BMdQD7RvSM=");
_c = Toast;
var _c;
$RefreshReg$(_c, "Toast");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/Toast.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEUixPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFTM0Msd0JBQXdCQyxRQUFRO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlKLFNBQVMsSUFBSTtBQUVyQ0QsWUFBVSxNQUFNO0FBQ2QsUUFBSU07QUFDSixVQUFNQyxVQUFVQSxDQUFDQyxNQUFNO0FBQ3JCSCxjQUFRRyxFQUFFQyxNQUFNO0FBQ2hCQyxtQkFBYUosS0FBSztBQUNsQkEsY0FBUUssV0FBVyxNQUFNTixRQUFRLElBQUksR0FBRyxJQUFJO0FBQUEsSUFDOUM7QUFFQU8sV0FBT0MsaUJBQWlCLFlBQVlOLE9BQU87QUFDM0MsV0FBTyxNQUFNO0FBQ1hLLGFBQU9FLG9CQUFvQixZQUFZUCxPQUFPO0FBQzlDRyxtQkFBYUosS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxNQUFJLENBQUNGLEtBQU0sUUFBTztBQUVsQixRQUFNVyxVQUFVWCxLQUFLWSxTQUFTO0FBQzlCLFFBQU1DLFNBQVNiLEtBQUtZLFNBQVM7QUFDN0IsUUFBTUUsWUFBWWQsS0FBS1ksU0FBUztBQUVoQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxjQUFXO0FBQUEsTUFDWCxXQUFVO0FBQUEsTUFFVjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVyxtRkFDVEQsVUFDSSx1Q0FDQUcsWUFDQSx5Q0FDQUQsU0FDQSx1Q0FDQSwwQ0FBMEM7QUFBQSxVQUVoRCxNQUFLO0FBQUEsVUFDTCxhQUFVO0FBQUEsVUFHVjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyx1RkFDVEYsVUFDSSxvREFDQUcsWUFDQSx1REFDQUQsU0FDQSxvREFDQSwwREFBMEQ7QUFBQSxnQkFHL0RGLG9CQUFVLE1BQU1HLFlBQVksTUFBTUQsU0FBUyxNQUFNO0FBQUE7QUFBQSxjQVhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2IsaUNBQUMsT0FBRSxXQUFVLDREQUNWYixlQUFLZSxXQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1kLFFBQVEsSUFBSTtBQUFBLGdCQUMzQixXQUFVO0FBQUEsZ0JBQ1YsY0FBVztBQUFBLGdCQUFpQjtBQUFBO0FBQUEsY0FKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQTtBQUFBO0FBQUEsUUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BNENBO0FBQUE7QUFBQSxJQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpREE7QUFFSjtBQUFDRixHQTVFdUJELE9BQUs7QUFBQSxLQUFMQTtBQUFLLElBQUFrQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVG9hc3QiLCJfcyIsIml0ZW0iLCJzZXRJdGVtIiwidGltZXIiLCJvblRvYXN0IiwiZSIsImRldGFpbCIsImNsZWFyVGltZW91dCIsInNldFRpbWVvdXQiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImlzRXJyb3IiLCJ0eXBlIiwiaXNJbmZvIiwiaXNXYXJuaW5nIiwibWVzc2FnZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRvYXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG4vKipcbiAqIFRvYXN0IENvbXBvbmVudFxuICogXG4gKiBNb2Rlcm4sIGZsb2F0aW5nIG5vdGlmaWNhdGlvbiBiYW5uZXIgc3R5bGVkIHdpdGggVGFpbHdpbmQgQ1NTLlxuICogTGlzdGVucyB0byB0aGUgZ2xvYmFsIGBwYjp0b2FzdGAgQ3VzdG9tRXZlbnQuXG4gKiBTdXBwb3J0czogJ3N1Y2Nlc3MnIChkZWZhdWx0KSwgJ2Vycm9yJywgJ2luZm8nLCAnd2FybmluZycuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRvYXN0KCkge1xuICBjb25zdCBbaXRlbSwgc2V0SXRlbV0gPSB1c2VTdGF0ZShudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCB0aW1lcjtcbiAgICBjb25zdCBvblRvYXN0ID0gKGUpID0+IHtcbiAgICAgIHNldEl0ZW0oZS5kZXRhaWwpO1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBzZXRJdGVtKG51bGwpLCAzNTAwKTtcbiAgICB9O1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwYjp0b2FzdFwiLCBvblRvYXN0KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwYjp0b2FzdFwiLCBvblRvYXN0KTtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGlmICghaXRlbSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgaXNFcnJvciA9IGl0ZW0udHlwZSA9PT0gXCJlcnJvclwiO1xuICBjb25zdCBpc0luZm8gPSBpdGVtLnR5cGUgPT09IFwiaW5mb1wiO1xuICBjb25zdCBpc1dhcm5pbmcgPSBpdGVtLnR5cGUgPT09IFwid2FybmluZ1wiO1xuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlXG4gICAgICBhcmlhLWxhYmVsPVwiTm90aWZpY2F0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIHRvcC01IHJpZ2h0LTUgei1bMTAwNTBdIG1heC13LXNtIHctW2NhbGMoMTAwdnctNDBweCldIHBvaW50ZXItZXZlbnRzLWF1dG9cIlxuICAgID5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgcm91bmRlZC0yeGwgcC00IHNoYWRvdy14bCBib3JkZXIgZmxleCBpdGVtcy1zdGFydCBnYXAtMyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgIGlzRXJyb3JcbiAgICAgICAgICAgID8gXCJib3JkZXItcm9zZS0yMDAgc2hhZG93LXJvc2UtNTAwLzEwXCJcbiAgICAgICAgICAgIDogaXNXYXJuaW5nXG4gICAgICAgICAgICA/IFwiYm9yZGVyLWFtYmVyLTIwMCBzaGFkb3ctYW1iZXItNTAwLzEwXCJcbiAgICAgICAgICAgIDogaXNJbmZvXG4gICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtMjAwIHNoYWRvdy10ZWFsLTUwMC8xMFwiXG4gICAgICAgICAgICA6IFwiYm9yZGVyLWVtZXJhbGQtMjAwIHNoYWRvdy1lbWVyYWxkLTUwMC8xMFwiXG4gICAgICAgIH1gfVxuICAgICAgICByb2xlPVwic3RhdHVzXCJcbiAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcbiAgICAgID5cbiAgICAgICAgey8qIFN0YXR1cyBJY29uICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPXtgdy04IGgtOCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTAgZm9udC1ib2xkIHRleHQtc20gJHtcbiAgICAgICAgICAgIGlzRXJyb3JcbiAgICAgICAgICAgICAgPyBcImJnLXJvc2UtNTAgdGV4dC1yb3NlLTYwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwXCJcbiAgICAgICAgICAgICAgOiBpc1dhcm5pbmdcbiAgICAgICAgICAgICAgPyBcImJnLWFtYmVyLTUwIHRleHQtYW1iZXItNjAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCJcbiAgICAgICAgICAgICAgOiBpc0luZm9cbiAgICAgICAgICAgICAgPyBcImJnLXRlYWwtNTAgdGV4dC10ZWFsLTYwMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwXCJcbiAgICAgICAgICAgICAgOiBcImJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTYwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwXCJcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIHtpc0Vycm9yID8gXCLinJVcIiA6IGlzV2FybmluZyA/IFwi4pqgXCIgOiBpc0luZm8gPyBcIuKEuVwiIDogXCLinJNcIn1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1lc3NhZ2UgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHB0LTFcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGxlYWRpbmctc251Z1wiPlxuICAgICAgICAgICAge2l0ZW0ubWVzc2FnZX1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEaXNtaXNzIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEl0ZW0obnVsbCl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgdGV4dC14cyBwLTEgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIuC4m+C4tOC4lOC4geC4suC4o+C5geC4iOC5ieC4h+C5gOC4leC4t+C4reC4mVwiXG4gICAgICAgID5cbiAgICAgICAgICDinJVcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1RvYXN0LmpzeCJ9