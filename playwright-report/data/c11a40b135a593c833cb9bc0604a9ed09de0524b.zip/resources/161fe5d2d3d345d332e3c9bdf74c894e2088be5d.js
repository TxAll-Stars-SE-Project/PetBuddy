import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HomePage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useSearchParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import Navbar from "/src/components/Navbar.jsx";
import Pagination from "/src/components/Pagination.jsx";
import SitterCard, { SitterCardSkeleton } from "/src/components/SitterCard.jsx";
import SitterFilters from "/src/components/SitterFilters.jsx";
import { useDebouncedValue } from "/src/hooks/useDebouncedValue.js";
import { searchSitters } from "/src/services/sitters.js";
import { DEFAULT_FILTERS, getPriceError } from "/src/utils/sitterOptions.js";
const SKELETON_COUNT = 4;
export default function HomePage() {
  _s();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") ?? "";
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [resetKey, setResetKey] = useState(0);
  const [reloadKey, setReloadKey] = useState(0);
  const [result, setResult] = useState({ status: "loading", sitters: [], pagination: null });
  const resultsRef = useRef(null);
  const debouncedMin = useDebouncedValue(filters.min);
  const debouncedMax = useDebouncedValue(filters.max);
  const queryKey = JSON.stringify({ ...filters, q, min: debouncedMin, max: debouncedMax });
  const query = useMemo(() => JSON.parse(queryKey), [queryKey]);
  const [pageState, setPageState] = useState({ key: queryKey, page: 1 });
  const page = pageState.key === queryKey ? pageState.page : 1;
  const setPage = (p) => setPageState({ key: queryKey, page: p });
  const priceError = getPriceError(filters);
  useEffect(() => {
    if (priceError) return;
    const controller = new AbortController();
    setResult((r) => ({ ...r, status: "loading" }));
    searchSitters(query, page, { signal: controller.signal }).then(({ sitters: sitters2, pagination: pagination2 }) => setResult({ status: "success", sitters: sitters2, pagination: pagination2 })).catch(() => {
      if (controller.signal.aborted) return;
      setResult((r) => ({ ...r, status: "error" }));
    });
    return () => controller.abort();
  }, [query, page, priceError, reloadKey]);
  const updateFilters = (patch) => setFilters((f) => ({ ...f, ...patch }));
  const updateArea = (patch) => setFilters((f) => ({
    ...f,
    ..."province" in patch && { province: patch.province },
    ..."district" in patch && { district: patch.district }
  }));
  const clearKeyword = () => setSearchParams((prev) => {
    const next = new URLSearchParams(prev);
    next.delete("q");
    return next;
  });
  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
    setResetKey((k) => k + 1);
    clearKeyword();
  };
  const { status, sitters, pagination } = result;
  useEffect(() => {
    if (status === "success" && pagination && pagination.total > 0 && sitters.length === 0 && page > pagination.totalPages) {
      setPage(pagination.totalPages);
    }
  });
  const changePage = (p) => {
    setPage(p);
    resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const showSkeleton = status === "loading" && sitters.length === 0;
  let countText = "";
  if (status === "loading") countText = "กำลังโหลด…";
  else if (status === "success") countText = `${pagination?.total ?? sitters.length} คน`;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
      lineNumber: 111,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "home-main search-page", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "page-title", children: "ค้นหาพี่เลี้ยงสัตว์เลี้ยง" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "กรองตามพื้นที่ ประเภทสัตว์ ราคา และคะแนนรีวิว เพื่อหาพี่เลี้ยงที่เหมาะกับน้อง ๆ ของคุณ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      q && /* @__PURE__ */ jsxDEV("div", { className: "search-chip", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "ค้นหา: ",
          /* @__PURE__ */ jsxDEV("strong", { children: q }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
            lineNumber: 120,
            columnNumber: 26
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 120,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", "aria-label": "ล้างคำค้นหา", onClick: clearKeyword, children: "×" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 121,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        SitterFilters,
        {
          filters,
          priceError,
          resetKey,
          onChange: updateFilters,
          onAreaChange: updateArea,
          onReset: resetFilters
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 125,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "result-head", ref: resultsRef, children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "พี่เลี้ยงทั้งหมด" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "result-count", children: countText }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 136,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 134,
        columnNumber: 9
      }, this),
      showSkeleton && /* @__PURE__ */ jsxDEV("div", { className: "sitter-list", children: Array.from({ length: SKELETON_COUNT }, (_, i) => /* @__PURE__ */ jsxDEV(SitterCardSkeleton, {}, i, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 141,
        columnNumber: 63
      }, this)) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      status === "error" && /* @__PURE__ */ jsxDEV("div", { className: "state-box state-box--error", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emoji", children: "⚠️" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 147,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "โหลดรายชื่อพี่เลี้ยงไม่สำเร็จ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่อีกครั้ง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 149,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn", onClick: () => setReloadKey((k) => k + 1), children: "ลองใหม่" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 150,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      status === "success" && sitters.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "state-box", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emoji", children: "🔍" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 156,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "ไม่พบพี่เลี้ยงที่ตรงกับเงื่อนไข" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 157,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "ลองปรับตัวกรองหรือล้างตัวกรองเพื่อดูพี่เลี้ยงทั้งหมด" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn--ghost", onClick: resetFilters, children: "ล้างตัวกรอง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 159,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 155,
        columnNumber: 9
      }, this),
      sitters.length > 0 && status !== "error" && /* @__PURE__ */ jsxDEV("div", { className: `sitter-list${status === "loading" ? " is-loading" : ""}`, children: sitters.map(
        (s) => /* @__PURE__ */ jsxDEV(
          SitterCard,
          {
            sitter: s
          },
          s.sitterId,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
            lineNumber: 167,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
        lineNumber: 165,
        columnNumber: 9
      }, this),
      status !== "error" && pagination && /* @__PURE__ */ jsxDEV(
        Pagination,
        {
          page: pagination.page,
          totalPages: pagination.totalPages,
          disabled: status === "loading",
          onChange: changePage
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
          lineNumber: 176,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx",
    lineNumber: 110,
    columnNumber: 5
  }, this);
}
_s(HomePage, "RafiCtbgXK2XbmnUwXmfbGLpGNw=", false, function() {
  return [useNavigate, useSearchParams, useDebouncedValue, useDebouncedValue];
});
_c = HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/HomePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNGTixTQUFTQSxXQUFXQyxTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDckQsU0FBU0MsaUJBQWlCQyxtQkFBbUI7QUFDN0MsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsY0FBY0MsMEJBQTBCO0FBQy9DLE9BQU9DLG1CQUFtQjtBQUMxQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGlCQUFpQkMscUJBQXFCO0FBRS9DLE1BQU1DLGlCQUFpQjtBQUV2Qix3QkFBd0JDLFdBQVc7QUFBQUMsS0FBQTtBQUNqQyxRQUFNQyxXQUFXYixZQUFZO0FBRzdCLFFBQU0sQ0FBQ2MsY0FBY0MsZUFBZSxJQUFJaEIsZ0JBQWdCO0FBQ3hELFFBQU1pQixJQUFJRixhQUFhRyxJQUFJLEdBQUcsS0FBSztBQUNuQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSXJCLFNBQVNVLGVBQWU7QUFDdEQsUUFBTSxDQUFDWSxVQUFVQyxXQUFXLElBQUl2QixTQUFTLENBQUM7QUFDMUMsUUFBTSxDQUFDd0IsV0FBV0MsWUFBWSxJQUFJekIsU0FBUyxDQUFDO0FBQzVDLFFBQU0sQ0FBQzBCLFFBQVFDLFNBQVMsSUFBSTNCLFNBQVMsRUFBRTRCLFFBQVEsV0FBV0MsU0FBUyxJQUFJQyxZQUFZLEtBQUssQ0FBQztBQUN6RixRQUFNQyxhQUFhaEMsT0FBTyxJQUFJO0FBRzlCLFFBQU1pQyxlQUFleEIsa0JBQWtCWSxRQUFRYSxHQUFHO0FBQ2xELFFBQU1DLGVBQWUxQixrQkFBa0JZLFFBQVFlLEdBQUc7QUFDbEQsUUFBTUMsV0FBV0MsS0FBS0MsVUFBVSxFQUFFLEdBQUdsQixTQUFTRixHQUFHZSxLQUFLRCxjQUFjRyxLQUFLRCxhQUFhLENBQUM7QUFFdkYsUUFBTUssUUFBUXpDLFFBQVEsTUFBTXVDLEtBQUtHLE1BQU1KLFFBQVEsR0FBRyxDQUFDQSxRQUFRLENBQUM7QUFFNUQsUUFBTSxDQUFDSyxXQUFXQyxZQUFZLElBQUkxQyxTQUFTLEVBQUUyQyxLQUFLUCxVQUFVUSxNQUFNLEVBQUUsQ0FBQztBQUNyRSxRQUFNQSxPQUFPSCxVQUFVRSxRQUFRUCxXQUFXSyxVQUFVRyxPQUFPO0FBQzNELFFBQU1DLFVBQVVBLENBQUNDLE1BQU1KLGFBQWEsRUFBRUMsS0FBS1AsVUFBVVEsTUFBTUUsRUFBRSxDQUFDO0FBRTlELFFBQU1DLGFBQWFwQyxjQUFjUyxPQUFPO0FBRXhDdkIsWUFBVSxNQUFNO0FBQ2QsUUFBSWtELFdBQVk7QUFDaEIsVUFBTUMsYUFBYSxJQUFJQyxnQkFBZ0I7QUFDdkN0QixjQUFVLENBQUN1QixPQUFPLEVBQUUsR0FBR0EsR0FBR3RCLFFBQVEsVUFBVSxFQUFFO0FBQzlDbkIsa0JBQWM4QixPQUFPSyxNQUFNLEVBQUVPLFFBQVFILFdBQVdHLE9BQU8sQ0FBQyxFQUNyREMsS0FBSyxDQUFDLEVBQUV2QixtQkFBU0Msd0JBQVcsTUFBTUgsVUFBVSxFQUFFQyxRQUFRLFdBQVdDLG1CQUFTQyx3QkFBVyxDQUFDLENBQUMsRUFDdkZ1QixNQUFNLE1BQU07QUFDWCxVQUFJTCxXQUFXRyxPQUFPRyxRQUFTO0FBQy9CM0IsZ0JBQVUsQ0FBQ3VCLE9BQU8sRUFBRSxHQUFHQSxHQUFHdEIsUUFBUSxRQUFRLEVBQUU7QUFBQSxJQUM5QyxDQUFDO0FBQ0gsV0FBTyxNQUFNb0IsV0FBV08sTUFBTTtBQUFBLEVBQ2hDLEdBQUcsQ0FBQ2hCLE9BQU9LLE1BQU1HLFlBQVl2QixTQUFTLENBQUM7QUFFdkMsUUFBTWdDLGdCQUFnQkEsQ0FBQ0MsVUFBVXBDLFdBQVcsQ0FBQ3FDLE9BQU8sRUFBRSxHQUFHQSxHQUFHLEdBQUdELE1BQU0sRUFBRTtBQUV2RSxRQUFNRSxhQUFhQSxDQUFDRixVQUNsQnBDLFdBQVcsQ0FBQ3FDLE9BQU87QUFBQSxJQUNqQixHQUFHQTtBQUFBQSxJQUNILEdBQUksY0FBY0QsU0FBUyxFQUFFRyxVQUFVSCxNQUFNRyxTQUFTO0FBQUEsSUFDdEQsR0FBSSxjQUFjSCxTQUFTLEVBQUVJLFVBQVVKLE1BQU1JLFNBQVM7QUFBQSxFQUN4RCxFQUFFO0FBQ0osUUFBTUMsZUFBZUEsTUFDbkI3QyxnQkFBZ0IsQ0FBQzhDLFNBQVM7QUFDeEIsVUFBTUMsT0FBTyxJQUFJQyxnQkFBZ0JGLElBQUk7QUFDckNDLFNBQUtFLE9BQU8sR0FBRztBQUNmLFdBQU9GO0FBQUFBLEVBQ1QsQ0FBQztBQUNILFFBQU1HLGVBQWVBLE1BQU07QUFDekI5QyxlQUFXWCxlQUFlO0FBQzFCYSxnQkFBWSxDQUFDNkMsTUFBTUEsSUFBSSxDQUFDO0FBQ3hCTixpQkFBYTtBQUFBLEVBQ2Y7QUFFQSxRQUFNLEVBQUVsQyxRQUFRQyxTQUFTQyxXQUFXLElBQUlKO0FBR3hDN0IsWUFBVSxNQUFNO0FBQ2QsUUFBSStCLFdBQVcsYUFBYUUsY0FBY0EsV0FBV3VDLFFBQVEsS0FBS3hDLFFBQVF5QyxXQUFXLEtBQUsxQixPQUFPZCxXQUFXeUMsWUFBWTtBQUN0SDFCLGNBQVFmLFdBQVd5QyxVQUFVO0FBQUEsSUFDL0I7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNQyxhQUFhQSxDQUFDMUIsTUFBTTtBQUN4QkQsWUFBUUMsQ0FBQztBQUNUZixlQUFXMEMsU0FBU0MsZUFBZSxFQUFFQyxVQUFVLFVBQVVDLE9BQU8sUUFBUSxDQUFDO0FBQUEsRUFDM0U7QUFDQSxRQUFNQyxlQUFlakQsV0FBVyxhQUFhQyxRQUFReUMsV0FBVztBQUVoRSxNQUFJUSxZQUFZO0FBQ2hCLE1BQUlsRCxXQUFXLFVBQVdrRCxhQUFZO0FBQUEsV0FDN0JsRCxXQUFXLFVBQVdrRCxhQUFZLEdBQUdoRCxZQUFZdUMsU0FBU3hDLFFBQVF5QyxNQUFNO0FBRWpGLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxVQUFLLFdBQVUseUJBQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUsY0FBYSx5Q0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRDtBQUFBLE1BQ3BELHVCQUFDLE9BQUUsV0FBVSxlQUFhLHNHQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVDcEQsS0FDQyx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFVBQUs7QUFBQTtBQUFBLFVBQU8sdUJBQUMsWUFBUUEsZUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFlBQU8sTUFBSyxVQUFTLGNBQVcsZUFBYyxTQUFTNEMsY0FBYyxpQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFdBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLFVBQVVOO0FBQUFBLFVBQ1YsY0FBY0c7QUFBQUEsVUFDZCxTQUFTUTtBQUFBQTtBQUFBQSxRQU5YO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU13QjtBQUFBLE1BR3hCLHVCQUFDLFNBQUksV0FBVSxlQUFjLEtBQUtwQyxZQUNoQztBQUFBLCtCQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQ3BCLHVCQUFDLFVBQUssV0FBVSxnQkFBZ0IrQyx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFdBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUNELGdCQUNDLHVCQUFDLFNBQUksV0FBVSxlQUNaRSxnQkFBTUMsS0FBSyxFQUFFVixRQUFRMUQsZUFBZSxHQUFHLENBQUNxRSxHQUFHQyxNQUFNLHVCQUFDLHdCQUF3QkEsR0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQixDQUFHLEtBRGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0R0RCxXQUFXLFdBQ1YsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFNBQVEsa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUN6Qix1QkFBQyxRQUFHLDZDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUNqQyx1QkFBQyxPQUFFLGlFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxRQUNwRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLE9BQU0sU0FBUyxNQUFNSCxhQUFhLENBQUMyQyxNQUFNQSxJQUFJLENBQUMsR0FBRyx1QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFdBSjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BR0R4QyxXQUFXLGFBQWFDLFFBQVF5QyxXQUFXLEtBQzFDLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFNBQVEsa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUN6Qix1QkFBQyxRQUFHLCtDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUNuQyx1QkFBQyxPQUFFLG9FQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQ7QUFBQSxRQUN2RCx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGtCQUFpQixTQUFTSCxjQUFjLDJCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FKckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFJRHRDLFFBQVF5QyxTQUFTLEtBQUsxQyxXQUFXLFdBQ2hDLHVCQUFDLFNBQUksV0FBVyxjQUFjQSxXQUFXLFlBQVksZ0JBQWdCLEVBQUUsSUFDcEVDLGtCQUFRc0Q7QUFBQUEsUUFBSSxDQUFDQyxNQUNaO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxRQUFRQTtBQUFBQTtBQUFBQSxVQURIQSxFQUFFQztBQUFBQSxVQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFWTtBQUFBLE1BRWIsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdEekQsV0FBVyxXQUFXRSxjQUNyQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTUEsV0FBV2M7QUFBQUEsVUFDakIsWUFBWWQsV0FBV3lDO0FBQUFBLFVBQ3ZCLFVBQVUzQyxXQUFXO0FBQUEsVUFDckIsVUFBVTRDO0FBQUFBO0FBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXVCO0FBQUEsU0FwRTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RUE7QUFBQSxPQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEVBO0FBRUo7QUFBQzFELEdBMUp1QkQsVUFBUTtBQUFBLFVBQ2JYLGFBR3VCRCxpQkFTbkJPLG1CQUNBQSxpQkFBaUI7QUFBQTtBQUFBLEtBZGhCSztBQUFRLElBQUF5RTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlU3RhdGUiLCJ1c2VTZWFyY2hQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsIk5hdmJhciIsIlBhZ2luYXRpb24iLCJTaXR0ZXJDYXJkIiwiU2l0dGVyQ2FyZFNrZWxldG9uIiwiU2l0dGVyRmlsdGVycyIsInVzZURlYm91bmNlZFZhbHVlIiwic2VhcmNoU2l0dGVycyIsIkRFRkFVTFRfRklMVEVSUyIsImdldFByaWNlRXJyb3IiLCJTS0VMRVRPTl9DT1VOVCIsIkhvbWVQYWdlIiwiX3MiLCJuYXZpZ2F0ZSIsInNlYXJjaFBhcmFtcyIsInNldFNlYXJjaFBhcmFtcyIsInEiLCJnZXQiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsInJlc2V0S2V5Iiwic2V0UmVzZXRLZXkiLCJyZWxvYWRLZXkiLCJzZXRSZWxvYWRLZXkiLCJyZXN1bHQiLCJzZXRSZXN1bHQiLCJzdGF0dXMiLCJzaXR0ZXJzIiwicGFnaW5hdGlvbiIsInJlc3VsdHNSZWYiLCJkZWJvdW5jZWRNaW4iLCJtaW4iLCJkZWJvdW5jZWRNYXgiLCJtYXgiLCJxdWVyeUtleSIsIkpTT04iLCJzdHJpbmdpZnkiLCJxdWVyeSIsInBhcnNlIiwicGFnZVN0YXRlIiwic2V0UGFnZVN0YXRlIiwia2V5IiwicGFnZSIsInNldFBhZ2UiLCJwIiwicHJpY2VFcnJvciIsImNvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJyIiwic2lnbmFsIiwidGhlbiIsImNhdGNoIiwiYWJvcnRlZCIsImFib3J0IiwidXBkYXRlRmlsdGVycyIsInBhdGNoIiwiZiIsInVwZGF0ZUFyZWEiLCJwcm92aW5jZSIsImRpc3RyaWN0IiwiY2xlYXJLZXl3b3JkIiwicHJldiIsIm5leHQiLCJVUkxTZWFyY2hQYXJhbXMiLCJkZWxldGUiLCJyZXNldEZpbHRlcnMiLCJrIiwidG90YWwiLCJsZW5ndGgiLCJ0b3RhbFBhZ2VzIiwiY2hhbmdlUGFnZSIsImN1cnJlbnQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiYmxvY2siLCJzaG93U2tlbGV0b24iLCJjb3VudFRleHQiLCJBcnJheSIsImZyb20iLCJfIiwiaSIsIm1hcCIsInMiLCJzaXR0ZXJJZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkhvbWVQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVNlYXJjaFBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9OYXZiYXIuanN4XCI7XG5pbXBvcnQgUGFnaW5hdGlvbiBmcm9tIFwiLi4vY29tcG9uZW50cy9QYWdpbmF0aW9uLmpzeFwiO1xuaW1wb3J0IFNpdHRlckNhcmQsIHsgU2l0dGVyQ2FyZFNrZWxldG9uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvU2l0dGVyQ2FyZC5qc3hcIjtcbmltcG9ydCBTaXR0ZXJGaWx0ZXJzIGZyb20gXCIuLi9jb21wb25lbnRzL1NpdHRlckZpbHRlcnMuanN4XCI7XG5pbXBvcnQgeyB1c2VEZWJvdW5jZWRWYWx1ZSB9IGZyb20gXCIuLi9ob29rcy91c2VEZWJvdW5jZWRWYWx1ZS5qc1wiO1xuaW1wb3J0IHsgc2VhcmNoU2l0dGVycyB9IGZyb20gXCIuLi9zZXJ2aWNlcy9zaXR0ZXJzLmpzXCI7XG5pbXBvcnQgeyBERUZBVUxUX0ZJTFRFUlMsIGdldFByaWNlRXJyb3IgfSBmcm9tIFwiLi4vdXRpbHMvc2l0dGVyT3B0aW9ucy5qc1wiO1xuXG5jb25zdCBTS0VMRVRPTl9DT1VOVCA9IDQ7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWVQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgLy8g4LiE4Liz4LiE4LmJ4LiZ4Lir4Liy4LiI4Liy4LiBIE5hdmJhciDguK3guKLguLnguYjguYPguJkgVVJMICg/cT0pIOC5gOC4nuC4t+C5iOC4reC5g+C4q+C5ieC5g+C4iuC5ieC5hOC4lOC5ieC4iOC4suC4geC4l+C4uOC4geC4q+C4meC5ieC4siDguKPguLXguYDguJ/guKPguIrguYHguKXguYnguKfguYTguKHguYjguKvguLLguKIg4LmB4Lil4Liw4LmB4LiK4Lij4LmM4Lil4Li04LiH4LiB4LmM4LmE4LiU4LmJXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgY29uc3QgcSA9IHNlYXJjaFBhcmFtcy5nZXQoXCJxXCIpID8/IFwiXCI7XG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKERFRkFVTFRfRklMVEVSUyk7XG4gIGNvbnN0IFtyZXNldEtleSwgc2V0UmVzZXRLZXldID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtyZWxvYWRLZXksIHNldFJlbG9hZEtleV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Jlc3VsdCwgc2V0UmVzdWx0XSA9IHVzZVN0YXRlKHsgc3RhdHVzOiBcImxvYWRpbmdcIiwgc2l0dGVyczogW10sIHBhZ2luYXRpb246IG51bGwgfSk7XG4gIGNvbnN0IHJlc3VsdHNSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgLy8g4LiK4LmI4Lit4LiH4Lij4Liy4LiE4Liy4Lie4Li04Lih4Lie4LmM4LiX4Li14Lil4Liw4LiV4Lix4Lin4Lit4Lix4LiB4Lip4LijIOKGkiDguKvguJnguYjguKfguIfguIHguYjguK3guJnguKLguLTguIcgQVBJOyDguJXguLHguKfguIHguKPguK3guIfguK3guLfguYjguJnguIHguJTguYHguKXguYnguKfguKLguLTguIfguJfguLHguJnguJfguLVcbiAgY29uc3QgZGVib3VuY2VkTWluID0gdXNlRGVib3VuY2VkVmFsdWUoZmlsdGVycy5taW4pO1xuICBjb25zdCBkZWJvdW5jZWRNYXggPSB1c2VEZWJvdW5jZWRWYWx1ZShmaWx0ZXJzLm1heCk7XG4gIGNvbnN0IHF1ZXJ5S2V5ID0gSlNPTi5zdHJpbmdpZnkoeyAuLi5maWx0ZXJzLCBxLCBtaW46IGRlYm91bmNlZE1pbiwgbWF4OiBkZWJvdW5jZWRNYXggfSk7XG4gIC8vIG9iamVjdCDguYDguJTguLTguKHguJXguKPguLLguJrguYPguJTguJfguLXguYjguITguYjguLLguYDguJfguYjguLLguYDguJTguLTguKEg4oaSIGVmZmVjdCDguYTguKHguYjguKPguLHguJnguIvguYnguLPguJfguLjguIHguITguKPguLHguYnguIfguJfguLXguYjguJ7guLTguKHguJ7guYzguIrguYjguK3guIfguKPguLLguITguLIgKOC4geC5iOC4reC4mSBkZWJvdW5jZSDguYDguKrguKPguYfguIgpXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlTWVtbygoKSA9PiBKU09OLnBhcnNlKHF1ZXJ5S2V5KSwgW3F1ZXJ5S2V5XSk7XG4gIC8vIOC4q+C4meC5ieC4suC4m+C4seC4iOC4iOC4uOC4muC4seC4meC4nOC4ueC4geC4geC4seC4muC4iuC4uOC4lOC4leC4seC4p+C4geC4o+C4reC4hzog4LiV4Lix4Lin4LiB4Lij4Lit4LiHL+C4hOC4s+C4hOC5ieC4meC5gOC4m+C4peC4teC5iOC4ouC4meC5gOC4oeC4t+C5iOC4reC5hOC4q+C4o+C5iOC4geC5h+C4geC4peC4seC4muC5hOC4m+C4q+C4meC5ieC4siAxIOC4reC4seC4leC5guC4meC4oeC4seC4leC4tFxuICBjb25zdCBbcGFnZVN0YXRlLCBzZXRQYWdlU3RhdGVdID0gdXNlU3RhdGUoeyBrZXk6IHF1ZXJ5S2V5LCBwYWdlOiAxIH0pO1xuICBjb25zdCBwYWdlID0gcGFnZVN0YXRlLmtleSA9PT0gcXVlcnlLZXkgPyBwYWdlU3RhdGUucGFnZSA6IDE7XG4gIGNvbnN0IHNldFBhZ2UgPSAocCkgPT4gc2V0UGFnZVN0YXRlKHsga2V5OiBxdWVyeUtleSwgcGFnZTogcCB9KTtcbiAgLy8g4LiV4Lij4Lin4LiI4LiI4Liy4LiB4LiE4LmI4Liy4LiX4Li14LmI4Lie4Li04Lih4Lie4LmM4Lit4Lii4Li54LmIICjguYTguKHguYggZGVib3VuY2UpIOC5gOC4nuC4t+C5iOC4reC5geC4iOC5ieC4h+C4nOC4ueC5ieC5g+C4iuC5ieC4l+C4seC4meC4l+C4tSDguYHguKXguLDguYTguKHguYjguKLguLTguIcgcmVxdWVzdCDguJfguLXguYjguIjguLDguYLguJTguJkgNDAwXG4gIGNvbnN0IHByaWNlRXJyb3IgPSBnZXRQcmljZUVycm9yKGZpbHRlcnMpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHByaWNlRXJyb3IpIHJldHVybjtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIHNldFJlc3VsdCgocikgPT4gKHsgLi4uciwgc3RhdHVzOiBcImxvYWRpbmdcIiB9KSk7XG4gICAgc2VhcmNoU2l0dGVycyhxdWVyeSwgcGFnZSwgeyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIH0pXG4gICAgICAudGhlbigoeyBzaXR0ZXJzLCBwYWdpbmF0aW9uIH0pID0+IHNldFJlc3VsdCh7IHN0YXR1czogXCJzdWNjZXNzXCIsIHNpdHRlcnMsIHBhZ2luYXRpb24gfSkpXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBpZiAoY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgcmV0dXJuOyAvLyByZXF1ZXN0IOC5gOC4geC5iOC4suC4luC4ueC4geC4ouC4geC5gOC4peC4tOC4geC5gOC4nuC4o+C4suC4sOC4leC4seC4p+C4geC4o+C4reC4h+C5gOC4m+C4peC4teC5iOC4ouC4mVxuICAgICAgICBzZXRSZXN1bHQoKHIpID0+ICh7IC4uLnIsIHN0YXR1czogXCJlcnJvclwiIH0pKTtcbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiBjb250cm9sbGVyLmFib3J0KCk7XG4gIH0sIFtxdWVyeSwgcGFnZSwgcHJpY2VFcnJvciwgcmVsb2FkS2V5XSk7XG5cbiAgY29uc3QgdXBkYXRlRmlsdGVycyA9IChwYXRjaCkgPT4gc2V0RmlsdGVycygoZikgPT4gKHsgLi4uZiwgLi4ucGF0Y2ggfSkpO1xuICAvLyBUaGFpQWRkcmVzc1NlbGVjdHMg4Liq4LmI4LiHIHBhdGNoIOC4l+C4teC5iOC4oeC4tSBwcm92aW5jZS9kaXN0cmljdCAoKyDguJXguLPguJrguKUg4LiL4Li24LmI4LiH4LiV4Lix4Lin4LiB4Lij4Lit4LiH4LmE4Lih4LmI4LmD4LiK4LmJKSDihpIg4LmA4LiB4LmH4Lia4LmA4LiJ4Lie4Liy4Liw4LiX4Li14LmI4LmD4LiK4LmJXG4gIGNvbnN0IHVwZGF0ZUFyZWEgPSAocGF0Y2gpID0+XG4gICAgc2V0RmlsdGVycygoZikgPT4gKHtcbiAgICAgIC4uLmYsXG4gICAgICAuLi4oXCJwcm92aW5jZVwiIGluIHBhdGNoICYmIHsgcHJvdmluY2U6IHBhdGNoLnByb3ZpbmNlIH0pLFxuICAgICAgLi4uKFwiZGlzdHJpY3RcIiBpbiBwYXRjaCAmJiB7IGRpc3RyaWN0OiBwYXRjaC5kaXN0cmljdCB9KSxcbiAgICB9KSk7XG4gIGNvbnN0IGNsZWFyS2V5d29yZCA9ICgpID0+XG4gICAgc2V0U2VhcmNoUGFyYW1zKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwcmV2KTtcbiAgICAgIG5leHQuZGVsZXRlKFwicVwiKTtcbiAgICAgIHJldHVybiBuZXh0O1xuICAgIH0pO1xuICBjb25zdCByZXNldEZpbHRlcnMgPSAoKSA9PiB7XG4gICAgc2V0RmlsdGVycyhERUZBVUxUX0ZJTFRFUlMpO1xuICAgIHNldFJlc2V0S2V5KChrKSA9PiBrICsgMSk7XG4gICAgY2xlYXJLZXl3b3JkKCk7XG4gIH07XG5cbiAgY29uc3QgeyBzdGF0dXMsIHNpdHRlcnMsIHBhZ2luYXRpb24gfSA9IHJlc3VsdDtcblxuICAvLyDguJzguKXguKXguLHguJ7guJjguYzguKXguJTguKXguIfguIjguJnguKvguJnguYnguLLguJfguLXguYjguYDguJvguLTguJTguK3guKLguLnguYjguYDguIHguLTguJnguIjguLPguJnguKfguJnguKvguJnguYnguLIgKOC5gOC4iuC5iOC4mSBzaXR0ZXIg4LiW4Li54LiB4Lib4Li04LiU4Lia4Lix4LiN4LiK4Li1KSDihpIg4Lii4LmJ4Lit4LiZ4LmE4Lib4Lir4LiZ4LmJ4Liy4Liq4Li44LiU4LiX4LmJ4Liy4LiiXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIgJiYgcGFnaW5hdGlvbiAmJiBwYWdpbmF0aW9uLnRvdGFsID4gMCAmJiBzaXR0ZXJzLmxlbmd0aCA9PT0gMCAmJiBwYWdlID4gcGFnaW5hdGlvbi50b3RhbFBhZ2VzKSB7XG4gICAgICBzZXRQYWdlKHBhZ2luYXRpb24udG90YWxQYWdlcyk7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBjaGFuZ2VQYWdlID0gKHApID0+IHtcbiAgICBzZXRQYWdlKHApO1xuICAgIHJlc3VsdHNSZWYuY3VycmVudD8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiwgYmxvY2s6IFwic3RhcnRcIiB9KTtcbiAgfTtcbiAgY29uc3Qgc2hvd1NrZWxldG9uID0gc3RhdHVzID09PSBcImxvYWRpbmdcIiAmJiBzaXR0ZXJzLmxlbmd0aCA9PT0gMDtcblxuICBsZXQgY291bnRUZXh0ID0gXCJcIjtcbiAgaWYgKHN0YXR1cyA9PT0gXCJsb2FkaW5nXCIpIGNvdW50VGV4dCA9IFwi4LiB4Liz4Lil4Lix4LiH4LmC4Lir4Lil4LiU4oCmXCI7XG4gIGVsc2UgaWYgKHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIGNvdW50VGV4dCA9IGAke3BhZ2luYXRpb24/LnRvdGFsID8/IHNpdHRlcnMubGVuZ3RofSDguITguJlgO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxOYXZiYXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImhvbWUtbWFpbiBzZWFyY2gtcGFnZVwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPuC4hOC5ieC4meC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hzwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tc3ViXCI+XG4gICAgICAgICAg4LiB4Lij4Lit4LiH4LiV4Liy4Lih4Lie4Li34LmJ4LiZ4LiX4Li14LmIIOC4m+C4o+C4sOC5gOC4oOC4l+C4quC4seC4leC4p+C5jCDguKPguLLguITguLIg4LmB4Lil4Liw4LiE4Liw4LmB4LiZ4LiZ4Lij4Li14Lin4Li04LinIOC5gOC4nuC4t+C5iOC4reC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C4teC5iOC5gOC4q+C4oeC4suC4sOC4geC4seC4muC4meC5ieC4reC4hyDguYYg4LiC4Lit4LiH4LiE4Li44LiTXG4gICAgICAgIDwvcD5cblxuICAgICAgICB7cSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2gtY2hpcFwiPlxuICAgICAgICAgICAgPHNwYW4+4LiE4LmJ4LiZ4Lir4LiyOiA8c3Ryb25nPntxfTwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9XCLguKXguYnguLLguIfguITguLPguITguYnguJnguKvguLJcIiBvbkNsaWNrPXtjbGVhcktleXdvcmR9PsOXPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPFNpdHRlckZpbHRlcnNcbiAgICAgICAgICBmaWx0ZXJzPXtmaWx0ZXJzfVxuICAgICAgICAgIHByaWNlRXJyb3I9e3ByaWNlRXJyb3J9XG4gICAgICAgICAgcmVzZXRLZXk9e3Jlc2V0S2V5fVxuICAgICAgICAgIG9uQ2hhbmdlPXt1cGRhdGVGaWx0ZXJzfVxuICAgICAgICAgIG9uQXJlYUNoYW5nZT17dXBkYXRlQXJlYX1cbiAgICAgICAgICBvblJlc2V0PXtyZXNldEZpbHRlcnN9XG4gICAgICAgIC8+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXN1bHQtaGVhZFwiIHJlZj17cmVzdWx0c1JlZn0+XG4gICAgICAgICAgPGgyPuC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C4seC5ieC4h+C4q+C4oeC4lDwvaDI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVzdWx0LWNvdW50XCI+e2NvdW50VGV4dH08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtzaG93U2tlbGV0b24gJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLWxpc3RcIj5cbiAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiBTS0VMRVRPTl9DT1VOVCB9LCAoXywgaSkgPT4gPFNpdHRlckNhcmRTa2VsZXRvbiBrZXk9e2l9IC8+KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7c3RhdHVzID09PSBcImVycm9yXCIgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdGUtYm94IHN0YXRlLWJveC0tZXJyb3JcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1vamlcIj7imqDvuI88L2Rpdj5cbiAgICAgICAgICAgIDxoMz7guYLguKvguKXguJTguKPguLLguKLguIrguLfguYjguK3guJ7guLXguYjguYDguKXguLXguYnguKLguIfguYTguKHguYjguKrguLPguYDguKPguYfguIg8L2gzPlxuICAgICAgICAgICAgPHA+4LmA4LiB4Li04LiU4LiC4LmJ4Lit4Lic4Li04LiU4Lie4Lil4Liy4LiU4LmD4LiZ4LiB4Liy4Lij4LmA4LiK4Li34LmI4Lit4Lih4LiV4LmI4LitIOC4geC4o+C4uOC4k+C4suC4peC4reC4h+C5g+C4q+C4oeC5iOC4reC4teC4geC4hOC4o+C4seC5ieC4hzwvcD5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0blwiIG9uQ2xpY2s9eygpID0+IHNldFJlbG9hZEtleSgoaykgPT4gayArIDEpfT7guKXguK3guIfguYPguKvguKHguYg8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7c3RhdHVzID09PSBcInN1Y2Nlc3NcIiAmJiBzaXR0ZXJzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0ZS1ib3hcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1vamlcIj7wn5SNPC9kaXY+XG4gICAgICAgICAgICA8aDM+4LmE4Lih4LmI4Lie4Lia4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4LiV4Lij4LiH4LiB4Lix4Lia4LmA4LiH4Li34LmI4Lit4LiZ4LmE4LiCPC9oMz5cbiAgICAgICAgICAgIDxwPuC4peC4reC4h+C4m+C4o+C4seC4muC4leC4seC4p+C4geC4o+C4reC4h+C4q+C4o+C4t+C4reC4peC5ieC4suC4h+C4leC4seC4p+C4geC4o+C4reC4h+C5gOC4nuC4t+C5iOC4reC4lOC4ueC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C4seC5ieC4h+C4q+C4oeC4lDwvcD5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0biBidG4tLWdob3N0XCIgb25DbGljaz17cmVzZXRGaWx0ZXJzfT7guKXguYnguLLguIfguJXguLHguKfguIHguKPguK3guIc8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7Lyog4Lij4Liw4Lir4Lin4LmI4Liy4LiH4LmC4Lir4Lil4LiU4LmD4Lir4Lih4LmI4Lii4Lix4LiH4LmB4Liq4LiU4LiH4Lic4Lil4Lil4Lix4Lie4LiY4LmM4LmA4LiU4Li04Lih4LmB4Lia4Lia4LiI4Liy4LiHIOC5hiDguYHguJfguJnguIHguLLguKPguIHguKPguLDguJ7guKPguLTguJrguYDguJvguYfguJkgc2tlbGV0b24gKi99XG4gICAgICAgIHtzaXR0ZXJzLmxlbmd0aCA+IDAgJiYgc3RhdHVzICE9PSBcImVycm9yXCIgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc2l0dGVyLWxpc3Qke3N0YXR1cyA9PT0gXCJsb2FkaW5nXCIgPyBcIiBpcy1sb2FkaW5nXCIgOiBcIlwifWB9PlxuICAgICAgICAgICAge3NpdHRlcnMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICAgIDxTaXR0ZXJDYXJkXG4gICAgICAgICAgICAgICAga2V5PXtzLnNpdHRlcklkfVxuICAgICAgICAgICAgICAgIHNpdHRlcj17c31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHtzdGF0dXMgIT09IFwiZXJyb3JcIiAmJiBwYWdpbmF0aW9uICYmIChcbiAgICAgICAgICA8UGFnaW5hdGlvblxuICAgICAgICAgICAgcGFnZT17cGFnaW5hdGlvbi5wYWdlfVxuICAgICAgICAgICAgdG90YWxQYWdlcz17cGFnaW5hdGlvbi50b3RhbFBhZ2VzfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e3N0YXR1cyA9PT0gXCJsb2FkaW5nXCJ9XG4gICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlUGFnZX1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9Ib21lUGFnZS5qc3gifQ==