import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/careReport/CareReportTimeline.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import "/src/components/careReport/careReport.css";
function toDayKey(iso) {
  return new Date(iso).toDateString();
}
function formatDayLabel(iso) {
  const date = new Date(iso);
  const today = /* @__PURE__ */ new Date();
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return "วันนี้";
  if (date.toDateString() === yesterday.toDateString()) return "เมื่อวาน";
  return date.toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "short", year: "numeric" });
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
}
function groupByDay(reports) {
  const sorted = [...reports].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const groups = [];
  for (const report of sorted) {
    const key = toDayKey(report.createdAt);
    const last = groups[groups.length - 1];
    if (last && last.key === key) last.items.push(report);
    else
      groups.push({ key, label: formatDayLabel(report.createdAt), items: [report] });
  }
  return groups;
}
export default function CareReportTimeline({ reports }) {
  _s();
  const [lightbox, setLightbox] = useState(null);
  useEffect(() => {
    if (!lightbox) return void 0;
    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.stopImmediatePropagation();
        setLightbox(null);
      }
    };
    window.addEventListener("keydown", handleKey, true);
    return () => window.removeEventListener("keydown", handleKey, true);
  }, [lightbox]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("ol", { className: "care-timeline", children: groupByDay(reports).map(
      (group) => /* @__PURE__ */ jsxDEV("li", { className: "care-timeline-day", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "care-timeline-day-label", children: group.label }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
          lineNumber: 76,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("ol", { className: "care-timeline-items", children: group.items.map(
          (r) => /* @__PURE__ */ jsxDEV("li", { className: "care-timeline-item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "care-timeline-dot", "aria-hidden": "true" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
              lineNumber: 80,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("time", { className: "care-timeline-time", dateTime: r.createdAt, children: [
              formatTime(r.createdAt),
              " น."
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
              lineNumber: 81,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "care-timeline-detail", children: r.reportDetail }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
              lineNumber: 84,
              columnNumber: 19
            }, this),
            r.photoUrl && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "care-timeline-photo",
                onClick: () => setLightbox(r),
                "aria-label": "ดูรูปขนาดเต็ม",
                children: /* @__PURE__ */ jsxDEV("img", { src: r.photoUrl, alt: `รูปกิจกรรม ${formatTime(r.createdAt)} น.`, loading: "lazy" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
                  lineNumber: 92,
                  columnNumber: 23
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
                lineNumber: 86,
                columnNumber: 15
              },
              this
            )
          ] }, r.reportId, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
            lineNumber: 79,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
          lineNumber: 77,
          columnNumber: 13
        }, this)
      ] }, group.key, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    lightbox && /* @__PURE__ */ jsxDEV("div", { className: "care-lightbox", onClick: () => setLightbox(null), role: "dialog", "aria-label": "รูปกิจกรรม", children: [
      /* @__PURE__ */ jsxDEV("img", { src: lightbox.photoUrl, alt: lightbox.reportDetail, onClick: (e) => e.stopPropagation() }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "care-lightbox-caption", children: [
        formatDayLabel(lightbox.createdAt),
        " · ",
        formatTime(lightbox.createdAt),
        " น."
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
        lineNumber: 105,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", className: "care-lightbox-close", "aria-label": "ปิด", children: "✕" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
        lineNumber: 108,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(CareReportTimeline, "wlcERxL/CG8w0f0bEPMDWgkVO2s=");
_c = CareReportTimeline;
var _c;
$RefreshReg$(_c, "CareReportTimeline");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportTimeline.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RJLG1CQUlRLGNBSlI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcERKLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPO0FBRVAsU0FBU0MsU0FBU0MsS0FBSztBQUNyQixTQUFPLElBQUlDLEtBQUtELEdBQUcsRUFBRUUsYUFBYTtBQUNwQztBQUVBLFNBQVNDLGVBQWVILEtBQUs7QUFDM0IsUUFBTUksT0FBTyxJQUFJSCxLQUFLRCxHQUFHO0FBQ3pCLFFBQU1LLFFBQVEsb0JBQUlKLEtBQUs7QUFDdkIsUUFBTUssWUFBWSxvQkFBSUwsS0FBSztBQUMzQkssWUFBVUMsUUFBUUYsTUFBTUcsUUFBUSxJQUFJLENBQUM7QUFDckMsTUFBSUosS0FBS0YsYUFBYSxNQUFNRyxNQUFNSCxhQUFhLEVBQUcsUUFBTztBQUN6RCxNQUFJRSxLQUFLRixhQUFhLE1BQU1JLFVBQVVKLGFBQWEsRUFBRyxRQUFPO0FBQzdELFNBQU9FLEtBQUtLLG1CQUFtQixTQUFTLEVBQUVDLFNBQVMsUUFBUUMsS0FBSyxXQUFXQyxPQUFPLFNBQVNDLE1BQU0sVUFBVSxDQUFDO0FBQzlHO0FBRUEsU0FBU0MsV0FBV2QsS0FBSztBQUN2QixTQUFPLElBQUlDLEtBQUtELEdBQUcsRUFBRWUsbUJBQW1CLFNBQVMsRUFBRUMsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQztBQUN6RjtBQUdBLFNBQVNDLFdBQVdDLFNBQVM7QUFDM0IsUUFBTUMsU0FBUyxDQUFDLEdBQUdELE9BQU8sRUFBRUUsS0FBSyxDQUFDQyxHQUFHQyxNQUFNLElBQUl0QixLQUFLc0IsRUFBRUMsU0FBUyxJQUFJLElBQUl2QixLQUFLcUIsRUFBRUUsU0FBUyxDQUFDO0FBQ3hGLFFBQU1DLFNBQVM7QUFDZixhQUFXQyxVQUFVTixRQUFRO0FBQzNCLFVBQU1PLE1BQU01QixTQUFTMkIsT0FBT0YsU0FBUztBQUNyQyxVQUFNSSxPQUFPSCxPQUFPQSxPQUFPSSxTQUFTLENBQUM7QUFDckMsUUFBSUQsUUFBUUEsS0FBS0QsUUFBUUEsSUFBS0MsTUFBS0UsTUFBTUMsS0FBS0wsTUFBTTtBQUFBO0FBQy9DRCxhQUFPTSxLQUFLLEVBQUVKLEtBQUtLLE9BQU83QixlQUFldUIsT0FBT0YsU0FBUyxHQUFHTSxPQUFPLENBQUNKLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDcEY7QUFDQSxTQUFPRDtBQUNUO0FBSUEsd0JBQXdCUSxtQkFBbUIsRUFBRWQsUUFBUSxHQUFHO0FBQUFlLEtBQUE7QUFDdEQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl0QyxTQUFTLElBQUk7QUFFN0NELFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3NDLFNBQVUsUUFBT0U7QUFDdEIsVUFBTUMsWUFBWUEsQ0FBQ0MsTUFBTTtBQUN2QixVQUFJQSxFQUFFWixRQUFRLFVBQVU7QUFDdEJZLFVBQUVDLHlCQUF5QjtBQUMzQkosb0JBQVksSUFBSTtBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBSyxXQUFPQyxpQkFBaUIsV0FBV0osV0FBVyxJQUFJO0FBQ2xELFdBQU8sTUFBTUcsT0FBT0Usb0JBQW9CLFdBQVdMLFdBQVcsSUFBSTtBQUFBLEVBQ3BFLEdBQUcsQ0FBQ0gsUUFBUSxDQUFDO0FBRWIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUcsV0FBVSxpQkFDWGpCLHFCQUFXQyxPQUFPLEVBQUV5QjtBQUFBQSxNQUFJLENBQUNDLFVBQ3hCLHVCQUFDLFFBQW1CLFdBQVUscUJBQzVCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDJCQUEyQkEsZ0JBQU1iLFNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxRQUFHLFdBQVUsdUJBQ1hhLGdCQUFNZixNQUFNYztBQUFBQSxVQUFJLENBQUNFLE1BQ2hCLHVCQUFDLFFBQW9CLFdBQVUsc0JBQzdCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFCQUFvQixlQUFZLFVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsVUFBSyxXQUFVLHNCQUFxQixVQUFVQSxFQUFFdEIsV0FDOUNWO0FBQUFBLHlCQUFXZ0MsRUFBRXRCLFNBQVM7QUFBQSxjQUFFO0FBQUEsaUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JzQixZQUFFQyxnQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNuREQsRUFBRUUsWUFDRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNWixZQUFZVSxDQUFDO0FBQUEsZ0JBQzVCLGNBQVc7QUFBQSxnQkFFWCxpQ0FBQyxTQUFJLEtBQUtBLEVBQUVFLFVBQVUsS0FBSyxjQUFjbEMsV0FBV2dDLEVBQUV0QixTQUFTLENBQUMsT0FBTyxTQUFRLFVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUE7QUFBQSxjQU52RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBZEtzQixFQUFFRyxVQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsUUFDRCxLQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0F0Qk9KLE1BQU1sQixLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxJQUNELEtBMUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxJQUVDUSxZQUNDLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsU0FBUyxNQUFNQyxZQUFZLElBQUksR0FBRyxNQUFLLFVBQVMsY0FBVyxjQUN4RjtBQUFBLDZCQUFDLFNBQUksS0FBS0QsU0FBU2EsVUFBVSxLQUFLYixTQUFTWSxjQUFjLFNBQVMsQ0FBQ1IsTUFBTUEsRUFBRVcsZ0JBQWdCLEtBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkY7QUFBQSxNQUM3Rix1QkFBQyxPQUFFLFdBQVUseUJBQ1YvQztBQUFBQSx1QkFBZWdDLFNBQVNYLFNBQVM7QUFBQSxRQUFFO0FBQUEsUUFBSVYsV0FBV3FCLFNBQVNYLFNBQVM7QUFBQSxRQUFFO0FBQUEsV0FEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHVCQUFzQixjQUFXLE9BQUssaUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0F2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlDQTtBQUVKO0FBQUNVLEdBM0R1QkQsb0JBQWtCO0FBQUEsS0FBbEJBO0FBQWtCLElBQUFrQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInRvRGF5S2V5IiwiaXNvIiwiRGF0ZSIsInRvRGF0ZVN0cmluZyIsImZvcm1hdERheUxhYmVsIiwiZGF0ZSIsInRvZGF5IiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ3ZWVrZGF5IiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwiZm9ybWF0VGltZSIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJncm91cEJ5RGF5IiwicmVwb3J0cyIsInNvcnRlZCIsInNvcnQiLCJhIiwiYiIsImNyZWF0ZWRBdCIsImdyb3VwcyIsInJlcG9ydCIsImtleSIsImxhc3QiLCJsZW5ndGgiLCJpdGVtcyIsInB1c2giLCJsYWJlbCIsIkNhcmVSZXBvcnRUaW1lbGluZSIsIl9zIiwibGlnaHRib3giLCJzZXRMaWdodGJveCIsInVuZGVmaW5lZCIsImhhbmRsZUtleSIsImUiLCJzdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24iLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIm1hcCIsImdyb3VwIiwiciIsInJlcG9ydERldGFpbCIsInBob3RvVXJsIiwicmVwb3J0SWQiLCJzdG9wUHJvcGFnYXRpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJlUmVwb3J0VGltZWxpbmUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBcIi4vY2FyZVJlcG9ydC5jc3NcIjtcblxuZnVuY3Rpb24gdG9EYXlLZXkoaXNvKSB7XG4gIHJldHVybiBuZXcgRGF0ZShpc28pLnRvRGF0ZVN0cmluZygpO1xufVxuXG5mdW5jdGlvbiBmb3JtYXREYXlMYWJlbChpc28pIHtcbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGlzbyk7XG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUoKTtcbiAgeWVzdGVyZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMSk7XG4gIGlmIChkYXRlLnRvRGF0ZVN0cmluZygpID09PSB0b2RheS50b0RhdGVTdHJpbmcoKSkgcmV0dXJuIFwi4Lin4Lix4LiZ4LiZ4Li14LmJXCI7XG4gIGlmIChkYXRlLnRvRGF0ZVN0cmluZygpID09PSB5ZXN0ZXJkYXkudG9EYXRlU3RyaW5nKCkpIHJldHVybiBcIuC5gOC4oeC4t+C5iOC4reC4p+C4suC4mVwiO1xuICByZXR1cm4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJ0aC1USFwiLCB7IHdlZWtkYXk6IFwibG9uZ1wiLCBkYXk6IFwibnVtZXJpY1wiLCBtb250aDogXCJzaG9ydFwiLCB5ZWFyOiBcIm51bWVyaWNcIiB9KTtcbn1cblxuZnVuY3Rpb24gZm9ybWF0VGltZShpc28pIHtcbiAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVUaW1lU3RyaW5nKFwidGgtVEhcIiwgeyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiB9KTtcbn1cblxuLy8g4LmD4Lir4Lih4LmI4Liq4Li44LiU4Lit4Lii4Li54LmI4Lia4LiZIOC5geC4peC5ieC4p+C4iOC4seC4lOC4geC4peC4uOC5iOC4oeC4leC4suC4oeC4p+C4seC4mVxuZnVuY3Rpb24gZ3JvdXBCeURheShyZXBvcnRzKSB7XG4gIGNvbnN0IHNvcnRlZCA9IFsuLi5yZXBvcnRzXS5zb3J0KChhLCBiKSA9PiBuZXcgRGF0ZShiLmNyZWF0ZWRBdCkgLSBuZXcgRGF0ZShhLmNyZWF0ZWRBdCkpO1xuICBjb25zdCBncm91cHMgPSBbXTtcbiAgZm9yIChjb25zdCByZXBvcnQgb2Ygc29ydGVkKSB7XG4gICAgY29uc3Qga2V5ID0gdG9EYXlLZXkocmVwb3J0LmNyZWF0ZWRBdCk7XG4gICAgY29uc3QgbGFzdCA9IGdyb3Vwc1tncm91cHMubGVuZ3RoIC0gMV07XG4gICAgaWYgKGxhc3QgJiYgbGFzdC5rZXkgPT09IGtleSkgbGFzdC5pdGVtcy5wdXNoKHJlcG9ydCk7XG4gICAgZWxzZSBncm91cHMucHVzaCh7IGtleSwgbGFiZWw6IGZvcm1hdERheUxhYmVsKHJlcG9ydC5jcmVhdGVkQXQpLCBpdGVtczogW3JlcG9ydF0gfSk7XG4gIH1cbiAgcmV0dXJuIGdyb3Vwcztcbn1cblxuLy8gQ2FyZVJlcG9ydFRpbWVsaW5lIOKAlCDguYHguKrguJTguIfguKPguLLguKLguIfguLLguJnguIHguLLguKPguJTguLnguYHguKXguYDguJvguYfguJnguYDguKrguYnguJnguYDguKfguKXguLIg4LmD4LiK4LmJ4Lij4LmI4Lin4Lih4LiB4Lix4LiZ4LiX4Lix4LmJ4LiHIG93bmVyIOC5geC4peC4sCBzaXR0ZXIgKFVTNy0zKVxuLy8gcmVwb3J0czog4Lij4Li54Lib4LmB4Lia4Lia4LmA4LiU4Li14Lii4Lin4LiB4Lix4LiaIEdFVCAvYXBpL2Jvb2tpbmdzL3tib29raW5nSUR9L3JlcG9ydHNcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhcmVSZXBvcnRUaW1lbGluZSh7IHJlcG9ydHMgfSkge1xuICBjb25zdCBbbGlnaHRib3gsIHNldExpZ2h0Ym94XSA9IHVzZVN0YXRlKG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFsaWdodGJveCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjb25zdCBoYW5kbGVLZXkgPSAoZSkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG4gICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7IC8vIOC4m+C4tOC4lOC5geC4hOC5iOC4o+C4ueC4myDguYTguKHguYjguYPguKvguYkgbW9kYWwg4LiX4Li14LmI4LiE4Lij4Lit4Lia4Lit4Lii4Li54LmI4Lib4Li04LiU4LiV4Liy4LihXG4gICAgICAgIHNldExpZ2h0Ym94KG51bGwpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleSwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXksIHRydWUpO1xuICB9LCBbbGlnaHRib3hdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8b2wgY2xhc3NOYW1lPVwiY2FyZS10aW1lbGluZVwiPlxuICAgICAgICB7Z3JvdXBCeURheShyZXBvcnRzKS5tYXAoKGdyb3VwKSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17Z3JvdXAua2V5fSBjbGFzc05hbWU9XCJjYXJlLXRpbWVsaW5lLWRheVwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImNhcmUtdGltZWxpbmUtZGF5LWxhYmVsXCI+e2dyb3VwLmxhYmVsfTwvaDM+XG4gICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwiY2FyZS10aW1lbGluZS1pdGVtc1wiPlxuICAgICAgICAgICAgICB7Z3JvdXAuaXRlbXMubWFwKChyKSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17ci5yZXBvcnRJZH0gY2xhc3NOYW1lPVwiY2FyZS10aW1lbGluZS1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJlLXRpbWVsaW5lLWRvdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8dGltZSBjbGFzc05hbWU9XCJjYXJlLXRpbWVsaW5lLXRpbWVcIiBkYXRlVGltZT17ci5jcmVhdGVkQXR9PlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VGltZShyLmNyZWF0ZWRBdCl9IOC4mS5cbiAgICAgICAgICAgICAgICAgIDwvdGltZT5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNhcmUtdGltZWxpbmUtZGV0YWlsXCI+e3IucmVwb3J0RGV0YWlsfTwvcD5cbiAgICAgICAgICAgICAgICAgIHtyLnBob3RvVXJsICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmUtdGltZWxpbmUtcGhvdG9cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpZ2h0Ym94KHIpfVxuICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLguJTguLnguKPguLnguJvguILguJnguLLguJTguYDguJXguYfguKFcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e3IucGhvdG9Vcmx9IGFsdD17YOC4o+C4ueC4m+C4geC4tOC4iOC4geC4o+C4o+C4oSAke2Zvcm1hdFRpbWUoci5jcmVhdGVkQXQpfSDguJkuYH0gbG9hZGluZz1cImxhenlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L29sPlxuICAgICAgICAgIDwvbGk+XG4gICAgICAgICkpfVxuICAgICAgPC9vbD5cblxuICAgICAge2xpZ2h0Ym94ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJlLWxpZ2h0Ym94XCIgb25DbGljaz17KCkgPT4gc2V0TGlnaHRib3gobnVsbCl9IHJvbGU9XCJkaWFsb2dcIiBhcmlhLWxhYmVsPVwi4Lij4Li54Lib4LiB4Li04LiI4LiB4Lij4Lij4LihXCI+XG4gICAgICAgICAgPGltZyBzcmM9e2xpZ2h0Ym94LnBob3RvVXJsfSBhbHQ9e2xpZ2h0Ym94LnJlcG9ydERldGFpbH0gb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9IC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2FyZS1saWdodGJveC1jYXB0aW9uXCI+XG4gICAgICAgICAgICB7Zm9ybWF0RGF5TGFiZWwobGlnaHRib3guY3JlYXRlZEF0KX0gwrcge2Zvcm1hdFRpbWUobGlnaHRib3guY3JlYXRlZEF0KX0g4LiZLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjYXJlLWxpZ2h0Ym94LWNsb3NlXCIgYXJpYS1sYWJlbD1cIuC4m+C4tOC4lFwiPlxuICAgICAgICAgICAg4pyVXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL2NhcmVSZXBvcnQvQ2FyZVJlcG9ydFRpbWVsaW5lLmpzeCJ9