import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate, Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { useAuth } from "/src/context/AuthContext.jsx";
import { toast } from "/src/utils/toast.js";
import { isEmail } from "/src/utils/validators.js";
import Logo from "/src/components/ui/Logo.jsx";
import TextInput from "/src/components/ui/TextInput.jsx";
import PasswordInput from "/src/components/ui/PasswordInput.jsx";
import Button from "/src/components/ui/Button.jsx";
import AlertBanner from "/src/components/ui/AlertBanner.jsx";
export default function LoginPage() {
  _s();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [values, setValues] = useState({ email: "", password: "", rememberMe: false });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [status, setStatus] = useState("idle");
  const set = (k) => (e) => setValues((v) => ({ ...v, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const onSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    const errs = {};
    if (!values.email.trim()) errs.email = "กรุณากรอกอีเมล";
    else if (!isEmail(values.email)) errs.email = "รูปแบบอีเมลไม่ถูกต้อง";
    if (!values.password) errs.password = "กรุณากรอกรหัสผ่าน";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setStatus("submitting");
    try {
      const data = await login(values.email, values.password, values.rememberMe);
      toast("เข้าสู่ระบบสำเร็จ");
      if (data?.user?.role === "sitter") {
        navigate("/sitter/dashboard");
      } else {
        navigate("/");
      }
    } catch (err) {
      const statusCode = err.status || err.response?.status;
      if (statusCode === 401) {
        setFormError("อีเมลหรือรหัสผ่านไม่ถูกต้อง");
      } else if (statusCode >= 500) {
        setFormError("เกิดข้อผิดพลาดจากเซิร์ฟเวอร์ กรุณาลองใหม่อีกครั้ง");
      } else {
        setFormError("เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง");
      }
    } finally {
      setStatus("idle");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
    /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "ยินดีต้อนรับกลับ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 85,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-sub", children: "เข้าสู่ระบบเพื่อใช้งาน PetBuddy" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 86,
      columnNumber: 9
    }, this),
    searchParams.get("expired") === "1" && /* @__PURE__ */ jsxDEV(AlertBanner, { type: "info", children: "เซสชันหมดอายุ กรุณาเข้าสู่ระบบอีกครั้ง" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 89,
      columnNumber: 9
    }, this),
    formError && /* @__PURE__ */ jsxDEV(AlertBanner, { type: "error", children: formError }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 91,
      columnNumber: 23
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit, noValidate: true, children: [
      /* @__PURE__ */ jsxDEV(
        TextInput,
        {
          label: "อีเมล",
          placeholder: "you@example.com",
          value: values.email,
          onChange: set("email"),
          error: errors.email
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
          lineNumber: 94,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        PasswordInput,
        {
          label: "รหัสผ่าน",
          placeholder: "••••••••",
          value: values.password,
          onChange: set("password"),
          error: errors.password
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
          lineNumber: 96,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("label", { className: "checkbox", children: [
        /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: values.rememberMe, onChange: set("rememberMe") }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
          lineNumber: 99,
          columnNumber: 13
        }, this),
        "จดจำฉันไว้"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
        lineNumber: 98,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", loading: status === "submitting", children: "เข้าสู่ระบบ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
        lineNumber: 102,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 93,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-links", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/forgot-password", children: "ลืมรหัสผ่าน?" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
        lineNumber: 106,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "dot", children: "·" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
        lineNumber: 107,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/register", children: "สมัครสมาชิก" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
        lineNumber: 108,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
      lineNumber: 105,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
    lineNumber: 83,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx",
    lineNumber: 82,
    columnNumber: 5
  }, this);
}
_s(LoginPage, "864dtEmNxf6BuHLMQ81L38bK9IQ=", false, function() {
  return [useAuth, useNavigate, useSearchParams];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LoginPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhFUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsTUFBTUMsdUJBQXVCO0FBQ25ELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxpQkFBaUI7QUFFeEIsd0JBQXdCQyxZQUFZO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxNQUFNLElBQUlWLFFBQVE7QUFDMUIsUUFBTVcsV0FBV2QsWUFBWTtBQUM3QixRQUFNLENBQUNlLFlBQVksSUFBSWIsZ0JBQWdCO0FBRXZDLFFBQU0sQ0FBQ2MsUUFBUUMsU0FBUyxJQUFJbEIsU0FBUyxFQUFFbUIsT0FBTyxJQUFJQyxVQUFVLElBQUlDLFlBQVksTUFBTSxDQUFDO0FBQ25GLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJdkIsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDd0IsV0FBV0MsWUFBWSxJQUFJekIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzBCLFFBQVFDLFNBQVMsSUFBSTNCLFNBQVMsTUFBTTtBQUUzQyxRQUFNNEIsTUFBTUEsQ0FBQ0MsTUFBTSxDQUFDQyxNQUNsQlosVUFBVSxDQUFDYSxPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDRixDQUFDLEdBQUdDLEVBQUVFLE9BQU9DLFNBQVMsYUFBYUgsRUFBRUUsT0FBT0UsVUFBVUosRUFBRUUsT0FBT0csTUFBTSxFQUFFO0FBRXBHLFFBQU1DLFdBQVcsT0FBT04sTUFBTTtBQUM1QkEsTUFBRU8sZUFBZTtBQUNqQlosaUJBQWEsRUFBRTtBQUVmLFVBQU1hLE9BQU8sQ0FBQztBQUNkLFFBQUksQ0FBQ3JCLE9BQU9FLE1BQU1vQixLQUFLLEVBQUdELE1BQUtuQixRQUFRO0FBQUEsYUFDOUIsQ0FBQ2IsUUFBUVcsT0FBT0UsS0FBSyxFQUFHbUIsTUFBS25CLFFBQVE7QUFDOUMsUUFBSSxDQUFDRixPQUFPRyxTQUFVa0IsTUFBS2xCLFdBQVc7QUFDdENHLGNBQVVlLElBQUk7QUFDZCxRQUFJRSxPQUFPQyxLQUFLSCxJQUFJLEVBQUVJLE9BQVE7QUFFOUJmLGNBQVUsWUFBWTtBQUN0QixRQUFJO0FBQ0YsWUFBTWdCLE9BQU8sTUFBTTdCLE1BQU1HLE9BQU9FLE9BQU9GLE9BQU9HLFVBQVVILE9BQU9JLFVBQVU7QUFDekVoQixZQUFNLG1CQUFtQjtBQUN6QixVQUFJc0MsTUFBTUMsTUFBTUMsU0FBUyxVQUFVO0FBQ2pDOUIsaUJBQVMsbUJBQW1CO0FBQUEsTUFDOUIsT0FBTztBQUNMQSxpQkFBUyxHQUFHO0FBQUEsTUFDZDtBQUFBLElBQ0YsU0FBUytCLEtBQUs7QUFDWixZQUFNQyxhQUFhRCxJQUFJcEIsVUFBVW9CLElBQUlFLFVBQVV0QjtBQUUvQyxVQUFJcUIsZUFBZSxLQUFLO0FBR3RCdEIscUJBQWEsNkJBQTZCO0FBQUEsTUFDNUMsV0FBV3NCLGNBQWMsS0FBSztBQUM1QnRCLHFCQUFhLG1EQUFtRDtBQUFBLE1BQ2xFLE9BQU87QUFDTEEscUJBQWEscUNBQXFDO0FBQUEsTUFDcEQ7QUFBQSxJQUNGLFVBQUM7QUFDQ0UsZ0JBQVUsTUFBTTtBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLElBQ0wsdUJBQUMsUUFBRyxXQUFVLGNBQWEsZ0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkM7QUFBQSxJQUMzQyx1QkFBQyxPQUFFLFdBQVUsWUFBVywrQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RDtBQUFBLElBRXREWCxhQUFhaUMsSUFBSSxTQUFTLE1BQU0sT0FDL0IsdUJBQUMsZUFBWSxNQUFLLFFBQU8sc0RBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Q7QUFBQSxJQUVoRXpCLGFBQWEsdUJBQUMsZUFBWSxNQUFLLFNBQVNBLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFbkQsdUJBQUMsVUFBSyxVQUFvQixZQUFVLE1BQ2xDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFVLE9BQU07QUFBQSxVQUFRLGFBQVk7QUFBQSxVQUNuQyxPQUFPUCxPQUFPRTtBQUFBQSxVQUFPLFVBQVVTLElBQUksT0FBTztBQUFBLFVBQUcsT0FBT04sT0FBT0g7QUFBQUE7QUFBQUEsUUFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQ21FO0FBQUEsTUFDbkU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFjLE9BQU07QUFBQSxVQUFXLGFBQVk7QUFBQSxVQUMxQyxPQUFPRixPQUFPRztBQUFBQSxVQUFVLFVBQVVRLElBQUksVUFBVTtBQUFBLFVBQUcsT0FBT04sT0FBT0Y7QUFBQUE7QUFBQUEsUUFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQzRFO0FBQUEsTUFDNUUsdUJBQUMsV0FBTSxXQUFVLFlBQ2Y7QUFBQSwrQkFBQyxXQUFNLE1BQUssWUFBVyxTQUFTSCxPQUFPSSxZQUFZLFVBQVVPLElBQUksWUFBWSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUE7QUFBQSxXQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVNGLFdBQVcsY0FBYywyQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLFNBVHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxRQUFLLElBQUcsb0JBQW1CLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsTUFDeEMsdUJBQUMsVUFBSyxXQUFVLE9BQU0saUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUN2Qix1QkFBQyxRQUFLLElBQUcsYUFBWSwyQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBSGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLE9BMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUNiLEdBbEZ1QkQsV0FBUztBQUFBLFVBQ2JSLFNBQ0RILGFBQ01FLGVBQWU7QUFBQTtBQUFBLEtBSGhCUztBQUFTLElBQUFzQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiTGluayIsInVzZVNlYXJjaFBhcmFtcyIsInVzZUF1dGgiLCJ0b2FzdCIsImlzRW1haWwiLCJMb2dvIiwiVGV4dElucHV0IiwiUGFzc3dvcmRJbnB1dCIsIkJ1dHRvbiIsIkFsZXJ0QmFubmVyIiwiTG9naW5QYWdlIiwiX3MiLCJsb2dpbiIsIm5hdmlnYXRlIiwic2VhcmNoUGFyYW1zIiwidmFsdWVzIiwic2V0VmFsdWVzIiwiZW1haWwiLCJwYXNzd29yZCIsInJlbWVtYmVyTWUiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJmb3JtRXJyb3IiLCJzZXRGb3JtRXJyb3IiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJzZXQiLCJrIiwiZSIsInYiLCJ0YXJnZXQiLCJ0eXBlIiwiY2hlY2tlZCIsInZhbHVlIiwib25TdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImVycnMiLCJ0cmltIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImRhdGEiLCJ1c2VyIiwicm9sZSIsImVyciIsInN0YXR1c0NvZGUiLCJyZXNwb25zZSIsImdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0LmpzeFwiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwiLi4vdXRpbHMvdG9hc3QuanNcIjtcbmltcG9ydCB7IGlzRW1haWwgfSBmcm9tIFwiLi4vdXRpbHMvdmFsaWRhdG9ycy5qc1wiO1xuaW1wb3J0IExvZ28gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvTG9nby5qc3hcIjtcbmltcG9ydCBUZXh0SW5wdXQgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvVGV4dElucHV0LmpzeFwiO1xuaW1wb3J0IFBhc3N3b3JkSW5wdXQgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvUGFzc3dvcmRJbnB1dC5qc3hcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQnV0dG9uLmpzeFwiO1xuaW1wb3J0IEFsZXJ0QmFubmVyIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0FsZXJ0QmFubmVyLmpzeFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XG4gIGNvbnN0IHsgbG9naW4gfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICBcbiAgY29uc3QgW3ZhbHVlcywgc2V0VmFsdWVzXSA9IHVzZVN0YXRlKHsgZW1haWw6IFwiXCIsIHBhc3N3b3JkOiBcIlwiLCByZW1lbWJlck1lOiBmYWxzZSB9KTtcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW2Zvcm1FcnJvciwgc2V0Rm9ybUVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoXCJpZGxlXCIpO1xuXG4gIGNvbnN0IHNldCA9IChrKSA9PiAoZSkgPT5cbiAgICBzZXRWYWx1ZXMoKHYpID0+ICh7IC4uLnYsIFtrXTogZS50YXJnZXQudHlwZSA9PT0gXCJjaGVja2JveFwiID8gZS50YXJnZXQuY2hlY2tlZCA6IGUudGFyZ2V0LnZhbHVlIH0pKTtcblxuICBjb25zdCBvblN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEZvcm1FcnJvcihcIlwiKTtcbiAgICBcbiAgICBjb25zdCBlcnJzID0ge307XG4gICAgaWYgKCF2YWx1ZXMuZW1haWwudHJpbSgpKSBlcnJzLmVtYWlsID0gXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguK3guLXguYDguKHguKVcIjtcbiAgICBlbHNlIGlmICghaXNFbWFpbCh2YWx1ZXMuZW1haWwpKSBlcnJzLmVtYWlsID0gXCLguKPguLnguJvguYHguJrguJrguK3guLXguYDguKHguKXguYTguKHguYjguJbguLnguIHguJXguYnguK3guIdcIjtcbiAgICBpZiAoIXZhbHVlcy5wYXNzd29yZCkgZXJycy5wYXNzd29yZCA9IFwi4LiB4Lij4Li44LiT4Liy4LiB4Lij4Lit4LiB4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZXCI7XG4gICAgc2V0RXJyb3JzKGVycnMpO1xuICAgIGlmIChPYmplY3Qua2V5cyhlcnJzKS5sZW5ndGgpIHJldHVybjtcblxuICAgIHNldFN0YXR1cyhcInN1Ym1pdHRpbmdcIik7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsb2dpbih2YWx1ZXMuZW1haWwsIHZhbHVlcy5wYXNzd29yZCwgdmFsdWVzLnJlbWVtYmVyTWUpO1xuICAgICAgdG9hc3QoXCLguYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJrguKrguLPguYDguKPguYfguIhcIik7XG4gICAgICBpZiAoZGF0YT8udXNlcj8ucm9sZSA9PT0gXCJzaXR0ZXJcIikge1xuICAgICAgICBuYXZpZ2F0ZShcIi9zaXR0ZXIvZGFzaGJvYXJkXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmF2aWdhdGUoXCIvXCIpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3Qgc3RhdHVzQ29kZSA9IGVyci5zdGF0dXMgfHwgZXJyLnJlc3BvbnNlPy5zdGF0dXM7XG5cbiAgICAgIGlmIChzdGF0dXNDb2RlID09PSA0MDEpIHtcbiAgICAgICAgLy8gQmFja2VuZCDguKrguYjguIcgSU5WQUxJRF9DUkVERU5USUFMUyDguJfguLHguYnguIcgZW1haWwg4LmE4Lih4LmI4Lih4Li1IOC5geC4peC4sCDguKPguKvguLHguKrguJzguLTguJRcbiAgICAgICAgLy8g4oaSIOC5geC4quC4lOC4h+C4guC5ieC4reC4hOC4p+C4suC4oeC5gOC4lOC4teC4ouC4p+C4geC4seC4mSAo4Lib4Lil4Lit4LiU4Lig4Lix4LiiIOC5hOC4oeC5iOC4muC4reC4geC4p+C5iOC4siBlbWFpbCDguKHguLXguIjguKPguLTguIfguYTguKvguKEpXG4gICAgICAgIHNldEZvcm1FcnJvcihcIuC4reC4teC5gOC4oeC4peC4q+C4o+C4t+C4reC4o+C4q+C4seC4quC4nOC5iOC4suC4meC5hOC4oeC5iOC4luC4ueC4geC4leC5ieC4reC4h1wiKTtcbiAgICAgIH0gZWxzZSBpZiAoc3RhdHVzQ29kZSA+PSA1MDApIHtcbiAgICAgICAgc2V0Rm9ybUVycm9yKFwi4LmA4LiB4Li04LiU4LiC4LmJ4Lit4Lic4Li04LiU4Lie4Lil4Liy4LiU4LiI4Liy4LiB4LmA4LiL4Li04Lij4LmM4Lif4LmA4Lin4Lit4Lij4LmMIOC4geC4o+C4uOC4k+C4suC4peC4reC4h+C5g+C4q+C4oeC5iOC4reC4teC4geC4hOC4o+C4seC5ieC4h1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldEZvcm1FcnJvcihcIuC5gOC4geC4tOC4lOC4guC5ieC4reC4nOC4tOC4lOC4nuC4peC4suC4lCDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIik7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFN0YXR1cyhcImlkbGVcIik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhZ2VcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jYXJkXCI+XG4gICAgICAgIDxMb2dvIC8+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJhdXRoLXRpdGxlXCI+4Lii4Li04LiZ4LiU4Li14LiV4LmJ4Lit4LiZ4Lij4Lix4Lia4LiB4Lil4Lix4LiaPC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJcIj7guYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJrguYDguJ7guLfguYjguK3guYPguIrguYnguIfguLLguJkgUGV0QnVkZHk8L3A+XG5cbiAgICAgICAge3NlYXJjaFBhcmFtcy5nZXQoXCJleHBpcmVkXCIpID09PSBcIjFcIiAmJiAoXG4gICAgICAgICAgPEFsZXJ0QmFubmVyIHR5cGU9XCJpbmZvXCI+4LmA4LiL4Liq4LiK4Lix4LiZ4Lir4Lih4LiU4Lit4Liy4Lii4Li4IOC4geC4o+C4uOC4k+C4suC5gOC4guC5ieC4suC4quC4ueC5iOC4o+C4sOC4muC4muC4reC4teC4geC4hOC4o+C4seC5ieC4hzwvQWxlcnRCYW5uZXI+XG4gICAgICAgICl9XG4gICAgICAgIHtmb3JtRXJyb3IgJiYgPEFsZXJ0QmFubmVyIHR5cGU9XCJlcnJvclwiPntmb3JtRXJyb3J9PC9BbGVydEJhbm5lcj59XG5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e29uU3VibWl0fSBub1ZhbGlkYXRlPlxuICAgICAgICAgIDxUZXh0SW5wdXQgbGFiZWw9XCLguK3guLXguYDguKHguKVcIiBwbGFjZWhvbGRlcj1cInlvdUBleGFtcGxlLmNvbVwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWVzLmVtYWlsfSBvbkNoYW5nZT17c2V0KFwiZW1haWxcIil9IGVycm9yPXtlcnJvcnMuZW1haWx9IC8+XG4gICAgICAgICAgPFBhc3N3b3JkSW5wdXQgbGFiZWw9XCLguKPguKvguLHguKrguJzguYjguLLguJlcIiBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWVzLnBhc3N3b3JkfSBvbkNoYW5nZT17c2V0KFwicGFzc3dvcmRcIil9IGVycm9yPXtlcnJvcnMucGFzc3dvcmR9IC8+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNoZWNrYm94XCI+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dmFsdWVzLnJlbWVtYmVyTWV9IG9uQ2hhbmdlPXtzZXQoXCJyZW1lbWJlck1lXCIpfSAvPlxuICAgICAgICAgICAg4LiI4LiU4LiI4Liz4LiJ4Lix4LiZ4LmE4Lin4LmJXG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBsb2FkaW5nPXtzdGF0dXMgPT09IFwic3VibWl0dGluZ1wifT7guYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJo8L0J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1saW5rc1wiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL2ZvcmdvdC1wYXNzd29yZFwiPuC4peC4t+C4oeC4o+C4q+C4seC4quC4nOC5iOC4suC4mT88L0xpbms+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZG90XCI+wrc8L3NwYW4+XG4gICAgICAgICAgPExpbmsgdG89XCIvcmVnaXN0ZXJcIj7guKrguKHguLHguITguKPguKrguKHguLLguIrguLTguIE8L0xpbms+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59Il0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL3BhZ2VzL0xvZ2luUGFnZS5qc3gifQ==