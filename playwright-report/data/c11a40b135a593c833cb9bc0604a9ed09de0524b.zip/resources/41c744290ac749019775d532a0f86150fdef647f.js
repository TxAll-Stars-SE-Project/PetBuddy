import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/SitterBookingCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/components/sitter/SitterBookingCard.css";
const statusLabels = {
  pending: "รอดำเนินการ",
  waiting_payment: "รอชำระเงิน",
  deposit_paid: "ชำระมัดจำแล้ว",
  confirmed: "ยืนยันแล้ว",
  in_progress: "กำลังดูแล",
  rejected: "ปฏิเสธแล้ว",
  cancelled: "ยกเลิกแล้ว",
  waiting_final_payment: "รอชำระส่วนที่เหลือ",
  completed: "เสร็จสิ้น"
};
const statusSymbols = {
  pending: "●",
  waiting_payment: "●",
  deposit_paid: "●",
  confirmed: "●",
  in_progress: "●",
  rejected: "×",
  cancelled: "−",
  waiting_final_payment: "●",
  completed: "✓"
};
const serviceTypeLabels = {
  walking: "พาสุนัขเดินเล่น",
  sitting: "ดูแลสัตว์เลี้ยง",
  boarding: "รับฝากสัตว์เลี้ยง",
  grooming: "อาบน้ำตัดขน",
  daycare: "รับดูแลช่วงกลางวัน"
};
const speciesLabels = {
  dog: "สุนัข",
  cat: "แมว",
  bird: "นก",
  exotic: "สัตว์พิเศษ"
};
function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value || "-";
  }
  return new Intl.DateTimeFormat("th-TH", {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(date);
}
function getPetDetails(booking) {
  if (booking.pets?.length) {
    return booking.pets.map((pet) => {
      const name = pet.petName || pet.name || "สัตว์เลี้ยง";
      const species = pet.species || pet.type;
      const details = [
        species ? speciesLabels[species] || species : "",
        pet.breed || ""
      ].filter(Boolean);
      return details.length ? `${name} (${details.join(", ")})` : name;
    }).join(", ");
  }
  if (booking.petName) {
    return `${booking.petName}${booking.petType ? ` (${booking.petType})` : ""}`;
  }
  return "ไม่มีข้อมูลสัตว์เลี้ยง";
}
export default function SitterBookingCard({
  booking,
  onAction,
  onRequestConfirm,
  isUpdating = false
}) {
  const serviceTypeLabel = serviceTypeLabels[booking.service.servicetype] || booking.service.servicetype;
  const totalPrice = Number(booking.totalprice) || 0;
  const runAction = (action) => {
    if (onRequestConfirm) {
      onRequestConfirm(booking, action);
    } else {
      onAction?.(booking.bookingId, action);
    }
  };
  return /* @__PURE__ */ jsxDEV("article", { className: "sitter-booking-card", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "sitter-booking-card__header", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "sitter-booking-card__title", children: booking.service.title || booking.serviceName || "บริการสัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "sitter-booking-card__service-type", children: serviceTypeLabel || "บริการสัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: `sitter-booking-card__status sitter-booking-card__status--${booking.bookingstatus}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "sitter-booking-card__status-symbol", "aria-hidden": "true", children: statusSymbols[booking.bookingstatus] }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
              lineNumber: 133,
              columnNumber: 11
            }, this),
            statusLabels[booking.bookingstatus]
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 130,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dl", { className: "sitter-booking-card__details", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "เจ้าของ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 142,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: booking.owner.fullname || booking.ownerName || "ไม่ระบุชื่อ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 143,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 141,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "เบอร์โทร" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 146,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: booking.owner.phone ? /* @__PURE__ */ jsxDEV("a", { href: `tel:${booking.owner.phone}`, children: booking.owner.phone }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 149,
          columnNumber: 13
        }, this) : "-" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 147,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 145,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail sitter-booking-card__detail--wide", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "สัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 156,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: getPetDetails(booking) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 155,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "เริ่ม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 160,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: formatDateTime(booking.starttime) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 161,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "สิ้นสุด" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 164,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: formatDateTime(booking.endtime) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 165,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "ราคารวม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: [
          totalPrice.toLocaleString("th-TH"),
          " บาท"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 169,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "แผนชำระเงิน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 172,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: booking.paymentplan === "full" ? "ชำระเต็มจำนวน" : "ชำระมัดจำ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 173,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 171,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-booking-card__detail sitter-booking-card__detail--wide", children: [
        /* @__PURE__ */ jsxDEV("dt", { children: "หมายเหตุ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 176,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { children: booking.note?.trim() || "ไม่มีหมายเหตุ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 177,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 175,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this),
    booking.bookingstatus === "pending" && (onAction || onRequestConfirm) && /* @__PURE__ */ jsxDEV("footer", { className: "sitter-booking-card__actions", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "sitter-booking-card__button sitter-booking-card__button--reject",
          type: "button",
          disabled: isUpdating,
          onClick: () => runAction("reject"),
          children: "ปฏิเสธ (Reject)"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 183,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "sitter-booking-card__button sitter-booking-card__button--accept",
          type: "button",
          disabled: isUpdating,
          onClick: () => runAction("accept"),
          children: "รับงาน (Accept)"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
          lineNumber: 191,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
      lineNumber: 182,
      columnNumber: 7
    }, this),
    (booking.bookingstatus === "confirmed" || booking.bookingstatus === "deposit_paid") && (onAction || onRequestConfirm) && /* @__PURE__ */ jsxDEV("footer", { className: "sitter-booking-card__actions", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        className: "sitter-booking-card__button sitter-booking-card__button--complete",
        type: "button",
        disabled: isUpdating,
        onClick: () => runAction("complete"),
        children: "ส่งงานเสร็จสิ้น (Complete Job)"
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
        lineNumber: 204,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
      lineNumber: 203,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
}
_c = SitterBookingCard;
var _c;
$RefreshReg$(_c, "SitterBookingCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/SitterBookingCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdVOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEdWLE9BQU87QUFTUCxNQUFNQSxlQUE4QztBQUFBLEVBQ2xEQyxTQUFTO0FBQUEsRUFDVEMsaUJBQWlCO0FBQUEsRUFDakJDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsYUFBYTtBQUFBLEVBQ2JDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsdUJBQXVCO0FBQUEsRUFDdkJDLFdBQVc7QUFDYjtBQUVBLE1BQU1DLGdCQUErQztBQUFBLEVBQ25EVCxTQUFTO0FBQUEsRUFDVEMsaUJBQWlCO0FBQUEsRUFDakJDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsYUFBYTtBQUFBLEVBQ2JDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsdUJBQXVCO0FBQUEsRUFDdkJDLFdBQVc7QUFDYjtBQUVBLE1BQU1FLG9CQUF1RTtBQUFBLEVBQzNFQyxTQUFTO0FBQUEsRUFDVEMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFBQSxFQUNWQyxVQUFVO0FBQUEsRUFDVkMsU0FBUztBQUNYO0FBRUEsTUFBTUMsZ0JBQXdDO0FBQUEsRUFDNUNDLEtBQUs7QUFBQSxFQUNMQyxLQUFLO0FBQUEsRUFDTEMsTUFBTTtBQUFBLEVBQ05DLFFBQVE7QUFDVjtBQUVBLFNBQVNDLGVBQWVDLE9BQXVCO0FBQzdDLFFBQU1DLE9BQU8sSUFBSUMsS0FBS0YsS0FBSztBQUMzQixNQUFJRyxPQUFPQyxNQUFNSCxLQUFLSSxRQUFRLENBQUMsR0FBRztBQUNoQyxXQUFPTCxTQUFTO0FBQUEsRUFDbEI7QUFFQSxTQUFPLElBQUlNLEtBQUtDLGVBQWUsU0FBUztBQUFBLElBQ3RDQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLEVBQ2IsQ0FBQyxFQUFFQyxPQUFPVCxJQUFJO0FBQ2hCO0FBRUEsU0FBU1UsY0FBY0MsU0FBMEI7QUFDL0MsTUFBSUEsUUFBUUMsTUFBTUMsUUFBUTtBQUN4QixXQUFPRixRQUFRQyxLQUNaRSxJQUFJLENBQUNDLFFBQVE7QUFDWixZQUFNQyxPQUFPRCxJQUFJRSxXQUFXRixJQUFJQyxRQUFRO0FBQ3hDLFlBQU1FLFVBQVVILElBQUlHLFdBQVdILElBQUlJO0FBQ25DLFlBQU1DLFVBQVU7QUFBQSxRQUNkRixVQUFVekIsY0FBY3lCLE9BQU8sS0FBS0EsVUFBVTtBQUFBLFFBQzlDSCxJQUFJTSxTQUFTO0FBQUEsTUFBRSxFQUNmQyxPQUFPQyxPQUFPO0FBQ2hCLGFBQU9ILFFBQVFQLFNBQVMsR0FBR0csSUFBSSxLQUFLSSxRQUFRSSxLQUFLLElBQUksQ0FBQyxNQUFNUjtBQUFBQSxJQUM5RCxDQUFDLEVBQ0FRLEtBQUssSUFBSTtBQUFBLEVBQ2Q7QUFFQSxNQUFJYixRQUFRTSxTQUFTO0FBQ25CLFdBQU8sR0FBR04sUUFBUU0sT0FBTyxHQUFHTixRQUFRYyxVQUFVLEtBQUtkLFFBQVFjLE9BQU8sTUFBTSxFQUFFO0FBQUEsRUFDNUU7QUFDQSxTQUFPO0FBQ1Q7QUFFQSx3QkFBd0JDLGtCQUFrQjtBQUFBLEVBQ3hDZjtBQUFBQSxFQUNBZ0I7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsYUFBYTtBQUNTLEdBQUc7QUFDekIsUUFBTUMsbUJBQ0ozQyxrQkFBa0J3QixRQUFRb0IsUUFBUUMsV0FBVyxLQUFLckIsUUFBUW9CLFFBQVFDO0FBQ3BFLFFBQU1DLGFBQWEvQixPQUFPUyxRQUFRdUIsVUFBVSxLQUFLO0FBQ2pELFFBQU1DLFlBQVlBLENBQUNDLFdBQTBCO0FBQzNDLFFBQUlSLGtCQUFrQjtBQUNwQkEsdUJBQWlCakIsU0FBU3lCLE1BQU07QUFBQSxJQUNsQyxPQUFPO0FBQ0xULGlCQUFXaEIsUUFBUTBCLFdBQVdELE1BQU07QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLGFBQVEsV0FBVSx1QkFDakI7QUFBQSwyQkFBQyxZQUFPLFdBQVUsK0JBQ2hCO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw4QkFDWHpCLGtCQUFRb0IsUUFBUU8sU0FBUzNCLFFBQVE0QixlQUFlLHVCQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FDVlQsOEJBQW9CLHVCQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVcsNERBQTREbkIsUUFBUTZCLGFBQWE7QUFBQSxVQUU1RjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzQ0FBcUMsZUFBWSxRQUM5RHRELHdCQUFjeUIsUUFBUTZCLGFBQWEsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0NoRSxhQUFhbUMsUUFBUTZCLGFBQWE7QUFBQTtBQUFBO0FBQUEsUUFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsZ0NBQ1o7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxRQUFHLHVCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsUUFBSTdCLGtCQUFROEIsTUFBTUMsWUFBWS9CLFFBQVFnQyxhQUFhLGlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsV0FGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQ1osdUJBQUMsUUFDRWhDLGtCQUFROEIsTUFBTUcsUUFDYix1QkFBQyxPQUFFLE1BQU0sT0FBT2pDLFFBQVE4QixNQUFNRyxLQUFLLElBQUtqQyxrQkFBUThCLE1BQU1HLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQsSUFFNUQsT0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFFBQUlsQyx3QkFBY0MsT0FBTyxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUztBQUFBLFFBQ1QsdUJBQUMsUUFBSWIseUJBQWVhLFFBQVFrQyxTQUFTLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxXQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxRQUFJL0MseUJBQWVhLFFBQVFtQyxPQUFPLEtBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxXQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxRQUFJYjtBQUFBQSxxQkFBV2MsZUFBZSxPQUFPO0FBQUEsVUFBRTtBQUFBLGFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFDZix1QkFBQyxRQUFJcEMsa0JBQVFxQyxnQkFBZ0IsU0FBUyxrQkFBa0IsZUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsUUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUNaLHVCQUFDLFFBQUlyQyxrQkFBUXNDLE1BQU1DLEtBQUssS0FBSyxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFdBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxJQUVDdkMsUUFBUTZCLGtCQUFrQixjQUFjYixZQUFZQyxxQkFDbkQsdUJBQUMsWUFBTyxXQUFVLGdDQUNoQjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixNQUFLO0FBQUEsVUFDTCxVQUFVQztBQUFBQSxVQUNWLFNBQVMsTUFBTU0sVUFBVSxRQUFRO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixNQUFLO0FBQUEsVUFDTCxVQUFVTjtBQUFBQSxVQUNWLFNBQVMsTUFBTU0sVUFBVSxRQUFRO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFKckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsS0FFQXhCLFFBQVE2QixrQkFBa0IsZUFBZTdCLFFBQVE2QixrQkFBa0Isb0JBQ2xFYixZQUFZQyxxQkFDWCx1QkFBQyxZQUFPLFdBQVUsZ0NBQ2hCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixNQUFLO0FBQUEsUUFDTCxVQUFVQztBQUFBQSxRQUNWLFNBQVMsTUFBTU0sVUFBVSxVQUFVO0FBQUEsUUFBRTtBQUFBO0FBQUEsTUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxPQTVGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEZBO0FBRUo7QUFBQ2dCLEtBbEh1QnpCO0FBQWlCLElBQUF5QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJzdGF0dXNMYWJlbHMiLCJwZW5kaW5nIiwid2FpdGluZ19wYXltZW50IiwiZGVwb3NpdF9wYWlkIiwiY29uZmlybWVkIiwiaW5fcHJvZ3Jlc3MiLCJyZWplY3RlZCIsImNhbmNlbGxlZCIsIndhaXRpbmdfZmluYWxfcGF5bWVudCIsImNvbXBsZXRlZCIsInN0YXR1c1N5bWJvbHMiLCJzZXJ2aWNlVHlwZUxhYmVscyIsIndhbGtpbmciLCJzaXR0aW5nIiwiYm9hcmRpbmciLCJncm9vbWluZyIsImRheWNhcmUiLCJzcGVjaWVzTGFiZWxzIiwiZG9nIiwiY2F0IiwiYmlyZCIsImV4b3RpYyIsImZvcm1hdERhdGVUaW1lIiwidmFsdWUiLCJkYXRlIiwiRGF0ZSIsIk51bWJlciIsImlzTmFOIiwiZ2V0VGltZSIsIkludGwiLCJEYXRlVGltZUZvcm1hdCIsImRhdGVTdHlsZSIsInRpbWVTdHlsZSIsImZvcm1hdCIsImdldFBldERldGFpbHMiLCJib29raW5nIiwicGV0cyIsImxlbmd0aCIsIm1hcCIsInBldCIsIm5hbWUiLCJwZXROYW1lIiwic3BlY2llcyIsInR5cGUiLCJkZXRhaWxzIiwiYnJlZWQiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsInBldFR5cGUiLCJTaXR0ZXJCb29raW5nQ2FyZCIsIm9uQWN0aW9uIiwib25SZXF1ZXN0Q29uZmlybSIsImlzVXBkYXRpbmciLCJzZXJ2aWNlVHlwZUxhYmVsIiwic2VydmljZSIsInNlcnZpY2V0eXBlIiwidG90YWxQcmljZSIsInRvdGFscHJpY2UiLCJydW5BY3Rpb24iLCJhY3Rpb24iLCJib29raW5nSWQiLCJ0aXRsZSIsInNlcnZpY2VOYW1lIiwiYm9va2luZ3N0YXR1cyIsIm93bmVyIiwiZnVsbG5hbWUiLCJvd25lck5hbWUiLCJwaG9uZSIsInN0YXJ0dGltZSIsImVuZHRpbWUiLCJ0b0xvY2FsZVN0cmluZyIsInBheW1lbnRwbGFuIiwibm90ZSIsInRyaW0iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaXR0ZXJCb29raW5nQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBCb29raW5nLCBCb29raW5nQWN0aW9uLCBCb29raW5nU3RhdHVzIH0gZnJvbSAnLi4vLi4vdHlwZXMvYm9va2luZyc7XG5pbXBvcnQgJy4vU2l0dGVyQm9va2luZ0NhcmQuY3NzJztcblxuaW50ZXJmYWNlIFNpdHRlckJvb2tpbmdDYXJkUHJvcHMge1xuICBib29raW5nOiBCb29raW5nO1xuICBvbkFjdGlvbj86IChib29raW5nSWQ6IG51bWJlciwgYWN0aW9uOiBCb29raW5nQWN0aW9uKSA9PiB2b2lkO1xuICBvblJlcXVlc3RDb25maXJtPzogKGJvb2tpbmc6IEJvb2tpbmcsIGFjdGlvbjogQm9va2luZ0FjdGlvbikgPT4gdm9pZDtcbiAgaXNVcGRhdGluZz86IGJvb2xlYW47XG59XG5cbmNvbnN0IHN0YXR1c0xhYmVsczogUmVjb3JkPEJvb2tpbmdTdGF0dXMsIHN0cmluZz4gPSB7XG4gIHBlbmRpbmc6ICfguKPguK3guJTguLPguYDguJnguLTguJnguIHguLLguKMnLFxuICB3YWl0aW5nX3BheW1lbnQ6ICfguKPguK3guIrguLPguKPguLDguYDguIfguLTguJknLFxuICBkZXBvc2l0X3BhaWQ6ICfguIrguLPguKPguLDguKHguLHguJTguIjguLPguYHguKXguYnguKcnLFxuICBjb25maXJtZWQ6ICfguKLguLfguJnguKLguLHguJnguYHguKXguYnguKcnLFxuICBpbl9wcm9ncmVzczogJ+C4geC4s+C4peC4seC4h+C4lOC4ueC5geC4pScsXG4gIHJlamVjdGVkOiAn4Lib4LiP4Li04LmA4Liq4LiY4LmB4Lil4LmJ4LinJyxcbiAgY2FuY2VsbGVkOiAn4Lii4LiB4LmA4Lil4Li04LiB4LmB4Lil4LmJ4LinJyxcbiAgd2FpdGluZ19maW5hbF9wYXltZW50OiAn4Lij4Lit4LiK4Liz4Lij4Liw4Liq4LmI4Lin4LiZ4LiX4Li14LmI4LmA4Lir4Lil4Li34LitJyxcbiAgY29tcGxldGVkOiAn4LmA4Liq4Lij4LmH4LiI4Liq4Li04LmJ4LiZJyxcbn07XG5cbmNvbnN0IHN0YXR1c1N5bWJvbHM6IFJlY29yZDxCb29raW5nU3RhdHVzLCBzdHJpbmc+ID0ge1xuICBwZW5kaW5nOiAn4pePJyxcbiAgd2FpdGluZ19wYXltZW50OiAn4pePJyxcbiAgZGVwb3NpdF9wYWlkOiAn4pePJyxcbiAgY29uZmlybWVkOiAn4pePJyxcbiAgaW5fcHJvZ3Jlc3M6ICfil48nLFxuICByZWplY3RlZDogJ8OXJyxcbiAgY2FuY2VsbGVkOiAn4oiSJyxcbiAgd2FpdGluZ19maW5hbF9wYXltZW50OiAn4pePJyxcbiAgY29tcGxldGVkOiAn4pyTJyxcbn07XG5cbmNvbnN0IHNlcnZpY2VUeXBlTGFiZWxzOiBSZWNvcmQ8Qm9va2luZ1snc2VydmljZSddWydzZXJ2aWNldHlwZSddLCBzdHJpbmc+ID0ge1xuICB3YWxraW5nOiAn4Lie4Liy4Liq4Li44LiZ4Lix4LiC4LmA4LiU4Li04LiZ4LmA4Lil4LmI4LiZJyxcbiAgc2l0dGluZzogJ+C4lOC4ueC5geC4peC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hycsXG4gIGJvYXJkaW5nOiAn4Lij4Lix4Lia4Lid4Liy4LiB4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHJyxcbiAgZ3Jvb21pbmc6ICfguK3guLLguJrguJnguYnguLPguJXguLHguJTguILguJknLFxuICBkYXljYXJlOiAn4Lij4Lix4Lia4LiU4Li54LmB4Lil4LiK4LmI4Lin4LiH4LiB4Lil4Liy4LiH4Lin4Lix4LiZJyxcbn07XG5cbmNvbnN0IHNwZWNpZXNMYWJlbHM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIGRvZzogJ+C4quC4uOC4meC4seC4gicsXG4gIGNhdDogJ+C5geC4oeC4pycsXG4gIGJpcmQ6ICfguJnguIEnLFxuICBleG90aWM6ICfguKrguLHguJXguKfguYzguJ7guLTguYDguKjguKknLFxufTtcblxuZnVuY3Rpb24gZm9ybWF0RGF0ZVRpbWUodmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZGF0ZS5nZXRUaW1lKCkpKSB7XG4gICAgcmV0dXJuIHZhbHVlIHx8ICctJztcbiAgfVxuXG4gIHJldHVybiBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgndGgtVEgnLCB7XG4gICAgZGF0ZVN0eWxlOiAnbWVkaXVtJyxcbiAgICB0aW1lU3R5bGU6ICdzaG9ydCcsXG4gIH0pLmZvcm1hdChkYXRlKTtcbn1cblxuZnVuY3Rpb24gZ2V0UGV0RGV0YWlscyhib29raW5nOiBCb29raW5nKTogc3RyaW5nIHtcbiAgaWYgKGJvb2tpbmcucGV0cz8ubGVuZ3RoKSB7XG4gICAgcmV0dXJuIGJvb2tpbmcucGV0c1xuICAgICAgLm1hcCgocGV0KSA9PiB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBwZXQucGV0TmFtZSB8fCBwZXQubmFtZSB8fCAn4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHJztcbiAgICAgICAgY29uc3Qgc3BlY2llcyA9IHBldC5zcGVjaWVzIHx8IHBldC50eXBlO1xuICAgICAgICBjb25zdCBkZXRhaWxzID0gW1xuICAgICAgICAgIHNwZWNpZXMgPyBzcGVjaWVzTGFiZWxzW3NwZWNpZXNdIHx8IHNwZWNpZXMgOiAnJyxcbiAgICAgICAgICBwZXQuYnJlZWQgfHwgJycsXG4gICAgICAgIF0uZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICByZXR1cm4gZGV0YWlscy5sZW5ndGggPyBgJHtuYW1lfSAoJHtkZXRhaWxzLmpvaW4oJywgJyl9KWAgOiBuYW1lO1xuICAgICAgfSlcbiAgICAgIC5qb2luKCcsICcpO1xuICB9XG5cbiAgaWYgKGJvb2tpbmcucGV0TmFtZSkge1xuICAgIHJldHVybiBgJHtib29raW5nLnBldE5hbWV9JHtib29raW5nLnBldFR5cGUgPyBgICgke2Jvb2tpbmcucGV0VHlwZX0pYCA6ICcnfWA7XG4gIH1cbiAgcmV0dXJuICfguYTguKHguYjguKHguLXguILguYnguK3guKHguLnguKXguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcnO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaXR0ZXJCb29raW5nQ2FyZCh7XG4gIGJvb2tpbmcsXG4gIG9uQWN0aW9uLFxuICBvblJlcXVlc3RDb25maXJtLFxuICBpc1VwZGF0aW5nID0gZmFsc2UsXG59OiBTaXR0ZXJCb29raW5nQ2FyZFByb3BzKSB7XG4gIGNvbnN0IHNlcnZpY2VUeXBlTGFiZWwgPVxuICAgIHNlcnZpY2VUeXBlTGFiZWxzW2Jvb2tpbmcuc2VydmljZS5zZXJ2aWNldHlwZV0gfHwgYm9va2luZy5zZXJ2aWNlLnNlcnZpY2V0eXBlO1xuICBjb25zdCB0b3RhbFByaWNlID0gTnVtYmVyKGJvb2tpbmcudG90YWxwcmljZSkgfHwgMDtcbiAgY29uc3QgcnVuQWN0aW9uID0gKGFjdGlvbjogQm9va2luZ0FjdGlvbikgPT4ge1xuICAgIGlmIChvblJlcXVlc3RDb25maXJtKSB7XG4gICAgICBvblJlcXVlc3RDb25maXJtKGJvb2tpbmcsIGFjdGlvbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIG9uQWN0aW9uPy4oYm9va2luZy5ib29raW5nSWQsIGFjdGlvbik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19oZWFkZXJcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZF9fdGl0bGVcIj5cbiAgICAgICAgICAgIHtib29raW5nLnNlcnZpY2UudGl0bGUgfHwgYm9va2luZy5zZXJ2aWNlTmFtZSB8fCAn4Lia4Lij4Li04LiB4Liy4Lij4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHJ31cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX3NlcnZpY2UtdHlwZVwiPlxuICAgICAgICAgICAge3NlcnZpY2VUeXBlTGFiZWwgfHwgJ+C4muC4o+C4tOC4geC4suC4o+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyd9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBjbGFzc05hbWU9e2BzaXR0ZXItYm9va2luZy1jYXJkX19zdGF0dXMgc2l0dGVyLWJvb2tpbmctY2FyZF9fc3RhdHVzLS0ke2Jvb2tpbmcuYm9va2luZ3N0YXR1c31gfVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZF9fc3RhdHVzLXN5bWJvbFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgICAge3N0YXR1c1N5bWJvbHNbYm9va2luZy5ib29raW5nc3RhdHVzXX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAge3N0YXR1c0xhYmVsc1tib29raW5nLmJvb2tpbmdzdGF0dXNdfVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPGRsIGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2RldGFpbHNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19kZXRhaWxcIj5cbiAgICAgICAgICA8ZHQ+4LmA4LiI4LmJ4Liy4LiC4Lit4LiHPC9kdD5cbiAgICAgICAgICA8ZGQ+e2Jvb2tpbmcub3duZXIuZnVsbG5hbWUgfHwgYm9va2luZy5vd25lck5hbWUgfHwgJ+C5hOC4oeC5iOC4o+C4sOC4muC4uOC4iuC4t+C5iOC4rSd9PC9kZD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZF9fZGV0YWlsXCI+XG4gICAgICAgICAgPGR0PuC5gOC4muC4reC4o+C5jOC5guC4l+C4ozwvZHQ+XG4gICAgICAgICAgPGRkPlxuICAgICAgICAgICAge2Jvb2tpbmcub3duZXIucGhvbmUgPyAoXG4gICAgICAgICAgICAgIDxhIGhyZWY9e2B0ZWw6JHtib29raW5nLm93bmVyLnBob25lfWB9Pntib29raW5nLm93bmVyLnBob25lfTwvYT5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICctJ1xuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19kZXRhaWwgc2l0dGVyLWJvb2tpbmctY2FyZF9fZGV0YWlsLS13aWRlXCI+XG4gICAgICAgICAgPGR0PuC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hzwvZHQ+XG4gICAgICAgICAgPGRkPntnZXRQZXREZXRhaWxzKGJvb2tpbmcpfTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2RldGFpbFwiPlxuICAgICAgICAgIDxkdD7guYDguKPguLTguYjguKE8L2R0PlxuICAgICAgICAgIDxkZD57Zm9ybWF0RGF0ZVRpbWUoYm9va2luZy5zdGFydHRpbWUpfTwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2RldGFpbFwiPlxuICAgICAgICAgIDxkdD7guKrguLTguYnguJnguKrguLjguJQ8L2R0PlxuICAgICAgICAgIDxkZD57Zm9ybWF0RGF0ZVRpbWUoYm9va2luZy5lbmR0aW1lKX08L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19kZXRhaWxcIj5cbiAgICAgICAgICA8ZHQ+4Lij4Liy4LiE4Liy4Lij4Lin4LihPC9kdD5cbiAgICAgICAgICA8ZGQ+e3RvdGFsUHJpY2UudG9Mb2NhbGVTdHJpbmcoJ3RoLVRIJyl9IOC4muC4suC4lzwvZGQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2RldGFpbFwiPlxuICAgICAgICAgIDxkdD7guYHguJzguJnguIrguLPguKPguLDguYDguIfguLTguJk8L2R0PlxuICAgICAgICAgIDxkZD57Ym9va2luZy5wYXltZW50cGxhbiA9PT0gJ2Z1bGwnID8gJ+C4iuC4s+C4o+C4sOC5gOC4leC5h+C4oeC4iOC4s+C4meC4p+C4mScgOiAn4LiK4Liz4Lij4Liw4Lih4Lix4LiU4LiI4LizJ308L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19kZXRhaWwgc2l0dGVyLWJvb2tpbmctY2FyZF9fZGV0YWlsLS13aWRlXCI+XG4gICAgICAgICAgPGR0PuC4q+C4oeC4suC4ouC5gOC4q+C4leC4uDwvZHQ+XG4gICAgICAgICAgPGRkPntib29raW5nLm5vdGU/LnRyaW0oKSB8fCAn4LmE4Lih4LmI4Lih4Li14Lir4Lih4Liy4Lii4LmA4Lir4LiV4Li4J308L2RkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGw+XG5cbiAgICAgIHtib29raW5nLmJvb2tpbmdzdGF0dXMgPT09ICdwZW5kaW5nJyAmJiAob25BY3Rpb24gfHwgb25SZXF1ZXN0Q29uZmlybSkgJiYgKFxuICAgICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2FjdGlvbnNcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzaXR0ZXItYm9va2luZy1jYXJkX19idXR0b24gc2l0dGVyLWJvb2tpbmctY2FyZF9fYnV0dG9uLS1yZWplY3RcIlxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBkaXNhYmxlZD17aXNVcGRhdGluZ31cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJ1bkFjdGlvbigncmVqZWN0Jyl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAg4Lib4LiP4Li04LmA4Liq4LiYIChSZWplY3QpXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZF9fYnV0dG9uIHNpdHRlci1ib29raW5nLWNhcmRfX2J1dHRvbi0tYWNjZXB0XCJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVXBkYXRpbmd9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBydW5BY3Rpb24oJ2FjY2VwdCcpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOC4o+C4seC4muC4h+C4suC4mSAoQWNjZXB0KVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvb3Rlcj5cbiAgICAgICl9XG4gICAgICB7KGJvb2tpbmcuYm9va2luZ3N0YXR1cyA9PT0gJ2NvbmZpcm1lZCcgfHwgYm9va2luZy5ib29raW5nc3RhdHVzID09PSAnZGVwb3NpdF9wYWlkJykgJiZcbiAgICAgICAgKG9uQWN0aW9uIHx8IG9uUmVxdWVzdENvbmZpcm0pICYmIChcbiAgICAgICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInNpdHRlci1ib29raW5nLWNhcmRfX2FjdGlvbnNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l0dGVyLWJvb2tpbmctY2FyZF9fYnV0dG9uIHNpdHRlci1ib29raW5nLWNhcmRfX2J1dHRvbi0tY29tcGxldGVcIlxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVXBkYXRpbmd9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJ1bkFjdGlvbignY29tcGxldGUnKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg4Liq4LmI4LiH4LiH4Liy4LiZ4LmA4Liq4Lij4LmH4LiI4Liq4Li04LmJ4LiZIChDb21wbGV0ZSBKb2IpXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvb3Rlcj5cbiAgICAgICAgKX1cbiAgICA8L2FydGljbGU+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvU2l0dGVyQm9va2luZ0NhcmQudHN4In0=