import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RegisterPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { toast } from "/src/utils/toast.js";
import { api } from "/src/services/api.js";
import { isEmail, isTel, isPostal, isThaiId, passwordOk, isUsername } from "/src/utils/validators.js";
import Logo from "/src/components/ui/Logo.jsx";
import TextInput from "/src/components/ui/TextInput.jsx";
import PasswordInput from "/src/components/ui/PasswordInput.jsx";
import Button from "/src/components/ui/Button.jsx";
import AlertBanner from "/src/components/ui/AlertBanner.jsx";
import RolePills from "/src/components/ui/RolePills.jsx";
import ThaiAddressSelects from "/src/components/ThaiAddressSelects.jsx";
const Req = ({ children }) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
  children,
  " ",
  /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
    lineNumber: 34,
    columnNumber: 14
  }, this)
] }, void 0, true, {
  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
  lineNumber: 34,
  columnNumber: 1
}, this);
_c = Req;
function validateRegister(v) {
  const e = {};
  if (!v.username.trim()) e.username = "กรุณากรอกชื่อผู้ใช้";
  else if (!isUsername(v.username)) e.username = "ชื่อผู้ใช้ต้องยาวอย่างน้อย 3 ตัวอักษร";
  else if (v.username.length > 50) e.username = "ชื่อผู้ใช้ต้องไม่เกิน 50 ตัวอักษร";
  if (!v.email.trim()) e.email = "กรุณากรอกอีเมล";
  else if (!isEmail(v.email)) e.email = "รูปแบบอีเมลไม่ถูกต้อง";
  if (!v.password) e.password = "กรุณากรอกรหัสผ่าน";
  else if (!passwordOk(v.password)) e.password = "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร ประกอบด้วยอักษรและตัวเลข";
  if (!v.confirm || v.confirm !== v.password) e.confirm = "รหัสผ่านไม่ตรงกัน";
  if (!v.tel.trim()) e.tel = "กรุณากรอกเบอร์โทร";
  else if (!isTel(v.tel)) e.tel = "เบอร์โทรต้องขึ้นต้นด้วย 0 และยาว 10 หลัก";
  if (!v.province) e.province = "กรุณาเลือกจังหวัด";
  if (!v.district) e.district = "กรุณาเลือกอำเภอ/เขต";
  if (!v.subdistrict) e.subdistrict = "กรุณาเลือกตำบล/แขวง";
  if (!v.postalCode) e.postalCode = "กรุณาเลือกตำบล/แขวง เพื่อให้ระบบเติมรหัสไปรษณีย์";
  if (v.address && v.address.length > 200) e.address = "ที่อยู่ต้องไม่เกิน 200 ตัวอักษร";
  if (v.role === "sitter") {
    if (!v.thaiId) e.thaiId = "กรุณากรอกเลขบัตรประชาชน";
    else if (!/^\d{13}$/.test(v.thaiId)) e.thaiId = "เลขบัตรประชาชนต้องเป็นตัวเลข 13 หลัก";
    if (!v.experience.trim()) e.experience = "กรุณากรอกประสบการณ์";
  }
  if (!v.consent) e.consent = "กรุณายินยอมก่อนสมัครสมาชิก";
  return e;
}
export default function RegisterPage() {
  _s();
  const navigate = useNavigate();
  const [values, setValues] = useState({
    role: "owner",
    username: "",
    email: "",
    password: "",
    confirm: "",
    tel: "",
    address: "",
    province: "",
    city: "",
    postalCode: "",
    thaiId: "",
    experience: "",
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [status, setStatus] = useState("idle");
  const set = (k) => (e) => setValues((v) => ({ ...v, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const onSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    const errs = validateRegister(values);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const payload = {
      username: values.username,
      email: values.email,
      password: values.password,
      tel: values.tel,
      address: values.address,
      province: values.province,
      district: values.district,
      subdistrict: values.subdistrict,
      postalCode: values.postalCode,
      role: values.role,
      consent: values.consent,
      ...values.role === "sitter" ? { thaiId: values.thaiId, experience: values.experience } : {}
    };
    setStatus("submitting");
    try {
      await api.post("/auth/register", payload);
      toast("สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ");
      navigate("/login");
    } catch (err) {
      const status2 = err.response?.status;
      const data = err.response?.data;
      if (status2 === 400 && data?.error === "VALIDATION_ERROR") {
        setErrors(Object.fromEntries(
          (data.errors || []).map((x) => [x.field, x.message])
        ));
      } else if (status2 === 409) {
        if (data?.error === "EMAIL_DUPLICATE") {
          setErrors({ email: "อีเมลนี้ถูกใช้งานแล้ว" });
        } else if (data?.error === "USERNAME_DUPLICATE") {
          if (Array.isArray(data?.errors)) {
            setErrors(Object.fromEntries(data.errors.map((x) => [x.field, x.message])));
          } else {
            setErrors({ username: "ชื่อผู้ใช้นี้ถูกใช้งานแล้ว" });
          }
        } else {
          setFormError("ข้อมูลนี้ถูกใช้งานแล้วในระบบ");
        }
      } else if (status2 >= 500) {
        toast("เกิดข้อผิดพลาดจากเซิร์ฟเวอร์ กรุณาลองใหม่อีกครั้ง", "info");
      } else {
        setFormError("เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง");
      }
    } finally {
      setStatus("idle");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card auth-card--wide", children: [
    /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 151,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "สร้างบัญชี PetBuddy" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 152,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-sub", children: "เข้าร่วมเป็นครอบครัวคนรักสัตว์" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 153,
      columnNumber: 9
    }, this),
    formError && /* @__PURE__ */ jsxDEV(AlertBanner, { type: "error", children: formError }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 155,
      columnNumber: 23
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit, noValidate: true, children: [
      /* @__PURE__ */ jsxDEV(RolePills, { value: values.role, onChange: (r) => setValues((v) => ({ ...v, role: r })) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 158,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid-2", children: [
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "ชื่อผู้ใช้" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 161,
              columnNumber: 29
            }, this),
            placeholder: "เช่น TanINWZA",
            value: values.username,
            onChange: set("username"),
            error: errors.username
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 161,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "อีเมล" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 163,
              columnNumber: 29
            }, this),
            placeholder: "you@example.com",
            value: values.email,
            onChange: set("email"),
            error: errors.email
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 163,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          PasswordInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "รหัสผ่าน" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 165,
              columnNumber: 33
            }, this),
            placeholder: "อย่างน้อย 8 ตัว มีอักษร+ตัวเลข",
            value: values.password,
            onChange: set("password"),
            error: errors.password
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 165,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          PasswordInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "ยืนยันรหัสผ่าน" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 167,
              columnNumber: 33
            }, this),
            placeholder: "กรอกรหัสผ่านอีกครั้ง",
            value: values.confirm,
            onChange: set("confirm"),
            error: errors.confirm
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 167,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "เบอร์โทร" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 169,
              columnNumber: 29
            }, this),
            placeholder: "0988888888",
            value: values.tel,
            onChange: set("tel"),
            error: errors.tel
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 169,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: "ที่อยู่ (บ้านเลขที่ / ถนน)",
            placeholder: "เช่น 99/12 หมู่ 5 ถ.พหลโยธิน",
            value: values.address,
            onChange: set("address"),
            error: errors.address
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 172,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 160,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        ThaiAddressSelects,
        {
          value: values,
          onChange: (patch) => setValues((v) => ({ ...v, ...patch })),
          errors
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
          lineNumber: 176,
          columnNumber: 9
        },
        this
      ),
      values.role === "sitter" && /* @__PURE__ */ jsxDEV("div", { className: "grid-2", children: [
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "เลขบัตรประชาชน (13 หลัก)" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 184,
              columnNumber: 31
            }, this),
            placeholder: "1101601805057",
            value: values.thaiId,
            onChange: set("thaiId"),
            error: errors.thaiId
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 184,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          TextInput,
          {
            label: /* @__PURE__ */ jsxDEV(Req, { children: "ประสบการณ์การดูแลสัตว์" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 186,
              columnNumber: 31
            }, this),
            placeholder: "เล่าประสบการณ์ของคุณ",
            value: values.experience,
            onChange: set("experience"),
            error: errors.experience
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 186,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 183,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "checkbox", children: [
          /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: values.consent, onChange: set("consent") }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 193,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "ยินยอมให้เก็บและใช้ข้อมูลส่วนบุคคลตามนโยบายความเป็นส่วนตัว ",
            /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
              lineNumber: 194,
              columnNumber: 78
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
            lineNumber: 194,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
          lineNumber: 192,
          columnNumber: 11
        }, this),
        errors.consent && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: errors.consent }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
          lineNumber: 196,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 191,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", loading: status === "submitting", children: "สมัครสมาชิก" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 157,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-links", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "muted", children: "มีบัญชีแล้ว?" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: "เข้าสู่ระบบ" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
        lineNumber: 204,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
      lineNumber: 202,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
    lineNumber: 150,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx",
    lineNumber: 149,
    columnNumber: 5
  }, this);
}
_s(RegisterPage, "KCrxIMuO/80P2eapIo12VqLLM0c=", false, function() {
  return [useNavigate];
});
_c2 = RegisterPage;
var _c, _c2;
$RefreshReg$(_c, "Req");
$RefreshReg$(_c2, "RegisterPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/RegisterPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0UsbUJBQWEsY0FBYjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkRixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsWUFBWTtBQUNsQyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsU0FBU0MsT0FBT0MsVUFBVUMsVUFBVUMsWUFBWUMsa0JBQWtCO0FBQzNFLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx3QkFBd0I7QUFFL0IsTUFBTUMsTUFBTUEsQ0FBQyxFQUFFQyxTQUFTLE1BQ3RCLG1DQUFHQTtBQUFBQTtBQUFBQSxFQUFTO0FBQUEsRUFBQyx1QkFBQyxVQUFLLFdBQVUsT0FBTSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1QjtBQUFBLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBMkM7QUFDM0NDLEtBRklGO0FBSU4sU0FBU0csaUJBQWlCQyxHQUFHO0FBQzNCLFFBQU1DLElBQUksQ0FBQztBQUNYLE1BQUksQ0FBQ0QsRUFBRUUsU0FBU0MsS0FBSyxFQUFHRixHQUFFQyxXQUFXO0FBQUEsV0FDNUIsQ0FBQ2QsV0FBV1ksRUFBRUUsUUFBUSxFQUFHRCxHQUFFQyxXQUFXO0FBQUEsV0FDdENGLEVBQUVFLFNBQVNFLFNBQVMsR0FBSUgsR0FBRUMsV0FBVztBQUU5QyxNQUFJLENBQUNGLEVBQUVLLE1BQU1GLEtBQUssRUFBR0YsR0FBRUksUUFBUTtBQUFBLFdBQ3RCLENBQUN0QixRQUFRaUIsRUFBRUssS0FBSyxFQUFHSixHQUFFSSxRQUFRO0FBRXRDLE1BQUksQ0FBQ0wsRUFBRU0sU0FBVUwsR0FBRUssV0FBVztBQUFBLFdBQ3JCLENBQUNuQixXQUFXYSxFQUFFTSxRQUFRLEVBQUdMLEdBQUVLLFdBQVc7QUFFL0MsTUFBSSxDQUFDTixFQUFFTyxXQUFXUCxFQUFFTyxZQUFZUCxFQUFFTSxTQUFVTCxHQUFFTSxVQUFVO0FBRXhELE1BQUksQ0FBQ1AsRUFBRVEsSUFBSUwsS0FBSyxFQUFHRixHQUFFTyxNQUFNO0FBQUEsV0FDbEIsQ0FBQ3hCLE1BQU1nQixFQUFFUSxHQUFHLEVBQUdQLEdBQUVPLE1BQU07QUFFaEMsTUFBSSxDQUFDUixFQUFFUyxTQUFVUixHQUFFUSxXQUFXO0FBRTlCLE1BQUksQ0FBQ1QsRUFBRVUsU0FBVVQsR0FBRVMsV0FBVztBQUU5QixNQUFJLENBQUNWLEVBQUVXLFlBQWFWLEdBQUVVLGNBQWM7QUFFcEMsTUFBSSxDQUFDWCxFQUFFWSxXQUFZWCxHQUFFVyxhQUFhO0FBRWxDLE1BQUlaLEVBQUVhLFdBQVdiLEVBQUVhLFFBQVFULFNBQVMsSUFBS0gsR0FBRVksVUFBVTtBQUVyRCxNQUFJYixFQUFFYyxTQUFTLFVBQVU7QUFDdkIsUUFBSSxDQUFDZCxFQUFFZSxPQUFRZCxHQUFFYyxTQUFTO0FBQUEsYUFFakIsQ0FBQyxXQUFXQyxLQUFLaEIsRUFBRWUsTUFBTSxFQUFHZCxHQUFFYyxTQUFTO0FBQ2hELFFBQUksQ0FBQ2YsRUFBRWlCLFdBQVdkLEtBQUssRUFBR0YsR0FBRWdCLGFBQWE7QUFBQSxFQUMzQztBQUNBLE1BQUksQ0FBQ2pCLEVBQUVrQixRQUFTakIsR0FBRWlCLFVBQVU7QUFDNUIsU0FBT2pCO0FBQ1Q7QUFFQSx3QkFBd0JrQixlQUFlO0FBQUFDLEtBQUE7QUFDckMsUUFBTUMsV0FBVzFDLFlBQVk7QUFDN0IsUUFBTSxDQUFDMkMsUUFBUUMsU0FBUyxJQUFJN0MsU0FBUztBQUFBLElBQ25Db0MsTUFBTTtBQUFBLElBQVNaLFVBQVU7QUFBQSxJQUFJRyxPQUFPO0FBQUEsSUFBSUMsVUFBVTtBQUFBLElBQUlDLFNBQVM7QUFBQSxJQUMvREMsS0FBSztBQUFBLElBQUlLLFNBQVM7QUFBQSxJQUFJSixVQUFVO0FBQUEsSUFBSWUsTUFBTTtBQUFBLElBQUlaLFlBQVk7QUFBQSxJQUMxREcsUUFBUTtBQUFBLElBQUlFLFlBQVk7QUFBQSxJQUFJQyxTQUFTO0FBQUEsRUFDdkMsQ0FBQztBQUNELFFBQU0sQ0FBQ08sUUFBUUMsU0FBUyxJQUFJaEQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDaUQsV0FBV0MsWUFBWSxJQUFJbEQsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ21ELFFBQVFDLFNBQVMsSUFBSXBELFNBQVMsTUFBTTtBQUUzQyxRQUFNcUQsTUFBTUEsQ0FBQ0MsTUFBTSxDQUFDL0IsTUFDbEJzQixVQUFVLENBQUN2QixPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDZ0MsQ0FBQyxHQUFHL0IsRUFBRWdDLE9BQU9DLFNBQVMsYUFBYWpDLEVBQUVnQyxPQUFPRSxVQUFVbEMsRUFBRWdDLE9BQU9HLE1BQU0sRUFBRTtBQUVwRyxRQUFNQyxXQUFXLE9BQU9wQyxNQUFNO0FBQzVCQSxNQUFFcUMsZUFBZTtBQUNqQlYsaUJBQWEsRUFBRTtBQUNmLFVBQU1XLE9BQU94QyxpQkFBaUJ1QixNQUFNO0FBQ3BDSSxjQUFVYSxJQUFJO0FBQ2QsUUFBSUMsT0FBT0MsS0FBS0YsSUFBSSxFQUFFbkMsT0FBUTtBQUU5QixVQUFNc0MsVUFBVTtBQUFBLE1BQ2R4QyxVQUFVb0IsT0FBT3BCO0FBQUFBLE1BQ2pCRyxPQUFPaUIsT0FBT2pCO0FBQUFBLE1BQ2RDLFVBQVVnQixPQUFPaEI7QUFBQUEsTUFDakJFLEtBQUtjLE9BQU9kO0FBQUFBLE1BQ1pLLFNBQVNTLE9BQU9UO0FBQUFBLE1BQ2hCSixVQUFVYSxPQUFPYjtBQUFBQSxNQUNqQkMsVUFBVVksT0FBT1o7QUFBQUEsTUFDakJDLGFBQWFXLE9BQU9YO0FBQUFBLE1BQ3BCQyxZQUFZVSxPQUFPVjtBQUFBQSxNQUNuQkUsTUFBTVEsT0FBT1I7QUFBQUEsTUFDYkksU0FBU0ksT0FBT0o7QUFBQUEsTUFDaEIsR0FBSUksT0FBT1IsU0FBUyxXQUNoQixFQUFFQyxRQUFRTyxPQUFPUCxRQUFRRSxZQUFZSyxPQUFPTCxXQUFXLElBQ3ZELENBQUM7QUFBQSxJQUNQO0FBRUFhLGNBQVUsWUFBWTtBQUN0QixRQUFJO0FBQ0YsWUFBTWhELElBQUk2RCxLQUFLLGtCQUFrQkQsT0FBTztBQUN4QzdELFlBQU0sb0NBQW9DO0FBQzFDd0MsZUFBUyxRQUFRO0FBQUEsSUFDbkIsU0FBU3VCLEtBQUs7QUFFWixZQUFNZixVQUFTZSxJQUFJQyxVQUFVaEI7QUFDN0IsWUFBTWlCLE9BQU9GLElBQUlDLFVBQVVDO0FBRTNCLFVBQUlqQixZQUFXLE9BQU9pQixNQUFNQyxVQUFVLG9CQUFvQjtBQUN4RHJCLGtCQUFVYyxPQUFPUTtBQUFBQSxXQUNkRixLQUFLckIsVUFBVSxJQUFJd0IsSUFBSSxDQUFDQyxNQUFNLENBQUNBLEVBQUVDLE9BQU9ELEVBQUVFLE9BQU8sQ0FBQztBQUFBLFFBQ3JELENBQUM7QUFBQSxNQUNILFdBQVd2QixZQUFXLEtBQUs7QUFDekIsWUFBSWlCLE1BQU1DLFVBQVUsbUJBQW1CO0FBQ3JDckIsb0JBQVUsRUFBRXJCLE9BQU8sd0JBQXdCLENBQUM7QUFBQSxRQUM5QyxXQUFXeUMsTUFBTUMsVUFBVSxzQkFBc0I7QUFDL0MsY0FBSU0sTUFBTUMsUUFBUVIsTUFBTXJCLE1BQU0sR0FBRztBQUMvQkMsc0JBQVVjLE9BQU9RLFlBQVlGLEtBQUtyQixPQUFPd0IsSUFBSSxDQUFDQyxNQUFNLENBQUNBLEVBQUVDLE9BQU9ELEVBQUVFLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFBQSxVQUM1RSxPQUFPO0FBQ0wxQixzQkFBVSxFQUFFeEIsVUFBVSw2QkFBNkIsQ0FBQztBQUFBLFVBQ3REO0FBQUEsUUFDRixPQUFPO0FBQ0wwQix1QkFBYSw4QkFBOEI7QUFBQSxRQUM3QztBQUFBLE1BQ0YsV0FBV0MsV0FBVSxLQUFLO0FBQ3hCaEQsY0FBTSxxREFBcUQsTUFBTTtBQUFBLE1BQ25FLE9BQU87QUFDTCtDLHFCQUFhLHFDQUFxQztBQUFBLE1BQ3BEO0FBQUEsSUFDRixVQUFDO0FBQ0NFLGdCQUFVLE1BQU07QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDJCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsSUFDTCx1QkFBQyxRQUFHLFdBQVUsY0FBYSxtQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUFBLElBQzlDLHVCQUFDLE9BQUUsV0FBVSxZQUFXLDhDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNEO0FBQUEsSUFFckRILGFBQWEsdUJBQUMsZUFBWSxNQUFLLFNBQVNBLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFbkQsdUJBQUMsVUFBSyxVQUFvQixZQUFVLE1BQ2xDO0FBQUEsNkJBQUMsYUFBVSxPQUFPTCxPQUFPUixNQUFNLFVBQVUsQ0FBQ3lDLE1BQU1oQyxVQUFVLENBQUN2QixPQUFPLEVBQUUsR0FBR0EsR0FBR2MsTUFBTXlDLEVBQUUsRUFBRSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNGO0FBQUEsTUFFdEYsdUJBQUMsU0FBSSxXQUFVLFVBQ2Y7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQVUsT0FBTyx1QkFBQyxPQUFJLDBCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUFRLGFBQVk7QUFBQSxZQUNuRCxPQUFPakMsT0FBT3BCO0FBQUFBLFlBQVUsVUFBVTZCLElBQUksVUFBVTtBQUFBLFlBQUcsT0FBT04sT0FBT3ZCO0FBQUFBO0FBQUFBLFVBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUM0RTtBQUFBLFFBQzVFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBVSxPQUFPLHVCQUFDLE9BQUkscUJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVTtBQUFBLFlBQVEsYUFBWTtBQUFBLFlBQzlDLE9BQU9vQixPQUFPakI7QUFBQUEsWUFBTyxVQUFVMEIsSUFBSSxPQUFPO0FBQUEsWUFBRyxPQUFPTixPQUFPcEI7QUFBQUE7QUFBQUEsVUFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ21FO0FBQUEsUUFDbkU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFjLE9BQU8sdUJBQUMsT0FBSSx3QkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhO0FBQUEsWUFBUSxhQUFZO0FBQUEsWUFDckQsT0FBT2lCLE9BQU9oQjtBQUFBQSxZQUFVLFVBQVV5QixJQUFJLFVBQVU7QUFBQSxZQUFHLE9BQU9OLE9BQU9uQjtBQUFBQTtBQUFBQSxVQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDNEU7QUFBQSxRQUM1RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQWMsT0FBTyx1QkFBQyxPQUFJLDhCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CO0FBQUEsWUFBUSxhQUFZO0FBQUEsWUFDM0QsT0FBT2dCLE9BQU9mO0FBQUFBLFlBQVMsVUFBVXdCLElBQUksU0FBUztBQUFBLFlBQUcsT0FBT04sT0FBT2xCO0FBQUFBO0FBQUFBLFVBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUN5RTtBQUFBLFFBQ3pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBVSxPQUFPLHVCQUFDLE9BQUksd0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBLFlBQVEsYUFBWTtBQUFBLFlBQ2pELE9BQU9lLE9BQU9kO0FBQUFBLFlBQUssVUFBVXVCLElBQUksS0FBSztBQUFBLFlBQUcsT0FBT04sT0FBT2pCO0FBQUFBO0FBQUFBLFVBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUM2RDtBQUFBLFFBRTdEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFBVSxPQUFNO0FBQUEsWUFBNkIsYUFBWTtBQUFBLFlBQ3hELE9BQU9jLE9BQU9UO0FBQUFBLFlBQVMsVUFBVWtCLElBQUksU0FBUztBQUFBLFlBQUcsT0FBT04sT0FBT1o7QUFBQUE7QUFBQUEsVUFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ3lFO0FBQUEsV0FiekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNGO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT1M7QUFBQUEsVUFDUCxVQUFVLENBQUNrQyxVQUFVakMsVUFBVSxDQUFDdkIsT0FBTyxFQUFFLEdBQUdBLEdBQUcsR0FBR3dELE1BQU0sRUFBRTtBQUFBLFVBQzFEO0FBQUE7QUFBQSxRQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdpQjtBQUFBLE1BR2hCbEMsT0FBT1IsU0FBUyxZQUNmLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFVLE9BQU8sdUJBQUMsT0FBSSx3Q0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQVEsYUFBWTtBQUFBLFlBQ2pFLE9BQU9RLE9BQU9QO0FBQUFBLFlBQVEsVUFBVWdCLElBQUksUUFBUTtBQUFBLFlBQUcsT0FBT04sT0FBT1Y7QUFBQUE7QUFBQUEsVUFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQ3NFO0FBQUEsUUFDdEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUFVLE9BQU8sdUJBQUMsT0FBSSxzQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQVEsYUFBWTtBQUFBLFlBQy9ELE9BQU9PLE9BQU9MO0FBQUFBLFlBQVksVUFBVWMsSUFBSSxZQUFZO0FBQUEsWUFBRyxPQUFPTixPQUFPUjtBQUFBQTtBQUFBQSxVQUR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDa0Y7QUFBQSxXQUpwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUdGLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLFlBQ2Y7QUFBQSxpQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTSyxPQUFPSixTQUFTLFVBQVVhLElBQUksU0FBUyxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQTJELHVCQUFDLFVBQUssV0FBVSxPQUFNLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLGVBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsYUFGakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ04sT0FBT1AsV0FBVyx1QkFBQyxTQUFJLFdBQVUsZUFBZU8saUJBQU9QLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUVFLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVNXLFdBQVcsY0FBYywyQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLFNBMUNyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxTQUFRLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsTUFDcEMsdUJBQUMsUUFBSyxJQUFHLFVBQVMsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxTQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMERBLEtBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0REE7QUFFSjtBQUFDVCxHQXpJdUJELGNBQVk7QUFBQSxVQUNqQnhDLFdBQVc7QUFBQTtBQUFBLE1BRE53QztBQUFZLElBQUFyQixJQUFBMkQ7QUFBQSxhQUFBM0QsSUFBQTtBQUFBLGFBQUEyRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmsiLCJ0b2FzdCIsImFwaSIsImlzRW1haWwiLCJpc1RlbCIsImlzUG9zdGFsIiwiaXNUaGFpSWQiLCJwYXNzd29yZE9rIiwiaXNVc2VybmFtZSIsIkxvZ28iLCJUZXh0SW5wdXQiLCJQYXNzd29yZElucHV0IiwiQnV0dG9uIiwiQWxlcnRCYW5uZXIiLCJSb2xlUGlsbHMiLCJUaGFpQWRkcmVzc1NlbGVjdHMiLCJSZXEiLCJjaGlsZHJlbiIsIl9jIiwidmFsaWRhdGVSZWdpc3RlciIsInYiLCJlIiwidXNlcm5hbWUiLCJ0cmltIiwibGVuZ3RoIiwiZW1haWwiLCJwYXNzd29yZCIsImNvbmZpcm0iLCJ0ZWwiLCJwcm92aW5jZSIsImRpc3RyaWN0Iiwic3ViZGlzdHJpY3QiLCJwb3N0YWxDb2RlIiwiYWRkcmVzcyIsInJvbGUiLCJ0aGFpSWQiLCJ0ZXN0IiwiZXhwZXJpZW5jZSIsImNvbnNlbnQiLCJSZWdpc3RlclBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwidmFsdWVzIiwic2V0VmFsdWVzIiwiY2l0eSIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsInN0YXR1cyIsInNldFN0YXR1cyIsInNldCIsImsiLCJ0YXJnZXQiLCJ0eXBlIiwiY2hlY2tlZCIsInZhbHVlIiwib25TdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImVycnMiLCJPYmplY3QiLCJrZXlzIiwicGF5bG9hZCIsInBvc3QiLCJlcnIiLCJyZXNwb25zZSIsImRhdGEiLCJlcnJvciIsImZyb21FbnRyaWVzIiwibWFwIiwieCIsImZpZWxkIiwibWVzc2FnZSIsIkFycmF5IiwiaXNBcnJheSIsInIiLCJwYXRjaCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWdpc3RlclBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCIuLi91dGlscy90b2FzdC5qc1wiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaS5qc1wiO1xuaW1wb3J0IHsgaXNFbWFpbCwgaXNUZWwsIGlzUG9zdGFsLCBpc1RoYWlJZCwgcGFzc3dvcmRPaywgaXNVc2VybmFtZSB9IGZyb20gXCIuLi91dGlscy92YWxpZGF0b3JzLmpzXCI7XG5pbXBvcnQgTG9nbyBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9Mb2dvLmpzeFwiO1xuaW1wb3J0IFRleHRJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9UZXh0SW5wdXQuanN4XCI7XG5pbXBvcnQgUGFzc3dvcmRJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9QYXNzd29yZElucHV0LmpzeFwiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9CdXR0b24uanN4XCI7XG5pbXBvcnQgQWxlcnRCYW5uZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQWxlcnRCYW5uZXIuanN4XCI7XG5pbXBvcnQgUm9sZVBpbGxzIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL1JvbGVQaWxscy5qc3hcIjtcbmltcG9ydCBUaGFpQWRkcmVzc1NlbGVjdHMgZnJvbSBcIi4uL2NvbXBvbmVudHMvVGhhaUFkZHJlc3NTZWxlY3RzLmpzeFwiO1xuXG5jb25zdCBSZXEgPSAoeyBjaGlsZHJlbiB9KSA9PiAoXG4gIDw+e2NoaWxkcmVufSA8c3BhbiBjbGFzc05hbWU9XCJyZXFcIj4qPC9zcGFuPjwvPlxuKTtcblxuZnVuY3Rpb24gdmFsaWRhdGVSZWdpc3Rlcih2KSB7XG4gIGNvbnN0IGUgPSB7fTtcbiAgaWYgKCF2LnVzZXJuYW1lLnRyaW0oKSkgZS51c2VybmFtZSA9IFwi4LiB4Lij4Li44LiT4Liy4LiB4Lij4Lit4LiB4LiK4Li34LmI4Lit4Lic4Li54LmJ4LmD4LiK4LmJXCI7XG4gIGVsc2UgaWYgKCFpc1VzZXJuYW1lKHYudXNlcm5hbWUpKSBlLnVzZXJuYW1lID0gXCLguIrguLfguYjguK3guJzguLnguYnguYPguIrguYnguJXguYnguK3guIfguKLguLLguKfguK3guKLguYjguLLguIfguJnguYnguK3guKIgMyDguJXguLHguKfguK3guLHguIHguKnguKNcIjtcbiAgZWxzZSBpZiAodi51c2VybmFtZS5sZW5ndGggPiA1MCkgZS51c2VybmFtZSA9IFwi4LiK4Li34LmI4Lit4Lic4Li54LmJ4LmD4LiK4LmJ4LiV4LmJ4Lit4LiH4LmE4Lih4LmI4LmA4LiB4Li04LiZIDUwIOC4leC4seC4p+C4reC4seC4geC4qeC4o1wiO1xuXG4gIGlmICghdi5lbWFpbC50cmltKCkpIGUuZW1haWwgPSBcIuC4geC4o+C4uOC4k+C4suC4geC4o+C4reC4geC4reC4teC5gOC4oeC4pVwiO1xuICBlbHNlIGlmICghaXNFbWFpbCh2LmVtYWlsKSkgZS5lbWFpbCA9IFwi4Lij4Li54Lib4LmB4Lia4Lia4Lit4Li14LmA4Lih4Lil4LmE4Lih4LmI4LiW4Li54LiB4LiV4LmJ4Lit4LiHXCI7XG5cbiAgaWYgKCF2LnBhc3N3b3JkKSBlLnBhc3N3b3JkID0gXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguKPguKvguLHguKrguJzguYjguLLguJlcIjtcbiAgZWxzZSBpZiAoIXBhc3N3b3JkT2sodi5wYXNzd29yZCkpIGUucGFzc3dvcmQgPSBcIuC4o+C4q+C4seC4quC4nOC5iOC4suC4meC4leC5ieC4reC4h+C4oeC4teC4reC4ouC5iOC4suC4h+C4meC5ieC4reC4oiA4IOC4leC4seC4p+C4reC4seC4geC4qeC4oyDguJvguKPguLDguIHguK3guJrguJTguYnguKfguKLguK3guLHguIHguKnguKPguYHguKXguLDguJXguLHguKfguYDguKXguIJcIjtcblxuICBpZiAoIXYuY29uZmlybSB8fCB2LmNvbmZpcm0gIT09IHYucGFzc3dvcmQpIGUuY29uZmlybSA9IFwi4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4LmE4Lih4LmI4LiV4Lij4LiH4LiB4Lix4LiZXCI7XG5cbiAgaWYgKCF2LnRlbC50cmltKCkpIGUudGVsID0gXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguYDguJrguK3guKPguYzguYLguJfguKNcIjtcbiAgZWxzZSBpZiAoIWlzVGVsKHYudGVsKSkgZS50ZWwgPSBcIuC5gOC4muC4reC4o+C5jOC5guC4l+C4o+C4leC5ieC4reC4h+C4guC4tuC5ieC4meC4leC5ieC4meC4lOC5ieC4p+C4oiAwIOC5geC4peC4sOC4ouC4suC4pyAxMCDguKvguKXguLHguIFcIjtcblxuICBpZiAoIXYucHJvdmluY2UpIGUucHJvdmluY2UgPSBcIuC4geC4o+C4uOC4k+C4suC5gOC4peC4t+C4reC4geC4iOC4seC4h+C4q+C4p+C4seC4lFwiO1xuXG4gIGlmICghdi5kaXN0cmljdCkgZS5kaXN0cmljdCA9IFwi4LiB4Lij4Li44LiT4Liy4LmA4Lil4Li34Lit4LiB4Lit4Liz4LmA4Lig4LitL+C5gOC4guC4lVwiO1xuXG4gIGlmICghdi5zdWJkaXN0cmljdCkgZS5zdWJkaXN0cmljdCA9IFwi4LiB4Lij4Li44LiT4Liy4LmA4Lil4Li34Lit4LiB4LiV4Liz4Lia4LilL+C5geC4guC4p+C4h1wiO1xuICBcbiAgaWYgKCF2LnBvc3RhbENvZGUpIGUucG9zdGFsQ29kZSA9IFwi4LiB4Lij4Li44LiT4Liy4LmA4Lil4Li34Lit4LiB4LiV4Liz4Lia4LilL+C5geC4guC4p+C4hyDguYDguJ7guLfguYjguK3guYPguKvguYnguKPguLDguJrguJrguYDguJXguLTguKHguKPguKvguLHguKrguYTguJvguKPguKnguJPguLXguKLguYxcIjtcblxuICBpZiAodi5hZGRyZXNzICYmIHYuYWRkcmVzcy5sZW5ndGggPiAyMDApIGUuYWRkcmVzcyA9IFwi4LiX4Li14LmI4Lit4Lii4Li54LmI4LiV4LmJ4Lit4LiH4LmE4Lih4LmI4LmA4LiB4Li04LiZIDIwMCDguJXguLHguKfguK3guLHguIHguKnguKNcIjtcblxuICBpZiAodi5yb2xlID09PSBcInNpdHRlclwiKSB7XG4gICAgaWYgKCF2LnRoYWlJZCkgZS50aGFpSWQgPSBcIuC4geC4o+C4uOC4k+C4suC4geC4o+C4reC4geC5gOC4peC4guC4muC4seC4leC4o+C4m+C4o+C4sOC4iuC4suC4iuC4mVwiO1xuICAgIC8vIOC5g+C4iuC5iSByZWdleCAxMyDguKvguKXguLHguIHguJ7guK0g4LmA4Lie4Lij4Liy4LiwIGJhY2tlbmQg4LiI4Lix4LiU4LiB4Liy4LijIE1vZHVsbyAxMSDguYPguKvguYnguYHguKXguYnguKdcbiAgICBlbHNlIGlmICghL15cXGR7MTN9JC8udGVzdCh2LnRoYWlJZCkpIGUudGhhaUlkID0gXCLguYDguKXguILguJrguLHguJXguKPguJvguKPguLDguIrguLLguIrguJnguJXguYnguK3guIfguYDguJvguYfguJnguJXguLHguKfguYDguKXguIIgMTMg4Lir4Lil4Lix4LiBXCI7XG4gICAgaWYgKCF2LmV4cGVyaWVuY2UudHJpbSgpKSBlLmV4cGVyaWVuY2UgPSBcIuC4geC4o+C4uOC4k+C4suC4geC4o+C4reC4geC4m+C4o+C4sOC4quC4muC4geC4suC4o+C4k+C5jFwiO1xuICB9XG4gIGlmICghdi5jb25zZW50KSBlLmNvbnNlbnQgPSBcIuC4geC4o+C4uOC4k+C4suC4ouC4tOC4meC4ouC4reC4oeC4geC5iOC4reC4meC4quC4oeC4seC4hOC4o+C4quC4oeC4suC4iuC4tOC4gVwiO1xuICByZXR1cm4gZTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVnaXN0ZXJQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IFt2YWx1ZXMsIHNldFZhbHVlc10gPSB1c2VTdGF0ZSh7XG4gICAgcm9sZTogXCJvd25lclwiLCB1c2VybmFtZTogXCJcIiwgZW1haWw6IFwiXCIsIHBhc3N3b3JkOiBcIlwiLCBjb25maXJtOiBcIlwiLFxuICAgIHRlbDogXCJcIiwgYWRkcmVzczogXCJcIiwgcHJvdmluY2U6IFwiXCIsIGNpdHk6IFwiXCIsIHBvc3RhbENvZGU6IFwiXCIsXG4gICAgdGhhaUlkOiBcIlwiLCBleHBlcmllbmNlOiBcIlwiLCBjb25zZW50OiBmYWxzZSxcbiAgfSk7XG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IFtmb3JtRXJyb3IsIHNldEZvcm1FcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFwiaWRsZVwiKTtcblxuICBjb25zdCBzZXQgPSAoaykgPT4gKGUpID0+XG4gICAgc2V0VmFsdWVzKCh2KSA9PiAoeyAuLi52LCBba106IGUudGFyZ2V0LnR5cGUgPT09IFwiY2hlY2tib3hcIiA/IGUudGFyZ2V0LmNoZWNrZWQgOiBlLnRhcmdldC52YWx1ZSB9KSk7XG5cbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRGb3JtRXJyb3IoXCJcIik7XG4gICAgY29uc3QgZXJycyA9IHZhbGlkYXRlUmVnaXN0ZXIodmFsdWVzKTtcbiAgICBzZXRFcnJvcnMoZXJycyk7XG4gICAgaWYgKE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCkgcmV0dXJuO1xuXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgIHVzZXJuYW1lOiB2YWx1ZXMudXNlcm5hbWUsXG4gICAgICBlbWFpbDogdmFsdWVzLmVtYWlsLFxuICAgICAgcGFzc3dvcmQ6IHZhbHVlcy5wYXNzd29yZCxcbiAgICAgIHRlbDogdmFsdWVzLnRlbCxcbiAgICAgIGFkZHJlc3M6IHZhbHVlcy5hZGRyZXNzLFxuICAgICAgcHJvdmluY2U6IHZhbHVlcy5wcm92aW5jZSxcbiAgICAgIGRpc3RyaWN0OiB2YWx1ZXMuZGlzdHJpY3QsICAgICAgICAgIFxuICAgICAgc3ViZGlzdHJpY3Q6IHZhbHVlcy5zdWJkaXN0cmljdCwgICAgXG4gICAgICBwb3N0YWxDb2RlOiB2YWx1ZXMucG9zdGFsQ29kZSxcbiAgICAgIHJvbGU6IHZhbHVlcy5yb2xlLFxuICAgICAgY29uc2VudDogdmFsdWVzLmNvbnNlbnQsXG4gICAgICAuLi4odmFsdWVzLnJvbGUgPT09IFwic2l0dGVyXCJcbiAgICAgICAgPyB7IHRoYWlJZDogdmFsdWVzLnRoYWlJZCwgZXhwZXJpZW5jZTogdmFsdWVzLmV4cGVyaWVuY2UgfVxuICAgICAgICA6IHt9KSxcbiAgICB9O1xuXG4gICAgc2V0U3RhdHVzKFwic3VibWl0dGluZ1wiKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvYXV0aC9yZWdpc3RlclwiLCBwYXlsb2FkKTtcbiAgICAgIHRvYXN0KFwi4Liq4Lih4Lix4LiE4Lij4Liq4Lih4Liy4LiK4Li04LiB4Liq4Liz4LmA4Lij4LmH4LiIIOC4geC4o+C4uOC4k+C4suC5gOC4guC5ieC4suC4quC4ueC5iOC4o+C4sOC4muC4mlwiKTtcbiAgICAgIG5hdmlnYXRlKFwiL2xvZ2luXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8g8J+RhyDguJTguLbguIcgc3RhdHVzIOC5geC4peC4sCBkYXRhIOC4iOC4suC4gSBBeGlvcyBlcnJvciByZXNwb25zZVxuICAgICAgY29uc3Qgc3RhdHVzID0gZXJyLnJlc3BvbnNlPy5zdGF0dXM7XG4gICAgICBjb25zdCBkYXRhID0gZXJyLnJlc3BvbnNlPy5kYXRhO1xuICAgICAgXG4gICAgICBpZiAoc3RhdHVzID09PSA0MDAgJiYgZGF0YT8uZXJyb3IgPT09IFwiVkFMSURBVElPTl9FUlJPUlwiKSB7XG4gICAgICAgIHNldEVycm9ycyhPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgICAgICAgKGRhdGEuZXJyb3JzIHx8IFtdKS5tYXAoKHgpID0+IFt4LmZpZWxkLCB4Lm1lc3NhZ2VdKVxuICAgICAgICApKTtcbiAgICAgIH0gZWxzZSBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgaWYgKGRhdGE/LmVycm9yID09PSBcIkVNQUlMX0RVUExJQ0FURVwiKSB7XG4gICAgICAgICAgc2V0RXJyb3JzKHsgZW1haWw6IFwi4Lit4Li14LmA4Lih4Lil4LiZ4Li14LmJ4LiW4Li54LiB4LmD4LiK4LmJ4LiH4Liy4LiZ4LmB4Lil4LmJ4LinXCIgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZGF0YT8uZXJyb3IgPT09IFwiVVNFUk5BTUVfRFVQTElDQVRFXCIpIHtcbiAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhPy5lcnJvcnMpKSB7XG4gICAgICAgICAgICBzZXRFcnJvcnMoT2JqZWN0LmZyb21FbnRyaWVzKGRhdGEuZXJyb3JzLm1hcCgoeCkgPT4gW3guZmllbGQsIHgubWVzc2FnZV0pKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEVycm9ycyh7IHVzZXJuYW1lOiBcIuC4iuC4t+C5iOC4reC4nOC4ueC5ieC5g+C4iuC5ieC4meC4teC5ieC4luC4ueC4geC5g+C4iuC5ieC4h+C4suC4meC5geC4peC5ieC4p1wiIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRGb3JtRXJyb3IoXCLguILguYnguK3guKHguLnguKXguJnguLXguYnguJbguLnguIHguYPguIrguYnguIfguLLguJnguYHguKXguYnguKfguYPguJnguKPguLDguJrguJpcIik7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoc3RhdHVzID49IDUwMCkge1xuICAgICAgICB0b2FzdChcIuC5gOC4geC4tOC4lOC4guC5ieC4reC4nOC4tOC4lOC4nuC4peC4suC4lOC4iOC4suC4geC5gOC4i+C4tOC4o+C5jOC4n+C5gOC4p+C4reC4o+C5jCDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIiwgXCJpbmZvXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0Rm9ybUVycm9yKFwi4LmA4LiB4Li04LiU4LiC4LmJ4Lit4Lic4Li04LiU4Lie4Lil4Liy4LiUIOC4geC4o+C4uOC4k+C4suC4peC4reC4h+C5g+C4q+C4oeC5iOC4reC4teC4geC4hOC4o+C4seC5ieC4h1wiKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtcGFnZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNhcmQgYXV0aC1jYXJkLS13aWRlXCI+XG4gICAgICAgIDxMb2dvIC8+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJhdXRoLXRpdGxlXCI+4Liq4Lij4LmJ4Liy4LiH4Lia4Lix4LiN4LiK4Li1IFBldEJ1ZGR5PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJcIj7guYDguILguYnguLLguKPguYjguKfguKHguYDguJvguYfguJnguITguKPguK3guJrguITguKPguLHguKfguITguJnguKPguLHguIHguKrguLHguJXguKfguYw8L3A+XG4gICAgICAgIFxuICAgICAgICB7Zm9ybUVycm9yICYmIDxBbGVydEJhbm5lciB0eXBlPVwiZXJyb3JcIj57Zm9ybUVycm9yfTwvQWxlcnRCYW5uZXI+fVxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtvblN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICA8Um9sZVBpbGxzIHZhbHVlPXt2YWx1ZXMucm9sZX0gb25DaGFuZ2U9eyhyKSA9PiBzZXRWYWx1ZXMoKHYpID0+ICh7IC4uLnYsIHJvbGU6IHIgfSkpfSAvPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkLTJcIj5cbiAgICAgICAgICA8VGV4dElucHV0IGxhYmVsPXs8UmVxPuC4iuC4t+C5iOC4reC4nOC4ueC5ieC5g+C4iuC5iTwvUmVxPn0gcGxhY2Vob2xkZXI9XCLguYDguIrguYjguJkgVGFuSU5XWkFcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy51c2VybmFtZX0gb25DaGFuZ2U9e3NldChcInVzZXJuYW1lXCIpfSBlcnJvcj17ZXJyb3JzLnVzZXJuYW1lfSAvPlxuICAgICAgICAgIDxUZXh0SW5wdXQgbGFiZWw9ezxSZXE+4Lit4Li14LmA4Lih4LilPC9SZXE+fSBwbGFjZWhvbGRlcj1cInlvdUBleGFtcGxlLmNvbVwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWVzLmVtYWlsfSBvbkNoYW5nZT17c2V0KFwiZW1haWxcIil9IGVycm9yPXtlcnJvcnMuZW1haWx9IC8+XG4gICAgICAgICAgPFBhc3N3b3JkSW5wdXQgbGFiZWw9ezxSZXE+4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZPC9SZXE+fSBwbGFjZWhvbGRlcj1cIuC4reC4ouC5iOC4suC4h+C4meC5ieC4reC4oiA4IOC4leC4seC4pyDguKHguLXguK3guLHguIHguKnguKMr4LiV4Lix4Lin4LmA4Lil4LiCXCJcbiAgICAgICAgICAgIHZhbHVlPXt2YWx1ZXMucGFzc3dvcmR9IG9uQ2hhbmdlPXtzZXQoXCJwYXNzd29yZFwiKX0gZXJyb3I9e2Vycm9ycy5wYXNzd29yZH0gLz5cbiAgICAgICAgICA8UGFzc3dvcmRJbnB1dCBsYWJlbD17PFJlcT7guKLguLfguJnguKLguLHguJnguKPguKvguLHguKrguJzguYjguLLguJk8L1JlcT59IHBsYWNlaG9sZGVyPVwi4LiB4Lij4Lit4LiB4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCJcbiAgICAgICAgICAgIHZhbHVlPXt2YWx1ZXMuY29uZmlybX0gb25DaGFuZ2U9e3NldChcImNvbmZpcm1cIil9IGVycm9yPXtlcnJvcnMuY29uZmlybX0gLz5cbiAgICAgICAgICA8VGV4dElucHV0IGxhYmVsPXs8UmVxPuC5gOC4muC4reC4o+C5jOC5guC4l+C4ozwvUmVxPn0gcGxhY2Vob2xkZXI9XCIwOTg4ODg4ODg4XCJcbiAgICAgICAgICAgIHZhbHVlPXt2YWx1ZXMudGVsfSBvbkNoYW5nZT17c2V0KFwidGVsXCIpfSBlcnJvcj17ZXJyb3JzLnRlbH0gLz5cbiAgICAgICAgICB7Lyog8J+RhyDguIrguYjguK3guIfguJnguLXguYkgXCLguYTguKHguYjguKHguLXguJTguLLguKdcIiDguYDguJ7guKPguLLguLDguYDguJvguYfguJnguJ/guLTguKXguJTguYzguJfguLLguIfguYDguKXguLfguK3guIEgKi99XG4gICAgICAgICAgPFRleHRJbnB1dCBsYWJlbD1cIuC4l+C4teC5iOC4reC4ouC4ueC5iCAo4Lia4LmJ4Liy4LiZ4LmA4Lil4LiC4LiX4Li14LmIIC8g4LiW4LiZ4LiZKVwiIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIDk5LzEyIOC4q+C4oeC4ueC5iCA1IOC4li7guJ7guKvguKXguYLguKLguJjguLTguJlcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy5hZGRyZXNzfSBvbkNoYW5nZT17c2V0KFwiYWRkcmVzc1wiKX0gZXJyb3I9e2Vycm9ycy5hZGRyZXNzfSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8VGhhaUFkZHJlc3NTZWxlY3RzXG4gICAgICAgICAgdmFsdWU9e3ZhbHVlc31cbiAgICAgICAgICBvbkNoYW5nZT17KHBhdGNoKSA9PiBzZXRWYWx1ZXMoKHYpID0+ICh7IC4uLnYsIC4uLnBhdGNoIH0pKX1cbiAgICAgICAgICBlcnJvcnM9e2Vycm9yc31cbiAgICAgICAgLz5cblxuICAgICAgICB7dmFsdWVzLnJvbGUgPT09IFwic2l0dGVyXCIgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZC0yXCI+XG4gICAgICAgICAgICA8VGV4dElucHV0IGxhYmVsPXs8UmVxPuC5gOC4peC4guC4muC4seC4leC4o+C4m+C4o+C4sOC4iuC4suC4iuC4mSAoMTMg4Lir4Lil4Lix4LiBKTwvUmVxPn0gcGxhY2Vob2xkZXI9XCIxMTAxNjAxODA1MDU3XCJcbiAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy50aGFpSWR9IG9uQ2hhbmdlPXtzZXQoXCJ0aGFpSWRcIil9IGVycm9yPXtlcnJvcnMudGhhaUlkfSAvPlxuICAgICAgICAgICAgPFRleHRJbnB1dCBsYWJlbD17PFJlcT7guJvguKPguLDguKrguJrguIHguLLguKPguJPguYzguIHguLLguKPguJTguLnguYHguKXguKrguLHguJXguKfguYw8L1JlcT59IHBsYWNlaG9sZGVyPVwi4LmA4Lil4LmI4Liy4Lib4Lij4Liw4Liq4Lia4LiB4Liy4Lij4LiT4LmM4LiC4Lit4LiH4LiE4Li44LiTXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy5leHBlcmllbmNlfSBvbkNoYW5nZT17c2V0KFwiZXhwZXJpZW5jZVwiKX0gZXJyb3I9e2Vycm9ycy5leHBlcmllbmNlfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmllbGRcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY2hlY2tib3hcIj5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXt2YWx1ZXMuY29uc2VudH0gb25DaGFuZ2U9e3NldChcImNvbnNlbnRcIil9IC8+XG4gICAgICAgICAgICA8c3Bhbj7guKLguLTguJnguKLguK3guKHguYPguKvguYnguYDguIHguYfguJrguYHguKXguLDguYPguIrguYnguILguYnguK3guKHguLnguKXguKrguYjguKfguJnguJrguLjguITguITguKXguJXguLLguKHguJnguYLguKLguJrguLLguKLguITguKfguLLguKHguYDguJvguYfguJnguKrguYjguKfguJnguJXguLHguKcgPHNwYW4gY2xhc3NOYW1lPVwicmVxXCI+Kjwvc3Bhbj48L3NwYW4+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICB7ZXJyb3JzLmNvbnNlbnQgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMuY29uc2VudH08L2Rpdj59XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBsb2FkaW5nPXtzdGF0dXMgPT09IFwic3VibWl0dGluZ1wifT7guKrguKHguLHguITguKPguKrguKHguLLguIrguLTguIE8L0J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWxpbmtzXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXV0ZWRcIj7guKHguLXguJrguLHguI3guIrguLXguYHguKXguYnguKc/PC9zcGFuPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCI+4LmA4LiC4LmJ4Liy4Liq4Li54LmI4Lij4Liw4Lia4LiaPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICBcbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlZ2lzdGVyUGFnZS5qc3gifQ==