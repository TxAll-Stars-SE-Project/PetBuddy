import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/ServiceCardSkeleton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import Skeleton from "/src/components/ui/Skeleton.jsx";
export default function ServiceCardSkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white border-2 border-slate-200 rounded-2xl p-5 custom-shadow flex flex-col space-y-3 min-h-[220px] animate-pulse", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-6 w-20 rounded-lg" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-24 rounded-full" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-[70px] space-y-2", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-3/4" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-7 w-28" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 min-h-[32px]", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-6 w-14 rounded-lg" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-6 w-14 rounded-lg" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-[44px] space-y-1.5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 w-full bg-slate-100 rounded" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 w-2/3 bg-slate-100 rounded" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-auto flex items-center gap-2 pt-3 border-t border-slate-100", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "flex-1 h-8 rounded-xl" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 63,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-8 w-12 rounded-xl" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_c = ServiceCardSkeleton;
var _c;
$RefreshReg$(_c, "ServiceCardSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/ServiceCardSkeleton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBbkJSLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQWFyQix3QkFBd0JDLHNCQUFzQjtBQUM1QyxTQUNFLHVCQUFDLFNBQUksV0FBVSx3SEFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLFlBQVMsV0FBVSx5QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLE1BQ3pDLHVCQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLFNBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsNkJBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUMvQix1QkFBQyxZQUFTLFdBQVUsY0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLFNBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsWUFBUyxXQUFVLHlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFDekMsdUJBQUMsWUFBUyxXQUFVLHlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLE1BQ2xELHVCQUFDLFNBQUksV0FBVSxzQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsU0FGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSw2QkFBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUMzQyx1QkFBQyxZQUFTLFdBQVUseUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEJBO0FBRUo7QUFBQ0MsS0FsQ3VCRDtBQUFtQixJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNrZWxldG9uIiwiU2VydmljZUNhcmRTa2VsZXRvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VDYXJkU2tlbGV0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBTa2VsZXRvbiBmcm9tIFwiLi9Ta2VsZXRvbi5qc3hcIjtcblxuLyoqXG4gKiBTZXJ2aWNlQ2FyZFNrZWxldG9uIENvbXBvbmVudFxuICogXG4gKiBSZXVzYWJsZSBzaGltbWVyIHBsYWNlaG9sZGVyIGZvciBhbiBpbmRpdmlkdWFsIFNlcnZpY2UgQ2FyZC5cbiAqIE1haW50YWlucyBsb2NrZWQgem9uZSBoZWlnaHRzIHRvIHByZXNlcnZlIGdyaWQgc3ltbWV0cnkgd2l0aG91dCBsYXlvdXQgc2hpZnRzOlxuICogLSBab25lIDE6IEJhZGdlICYgU3RhdHVzXG4gKiAtIFpvbmUgMjogVGl0bGUgJiBQcmljZSAobWluLWgtWzcwcHhdKVxuICogLSBab25lIDM6IFNwZWNpZXMgQ2hpcHMgKG1pbi1oLVszMnB4XSlcbiAqIC0gWm9uZSA0OiBEZXNjcmlwdGlvbiAobWluLWgtWzQ0cHhdKVxuICogLSBab25lIDU6IEFjdGlvbiBidXR0b25zIChtdC1hdXRvKVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlQ2FyZFNrZWxldG9uKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLTJ4bCBwLTUgY3VzdG9tLXNoYWRvdyBmbGV4IGZsZXgtY29sIHNwYWNlLXktMyBtaW4taC1bMjIwcHhdIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgIHsvKiBab25lIDE6IEJhZGdlICYgU3RhdHVzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNiB3LTIwIHJvdW5kZWQtbGdcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctMjQgcm91bmRlZC1mdWxsXCIgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogWm9uZSAyOiBUaXRsZSAmIFByaWNlIChNaW4taC1bNzBweF0pICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1bNzBweF0gc3BhY2UteS0yXCI+XG4gICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy0zLzRcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC03IHctMjhcIiAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBab25lIDM6IFNwZWNpZXMgQ2hpcHMgKE1pbi1oLVszMnB4XSkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTEuNSBtaW4taC1bMzJweF1cIj5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNiB3LTE0IHJvdW5kZWQtbGdcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC02IHctMTQgcm91bmRlZC1sZ1wiIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFpvbmUgNDogRGVzY3JpcHRpb24gKE1pbi1oLVs0NHB4XSkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLVs0NHB4XSBzcGFjZS15LTEuNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMy41IHctZnVsbCBiZy1zbGF0ZS0xMDAgcm91bmRlZFwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zLjUgdy0yLzMgYmctc2xhdGUtMTAwIHJvdW5kZWRcIiAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBab25lIDU6IEFjdGlvbiBidXR0b25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiZmxleC0xIGgtOCByb3VuZGVkLXhsXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtOCB3LTEyIHJvdW5kZWQteGxcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9TZXJ2aWNlQ2FyZFNrZWxldG9uLmpzeCJ9