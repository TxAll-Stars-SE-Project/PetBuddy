import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/dev/CareReportPreviewPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import CareReportsModal from "/src/components/careReport/CareReportsModal.jsx";
import CareReportFormModal from "/src/components/careReport/CareReportFormModal.jsx";
import { MOCK_BOOKING_SUBTITLE, MOCK_REPORTS, buildMockReport } from "/src/components/careReport/careReport.mock.js";
import { toast } from "/src/utils/toast.js";
const VIEWERS = [
  { key: "owner", label: "เจ้าของ (Owner)" },
  { key: "sitter", label: "พี่เลี้ยง (Sitter)" }
];
const LIST_STATES = [
  { key: "success", label: "มีรายงาน" },
  { key: "empty", label: "ยังไม่มีรายงาน" },
  { key: "loading", label: "กำลังโหลด" },
  { key: "error", label: "โหลดไม่สำเร็จ" }
];
export default function CareReportPreviewPage() {
  _s();
  const [viewer, setViewer] = useState("owner");
  const [listState, setListState] = useState("success");
  const [failSubmit, setFailSubmit] = useState(false);
  const [reports, setReports] = useState(MOCK_REPORTS);
  const [openModal, setOpenModal] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const shownReports = listState === "empty" || listState === "error" ? [] : reports;
  const status = listState === "empty" ? "success" : listState;
  const handleSubmit = (payload) => {
    setIsSubmitting(true);
    setSubmitError("");
    setTimeout(() => {
      setIsSubmitting(false);
      if (failSubmit) {
        setSubmitError("ส่งรายงานได้เฉพาะระหว่างที่กำลังให้บริการเท่านั้น");
        return;
      }
      setReports((prev) => [...prev, buildMockReport(payload)]);
      setListState("success");
      setOpenModal("list");
      toast("ส่งรายงานเรียบร้อยแล้ว", "success");
    }, 900);
  };
  return /* @__PURE__ */ jsxDEV("main", { className: "home-main", style: { maxWidth: 720 }, children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "page-title", children: "US7-3 · Care Report UI Preview" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
      lineNumber: 72,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "หน้าทดสอบ UI ด้วยข้อมูลจำลอง ยังไม่เชื่อมต่อ API" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "booking-card", style: { display: "grid", gap: 16 }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "row-label", children: "มุมมอง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "booking-tabs", children: VIEWERS.map(
          (v) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: `chip-btn${viewer === v.key ? " active" : ""}`,
              onClick: () => setViewer(v.key),
              children: v.label
            },
            v.key,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
              lineNumber: 80,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 78,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "row-label", children: "สถานะรายการรายงาน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 93,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "booking-tabs", children: LIST_STATES.map(
          (s) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: `chip-btn${listState === s.key ? " active" : ""}`,
              onClick: () => setListState(s.key),
              children: s.label
            },
            s.key,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
              lineNumber: 96,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 94,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 92,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", gap: 8, alignItems: "center", fontSize: 14 }, children: [
        /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: failSubmit, onChange: (e) => setFailSubmit(e.target.checked) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        "จำลองการส่งรายงานล้มเหลว (400)"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 108,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 10, flexWrap: "wrap" }, children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn--small", onClick: () => setOpenModal("list"), children: [
          "ดูรายงานการดูแล (",
          shownReports.length,
          ")"
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this),
        viewer === "sitter" && /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn--small btn--ghost", onClick: () => setOpenModal("form"), children: "+ ส่งรายงาน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    openModal === "list" && /* @__PURE__ */ jsxDEV(
      CareReportsModal,
      {
        subtitle: MOCK_BOOKING_SUBTITLE,
        status,
        reports: shownReports,
        viewer,
        canSubmit: viewer === "sitter",
        onRetry: () => setListState("success"),
        onAddReport: () => setOpenModal("form"),
        onClose: () => setOpenModal(null)
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 126,
        columnNumber: 7
      },
      this
    ),
    openModal === "form" && /* @__PURE__ */ jsxDEV(
      CareReportFormModal,
      {
        subtitle: MOCK_BOOKING_SUBTITLE,
        isSubmitting,
        submitError,
        onSubmit: handleSubmit,
        onClose: () => {
          setSubmitError("");
          setOpenModal(null);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
        lineNumber: 139,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
}
_s(CareReportPreviewPage, "TqKTUP16euMx7Q11cJ5ScmoynDI=");
_c = CareReportPreviewPage;
var _c;
$RefreshReg$(_c, "CareReportPreviewPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/dev/CareReportPreviewPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBETixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHlCQUF5QjtBQUNoQyxTQUFTQyx1QkFBdUJDLGNBQWNDLHVCQUF1QjtBQUNyRSxTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLFVBQVU7QUFBQSxFQUNkLEVBQUVDLEtBQUssU0FBU0MsT0FBTyxrQkFBa0I7QUFBQSxFQUN6QyxFQUFFRCxLQUFLLFVBQVVDLE9BQU8scUJBQXFCO0FBQUM7QUFHaEQsTUFBTUMsY0FBYztBQUFBLEVBQ2xCLEVBQUVGLEtBQUssV0FBV0MsT0FBTyxXQUFXO0FBQUEsRUFDcEMsRUFBRUQsS0FBSyxTQUFTQyxPQUFPLGlCQUFpQjtBQUFBLEVBQ3hDLEVBQUVELEtBQUssV0FBV0MsT0FBTyxZQUFZO0FBQUEsRUFDckMsRUFBRUQsS0FBSyxTQUFTQyxPQUFPLGdCQUFnQjtBQUFDO0FBTzFDLHdCQUF3QkUsd0JBQXdCO0FBQUFDLEtBQUE7QUFDOUMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlkLFNBQVMsT0FBTztBQUM1QyxRQUFNLENBQUNlLFdBQVdDLFlBQVksSUFBSWhCLFNBQVMsU0FBUztBQUNwRCxRQUFNLENBQUNpQixZQUFZQyxhQUFhLElBQUlsQixTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBU0ksWUFBWTtBQUNuRCxRQUFNLENBQUNpQixXQUFXQyxZQUFZLElBQUl0QixTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDdUIsY0FBY0MsZUFBZSxJQUFJeEIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3lCLGFBQWFDLGNBQWMsSUFBSTFCLFNBQVMsRUFBRTtBQUVqRCxRQUFNMkIsZUFBZVosY0FBYyxXQUFXQSxjQUFjLFVBQVUsS0FBS0k7QUFDM0UsUUFBTVMsU0FBU2IsY0FBYyxVQUFVLFlBQVlBO0FBRW5ELFFBQU1jLGVBQWVBLENBQUNDLFlBQVk7QUFDaENOLG9CQUFnQixJQUFJO0FBQ3BCRSxtQkFBZSxFQUFFO0FBQ2pCSyxlQUFXLE1BQU07QUFDZlAsc0JBQWdCLEtBQUs7QUFDckIsVUFBSVAsWUFBWTtBQUNkUyx1QkFBZSxtREFBbUQ7QUFDbEU7QUFBQSxNQUNGO0FBQ0FOLGlCQUFXLENBQUNZLFNBQVMsQ0FBQyxHQUFHQSxNQUFNM0IsZ0JBQWdCeUIsT0FBTyxDQUFDLENBQUM7QUFDeERkLG1CQUFhLFNBQVM7QUFDdEJNLG1CQUFhLE1BQU07QUFDbkJoQixZQUFNLDBCQUEwQixTQUFTO0FBQUEsSUFDM0MsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxXQUFVLGFBQVksT0FBTyxFQUFFMkIsVUFBVSxJQUFJLEdBQ2pEO0FBQUEsMkJBQUMsUUFBRyxXQUFVLGNBQWEsOENBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUN6RCx1QkFBQyxPQUFFLFdBQVUsZUFBYyxnRUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRTtBQUFBLElBRTNFLHVCQUFDLGFBQVEsV0FBVSxnQkFBZSxPQUFPLEVBQUVDLFNBQVMsUUFBUUMsS0FBSyxHQUFHLEdBQ2xFO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUFZLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsUUFDakMsdUJBQUMsU0FBSSxXQUFVLGdCQUNaNUIsa0JBQVE2QjtBQUFBQSxVQUFJLENBQUNDLE1BQ1o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLFdBQVcsV0FBV3hCLFdBQVd3QixFQUFFN0IsTUFBTSxZQUFZLEVBQUU7QUFBQSxjQUN2RCxTQUFTLE1BQU1NLFVBQVV1QixFQUFFN0IsR0FBRztBQUFBLGNBRTdCNkIsWUFBRTVCO0FBQUFBO0FBQUFBLFlBTEU0QixFQUFFN0I7QUFBQUEsWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxRQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFBWSxpQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFNBQUksV0FBVSxnQkFDWkUsc0JBQVkwQjtBQUFBQSxVQUFJLENBQUNFLE1BQ2hCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxXQUFXLFdBQVd2QixjQUFjdUIsRUFBRTlCLE1BQU0sWUFBWSxFQUFFO0FBQUEsY0FDMUQsU0FBUyxNQUFNUSxhQUFhc0IsRUFBRTlCLEdBQUc7QUFBQSxjQUVoQzhCLFlBQUU3QjtBQUFBQTtBQUFBQSxZQUxFNkIsRUFBRTlCO0FBQUFBLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsUUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxXQUFNLE9BQU8sRUFBRTBCLFNBQVMsUUFBUUMsS0FBSyxHQUFHSSxZQUFZLFVBQVVDLFVBQVUsR0FBRyxHQUMxRTtBQUFBLCtCQUFDLFdBQU0sTUFBSyxZQUFXLFNBQVN2QixZQUFZLFVBQVUsQ0FBQ3dCLE1BQU12QixjQUFjdUIsRUFBRUMsT0FBT0MsT0FBTyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUE7QUFBQSxXQUQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFDLEtBQUssSUFBSVMsVUFBVSxPQUFPLEdBQ3ZEO0FBQUEsK0JBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxrQkFBaUIsU0FBUyxNQUFNdEIsYUFBYSxNQUFNLEdBQUU7QUFBQTtBQUFBLFVBQ2pFSyxhQUFha0I7QUFBQUEsVUFBTztBQUFBLGFBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0NoQyxXQUFXLFlBQ1YsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSw2QkFBNEIsU0FBUyxNQUFNUyxhQUFhLE1BQU0sR0FBRSwyQkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0RBO0FBQUEsSUFFQ0QsY0FBYyxVQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxVQUFVbEI7QUFBQUEsUUFDVjtBQUFBLFFBQ0EsU0FBU3dCO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBLFdBQVdkLFdBQVc7QUFBQSxRQUN0QixTQUFTLE1BQU1HLGFBQWEsU0FBUztBQUFBLFFBQ3JDLGFBQWEsTUFBTU0sYUFBYSxNQUFNO0FBQUEsUUFDdEMsU0FBUyxNQUFNQSxhQUFhLElBQUk7QUFBQTtBQUFBLE1BUmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFvQztBQUFBLElBSXJDRCxjQUFjLFVBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFVBQVVsQjtBQUFBQSxRQUNWO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVTBCO0FBQUFBLFFBQ1YsU0FBUyxNQUFNO0FBQ2JILHlCQUFlLEVBQUU7QUFDakJKLHVCQUFhLElBQUk7QUFBQSxRQUNuQjtBQUFBO0FBQUEsTUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRSTtBQUFBLE9BNUVSO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFSjtBQUFDVixHQTlHdUJELHVCQUFxQjtBQUFBLEtBQXJCQTtBQUFxQixJQUFBbUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDYXJlUmVwb3J0c01vZGFsIiwiQ2FyZVJlcG9ydEZvcm1Nb2RhbCIsIk1PQ0tfQk9PS0lOR19TVUJUSVRMRSIsIk1PQ0tfUkVQT1JUUyIsImJ1aWxkTW9ja1JlcG9ydCIsInRvYXN0IiwiVklFV0VSUyIsImtleSIsImxhYmVsIiwiTElTVF9TVEFURVMiLCJDYXJlUmVwb3J0UHJldmlld1BhZ2UiLCJfcyIsInZpZXdlciIsInNldFZpZXdlciIsImxpc3RTdGF0ZSIsInNldExpc3RTdGF0ZSIsImZhaWxTdWJtaXQiLCJzZXRGYWlsU3VibWl0IiwicmVwb3J0cyIsInNldFJlcG9ydHMiLCJvcGVuTW9kYWwiLCJzZXRPcGVuTW9kYWwiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJzdWJtaXRFcnJvciIsInNldFN1Ym1pdEVycm9yIiwic2hvd25SZXBvcnRzIiwic3RhdHVzIiwiaGFuZGxlU3VibWl0IiwicGF5bG9hZCIsInNldFRpbWVvdXQiLCJwcmV2IiwibWF4V2lkdGgiLCJkaXNwbGF5IiwiZ2FwIiwibWFwIiwidiIsInMiLCJhbGlnbkl0ZW1zIiwiZm9udFNpemUiLCJlIiwidGFyZ2V0IiwiY2hlY2tlZCIsImZsZXhXcmFwIiwibGVuZ3RoIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2FyZVJlcG9ydFByZXZpZXdQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IENhcmVSZXBvcnRzTW9kYWwgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvY2FyZVJlcG9ydC9DYXJlUmVwb3J0c01vZGFsLmpzeFwiO1xuaW1wb3J0IENhcmVSZXBvcnRGb3JtTW9kYWwgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvY2FyZVJlcG9ydC9DYXJlUmVwb3J0Rm9ybU1vZGFsLmpzeFwiO1xuaW1wb3J0IHsgTU9DS19CT09LSU5HX1NVQlRJVExFLCBNT0NLX1JFUE9SVFMsIGJ1aWxkTW9ja1JlcG9ydCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2NhcmVSZXBvcnQvY2FyZVJlcG9ydC5tb2NrLmpzXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCIuLi8uLi91dGlscy90b2FzdC5qc1wiO1xuXG5jb25zdCBWSUVXRVJTID0gW1xuICB7IGtleTogXCJvd25lclwiLCBsYWJlbDogXCLguYDguIjguYnguLLguILguK3guIcgKE93bmVyKVwiIH0sXG4gIHsga2V5OiBcInNpdHRlclwiLCBsYWJlbDogXCLguJ7guLXguYjguYDguKXguLXguYnguKLguIcgKFNpdHRlcilcIiB9LFxuXTtcblxuY29uc3QgTElTVF9TVEFURVMgPSBbXG4gIHsga2V5OiBcInN1Y2Nlc3NcIiwgbGFiZWw6IFwi4Lih4Li14Lij4Liy4Lii4LiH4Liy4LiZXCIgfSxcbiAgeyBrZXk6IFwiZW1wdHlcIiwgbGFiZWw6IFwi4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14Lij4Liy4Lii4LiH4Liy4LiZXCIgfSxcbiAgeyBrZXk6IFwibG9hZGluZ1wiLCBsYWJlbDogXCLguIHguLPguKXguLHguIfguYLguKvguKXguJRcIiB9LFxuICB7IGtleTogXCJlcnJvclwiLCBsYWJlbDogXCLguYLguKvguKXguJTguYTguKHguYjguKrguLPguYDguKPguYfguIhcIiB9LFxuXTtcblxuLy8gVE9ETyhVUzctMyDguKPguK3guJogZnJvbnRlbmQpOiDguKXguJrguYTguJ/guKXguYzguJnguLXguYnguJfguLTguYnguIfguJXguK3guJnguJXguYjguK0gQVBJIOC4iOC4o+C4tOC4hyAobWVyZ2Ug4LiE4Lij4Lix4LmJ4LiH4LiX4Li14LmIIDIpXG4vLyAgIOC4peC4muC4nuC4o+C5ieC4reC4oeC4geC4seC4mTogY29tcG9uZW50cy9jYXJlUmVwb3J0L2NhcmVSZXBvcnQubW9jay5qcyArIHJvdXRlIC9kZXYvY2FyZS1yZXBvcnQg4LmD4LiZIEFwcC5qc3hcbi8vICAg4LiC4Lit4LiH4LiI4Lij4Li04LiH4LmD4Lir4LmJ4LmA4Lib4Li04LiUIENhcmVSZXBvcnRzTW9kYWwgLyBDYXJlUmVwb3J0Rm9ybU1vZGFsIOC4iOC4suC4gSBPd25lckJvb2tpbmdQYWdlIOC5geC4peC4sCBTaXR0ZXJCb29raW5nQ2FyZCDguYHguJfguJlcbi8vIENhcmVSZXBvcnRQcmV2aWV3UGFnZSDigJQg4Lir4LiZ4LmJ4Liy4LiU4Li5IFVJIOC4guC4reC4hyBVUzctMyDguJTguYnguKfguKIgbW9jayBkYXRhICjguYDguJvguLTguJTguYDguInguJ7guLLguLDguJXguK3guJkgZGV2OiAvZGV2L2NhcmUtcmVwb3J0KVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2FyZVJlcG9ydFByZXZpZXdQYWdlKCkge1xuICBjb25zdCBbdmlld2VyLCBzZXRWaWV3ZXJdID0gdXNlU3RhdGUoXCJvd25lclwiKTtcbiAgY29uc3QgW2xpc3RTdGF0ZSwgc2V0TGlzdFN0YXRlXSA9IHVzZVN0YXRlKFwic3VjY2Vzc1wiKTtcbiAgY29uc3QgW2ZhaWxTdWJtaXQsIHNldEZhaWxTdWJtaXRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcmVwb3J0cywgc2V0UmVwb3J0c10gPSB1c2VTdGF0ZShNT0NLX1JFUE9SVFMpO1xuICBjb25zdCBbb3Blbk1vZGFsLCBzZXRPcGVuTW9kYWxdID0gdXNlU3RhdGUobnVsbCk7IC8vIFwibGlzdFwiIHwgXCJmb3JtXCIgfCBudWxsXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzdWJtaXRFcnJvciwgc2V0U3VibWl0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3Qgc2hvd25SZXBvcnRzID0gbGlzdFN0YXRlID09PSBcImVtcHR5XCIgfHwgbGlzdFN0YXRlID09PSBcImVycm9yXCIgPyBbXSA6IHJlcG9ydHM7XG4gIGNvbnN0IHN0YXR1cyA9IGxpc3RTdGF0ZSA9PT0gXCJlbXB0eVwiID8gXCJzdWNjZXNzXCIgOiBsaXN0U3RhdGU7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKHBheWxvYWQpID0+IHtcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG4gICAgc2V0U3VibWl0RXJyb3IoXCJcIik7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgICAgaWYgKGZhaWxTdWJtaXQpIHtcbiAgICAgICAgc2V0U3VibWl0RXJyb3IoXCLguKrguYjguIfguKPguLLguKLguIfguLLguJnguYTguJTguYnguYDguInguJ7guLLguLDguKPguLDguKvguKfguYjguLLguIfguJfguLXguYjguIHguLPguKXguLHguIfguYPguKvguYnguJrguKPguLTguIHguLLguKPguYDguJfguYjguLLguJnguLHguYnguJlcIik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHNldFJlcG9ydHMoKHByZXYpID0+IFsuLi5wcmV2LCBidWlsZE1vY2tSZXBvcnQocGF5bG9hZCldKTtcbiAgICAgIHNldExpc3RTdGF0ZShcInN1Y2Nlc3NcIik7XG4gICAgICBzZXRPcGVuTW9kYWwoXCJsaXN0XCIpO1xuICAgICAgdG9hc3QoXCLguKrguYjguIfguKPguLLguKLguIfguLLguJnguYDguKPguLXguKLguJrguKPguYnguK3guKLguYHguKXguYnguKdcIiwgXCJzdWNjZXNzXCIpO1xuICAgIH0sIDkwMCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJob21lLW1haW5cIiBzdHlsZT17eyBtYXhXaWR0aDogNzIwIH19PlxuICAgICAgPGgxIGNsYXNzTmFtZT1cInBhZ2UtdGl0bGVcIj5VUzctMyDCtyBDYXJlIFJlcG9ydCBVSSBQcmV2aWV3PC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tc3ViXCI+4Lir4LiZ4LmJ4Liy4LiX4LiU4Liq4Lit4LiaIFVJIOC4lOC5ieC4p+C4ouC4guC5ieC4reC4oeC4ueC4peC4iOC4s+C4peC4reC4hyDguKLguLHguIfguYTguKHguYjguYDguIrguLfguYjguK3guKHguJXguYjguK0gQVBJPC9wPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJib29raW5nLWNhcmRcIiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiAxNiB9fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdy1sYWJlbFwiPuC4oeC4uOC4oeC4oeC4reC4hzwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy10YWJzXCI+XG4gICAgICAgICAgICB7VklFV0VSUy5tYXAoKHYpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17di5rZXl9XG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY2hpcC1idG4ke3ZpZXdlciA9PT0gdi5rZXkgPyBcIiBhY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3ZXIodi5rZXkpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3YubGFiZWx9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3ctbGFiZWxcIj7guKrguJbguLLguJnguLDguKPguLLguKLguIHguLLguKPguKPguLLguKLguIfguLLguJk8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctdGFic1wiPlxuICAgICAgICAgICAge0xJU1RfU1RBVEVTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtzLmtleX1cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BjaGlwLWJ0biR7bGlzdFN0YXRlID09PSBzLmtleSA/IFwiIGFjdGl2ZVwiIDogXCJcIn1gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExpc3RTdGF0ZShzLmtleSl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7cy5sYWJlbH1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IDgsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGZvbnRTaXplOiAxNCB9fT5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17ZmFpbFN1Ym1pdH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRGYWlsU3VibWl0KGUudGFyZ2V0LmNoZWNrZWQpfSAvPlxuICAgICAgICAgIOC4iOC4s+C4peC4reC4h+C4geC4suC4o+C4quC5iOC4h+C4o+C4suC4ouC4h+C4suC4meC4peC5ieC4oeC5gOC4q+C4peC4pyAoNDAwKVxuICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMTAsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLS1zbWFsbFwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW5Nb2RhbChcImxpc3RcIil9PlxuICAgICAgICAgICAg4LiU4Li54Lij4Liy4Lii4LiH4Liy4LiZ4LiB4Liy4Lij4LiU4Li54LmB4LilICh7c2hvd25SZXBvcnRzLmxlbmd0aH0pXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAge3ZpZXdlciA9PT0gXCJzaXR0ZXJcIiAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLS1zbWFsbCBidG4tLWdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0T3Blbk1vZGFsKFwiZm9ybVwiKX0+XG4gICAgICAgICAgICAgICsg4Liq4LmI4LiH4Lij4Liy4Lii4LiH4Liy4LiZXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAge29wZW5Nb2RhbCA9PT0gXCJsaXN0XCIgJiYgKFxuICAgICAgICA8Q2FyZVJlcG9ydHNNb2RhbFxuICAgICAgICAgIHN1YnRpdGxlPXtNT0NLX0JPT0tJTkdfU1VCVElUTEV9XG4gICAgICAgICAgc3RhdHVzPXtzdGF0dXN9XG4gICAgICAgICAgcmVwb3J0cz17c2hvd25SZXBvcnRzfVxuICAgICAgICAgIHZpZXdlcj17dmlld2VyfVxuICAgICAgICAgIGNhblN1Ym1pdD17dmlld2VyID09PSBcInNpdHRlclwifVxuICAgICAgICAgIG9uUmV0cnk9eygpID0+IHNldExpc3RTdGF0ZShcInN1Y2Nlc3NcIil9XG4gICAgICAgICAgb25BZGRSZXBvcnQ9eygpID0+IHNldE9wZW5Nb2RhbChcImZvcm1cIil9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0T3Blbk1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge29wZW5Nb2RhbCA9PT0gXCJmb3JtXCIgJiYgKFxuICAgICAgICA8Q2FyZVJlcG9ydEZvcm1Nb2RhbFxuICAgICAgICAgIHN1YnRpdGxlPXtNT0NLX0JPT0tJTkdfU1VCVElUTEV9XG4gICAgICAgICAgaXNTdWJtaXR0aW5nPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgc3VibWl0RXJyb3I9e3N1Ym1pdEVycm9yfVxuICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgICAgc2V0U3VibWl0RXJyb3IoXCJcIik7XG4gICAgICAgICAgICBzZXRPcGVuTW9kYWwobnVsbCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9tYWluPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL3BhZ2VzL2Rldi9DYXJlUmVwb3J0UHJldmlld1BhZ2UuanN4In0=