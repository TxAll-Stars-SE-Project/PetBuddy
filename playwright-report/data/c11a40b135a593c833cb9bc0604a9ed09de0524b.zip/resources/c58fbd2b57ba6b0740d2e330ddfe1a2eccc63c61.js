import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/ServiceFormModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import ServiceFormHeader from "/src/components/sitter/serviceForm/ServiceFormHeader.jsx";
import ServiceFormAlert from "/src/components/sitter/serviceForm/ServiceFormAlert.jsx";
import ServiceNameInput from "/src/components/sitter/serviceForm/ServiceNameInput.jsx";
import ServiceCategorySelect from "/src/components/sitter/serviceForm/ServiceCategorySelect.jsx";
import PriceStepperInput from "/src/components/sitter/serviceForm/PriceStepperInput.jsx";
import SpeciesChipSelector from "/src/components/sitter/serviceForm/SpeciesChipSelector.jsx";
import ServiceDescriptionInput from "/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx";
import ServiceStatusSelect from "/src/components/sitter/serviceForm/ServiceStatusSelect.jsx";
import ServiceFormFooter from "/src/components/sitter/serviceForm/ServiceFormFooter.jsx";
import {
  getPriceUnitHint,
  validateServiceForm,
  buildServicePayload
} from "/src/utils/serviceLogic.js";
export default function ServiceFormModal({
  onClose,
  onSave,
  serviceToEdit = null
}) {
  _s();
  const isEditMode = Boolean(serviceToEdit);
  const [serviceName, setServiceName] = useState(() => serviceToEdit?.serviceName || serviceToEdit?.servicename || "");
  const [serviceType, setServiceType] = useState(() => serviceToEdit?.serviceType || serviceToEdit?.servicetype || "daycare");
  const [price, setPrice] = useState(() => Number(serviceToEdit?.price) || 350);
  const [species, setSpecies] = useState(() => {
    if (Array.isArray(serviceToEdit?.species) && serviceToEdit.species.length > 0) {
      return serviceToEdit.species;
    }
    return ["dog"];
  });
  const [description, setDescription] = useState(() => serviceToEdit?.description || "");
  const [status, setStatus] = useState(() => serviceToEdit?.status || "published");
  const [errors, setErrors] = useState({});
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && onClose) onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);
  const priceUnitHint = getPriceUnitHint(serviceType);
  const handleSubmit = (e) => {
    e.preventDefault();
    setHasAttemptedSubmit(true);
    const validationResult = validateServiceForm({
      serviceName,
      price,
      species,
      description
    });
    setErrors(validationResult.errors);
    if (!validationResult.isValid) return;
    const payload = buildServicePayload({
      serviceName,
      serviceType,
      price,
      species,
      description,
      status,
      activeService: serviceToEdit
    });
    if (onSave) onSave(payload);
  };
  const hasErrors = Object.keys(errors).length > 0;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs transition-opacity duration-200",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "service-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 shadow-2xl space-y-5 animate-fade-in max-h-[90vh] overflow-y-auto",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV(ServiceFormHeader, { isEditMode, onClose }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
              lineNumber: 133,
              columnNumber: 9
            }, this),
            hasAttemptedSubmit && hasErrors && /* @__PURE__ */ jsxDEV(ServiceFormAlert, {}, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
              lineNumber: 136,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV(
                ServiceNameInput,
                {
                  value: serviceName,
                  onChange: (val) => {
                    setServiceName(val);
                    if (errors.serviceName) setErrors((prev) => ({ ...prev, serviceName: "" }));
                  },
                  error: errors.serviceName
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                  lineNumber: 141,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  ServiceCategorySelect,
                  {
                    value: serviceType,
                    onChange: setServiceType
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                    lineNumber: 152,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  PriceStepperInput,
                  {
                    id: "service-price-input",
                    value: price,
                    onChange: (val) => {
                      setPrice(val);
                      if (errors.price) setErrors((prev) => ({ ...prev, price: "" }));
                    },
                    unitHint: priceUnitHint,
                    error: errors.price
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                    lineNumber: 156,
                    columnNumber: 13
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                lineNumber: 151,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                SpeciesChipSelector,
                {
                  value: species,
                  onChange: (val) => {
                    setSpecies(val);
                    if (errors.species) setErrors((prev) => ({ ...prev, species: "" }));
                  },
                  error: errors.species
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                  lineNumber: 169,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                ServiceDescriptionInput,
                {
                  value: description,
                  onChange: (val) => {
                    setDescription(val);
                    if (errors.description) setErrors((prev) => ({ ...prev, description: "" }));
                  },
                  error: errors.description
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                  lineNumber: 179,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                ServiceStatusSelect,
                {
                  value: status,
                  onChange: setStatus
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                  lineNumber: 189,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                ServiceFormFooter,
                {
                  onClose,
                  isEditMode,
                  showIncompleteWarning: hasAttemptedSubmit && hasErrors
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
                  lineNumber: 195,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
              lineNumber: 139,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
          lineNumber: 128,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx",
      lineNumber: 118,
      columnNumber: 5
    },
    this
  );
}
_s(ServiceFormModal, "vTwONFGidZzFVndT/QYkt2lQ3rQ=");
_c = ServiceFormModal;
var _c;
$RefreshReg$(_c, "ServiceFormModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/ServiceFormModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUhROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpIUixPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyx5QkFBeUI7QUFDaEMsT0FBT0MsNkJBQTZCO0FBQ3BDLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyx1QkFBdUI7QUFDOUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBZ0JQLHdCQUF3QkMsaUJBQWlCO0FBQUEsRUFDdkNDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGdCQUFnQjtBQUNsQixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNQyxhQUFhQyxRQUFRSCxhQUFhO0FBR3hDLFFBQU0sQ0FBQ0ksYUFBYUMsY0FBYyxJQUFJdEIsU0FBUyxNQUFNaUIsZUFBZUksZUFBZUosZUFBZU0sZUFBZSxFQUFFO0FBQ25ILFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJekIsU0FBUyxNQUFNaUIsZUFBZU8sZUFBZVAsZUFBZVMsZUFBZSxTQUFTO0FBQzFILFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJNUIsU0FBUyxNQUFNNkIsT0FBT1osZUFBZVUsS0FBSyxLQUFLLEdBQUc7QUFDNUUsUUFBTSxDQUFDRyxTQUFTQyxVQUFVLElBQUkvQixTQUFTLE1BQU07QUFDM0MsUUFBSWdDLE1BQU1DLFFBQVFoQixlQUFlYSxPQUFPLEtBQUtiLGNBQWNhLFFBQVFJLFNBQVMsR0FBRztBQUM3RSxhQUFPakIsY0FBY2E7QUFBQUEsSUFDdkI7QUFDQSxXQUFPLENBQUMsS0FBSztBQUFBLEVBQ2YsQ0FBQztBQUNELFFBQU0sQ0FBQ0ssYUFBYUMsY0FBYyxJQUFJcEMsU0FBUyxNQUFNaUIsZUFBZWtCLGVBQWUsRUFBRTtBQUNyRixRQUFNLENBQUNFLFFBQVFDLFNBQVMsSUFBSXRDLFNBQVMsTUFBTWlCLGVBQWVvQixVQUFVLFdBQVc7QUFHL0UsUUFBTSxDQUFDRSxRQUFRQyxTQUFTLElBQUl4QyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN5QyxvQkFBb0JDLHFCQUFxQixJQUFJMUMsU0FBUyxLQUFLO0FBR2xFQyxZQUFVLE1BQU07QUFDZCxVQUFNMEMsZ0JBQWdCQSxDQUFDQyxNQUFNO0FBQzNCLFVBQUlBLEVBQUVDLFFBQVEsWUFBWTlCLFFBQVNBLFNBQVE7QUFBQSxJQUM3QztBQUNBK0IsV0FBT0MsaUJBQWlCLFdBQVdKLGFBQWE7QUFDaEQsV0FBTyxNQUFNRyxPQUFPRSxvQkFBb0IsV0FBV0wsYUFBYTtBQUFBLEVBQ2xFLEdBQUcsQ0FBQzVCLE9BQU8sQ0FBQztBQUVaLFFBQU1rQyxnQkFBZ0J0QyxpQkFBaUJhLFdBQVc7QUFFbEQsUUFBTTBCLGVBQWVBLENBQUNOLE1BQU07QUFDMUJBLE1BQUVPLGVBQWU7QUFDakJULDBCQUFzQixJQUFJO0FBRzFCLFVBQU1VLG1CQUFtQnhDLG9CQUFvQjtBQUFBLE1BQzNDUztBQUFBQSxNQUNBTTtBQUFBQSxNQUNBRztBQUFBQSxNQUNBSztBQUFBQSxJQUNGLENBQUM7QUFFREssY0FBVVksaUJBQWlCYixNQUFNO0FBRWpDLFFBQUksQ0FBQ2EsaUJBQWlCQyxRQUFTO0FBRy9CLFVBQU1DLFVBQVV6QyxvQkFBb0I7QUFBQSxNQUNsQ1E7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUs7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQWtCLGVBQWV0QztBQUFBQSxJQUNqQixDQUFDO0FBRUQsUUFBSUQsT0FBUUEsUUFBT3NDLE9BQU87QUFBQSxFQUM1QjtBQUVBLFFBQU1FLFlBQVlDLE9BQU9DLEtBQUtuQixNQUFNLEVBQUVMLFNBQVM7QUFFL0MsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BSVYsTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsbUJBQWdCO0FBQUEsTUFHaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsQ0FBQ1UsTUFBTUEsRUFBRWUsZ0JBQWdCO0FBQUEsVUFHbEM7QUFBQSxtQ0FBQyxxQkFBa0IsWUFBd0IsV0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUczRGxCLHNCQUFzQmUsYUFBYSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBR3JELHVCQUFDLFVBQUssVUFBVU4sY0FBYyxXQUFVLGFBRXRDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTzdCO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3VDLFFBQVE7QUFDakJ0QyxtQ0FBZXNDLEdBQUc7QUFDbEIsd0JBQUlyQixPQUFPbEIsWUFBYW1CLFdBQVUsQ0FBQ3FCLFVBQVUsRUFBRSxHQUFHQSxNQUFNeEMsYUFBYSxHQUFHLEVBQUU7QUFBQSxrQkFDNUU7QUFBQSxrQkFDQSxPQUFPa0IsT0FBT2xCO0FBQUFBO0FBQUFBLGdCQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNEI7QUFBQSxjQUk1Qix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPRztBQUFBQSxvQkFDUCxVQUFVQztBQUFBQTtBQUFBQSxrQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRTJCO0FBQUEsZ0JBRTNCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxPQUFPRTtBQUFBQSxvQkFDUCxVQUFVLENBQUNpQyxRQUFRO0FBQ2pCaEMsK0JBQVNnQyxHQUFHO0FBQ1osMEJBQUlyQixPQUFPWixNQUFPYSxXQUFVLENBQUNxQixVQUFVLEVBQUUsR0FBR0EsTUFBTWxDLE9BQU8sR0FBRyxFQUFFO0FBQUEsb0JBQ2hFO0FBQUEsb0JBQ0EsVUFBVXNCO0FBQUFBLG9CQUNWLE9BQU9WLE9BQU9aO0FBQUFBO0FBQUFBLGtCQVJoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUXNCO0FBQUEsbUJBYnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9HO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQzhCLFFBQVE7QUFDakI3QiwrQkFBVzZCLEdBQUc7QUFDZCx3QkFBSXJCLE9BQU9ULFFBQVNVLFdBQVUsQ0FBQ3FCLFVBQVUsRUFBRSxHQUFHQSxNQUFNL0IsU0FBUyxHQUFHLEVBQUU7QUFBQSxrQkFDcEU7QUFBQSxrQkFDQSxPQUFPUyxPQUFPVDtBQUFBQTtBQUFBQSxnQkFOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXdCO0FBQUEsY0FJeEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0s7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDeUIsUUFBUTtBQUNqQnhCLG1DQUFld0IsR0FBRztBQUNsQix3QkFBSXJCLE9BQU9KLFlBQWFLLFdBQVUsQ0FBQ3FCLFVBQVUsRUFBRSxHQUFHQSxNQUFNMUIsYUFBYSxHQUFHLEVBQUU7QUFBQSxrQkFDNUU7QUFBQSxrQkFDQSxPQUFPSSxPQUFPSjtBQUFBQTtBQUFBQSxnQkFOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTRCO0FBQUEsY0FJNUI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0U7QUFBQUEsa0JBQ1AsVUFBVUM7QUFBQUE7QUFBQUEsZ0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRXNCO0FBQUEsY0FJdEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLHVCQUF1Qkcsc0JBQXNCZTtBQUFBQTtBQUFBQSxnQkFIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR3lEO0FBQUEsaUJBM0QzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZEQTtBQUFBO0FBQUE7QUFBQSxRQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUF5RUE7QUFBQTtBQUFBLElBbkZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW9GQTtBQUVKO0FBQUN0QyxHQTFKdUJKLGtCQUFnQjtBQUFBLEtBQWhCQTtBQUFnQixJQUFBZ0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlNlcnZpY2VGb3JtSGVhZGVyIiwiU2VydmljZUZvcm1BbGVydCIsIlNlcnZpY2VOYW1lSW5wdXQiLCJTZXJ2aWNlQ2F0ZWdvcnlTZWxlY3QiLCJQcmljZVN0ZXBwZXJJbnB1dCIsIlNwZWNpZXNDaGlwU2VsZWN0b3IiLCJTZXJ2aWNlRGVzY3JpcHRpb25JbnB1dCIsIlNlcnZpY2VTdGF0dXNTZWxlY3QiLCJTZXJ2aWNlRm9ybUZvb3RlciIsImdldFByaWNlVW5pdEhpbnQiLCJ2YWxpZGF0ZVNlcnZpY2VGb3JtIiwiYnVpbGRTZXJ2aWNlUGF5bG9hZCIsIlNlcnZpY2VGb3JtTW9kYWwiLCJvbkNsb3NlIiwib25TYXZlIiwic2VydmljZVRvRWRpdCIsIl9zIiwiaXNFZGl0TW9kZSIsIkJvb2xlYW4iLCJzZXJ2aWNlTmFtZSIsInNldFNlcnZpY2VOYW1lIiwic2VydmljZW5hbWUiLCJzZXJ2aWNlVHlwZSIsInNldFNlcnZpY2VUeXBlIiwic2VydmljZXR5cGUiLCJwcmljZSIsInNldFByaWNlIiwiTnVtYmVyIiwic3BlY2llcyIsInNldFNwZWNpZXMiLCJBcnJheSIsImlzQXJyYXkiLCJsZW5ndGgiLCJkZXNjcmlwdGlvbiIsInNldERlc2NyaXB0aW9uIiwic3RhdHVzIiwic2V0U3RhdHVzIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiaGFzQXR0ZW1wdGVkU3VibWl0Iiwic2V0SGFzQXR0ZW1wdGVkU3VibWl0IiwiaGFuZGxlS2V5RG93biIsImUiLCJrZXkiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInByaWNlVW5pdEhpbnQiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInZhbGlkYXRpb25SZXN1bHQiLCJpc1ZhbGlkIiwicGF5bG9hZCIsImFjdGl2ZVNlcnZpY2UiLCJoYXNFcnJvcnMiLCJPYmplY3QiLCJrZXlzIiwic3RvcFByb3BhZ2F0aW9uIiwidmFsIiwicHJldiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VGb3JtTW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2VydmljZUZvcm1IZWFkZXIgZnJvbSBcIi4vc2VydmljZUZvcm0vU2VydmljZUZvcm1IZWFkZXIuanN4XCI7XG5pbXBvcnQgU2VydmljZUZvcm1BbGVydCBmcm9tIFwiLi9zZXJ2aWNlRm9ybS9TZXJ2aWNlRm9ybUFsZXJ0LmpzeFwiO1xuaW1wb3J0IFNlcnZpY2VOYW1lSW5wdXQgZnJvbSBcIi4vc2VydmljZUZvcm0vU2VydmljZU5hbWVJbnB1dC5qc3hcIjtcbmltcG9ydCBTZXJ2aWNlQ2F0ZWdvcnlTZWxlY3QgZnJvbSBcIi4vc2VydmljZUZvcm0vU2VydmljZUNhdGVnb3J5U2VsZWN0LmpzeFwiO1xuaW1wb3J0IFByaWNlU3RlcHBlcklucHV0IGZyb20gXCIuL3NlcnZpY2VGb3JtL1ByaWNlU3RlcHBlcklucHV0LmpzeFwiO1xuaW1wb3J0IFNwZWNpZXNDaGlwU2VsZWN0b3IgZnJvbSBcIi4vc2VydmljZUZvcm0vU3BlY2llc0NoaXBTZWxlY3Rvci5qc3hcIjtcbmltcG9ydCBTZXJ2aWNlRGVzY3JpcHRpb25JbnB1dCBmcm9tIFwiLi9zZXJ2aWNlRm9ybS9TZXJ2aWNlRGVzY3JpcHRpb25JbnB1dC5qc3hcIjtcbmltcG9ydCBTZXJ2aWNlU3RhdHVzU2VsZWN0IGZyb20gXCIuL3NlcnZpY2VGb3JtL1NlcnZpY2VTdGF0dXNTZWxlY3QuanN4XCI7XG5pbXBvcnQgU2VydmljZUZvcm1Gb290ZXIgZnJvbSBcIi4vc2VydmljZUZvcm0vU2VydmljZUZvcm1Gb290ZXIuanN4XCI7XG5pbXBvcnQge1xuICBnZXRQcmljZVVuaXRIaW50LFxuICB2YWxpZGF0ZVNlcnZpY2VGb3JtLFxuICBidWlsZFNlcnZpY2VQYXlsb2FkLFxufSBmcm9tIFwiLi4vLi4vdXRpbHMvc2VydmljZUxvZ2ljLmpzXCI7XG5cbi8qKlxuICogU2VydmljZUZvcm1Nb2RhbCBDb21wb25lbnRcbiAqIFxuICogTW9kdWxhciBGb3JtIE9yY2hlc3RyYXRvcjpcbiAqIC0gQ29tcG9zZWQgb2Ygc3BlY2lhbGl6ZWQgc3ViY29tcG9uZW50cyAoTGVnbyBibG9ja3MpIGluIGBjb21wb25lbnRzL3NpdHRlci9zZXJ2aWNlRm9ybS9gLlxuICogLSBFYWNoIHN1YmNvbXBvbmVudCBlbmNhcHN1bGF0ZXMgaXRzIG93biBwcmVzZW50YXRpb24gJiBldmVudHMsIGNvbW11bmljYXRpbmcgb25seSBkYXRhIGNoYW5nZXMgdG8gcGFyZW50LlxuICogLSBNYW5hZ2VzIG92ZXJhbGwgZm9ybSBzdGF0ZSwgdmFsaWRhdGlvbiBvbiBzdWJtaXQsIGFuZCBlc2NhcGUta2V5IGhhbmRsaW5nLlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW3Byb3BzLmlzT3Blbl0gLSBPcHRpb25hbCBtb2RhbCB2aXNpYmlsaXR5IGZsYWcuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vbkNsb3NlIC0gTW9kYWwgY2xvc2UgaGFuZGxlci5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uU2F2ZSAtIENhbGxiYWNrIHJlY2VpdmluZyB2YWxpZGF0ZWQgcGF5bG9hZC5cbiAqIEBwYXJhbSB7T2JqZWN0fG51bGx9IFtwcm9wcy5zZXJ2aWNlVG9FZGl0XSAtIFNlcnZpY2Ugb2JqZWN0IHRvIGVkaXQsIG9yIG51bGwgZm9yIGFkZCBtb2RlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlRm9ybU1vZGFsKHtcbiAgb25DbG9zZSxcbiAgb25TYXZlLFxuICBzZXJ2aWNlVG9FZGl0ID0gbnVsbCxcbn0pIHtcbiAgY29uc3QgaXNFZGl0TW9kZSA9IEJvb2xlYW4oc2VydmljZVRvRWRpdCk7XG5cbiAgLy8gMS4gQ28tbG9jYXRlZCBGb3JtIFN0YXRlIChJbml0aWFsaXplZCBkaXJlY3RseSBmcm9tIHNlcnZpY2VUb0VkaXQgaWYgZWRpdGluZylcbiAgY29uc3QgW3NlcnZpY2VOYW1lLCBzZXRTZXJ2aWNlTmFtZV0gPSB1c2VTdGF0ZSgoKSA9PiBzZXJ2aWNlVG9FZGl0Py5zZXJ2aWNlTmFtZSB8fCBzZXJ2aWNlVG9FZGl0Py5zZXJ2aWNlbmFtZSB8fCBcIlwiKTtcbiAgY29uc3QgW3NlcnZpY2VUeXBlLCBzZXRTZXJ2aWNlVHlwZV0gPSB1c2VTdGF0ZSgoKSA9PiBzZXJ2aWNlVG9FZGl0Py5zZXJ2aWNlVHlwZSB8fCBzZXJ2aWNlVG9FZGl0Py5zZXJ2aWNldHlwZSB8fCBcImRheWNhcmVcIik7XG4gIGNvbnN0IFtwcmljZSwgc2V0UHJpY2VdID0gdXNlU3RhdGUoKCkgPT4gTnVtYmVyKHNlcnZpY2VUb0VkaXQ/LnByaWNlKSB8fCAzNTApO1xuICBjb25zdCBbc3BlY2llcywgc2V0U3BlY2llc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoc2VydmljZVRvRWRpdD8uc3BlY2llcykgJiYgc2VydmljZVRvRWRpdC5zcGVjaWVzLmxlbmd0aCA+IDApIHtcbiAgICAgIHJldHVybiBzZXJ2aWNlVG9FZGl0LnNwZWNpZXM7XG4gICAgfVxuICAgIHJldHVybiBbXCJkb2dcIl07XG4gIH0pO1xuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCgpID0+IHNlcnZpY2VUb0VkaXQ/LmRlc2NyaXB0aW9uIHx8IFwiXCIpO1xuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoKCkgPT4gc2VydmljZVRvRWRpdD8uc3RhdHVzIHx8IFwicHVibGlzaGVkXCIpO1xuXG4gIC8vIDIuIFZhbGlkYXRpb24gU3RhdGVcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcbiAgY29uc3QgW2hhc0F0dGVtcHRlZFN1Ym1pdCwgc2V0SGFzQXR0ZW1wdGVkU3VibWl0XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyAzLiBDbG9zZSBvbiBFc2NhcGUga2V5IChBY3RpdmUgd2hpbGUgbW91bnRlZClcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGUpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIiAmJiBvbkNsb3NlKSBvbkNsb3NlKCk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duKTtcbiAgfSwgW29uQ2xvc2VdKTtcblxuICBjb25zdCBwcmljZVVuaXRIaW50ID0gZ2V0UHJpY2VVbml0SGludChzZXJ2aWNlVHlwZSk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0SGFzQXR0ZW1wdGVkU3VibWl0KHRydWUpO1xuXG4gICAgLy8gQ2FsbCBwdXJlIHZhbGlkYXRpb24gaGVscGVyIGZyb20gdXRpbHNcbiAgICBjb25zdCB2YWxpZGF0aW9uUmVzdWx0ID0gdmFsaWRhdGVTZXJ2aWNlRm9ybSh7XG4gICAgICBzZXJ2aWNlTmFtZSxcbiAgICAgIHByaWNlLFxuICAgICAgc3BlY2llcyxcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgIH0pO1xuXG4gICAgc2V0RXJyb3JzKHZhbGlkYXRpb25SZXN1bHQuZXJyb3JzKTtcblxuICAgIGlmICghdmFsaWRhdGlvblJlc3VsdC5pc1ZhbGlkKSByZXR1cm47XG5cbiAgICAvLyBDYWxsIHB1cmUgcGF5bG9hZCBidWlsZGVyIGZyb20gdXRpbHNcbiAgICBjb25zdCBwYXlsb2FkID0gYnVpbGRTZXJ2aWNlUGF5bG9hZCh7XG4gICAgICBzZXJ2aWNlTmFtZSxcbiAgICAgIHNlcnZpY2VUeXBlLFxuICAgICAgcHJpY2UsXG4gICAgICBzcGVjaWVzLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBzdGF0dXMsXG4gICAgICBhY3RpdmVTZXJ2aWNlOiBzZXJ2aWNlVG9FZGl0LFxuICAgIH0pO1xuXG4gICAgaWYgKG9uU2F2ZSkgb25TYXZlKHBheWxvYWQpO1xuICB9O1xuXG4gIGNvbnN0IGhhc0Vycm9ycyA9IE9iamVjdC5rZXlzKGVycm9ycykubGVuZ3RoID4gMDtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctc2xhdGUtOTAwLzc1IGJhY2tkcm9wLWJsdXIteHMgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTIwMFwiXG4gICAgICAvLyBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgLy8gICBpZiAoZS50YXJnZXQgPT09IGUuY3VycmVudFRhcmdldCAmJiBvbkNsb3NlKSBvbkNsb3NlKCk7XG4gICAgICAvLyB9fVxuICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsbGVkYnk9XCJzZXJ2aWNlLW1vZGFsLXRpdGxlXCJcbiAgICA+XG4gICAgICB7LyogTW9kYWwgRGlhbG9nIENhcmQgKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIG1heC13LWxnIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTUgYW5pbWF0ZS1mYWRlLWluIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIlxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgID5cbiAgICAgICAgey8qIFN1YmNvbXBvbmVudDogTW9kYWwgSGVhZGVyICovfVxuICAgICAgICA8U2VydmljZUZvcm1IZWFkZXIgaXNFZGl0TW9kZT17aXNFZGl0TW9kZX0gb25DbG9zZT17b25DbG9zZX0gLz5cblxuICAgICAgICB7LyogU3ViY29tcG9uZW50OiBUb3AgSW5jb21wbGV0ZSBBbGVydCBCYW5uZXIgKi99XG4gICAgICAgIHtoYXNBdHRlbXB0ZWRTdWJtaXQgJiYgaGFzRXJyb3JzICYmIDxTZXJ2aWNlRm9ybUFsZXJ0IC8+fVxuXG4gICAgICAgIHsvKiBGb3JtIEJvZHk6IE1vZHVsYXIgQ29tcG9zaXRpb24gKi99XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiBTdWJjb21wb25lbnQ6IFNlcnZpY2UgTmFtZSAqL31cbiAgICAgICAgICA8U2VydmljZU5hbWVJbnB1dFxuICAgICAgICAgICAgdmFsdWU9e3NlcnZpY2VOYW1lfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHtcbiAgICAgICAgICAgICAgc2V0U2VydmljZU5hbWUodmFsKTtcbiAgICAgICAgICAgICAgaWYgKGVycm9ycy5zZXJ2aWNlTmFtZSkgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBzZXJ2aWNlTmFtZTogXCJcIiB9KSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5zZXJ2aWNlTmFtZX1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgey8qIFN1YmNvbXBvbmVudHM6IENhdGVnb3J5IERyb3Bkb3duICYgU3RlcHBlciBQcmljZSAoMi1Db2x1bW4gR3JpZCkgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICA8U2VydmljZUNhdGVnb3J5U2VsZWN0XG4gICAgICAgICAgICAgIHZhbHVlPXtzZXJ2aWNlVHlwZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlcnZpY2VUeXBlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxQcmljZVN0ZXBwZXJJbnB1dFxuICAgICAgICAgICAgICBpZD1cInNlcnZpY2UtcHJpY2UtaW5wdXRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cHJpY2V9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0UHJpY2UodmFsKTtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3JzLnByaWNlKSBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIHByaWNlOiBcIlwiIH0pKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgdW5pdEhpbnQ9e3ByaWNlVW5pdEhpbnR9XG4gICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMucHJpY2V9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFN1YmNvbXBvbmVudDogU3BlY2llcyBDaGlwIFNlbGVjdG9yICovfVxuICAgICAgICAgIDxTcGVjaWVzQ2hpcFNlbGVjdG9yXG4gICAgICAgICAgICB2YWx1ZT17c3BlY2llc31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XG4gICAgICAgICAgICAgIHNldFNwZWNpZXModmFsKTtcbiAgICAgICAgICAgICAgaWYgKGVycm9ycy5zcGVjaWVzKSBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIHNwZWNpZXM6IFwiXCIgfSkpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGVycm9yPXtlcnJvcnMuc3BlY2llc31cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgey8qIFN1YmNvbXBvbmVudDogRGVzY3JpcHRpb24gKi99XG4gICAgICAgICAgPFNlcnZpY2VEZXNjcmlwdGlvbklucHV0XG4gICAgICAgICAgICB2YWx1ZT17ZGVzY3JpcHRpb259XG4gICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4ge1xuICAgICAgICAgICAgICBzZXREZXNjcmlwdGlvbih2YWwpO1xuICAgICAgICAgICAgICBpZiAoZXJyb3JzLmRlc2NyaXB0aW9uKSBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIGRlc2NyaXB0aW9uOiBcIlwiIH0pKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBlcnJvcj17ZXJyb3JzLmRlc2NyaXB0aW9ufVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICB7LyogU3ViY29tcG9uZW50OiBTdGF0dXMgRHJvcGRvd24gKi99XG4gICAgICAgICAgPFNlcnZpY2VTdGF0dXNTZWxlY3RcbiAgICAgICAgICAgIHZhbHVlPXtzdGF0dXN9XG4gICAgICAgICAgICBvbkNoYW5nZT17c2V0U3RhdHVzfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICB7LyogU3ViY29tcG9uZW50OiBBY3Rpb24gRm9vdGVyICovfVxuICAgICAgICAgIDxTZXJ2aWNlRm9ybUZvb3RlclxuICAgICAgICAgICAgb25DbG9zZT17b25DbG9zZX1cbiAgICAgICAgICAgIGlzRWRpdE1vZGU9e2lzRWRpdE1vZGV9XG4gICAgICAgICAgICBzaG93SW5jb21wbGV0ZVdhcm5pbmc9e2hhc0F0dGVtcHRlZFN1Ym1pdCAmJiBoYXNFcnJvcnN9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvU2VydmljZUZvcm1Nb2RhbC5qc3gifQ==