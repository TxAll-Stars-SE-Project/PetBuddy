import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceStatusSelect.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceStatusSelect({
  value,
  onChange,
  id = "service-status-select"
}) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-xs font-semibold text-slate-700 mb-1", children: "สถานะการให้บริการ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        id,
        value,
        onChange: (e) => onChange(e.target.value),
        className: "w-full px-3 py-2 text-sm border-2 border-slate-200 rounded-xl focus:outline-none focus:border-[#F97316] bg-white text-slate-800 cursor-pointer",
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "published", children: "เปิดรับบริการ (Published)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx",
            lineNumber: 48,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "draft", children: "ปิดรับชั่วคราว (Draft / Paused)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx",
            lineNumber: 49,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx",
        lineNumber: 42,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
}
_c = ServiceStatusSelect;
var _c;
$RefreshReg$(_c, "ServiceStatusSelect");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceStatusSelect.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkJOLE9BQU9BLFdBQVc7QUFZbEIsd0JBQXdCQyxvQkFBb0I7QUFBQSxFQUMxQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsS0FBSztBQUNQLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxXQUFNLFNBQVNBLElBQUksV0FBVSxtREFBaUQsaUNBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxDQUFDQyxNQUFNRixTQUFTRSxFQUFFQyxPQUFPSixLQUFLO0FBQUEsUUFDeEMsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxZQUFPLE9BQU0sYUFBWSx5Q0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxZQUFPLE9BQU0sU0FBUSwrQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQTtBQUFBO0FBQUEsTUFQdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUE7QUFBQSxPQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNLLEtBckJ1Qk47QUFBbUIsSUFBQU07QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTZXJ2aWNlU3RhdHVzU2VsZWN0IiwidmFsdWUiLCJvbkNoYW5nZSIsImlkIiwiZSIsInRhcmdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VTdGF0dXNTZWxlY3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBTZXJ2aWNlU3RhdHVzU2VsZWN0IENvbXBvbmVudFxuICogXG4gKiBEcm9wZG93biBzZWxlY3RvciBmb3Igc2VydmljZSBzdGF0dXMgKHB1Ymxpc2hlZCB2cyBkcmFmdC9wYXVzZWQpLlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7c3RyaW5nfSBwcm9wcy52YWx1ZSAtIEN1cnJlbnQgc3RhdHVzIHZhbHVlICgncHVibGlzaGVkJyB8ICdkcmFmdCcpLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcHJvcHMub25DaGFuZ2UgLSBIYW5kbGVyIGNhbGxlZCB3aXRoIHVwZGF0ZWQgc3RhdHVzLlxuICogQHBhcmFtIHtzdHJpbmd9IFtwcm9wcy5pZF0gLSBFbGVtZW50IGlkIGZvciBhY2Nlc3NpYmlsaXR5LlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlU3RhdHVzU2VsZWN0KHtcbiAgdmFsdWUsXG4gIG9uQ2hhbmdlLFxuICBpZCA9IFwic2VydmljZS1zdGF0dXMtc2VsZWN0XCIsXG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtpZH0gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAg4Liq4LiW4Liy4LiZ4Liw4LiB4Liy4Lij4LmD4Lir4LmJ4Lia4Lij4Li04LiB4Liy4LijXG4gICAgICA8L2xhYmVsPlxuICAgICAgPHNlbGVjdFxuICAgICAgICBpZD17aWR9XG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC1zbSBib3JkZXItMiBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bI0Y5NzMxNl0gYmctd2hpdGUgdGV4dC1zbGF0ZS04MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwicHVibGlzaGVkXCI+4LmA4Lib4Li04LiU4Lij4Lix4Lia4Lia4Lij4Li04LiB4Liy4LijIChQdWJsaXNoZWQpPC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJkcmFmdFwiPuC4m+C4tOC4lOC4o+C4seC4muC4iuC4seC5iOC4p+C4hOC4o+C4suC4pyAoRHJhZnQgLyBQYXVzZWQpPC9vcHRpb24+XG4gICAgICA8L3NlbGVjdD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3NpdHRlci9zZXJ2aWNlRm9ybS9TZXJ2aWNlU3RhdHVzU2VsZWN0LmpzeCJ9