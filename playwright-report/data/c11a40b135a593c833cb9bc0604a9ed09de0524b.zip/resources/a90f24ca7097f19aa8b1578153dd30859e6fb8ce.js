import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceCategorySelect.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { SERVICE_TYPE_OPTIONS } from "/src/utils/serviceLogic.js";
export default function ServiceCategorySelect({
  value,
  onChange,
  id = "service-type-select"
}) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-xs font-semibold text-slate-700 mb-1", children: [
      "หมวดหมู่บริการ ",
      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx",
        lineNumber: 41,
        columnNumber: 24
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        id,
        value,
        onChange: (e) => onChange(e.target.value),
        className: "w-full px-3 py-2 text-sm border-2 border-slate-200 rounded-xl focus:outline-none focus:border-[#F97316] bg-white text-slate-800 cursor-pointer",
        children: SERVICE_TYPE_OPTIONS.map(
          (opt) => /* @__PURE__ */ jsxDEV("option", { value: opt.value, children: opt.label }, opt.value, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx",
            lineNumber: 50,
            columnNumber: 9
          }, this)
        )
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx",
        lineNumber: 43,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c = ServiceCategorySelect;
var _c;
$RefreshReg$(_c, "ServiceCategorySelect");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceCategorySelect.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJ1Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXJCdkIsT0FBT0EsV0FBVztBQUNsQixTQUFTQyw0QkFBNEI7QUFZckMsd0JBQXdCQyxzQkFBc0I7QUFBQSxFQUM1Q0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsS0FBSztBQUNQLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxXQUFNLFNBQVNBLElBQUksV0FBVSxtREFBaUQ7QUFBQTtBQUFBLE1BQzlELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxDQUFDQyxNQUFNRixTQUFTRSxFQUFFQyxPQUFPSixLQUFLO0FBQUEsUUFDeEMsV0FBVTtBQUFBLFFBRVRGLCtCQUFxQk87QUFBQUEsVUFBSSxDQUFDQyxRQUN6Qix1QkFBQyxZQUF1QixPQUFPQSxJQUFJTixPQUNoQ00sY0FBSUMsU0FETUQsSUFBSU4sT0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBQ0Q7QUFBQTtBQUFBLE1BVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0E7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDUSxLQXhCdUJUO0FBQXFCLElBQUFTO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU0VSVklDRV9UWVBFX09QVElPTlMiLCJTZXJ2aWNlQ2F0ZWdvcnlTZWxlY3QiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiaWQiLCJlIiwidGFyZ2V0IiwibWFwIiwib3B0IiwibGFiZWwiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXJ2aWNlQ2F0ZWdvcnlTZWxlY3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFNFUlZJQ0VfVFlQRV9PUFRJT05TIH0gZnJvbSBcIi4uLy4uLy4uL3V0aWxzL3NlcnZpY2VMb2dpYy5qc1wiO1xuXG4vKipcbiAqIFNlcnZpY2VDYXRlZ29yeVNlbGVjdCBDb21wb25lbnRcbiAqIFxuICogRHJvcGRvd24gc2VsZWN0b3IgZm9yIHNlcnZpY2UgY2F0ZWdvcnkgKHdhbGtpbmcsIGRheWNhcmUsIGJvYXJkaW5nLCBncm9vbWluZywgc2l0dGluZykuXG4gKiBcbiAqIEBwYXJhbSB7T2JqZWN0fSBwcm9wc1xuICogQHBhcmFtIHtzdHJpbmd9IHByb3BzLnZhbHVlIC0gU2VsZWN0ZWQgc2VydmljZSBjYXRlZ29yeS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2hhbmdlIC0gSGFuZGxlciBjYWxsZWQgd2l0aCBzZWxlY3RlZCBjYXRlZ29yeSB2YWx1ZS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBbcHJvcHMuaWRdIC0gRWxlbWVudCBpZCBmb3IgYWNjZXNzaWJpbGl0eS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VydmljZUNhdGVnb3J5U2VsZWN0KHtcbiAgdmFsdWUsXG4gIG9uQ2hhbmdlLFxuICBpZCA9IFwic2VydmljZS10eXBlLXNlbGVjdFwiLFxufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8bGFiZWwgaHRtbEZvcj17aWR9IGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgIOC4q+C4oeC4p+C4lOC4q+C4oeC4ueC5iOC4muC4o+C4tOC4geC4suC4oyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxuICAgICAgPC9sYWJlbD5cbiAgICAgIDxzZWxlY3RcbiAgICAgICAgaWQ9e2lkfVxuICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLXhsIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyNGOTczMTZdIGJnLXdoaXRlIHRleHQtc2xhdGUtODAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgID5cbiAgICAgICAge1NFUlZJQ0VfVFlQRV9PUFRJT05TLm1hcCgob3B0KSA9PiAoXG4gICAgICAgICAgPG9wdGlvbiBrZXk9e29wdC52YWx1ZX0gdmFsdWU9e29wdC52YWx1ZX0+XG4gICAgICAgICAgICB7b3B0LmxhYmVsfVxuICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICApKX1cbiAgICAgIDwvc2VsZWN0PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL3NlcnZpY2VGb3JtL1NlcnZpY2VDYXRlZ29yeVNlbGVjdC5qc3gifQ==