import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/MyServicesSection.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import ServiceCard from "/src/components/sitter/dashboard/ServiceCard.jsx";
import ServiceCardSkeleton from "/src/components/ui/ServiceCardSkeleton.jsx";
export default function MyServicesSection({
  services = [],
  isLoading = false,
  onAddService,
  onEditService,
  onDeleteService
}) {
  return /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-2xl border border-slate-200 custom-shadow p-5 sm:p-6 space-y-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-slate-200 flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-base sm:text-lg font-bold text-slate-900 leading-tight", children: "บริการของฉัน (My Services)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
            lineNumber: 53,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "bg-slate-100 text-slate-700 border border-slate-300 text-xs px-2.5 py-0.5 rounded-full font-bold", children: [
            services.length,
            " บริการ"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
            lineNumber: 56,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 font-medium mt-0.5", children: "จัดการรายการบริการที่คุณเปิดรับดูแล" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 60,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onAddService,
          className: "px-4 py-2 bg-[#0F766E] hover:bg-[#115E59] text-white rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 shadow-xs cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-base leading-none font-bold", children: "+" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
              lineNumber: 70,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "เพิ่มบริการใหม่" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
              lineNumber: 71,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 65,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    isLoading && services.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [1, 2, 3].map(
      (n) => /* @__PURE__ */ jsxDEV(ServiceCardSkeleton, {}, n, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this) : services.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-12 px-6 text-center bg-[#FAFBFB] rounded-2xl border-2 border-dashed border-slate-200 space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.5", d: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 86,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 85,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 84,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-slate-800", children: "ยังไม่มีบริการที่คุณเปิดรับ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 90,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 max-w-sm mx-auto", children: "คุณยังไม่ได้ลงทะเบียนบริการใดๆ คลิกปุ่มด้านล่างเพื่อเริ่มสร้างบริการแรกของคุณ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 91,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
        lineNumber: 89,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onAddService,
          className: "mt-1 inline-flex items-center gap-1.5 px-4 py-2 bg-[#0F766E] hover:bg-[#115E59] text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-all cursor-pointer",
          children: /* @__PURE__ */ jsxDEV("span", { children: "+ เพิ่มบริการใหม่" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
            lineNumber: 100,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 95,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
      lineNumber: 83,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: services.map((service) => {
      const sId = service.serviceId || service.serviceid || service.id;
      return /* @__PURE__ */ jsxDEV(
        ServiceCard,
        {
          service,
          onEdit: () => onEditService && onEditService(service),
          onDelete: () => onDeleteService && onDeleteService(sId)
        },
        sId,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
          lineNumber: 108,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
      lineNumber: 104,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
_c = MyServicesSection;
var _c;
$RefreshReg$(_c, "MyServicesSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/MyServicesSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNZOzs7Ozs7Ozs7Ozs7Ozs7O0FBakNaLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLHlCQUF5QjtBQWtCaEMsd0JBQXdCQyxrQkFBa0I7QUFBQSxFQUN4Q0MsV0FBVztBQUFBLEVBQ1hDLFlBQVk7QUFBQSxFQUNaQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLGFBQVEsV0FBVSxtRkFFakI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLCtEQUE2RCwwQ0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLG9HQUNiSjtBQUFBQSxxQkFBU0s7QUFBQUEsWUFBTztBQUFBLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDZDQUEyQyxtREFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTSDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG9DQUFtQyxpQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNwRCx1QkFBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUE7QUFBQTtBQUFBLFFBTnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBR0NELGFBQWFELFNBQVNLLFdBQVcsSUFDaEMsdUJBQUMsU0FBSSxXQUFVLHdEQUNaLFdBQUMsR0FBRyxHQUFHLENBQUMsRUFBRUM7QUFBQUEsTUFBSSxDQUFDQyxNQUNkLHVCQUFDLHlCQUF5QkEsR0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLElBQzdCLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLElBQ0VQLFNBQVNLLFdBQVcsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLHFHQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNIQUNiLGlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLE9BQU0sR0FBRSxxRUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SSxLQUQxSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLG9DQUFtQywyQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUMsNkZBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0g7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFFVixpQ0FBQyxVQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUE7QUFBQSxRQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pGLG1CQUFTTSxJQUFJLENBQUNFLFlBQVk7QUFDekIsWUFBTUMsTUFBTUQsUUFBUUUsYUFBYUYsUUFBUUcsYUFBYUgsUUFBUUk7QUFDOUQsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUM7QUFBQSxVQUNBLFFBQVEsTUFBTVQsaUJBQWlCQSxjQUFjSyxPQUFPO0FBQUEsVUFDcEQsVUFBVSxNQUFNSixtQkFBbUJBLGdCQUFnQkssR0FBRztBQUFBO0FBQUEsUUFIakRBO0FBQUFBLFFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUkwRDtBQUFBLElBRzlELENBQUMsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQXBFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0VBO0FBRUo7QUFBQ0ksS0FoRnVCZDtBQUFpQixJQUFBYztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNlcnZpY2VDYXJkIiwiU2VydmljZUNhcmRTa2VsZXRvbiIsIk15U2VydmljZXNTZWN0aW9uIiwic2VydmljZXMiLCJpc0xvYWRpbmciLCJvbkFkZFNlcnZpY2UiLCJvbkVkaXRTZXJ2aWNlIiwib25EZWxldGVTZXJ2aWNlIiwibGVuZ3RoIiwibWFwIiwibiIsInNlcnZpY2UiLCJzSWQiLCJzZXJ2aWNlSWQiLCJzZXJ2aWNlaWQiLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk15U2VydmljZXNTZWN0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2VydmljZUNhcmQgZnJvbSBcIi4vU2VydmljZUNhcmQuanN4XCI7XG5pbXBvcnQgU2VydmljZUNhcmRTa2VsZXRvbiBmcm9tIFwiLi4vLi4vdWkvU2VydmljZUNhcmRTa2VsZXRvbi5qc3hcIjtcblxuLyoqXG4gKiBNeVNlcnZpY2VzU2VjdGlvbiBDb21wb25lbnRcbiAqIFxuICogU2l0dGVyIERhc2hib2FyZCBzZWN0aW9uIGZvciBtYW5hZ2luZyBwZXQgY2FyZSBzZXJ2aWNlczpcbiAqIC0gSGVhZGVyIHdpdGggc2VydmljZSBjb3VudCBiYWRnZSBhbmQgXCIrIOC5gOC4nuC4tOC5iOC4oeC4muC4o+C4tOC4geC4suC4o+C5g+C4q+C4oeC5iFwiIGFjdGlvbiBidXR0b24uXG4gKiAtIExvYWRpbmcgc3Bpbm5lciBzdGF0ZSB3aGVuIGZldGNoaW5nIHNlcnZpY2VzLlxuICogLSBDbGVhbiBlbXB0eSBzdGF0ZSB3aGVuIG5vIHNlcnZpY2VzIGFyZSByZWdpc3RlcmVkIHlldC5cbiAqIC0gUmVzcG9uc2l2ZSAzLWNvbHVtbiBncmlkIHJlbmRlcmluZyBpbmRpdmlkdWFsIFNlcnZpY2VDYXJkcy5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge0FycmF5fSBwcm9wcy5zZXJ2aWNlcyAtIEFycmF5IG9mIHNlcnZpY2Ugb2JqZWN0cy5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gcHJvcHMuaXNMb2FkaW5nIC0gTG9hZGluZyBzdGF0ZSBmbGFnLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcHJvcHMub25BZGRTZXJ2aWNlIC0gQ2FsbGJhY2sgdG8gb3BlbiB0aGUgYWRkIHNlcnZpY2UgbW9kYWwuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vbkVkaXRTZXJ2aWNlIC0gQ2FsbGJhY2sgdG8gZWRpdCBhIHNwZWNpZmljIHNlcnZpY2UuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vbkRlbGV0ZVNlcnZpY2UgLSBDYWxsYmFjayB0byBkZWxldGUgYSBzcGVjaWZpYyBzZXJ2aWNlIGJ5IElELlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNeVNlcnZpY2VzU2VjdGlvbih7XG4gIHNlcnZpY2VzID0gW10sXG4gIGlzTG9hZGluZyA9IGZhbHNlLFxuICBvbkFkZFNlcnZpY2UsXG4gIG9uRWRpdFNlcnZpY2UsXG4gIG9uRGVsZXRlU2VydmljZSxcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBjdXN0b20tc2hhZG93IHAtNSBzbTpwLTYgc3BhY2UteS00XCI+XG4gICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBzbTp0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIOC4muC4o+C4tOC4geC4suC4o+C4guC4reC4h+C4ieC4seC4mSAoTXkgU2VydmljZXMpXG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQteHMgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHtzZXJ2aWNlcy5sZW5ndGh9IOC4muC4o+C4tOC4geC4suC4o1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gbXQtMC41XCI+XG4gICAgICAgICAgICDguIjguLHguJTguIHguLLguKPguKPguLLguKLguIHguLLguKPguJrguKPguLTguIHguLLguKPguJfguLXguYjguITguLjguJPguYDguJvguLTguJTguKPguLHguJrguJTguLnguYHguKVcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkFkZFNlcnZpY2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLVsjMEY3NjZFXSBob3ZlcjpiZy1bIzExNUU1OV0gdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGxlYWRpbmctbm9uZSBmb250LWJvbGRcIj4rPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPuC5gOC4nuC4tOC5iOC4oeC4muC4o+C4tOC4geC4suC4o+C5g+C4q+C4oeC5iDwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNlcnZpY2UgQ2FyZHMgR3JpZCAvIEVtcHR5IC8gTG9hZGluZyBTdGF0ZSAqL31cbiAgICAgIHtpc0xvYWRpbmcgJiYgc2VydmljZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICB7WzEsIDIsIDNdLm1hcCgobikgPT4gKFxuICAgICAgICAgICAgPFNlcnZpY2VDYXJkU2tlbGV0b24ga2V5PXtufSAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiBzZXJ2aWNlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgcHgtNiB0ZXh0LWNlbnRlciBiZy1bI0ZBRkJGQl0gcm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMjAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIG14LWF1dG8gcm91bmRlZC0yeGwgYmctc2xhdGUtMTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNiBoLTZcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMS41XCIgZD1cIk0yMCA3bC04LTQtOCA0bTE2IDBsLTggNG04LTR2MTBsLTggNG0wLTEwTDQgN204IDR2MTBNNCA3djEwbDggNFwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj7guKLguLHguIfguYTguKHguYjguKHguLXguJrguKPguLTguIHguLLguKPguJfguLXguYjguITguLjguJPguYDguJvguLTguJTguKPguLHguJo8L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG1heC13LXNtIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAg4LiE4Li44LiT4Lii4Lix4LiH4LmE4Lih4LmI4LmE4LiU4LmJ4Lil4LiH4LiX4Liw4LmA4Lia4Li14Lii4LiZ4Lia4Lij4Li04LiB4Liy4Lij4LmD4LiU4LmGIOC4hOC4peC4tOC4geC4m+C4uOC5iOC4oeC4lOC5ieC4suC4meC4peC5iOC4suC4h+C5gOC4nuC4t+C5iOC4reC5gOC4o+C4tOC5iOC4oeC4quC4o+C5ieC4suC4h+C4muC4o+C4tOC4geC4suC4o+C5geC4o+C4geC4guC4reC4h+C4hOC4uOC4k1xuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25BZGRTZXJ2aWNlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgYmctWyMwRjc2NkVdIGhvdmVyOmJnLVsjMTE1RTU5XSB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtYm9sZCBzaGFkb3cteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPisg4LmA4Lie4Li04LmI4Lih4Lia4Lij4Li04LiB4Liy4Lij4LmD4Lir4Lih4LmIPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICAgIHtzZXJ2aWNlcy5tYXAoKHNlcnZpY2UpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNJZCA9IHNlcnZpY2Uuc2VydmljZUlkIHx8IHNlcnZpY2Uuc2VydmljZWlkIHx8IHNlcnZpY2UuaWQ7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8U2VydmljZUNhcmRcbiAgICAgICAgICAgICAgICBrZXk9e3NJZH1cbiAgICAgICAgICAgICAgICBzZXJ2aWNlPXtzZXJ2aWNlfVxuICAgICAgICAgICAgICAgIG9uRWRpdD17KCkgPT4gb25FZGl0U2VydmljZSAmJiBvbkVkaXRTZXJ2aWNlKHNlcnZpY2UpfVxuICAgICAgICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiBvbkRlbGV0ZVNlcnZpY2UgJiYgb25EZWxldGVTZXJ2aWNlKHNJZCl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL2Rhc2hib2FyZC9NeVNlcnZpY2VzU2VjdGlvbi5qc3gifQ==