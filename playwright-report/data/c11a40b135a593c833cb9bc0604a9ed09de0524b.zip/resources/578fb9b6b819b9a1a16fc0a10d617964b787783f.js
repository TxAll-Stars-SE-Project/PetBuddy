import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/ServiceFeedbackModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"];
export default function ServiceFeedbackModal({
  onClose,
  type = "create",
  serviceData = null
}) {
  _s();
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && onClose) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);
  const isCreate = type === "create";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "feedback-title",
      className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in",
      onClick: (e) => {
        if (e.target === e.currentTarget && onClose) onClose();
      },
      children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl max-w-md w-full p-6 text-center border border-slate-200 shadow-xl space-y-5 animate-scale-up", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: isCreate ? /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-[#FFF3E8] border border-[#FED7AA] text-[#F97316] flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-8 h-8",
            fill: "none",
            viewBox: "0 0 24 24",
            strokeWidth: 2.5,
            stroke: "currentColor",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M4.5 12.75l6 6 9-13.5"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
                lineNumber: 76,
                columnNumber: 17
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 69,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 68,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center shadow-xs", children: /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-8 h-8",
            fill: "none",
            viewBox: "0 0 24 24",
            strokeWidth: 2.5,
            stroke: "currentColor",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M4.5 12.75l6 6 9-13.5"
              },
              void 0,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
                lineNumber: 92,
                columnNumber: 17
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 85,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 84,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 66,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(
            "h3",
            {
              id: "feedback-title",
              className: "text-lg font-bold text-slate-800",
              children: isCreate ? "Your service has been published successfully" : "Service details updated successfully."
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
              lineNumber: 104,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: isCreate ? "บริการของคุณเปิดรับจองจากเจ้าของสัตว์เลี้ยงเรียบร้อยแล้ว" : "บันทึกการแก้ไขข้อมูลและอัตราค่าบริการเรียบร้อยแล้ว" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 112,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 103,
          columnNumber: 9
        }, this),
        serviceData && /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-left text-xs space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 text-sm", children: serviceData.serviceName || serviceData.servicename || "บริการดูแลสัตว์เลี้ยง" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
              lineNumber: 123,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#F97316] text-sm", children: [
              "฿",
              serviceData.price,
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-normal text-slate-500", children: serviceData.priceUnitHint || "/ ครั้ง" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
                lineNumber: 128,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
              lineNumber: 126,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 122,
            columnNumber: 13
          }, this),
          Array.isArray(serviceData.species) && serviceData.species.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5 pt-1", children: serviceData.species.map(
            (sp) => /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: "px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[11px] text-slate-600",
                children: sp === "dog" ? "สุนัข" : sp === "cat" ? "แมว" : sp === "bird" ? "นก" : sp === "small_animal" ? "สัตว์ขนาดเล็ก" : sp
              },
              sp,
              false,
              {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
                lineNumber: 137,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 135,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 121,
          columnNumber: 9
        }, this),
        !isCreate && /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-[11px] text-blue-900 text-left flex items-start gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4 text-blue-600 shrink-0 mt-0.5",
              viewBox: "0 0 20 20",
              fill: "currentColor",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  fillRule: "evenodd",
                  d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                  clipRule: "evenodd"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
                  lineNumber: 165,
                  columnNumber: 15
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
              lineNumber: 160,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "ข้อตกลงประวัติการจองเดิม:" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
              lineNumber: 172,
              columnNumber: 15
            }, this),
            " อัตราและเงื่อนไขใหม่นี้จะมีผลกับการจองใหม่หลังจากนี้เป็นต้นไป โดยไม่มีผลกระทบต่อราคาที่ตกลงไว้ในประวัติการจองเดิม"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 171,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 159,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onClose,
            className: "w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#F97316] hover:bg-[#EA580C] transition-colors shadow-xs cursor-pointer",
            children: isCreate ? "ดูบริการของฉัน" : "ตกลง"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
            lineNumber: 179,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
          lineNumber: 178,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
        lineNumber: 64,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx",
      lineNumber: 55,
      columnNumber: 5
    },
    this
  );
}
_s(ServiceFeedbackModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ServiceFeedbackModal;
var _c;
$RefreshReg$(_c, "ServiceFeedbackModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceFeedbackModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF4RGhCLE9BQU9BLFNBQVNDLGlCQUFpQjtBQWdCakMsd0JBQXdCQyxxQkFBcUI7QUFBQSxFQUMzQ0M7QUFBQUEsRUFDQUMsT0FBTztBQUFBLEVBQ1BDLGNBQWM7QUFDaEIsR0FBRztBQUFBQyxLQUFBO0FBRURMLFlBQVUsTUFBTTtBQUNkLFVBQU1NLGdCQUFnQkEsQ0FBQ0MsTUFBTTtBQUMzQixVQUFJQSxFQUFFQyxRQUFRLFlBQVlOLFNBQVM7QUFDakNBLGdCQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFDQU8sV0FBT0MsaUJBQWlCLFdBQVdKLGFBQWE7QUFDaEQsV0FBTyxNQUFNRyxPQUFPRSxvQkFBb0IsV0FBV0wsYUFBYTtBQUFBLEVBQ2xFLEdBQUcsQ0FBQ0osT0FBTyxDQUFDO0FBRVosUUFBTVUsV0FBV1QsU0FBUztBQUUxQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxjQUFXO0FBQUEsTUFDWCxtQkFBZ0I7QUFBQSxNQUNoQixXQUFVO0FBQUEsTUFDVixTQUFTLENBQUNJLE1BQU07QUFDZCxZQUFJQSxFQUFFTSxXQUFXTixFQUFFTyxpQkFBaUJaLFFBQVNBLFNBQVE7QUFBQSxNQUN2RDtBQUFBLE1BRUEsaUNBQUMsU0FBSSxXQUFVLHFIQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVCQUNaVSxxQkFDQyx1QkFBQyxTQUFJLFdBQVUseUhBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLGFBQWE7QUFBQSxZQUNiLFFBQU87QUFBQSxZQUVQO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsR0FBRTtBQUFBO0FBQUEsY0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHMkI7QUFBQTtBQUFBLFVBVjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhIQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixNQUFLO0FBQUEsWUFDTCxTQUFRO0FBQUEsWUFDUixhQUFhO0FBQUEsWUFDYixRQUFPO0FBQUEsWUFFUDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGVBQWM7QUFBQSxnQkFDZCxnQkFBZTtBQUFBLGdCQUNmLEdBQUU7QUFBQTtBQUFBLGNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRzJCO0FBQUE7QUFBQSxVQVY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQSxLQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FFVEEscUJBQ0csaURBQ0E7QUFBQTtBQUFBLFlBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwwQkFDVkEscUJBQ0csNkRBQ0Esd0RBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFHQ1IsZUFDQyx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsb0NBQ2JBLHNCQUFZVyxlQUFlWCxZQUFZWSxlQUFlLDJCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsb0NBQWtDO0FBQUE7QUFBQSxjQUM5Q1osWUFBWWE7QUFBQUEsY0FBTztBQUFBLGNBQ3JCLHVCQUFDLFVBQUssV0FBVSwwQ0FDYmIsc0JBQVljLGlCQUFpQixhQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUNDLE1BQU1DLFFBQVFoQixZQUFZaUIsT0FBTyxLQUFLakIsWUFBWWlCLFFBQVFDLFNBQVMsS0FDbEUsdUJBQUMsU0FBSSxXQUFVLCtCQUNabEIsc0JBQVlpQixRQUFRRTtBQUFBQSxZQUFJLENBQUNDLE9BQ3hCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVUQSxpQkFBTyxRQUNKLFVBQ0FBLE9BQU8sUUFDUCxRQUNBQSxPQUFPLFNBQ1AsT0FDQUEsT0FBTyxpQkFDUCxrQkFDQUE7QUFBQUE7QUFBQUEsY0FYQ0E7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxVQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsYUEvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQTtBQUFBLFFBSUQsQ0FBQ1osWUFDQSx1QkFBQyxTQUFJLFdBQVUsa0hBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBRUw7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsVUFBUztBQUFBLGtCQUNULEdBQUU7QUFBQSxrQkFDRixVQUFTO0FBQUE7QUFBQSxnQkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHb0I7QUFBQTtBQUFBLFlBUnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQSx1QkFBQyxVQUNDO0FBQUEsbUNBQUMsWUFBTyx5Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQVM7QUFBQSxlQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUlGLHVCQUFDLFNBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNWO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVRVLHFCQUFXLG1CQUFtQjtBQUFBO0FBQUEsVUFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkhBO0FBQUE7QUFBQSxJQXBJRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxSUE7QUFFSjtBQUFDUCxHQTFKdUJKLHNCQUFvQjtBQUFBLEtBQXBCQTtBQUFvQixJQUFBd0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJTZXJ2aWNlRmVlZGJhY2tNb2RhbCIsIm9uQ2xvc2UiLCJ0eXBlIiwic2VydmljZURhdGEiLCJfcyIsImhhbmRsZUtleURvd24iLCJlIiwia2V5Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJpc0NyZWF0ZSIsInRhcmdldCIsImN1cnJlbnRUYXJnZXQiLCJzZXJ2aWNlTmFtZSIsInNlcnZpY2VuYW1lIiwicHJpY2UiLCJwcmljZVVuaXRIaW50IiwiQXJyYXkiLCJpc0FycmF5Iiwic3BlY2llcyIsImxlbmd0aCIsIm1hcCIsInNwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VydmljZUZlZWRiYWNrTW9kYWwuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBTZXJ2aWNlRmVlZGJhY2tNb2RhbCBDb21wb25lbnRcbiAqIFxuICog8J+OkyBMYXllciAzOiBQcmVzZW50YXRpb24gVUkgTW9kYWxcbiAqIC0gRGlzcGxheXMgYSBjb3p5LCByZWFzc3VyaW5nIGZlZWRiYWNrIHBvcHVwIHdoZW4gYSBzZXJ2aWNlIGlzIHB1Ymxpc2hlZCBvciB1cGRhdGVkLlxuICogLSBDb21wbGllcyB3aXRoIFplcm8gRW1vamlzIGRlc2lnbiBzdGFuZGFyZCB1c2luZyBjbGVhbiBTVkdzLlxuICogLSBFeHBsaWNpdGx5IGNvbW11bmljYXRlcyBoaXN0b3JpY2FsIGJvb2tpbmcgc25hcHNob3QgaW50ZWdyaXR5IGZvciBlZGl0cy5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHByb3BzLmlzT3BlbiAtIE1vZGFsIHZpc2liaWxpdHkgZmxhZy5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2xvc2UgLSBNb2RhbCBkaXNtaXNzYWwgY2FsbGJhY2suXG4gKiBAcGFyYW0geydjcmVhdGUnfCdlZGl0J30gcHJvcHMudHlwZSAtIE9wZXJhdGlvbiB0eXBlICgnY3JlYXRlJyBmb3IgcHVibGlzaCwgJ2VkaXQnIGZvciB1cGRhdGUpLlxuICogQHBhcmFtIHtPYmplY3R8bnVsbH0gcHJvcHMuc2VydmljZURhdGEgLSBTdW1tYXJ5IG9mIHRoZSBjcmVhdGVkL2VkaXRlZCBzZXJ2aWNlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlRmVlZGJhY2tNb2RhbCh7XG4gIG9uQ2xvc2UsXG4gIHR5cGUgPSBcImNyZWF0ZVwiLFxuICBzZXJ2aWNlRGF0YSA9IG51bGwsXG59KSB7XG4gIC8vIEFjY2Vzc2liaWxpdHk6IENsb3NlIG9uIEVzY2FwZSBrZXkgcHJlc3MgKEFjdGl2ZSB3aGlsZSBtb3VudGVkKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZSkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiICYmIG9uQ2xvc2UpIHtcbiAgICAgICAgb25DbG9zZSgpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtvbkNsb3NlXSk7XG5cbiAgY29uc3QgaXNDcmVhdGUgPSB0eXBlID09PSBcImNyZWF0ZVwiO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsbGVkYnk9XCJmZWVkYmFjay10aXRsZVwiXG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLXNsYXRlLTkwMC82MCBiYWNrZHJvcC1ibHVyLXhzIGFuaW1hdGUtZmFkZS1pblwiXG4gICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICBpZiAoZS50YXJnZXQgPT09IGUuY3VycmVudFRhcmdldCAmJiBvbkNsb3NlKSBvbkNsb3NlKCk7XG4gICAgICB9fVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgbWF4LXctbWQgdy1mdWxsIHAtNiB0ZXh0LWNlbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3cteGwgc3BhY2UteS01IGFuaW1hdGUtc2NhbGUtdXBcIj5cbiAgICAgICAgey8qIEhlYWRlciBJY29uIEJhZGdlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICB7aXNDcmVhdGUgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctWyNGRkYzRThdIGJvcmRlciBib3JkZXItWyNGRUQ3QUFdIHRleHQtWyNGOTczMTZdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOFwiXG4gICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyLjV9XG4gICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBkPVwiTTQuNSAxMi43NWw2IDYgOS0xMy41XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHRleHQtZW1lcmFsZC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04XCJcbiAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezIuNX1cbiAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNNC41IDEyLjc1bDYgNiA5LTEzLjVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRpdGxlICYgSGVhZGxpbmUgKFN0cmljdCBCREQgdGV4dCBtYXRjaGluZykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICA8aDNcbiAgICAgICAgICAgIGlkPVwiZmVlZGJhY2stdGl0bGVcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc0NyZWF0ZVxuICAgICAgICAgICAgICA/IFwiWW91ciBzZXJ2aWNlIGhhcyBiZWVuIHB1Ymxpc2hlZCBzdWNjZXNzZnVsbHlcIlxuICAgICAgICAgICAgICA6IFwiU2VydmljZSBkZXRhaWxzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LlwifVxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAge2lzQ3JlYXRlXG4gICAgICAgICAgICAgID8gXCLguJrguKPguLTguIHguLLguKPguILguK3guIfguITguLjguJPguYDguJvguLTguJTguKPguLHguJrguIjguK3guIfguIjguLLguIHguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguYDguKPguLXguKLguJrguKPguYnguK3guKLguYHguKXguYnguKdcIlxuICAgICAgICAgICAgICA6IFwi4Lia4Lix4LiZ4LiX4Li24LiB4LiB4Liy4Lij4LmB4LiB4LmJ4LmE4LiC4LiC4LmJ4Lit4Lih4Li54Lil4LmB4Lil4Liw4Lit4Lix4LiV4Lij4Liy4LiE4LmI4Liy4Lia4Lij4Li04LiB4Liy4Lij4LmA4Lij4Li14Lii4Lia4Lij4LmJ4Lit4Lii4LmB4Lil4LmJ4LinXCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2VydmljZSBTdW1tYXJ5IENhcmQgKi99XG4gICAgICAgIHtzZXJ2aWNlRGF0YSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLXhsIHAtMy41IHRleHQtbGVmdCB0ZXh0LXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICB7c2VydmljZURhdGEuc2VydmljZU5hbWUgfHwgc2VydmljZURhdGEuc2VydmljZW5hbWUgfHwgXCLguJrguKPguLTguIHguLLguKPguJTguLnguYHguKXguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIdcIn1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bI0Y5NzMxNl0gdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgIOC4v3tzZXJ2aWNlRGF0YS5wcmljZX17XCIgXCJ9XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtzZXJ2aWNlRGF0YS5wcmljZVVuaXRIaW50IHx8IFwiLyDguITguKPguLHguYnguIdcIn1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7QXJyYXkuaXNBcnJheShzZXJ2aWNlRGF0YS5zcGVjaWVzKSAmJiBzZXJ2aWNlRGF0YS5zcGVjaWVzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjUgcHQtMVwiPlxuICAgICAgICAgICAgICAgIHtzZXJ2aWNlRGF0YS5zcGVjaWVzLm1hcCgoc3ApID0+IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGtleT17c3B9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7c3AgPT09IFwiZG9nXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwi4Liq4Li44LiZ4Lix4LiCXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IHNwID09PSBcImNhdFwiXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIuC5geC4oeC4p1wiXG4gICAgICAgICAgICAgICAgICAgICAgOiBzcCA9PT0gXCJiaXJkXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwi4LiZ4LiBXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IHNwID09PSBcInNtYWxsX2FuaW1hbFwiXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIuC4quC4seC4leC4p+C5jOC4guC4meC4suC4lOC5gOC4peC5h+C4gVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBzcH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBTY2VuYXJpbyAyIFJlYXNzdXJhbmNlIE5vdGUgKEZvciBFZGl0IE1vZGUpICovfVxuICAgICAgICB7IWlzQ3JlYXRlICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLWJsdWUtNTAvNzAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCB0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtOTAwIHRleHQtbGVmdCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMCBzaHJpbmstMCBtdC0wLjVcIlxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcbiAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgICAgICAgICBkPVwiTTE4IDEwYTggOCAwIDExLTE2IDAgOCA4IDAgMDExNiAwem0tNy00YTEgMSAwIDExLTIgMCAxIDEgMCAwMTIgMHpNOSA5YTEgMSAwIDAwMCAydjNhMSAxIDAgMDAxIDFoMWExIDEgMCAxMDAtMnYtM2ExIDEgMCAwMC0xLTFIOXpcIlxuICAgICAgICAgICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICA8c3Ryb25nPuC4guC5ieC4reC4leC4geC4peC4h+C4m+C4o+C4sOC4p+C4seC4leC4tOC4geC4suC4o+C4iOC4reC4h+C5gOC4lOC4tOC4oTo8L3N0cm9uZz4g4Lit4Lix4LiV4Lij4Liy4LmB4Lil4Liw4LmA4LiH4Li34LmI4Lit4LiZ4LmE4LiC4LmD4Lir4Lih4LmI4LiZ4Li14LmJ4LiI4Liw4Lih4Li14Lic4Lil4LiB4Lix4Lia4LiB4Liy4Lij4LiI4Lit4LiH4LmD4Lir4Lih4LmI4Lir4Lil4Lix4LiH4LiI4Liy4LiB4LiZ4Li14LmJ4LmA4Lib4LmH4LiZ4LiV4LmJ4LiZ4LmE4LibIOC5guC4lOC4ouC5hOC4oeC5iOC4oeC4teC4nOC4peC4geC4o+C4sOC4l+C4muC4leC5iOC4reC4o+C4suC4hOC4suC4l+C4teC5iOC4leC4geC4peC4h+C5hOC4p+C5ieC5g+C4meC4m+C4o+C4sOC4p+C4seC4leC4tOC4geC4suC4o+C4iOC4reC4h+C5gOC4lOC4tOC4oVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBBY3Rpb24gQnV0dG9uICovfVxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctWyNGOTczMTZdIGhvdmVyOmJnLVsjRUE1ODBDXSB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc0NyZWF0ZSA/IFwi4LiU4Li54Lia4Lij4Li04LiB4Liy4Lij4LiC4Lit4LiH4LiJ4Lix4LiZXCIgOiBcIuC4leC4geC4peC4h1wifVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL2Rhc2hib2FyZC9TZXJ2aWNlRmVlZGJhY2tNb2RhbC5qc3gifQ==