import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceNameInput.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceNameInput({
  value,
  onChange,
  error = "",
  id = "service-name-input"
}) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-xs font-semibold text-slate-700 mb-1", children: [
      "ชื่อบริการ ",
      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx",
        lineNumber: 42,
        columnNumber: 20
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        id,
        type: "text",
        value,
        onChange: (e) => onChange(e.target.value),
        placeholder: "เช่น รับฝากดูแลรายวัน มีสนามหญ้าวิ่งเล่น",
        className: `w-full px-3 py-2 text-sm border-2 rounded-xl focus:outline-none bg-white text-slate-800 transition-colors ${error ? "border-red-400 focus:border-red-500" : "border-slate-200 focus:border-[#F97316]"}`
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx",
        lineNumber: 44,
        columnNumber: 7
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-500 mt-1 block", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_c = ServiceNameInput;
var _c;
$RefreshReg$(_c, "ServiceNameInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceNameInput.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JtQjs7Ozs7Ozs7Ozs7Ozs7OztBQXRCbkIsT0FBT0EsV0FBVztBQWFsQix3QkFBd0JDLGlCQUFpQjtBQUFBLEVBQ3ZDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxRQUFRO0FBQUEsRUFDUkMsS0FBSztBQUNQLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxXQUFNLFNBQVNBLElBQUksV0FBVSxtREFBaUQ7QUFBQTtBQUFBLE1BQ2xFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxNQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0EsVUFBVSxDQUFDQyxNQUFNSCxTQUFTRyxFQUFFQyxPQUFPTCxLQUFLO0FBQUEsUUFDeEMsYUFBWTtBQUFBLFFBQ1osV0FBVyw2R0FDVEUsUUFDSSx3Q0FDQSx5Q0FBeUM7QUFBQTtBQUFBLE1BVGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVLO0FBQUEsSUFFSkEsU0FDQyx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLE9BakI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0ksS0E1QnVCUDtBQUFnQixJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNlcnZpY2VOYW1lSW5wdXQiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZXJyb3IiLCJpZCIsImUiLCJ0YXJnZXQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXJ2aWNlTmFtZUlucHV0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogU2VydmljZU5hbWVJbnB1dCBDb21wb25lbnRcbiAqIFxuICogU3BlY2lhbGl6ZWQgaW5wdXQgZmllbGQgZm9yIHNlcnZpY2UgbmFtZSB3aXRoIHJlcXVpcmVkIGluZGljYXRvciBhbmQgZXJyb3IgbWVzc2FnZS5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge3N0cmluZ30gcHJvcHMudmFsdWUgLSBDdXJyZW50IHNlcnZpY2UgbmFtZSB0ZXh0LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcHJvcHMub25DaGFuZ2UgLSBIYW5kbGVyIGNhbGxlZCB3aXRoIHVwZGF0ZWQgdGV4dC5cbiAqIEBwYXJhbSB7c3RyaW5nfSBbcHJvcHMuZXJyb3JdIC0gVmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlIGlmIGFueS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBbcHJvcHMuaWRdIC0gRWxlbWVudCBpZCBmb3IgYWNjZXNzaWJpbGl0eS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VydmljZU5hbWVJbnB1dCh7XG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbiAgZXJyb3IgPSBcIlwiLFxuICBpZCA9IFwic2VydmljZS1uYW1lLWlucHV0XCIsXG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtpZH0gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAg4LiK4Li34LmI4Lit4Lia4Lij4Li04LiB4Liy4LijIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGlucHV0XG4gICAgICAgIGlkPXtpZH1cbiAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICBwbGFjZWhvbGRlcj1cIuC5gOC4iuC5iOC4mSDguKPguLHguJrguJ3guLLguIHguJTguLnguYHguKXguKPguLLguKLguKfguLHguJkg4Lih4Li14Liq4LiZ4Liy4Lih4Lir4LiN4LmJ4Liy4Lin4Li04LmI4LiH4LmA4Lil4LmI4LiZXCJcbiAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMiB0ZXh0LXNtIGJvcmRlci0yIHJvdW5kZWQteGwgZm9jdXM6b3V0bGluZS1ub25lIGJnLXdoaXRlIHRleHQtc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgZXJyb3JcbiAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTQwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiXG4gICAgICAgICAgICA6IFwiYm9yZGVyLXNsYXRlLTIwMCBmb2N1czpib3JkZXItWyNGOTczMTZdXCJcbiAgICAgICAgfWB9XG4gICAgICAvPlxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC01MDAgbXQtMSBibG9ja1wiPntlcnJvcn08L3NwYW4+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL3NlcnZpY2VGb3JtL1NlcnZpY2VOYW1lSW5wdXQuanN4In0=