import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ReviewModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { saveBookingReview } from "/src/utils/reviewStorage.js";
import { createBookingReview } from "/src/services/reviews.js";
import { toast } from "/src/utils/toast.js";
const RATING_LABELS = {
  1: "ต้องปรับปรุง (1/5)",
  2: "พอใช้ (2/5)",
  3: "ปานกลาง (3/5)",
  4: "ดีมาก (4/5)",
  5: "ยอดเยี่ยม ประทับใจมาก (5/5)"
};
export default function ReviewModal({
  booking,
  existingReview = null,
  isOpen = false,
  onClose,
  onSubmitSuccess
}) {
  _s();
  const isViewMode = Boolean(existingReview && (existingReview.rating || existingReview.status === "reviewed"));
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && onClose && !isSubmitting) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose, isSubmitting]);
  useEffect(() => {
    if (isOpen) {
      if (isViewMode && existingReview) {
        setRating(Number(existingReview.rating) || 5);
        setComment(existingReview.comment || "");
      } else {
        setRating(5);
        setHoverRating(0);
        setComment("");
      }
      setIsSubmitting(false);
    }
  }, [isOpen, booking?.bookingId, isViewMode, existingReview]);
  if (!isOpen || !booking) return null;
  const currentScore = isViewMode ? Number(existingReview?.rating) || 5 : hoverRating || rating;
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isViewMode) {
      if (onClose) onClose();
      return;
    }
    setIsSubmitting(true);
    try {
      const apiResult = await createBookingReview({
        bookingId: booking.bookingId,
        rating,
        comment
      });
      const saved = saveBookingReview(booking.bookingId, {
        rating,
        comment,
        sitterName: booking.sitterName,
        serviceName: booking.serviceName,
        reviewId: apiResult?.reviewId
      });
      toast("ส่งรีวิวเรียบร้อยแล้ว ขอบคุณสำหรับความคิดเห็นของคุณ!", "success");
      if (onSubmitSuccess) {
        onSubmitSuccess(saved || apiResult);
      }
      if (onClose) {
        onClose();
      }
    } catch (err) {
      console.error("Submit review error:", err);
      const message = err.response?.data?.message || "เกิดข้อผิดพลาดในการส่งรีวิว กรุณาลองใหม่อีกครั้ง";
      toast(message, "error");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "delete-modal-overlay",
      onClick: () => !isSubmitting && onClose && onClose(),
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "review-modal-title",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "delete-modal review-modal",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "review-modal-header", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "review-header-badge", children: isViewMode ? "⭐ รีวิวของคุณ" : "⭐ รีวิวและให้คะแนน" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 149,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { id: "review-modal-title", className: "review-title", children: isViewMode ? "รีวิวที่คุณส่งแล้ว" : "ให้คะแนนการบริการ" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 152,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "review-subtitle", children: isViewMode ? "ขอบคุณที่ช่วยแชร์ความคิดเห็นเพื่อเป็นประโยชน์ต่อผู้ใช้ท่านอื่นและพี่เลี้ยง" : "ความเห็นของคุณช่วยให้พี่เลี้ยงพัฒนาบริการและช่วยให้ผู้ใช้อื่นตัดสินใจได้ดียิ่งขึ้น" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 155,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
              lineNumber: 148,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "review-booking-summary", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "review-summary-row", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "review-summary-tag", children: [
                  "การจอง #",
                  booking.bookingId
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 165,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "review-summary-status", children: "เสร็จสิ้น" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 166,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 164,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "review-summary-details", children: [
                /* @__PURE__ */ jsxDEV("p", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "พี่เลี้ยง:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 169,
                    columnNumber: 16
                  }, this),
                  " ",
                  booking.sitterName || "พี่เลี้ยงสัตว์เลี้ยง"
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 169,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "บริการ:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 170,
                    columnNumber: 16
                  }, this),
                  " ",
                  booking.serviceName || "บริการดูแลสัตว์เลี้ยง"
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 170,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 168,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
              lineNumber: 163,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "review-form", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "review-rating-section", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "review-section-label", children: isViewMode ? "คะแนนที่คุณให้" : "คะแนนความพึงพอใจ" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 177,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `review-stars-group ${isViewMode ? "review-stars-group--readonly" : ""}`,
                    role: "radiogroup",
                    "aria-label": isViewMode ? "คะแนนที่คุณให้" : "คะแนนความพึงพอใจ",
                    children: [1, 2, 3, 4, 5].map(
                      (star) => /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          role: "radio",
                          "aria-checked": star === rating,
                          className: `review-star-btn ${star <= currentScore ? "is-active" : ""}`,
                          onClick: () => !isViewMode && setRating(star),
                          onMouseEnter: () => !isViewMode && setHoverRating(star),
                          onMouseLeave: () => !isViewMode && setHoverRating(0),
                          "aria-label": `${star} ดาว`,
                          disabled: isViewMode,
                          children: "★"
                        },
                        star,
                        false,
                        {
                          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                          lineNumber: 186,
                          columnNumber: 15
                        },
                        this
                      )
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 180,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "review-score-label", children: RATING_LABELS[currentScore] || `${currentScore} ดาว` }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 202,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 176,
                columnNumber: 11
              }, this),
              isViewMode ? /* @__PURE__ */ jsxDEV("div", { className: "review-comment-section", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "review-section-label", children: "ความคิดเห็นของคุณ" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 210,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "review-view-comment-box", children: existingReview?.comment ? /* @__PURE__ */ jsxDEV("p", { className: "review-view-comment-text", children: [
                  "“",
                  existingReview.comment,
                  "”"
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 213,
                  columnNumber: 15
                }, this) : /* @__PURE__ */ jsxDEV("p", { className: "review-view-comment-empty", children: "(ไม่มีข้อความรีวิวเพิ่มเติม)" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 215,
                  columnNumber: 15
                }, this) }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 211,
                  columnNumber: 15
                }, this),
                existingReview?.reviewedAt && /* @__PURE__ */ jsxDEV("div", { className: "review-reviewed-at", children: [
                  "🗓️ ส่งรีวิวเมื่อ: ",
                  new Date(existingReview.reviewedAt).toLocaleString("th-TH", {
                    dateStyle: "medium",
                    timeStyle: "short"
                  }),
                  " น."
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 219,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 209,
                columnNumber: 11
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "review-comment-section", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "review-comment-header", children: [
                  /* @__PURE__ */ jsxDEV("label", { htmlFor: "review-comment", className: "review-section-label", children: "ความคิดเห็นเพิ่มเติม (ไม่บังคับ)" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 230,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "review-char-count", children: [
                    comment.length,
                    "/200"
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 233,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 229,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    id: "review-comment",
                    className: "review-textarea",
                    rows: 3,
                    maxLength: 200,
                    placeholder: "บอกเล่าความประทับใจ เช่น การดูแลน้องสัตว์เลี้ยง ความใส่ใจ ความตรงต่อเวลา...",
                    value: comment,
                    onChange: (e) => setComment(e.target.value),
                    disabled: isSubmitting
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 235,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 228,
                columnNumber: 11
              }, this),
              !isViewMode && /* @__PURE__ */ jsxDEV("div", { className: "review-rule-notice", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "⏳" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 251,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "เงื่อนไขการรีวิว:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 253,
                    columnNumber: 17
                  }, this),
                  " คุณสามารถเขียนรีวิวได้ภายใน 14 วันหลังเสร็จสิ้นบริการ หากเกินกำหนดระบบจะปิดรับรีวิวอัตโนมัติ"
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 252,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 250,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions review-modal-actions", children: isViewMode ? /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "profile-save-button review-submit-button",
                  onClick: onClose,
                  style: { width: "100%" },
                  children: "ปิดหน้าต่าง"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                  lineNumber: 261,
                  columnNumber: 13
                },
                this
              ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "delete-cancel-button",
                    onClick: onClose,
                    disabled: isSubmitting,
                    children: "ยกเลิก"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 271,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "profile-save-button review-submit-button",
                    disabled: isSubmitting,
                    children: isSubmitting ? "กำลังส่งรีวิว..." : "ส่งรีวิว"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                    lineNumber: 279,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 270,
                columnNumber: 13
              }, this) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
                lineNumber: 259,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
              lineNumber: 174,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
          lineNumber: 144,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx",
      lineNumber: 137,
      columnNumber: 5
    },
    this
  );
}
_s(ReviewModal, "Sp+gRx+PTTGiZR4yfode2jgIp4o=");
_c = ReviewModal;
var _c;
$RefreshReg$(_c, "ReviewModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ReviewModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUlVLFNBeUhJLFVBekhKOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpJVixPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLGdCQUFnQjtBQUFBLEVBQ3BCLEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFBQSxFQUNILEdBQUc7QUFDTDtBQWdCQSx3QkFBd0JDLFlBQVk7QUFBQSxFQUNsQ0M7QUFBQUEsRUFDQUMsaUJBQWlCO0FBQUEsRUFDakJDLFNBQVM7QUFBQSxFQUNUQztBQUFBQSxFQUNBQztBQUNGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLGFBQWFDLFFBQVFOLG1CQUFtQkEsZUFBZU8sVUFBVVAsZUFBZVEsV0FBVyxXQUFXO0FBRTVHLFFBQU0sQ0FBQ0QsUUFBUUUsU0FBUyxJQUFJakIsU0FBUyxDQUFDO0FBQ3RDLFFBQU0sQ0FBQ2tCLGFBQWFDLGNBQWMsSUFBSW5CLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUNvQixTQUFTQyxVQUFVLElBQUlyQixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDc0IsY0FBY0MsZUFBZSxJQUFJdkIsU0FBUyxLQUFLO0FBR3REQyxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNRLE9BQVE7QUFDYixVQUFNZSxnQkFBZ0JBLENBQUNDLE1BQU07QUFDM0IsVUFBSUEsRUFBRUMsUUFBUSxZQUFZaEIsV0FBVyxDQUFDWSxjQUFjO0FBQ2xEWixnQkFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQ0FpQixXQUFPQyxpQkFBaUIsV0FBV0osYUFBYTtBQUNoRCxXQUFPLE1BQU1HLE9BQU9FLG9CQUFvQixXQUFXTCxhQUFhO0FBQUEsRUFDbEUsR0FBRyxDQUFDZixRQUFRQyxTQUFTWSxZQUFZLENBQUM7QUFHbENyQixZQUFVLE1BQU07QUFDZCxRQUFJUSxRQUFRO0FBQ1YsVUFBSUksY0FBY0wsZ0JBQWdCO0FBQ2hDUyxrQkFBVWEsT0FBT3RCLGVBQWVPLE1BQU0sS0FBSyxDQUFDO0FBQzVDTSxtQkFBV2IsZUFBZVksV0FBVyxFQUFFO0FBQUEsTUFDekMsT0FBTztBQUNMSCxrQkFBVSxDQUFDO0FBQ1hFLHVCQUFlLENBQUM7QUFDaEJFLG1CQUFXLEVBQUU7QUFBQSxNQUNmO0FBQ0FFLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ2QsUUFBUUYsU0FBU3dCLFdBQVdsQixZQUFZTCxjQUFjLENBQUM7QUFFM0QsTUFBSSxDQUFDQyxVQUFVLENBQUNGLFFBQVMsUUFBTztBQUVoQyxRQUFNeUIsZUFBZW5CLGFBQWNpQixPQUFPdEIsZ0JBQWdCTyxNQUFNLEtBQUssSUFBTUcsZUFBZUg7QUFFMUYsUUFBTWtCLGVBQWUsT0FBT1IsTUFBTTtBQUNoQ0EsTUFBRVMsZUFBZTtBQUNqQixRQUFJckIsWUFBWTtBQUNkLFVBQUlILFFBQVNBLFNBQVE7QUFDckI7QUFBQSxJQUNGO0FBRUFhLG9CQUFnQixJQUFJO0FBRXBCLFFBQUk7QUFFRixZQUFNWSxZQUFZLE1BQU1oQyxvQkFBb0I7QUFBQSxRQUMxQzRCLFdBQVd4QixRQUFRd0I7QUFBQUEsUUFDbkJoQjtBQUFBQSxRQUNBSztBQUFBQSxNQUNGLENBQUM7QUFHRCxZQUFNZ0IsUUFBUWxDLGtCQUFrQkssUUFBUXdCLFdBQVc7QUFBQSxRQUNqRGhCO0FBQUFBLFFBQ0FLO0FBQUFBLFFBQ0FpQixZQUFZOUIsUUFBUThCO0FBQUFBLFFBQ3BCQyxhQUFhL0IsUUFBUStCO0FBQUFBLFFBQ3JCQyxVQUFVSixXQUFXSTtBQUFBQSxNQUN2QixDQUFDO0FBRURuQyxZQUFNLHdEQUF3RCxTQUFTO0FBRXZFLFVBQUlPLGlCQUFpQjtBQUNuQkEsd0JBQWdCeUIsU0FBU0QsU0FBUztBQUFBLE1BQ3BDO0FBQ0EsVUFBSXpCLFNBQVM7QUFDWEEsZ0JBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRixTQUFTOEIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHdCQUF3QkYsR0FBRztBQUN6QyxZQUFNRyxVQUNKSCxJQUFJSSxVQUFVQyxNQUFNRixXQUFXO0FBQ2pDdkMsWUFBTXVDLFNBQVMsT0FBTztBQUFBLElBQ3hCLFVBQUM7QUFDQ3BCLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsU0FBUyxNQUFNLENBQUNELGdCQUFnQlosV0FBV0EsUUFBUTtBQUFBLE1BQ25ELE1BQUs7QUFBQSxNQUNMLGNBQVc7QUFBQSxNQUNYLG1CQUFnQjtBQUFBLE1BRWhCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixTQUFTLENBQUNlLE1BQU1BLEVBQUVxQixnQkFBZ0I7QUFBQSxVQUVsQztBQUFBLG1DQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1QkFDWmpDLHVCQUFhLGtCQUFrQix3QkFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxJQUFHLHNCQUFxQixXQUFVLGdCQUNuQ0EsdUJBQWEsdUJBQXVCLHVCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsbUJBQ1ZBLHVCQUNHLCtFQUNBLHdGQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxrQkFBU04sUUFBUXdCO0FBQUFBLHFCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRTtBQUFBLGdCQUNoRSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHlCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBLG1CQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxPQUFFO0FBQUEseUNBQUMsWUFBTywwQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQjtBQUFBLGtCQUFTO0FBQUEsa0JBQUV4QixRQUFROEIsY0FBYztBQUFBLHFCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RTtBQUFBLGdCQUM3RSx1QkFBQyxPQUFFO0FBQUEseUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTlCLFFBQVErQixlQUFlO0FBQUEscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRFO0FBQUEsbUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQSx1QkFBQyxVQUFLLFVBQVVMLGNBQWMsV0FBVSxlQUV0QztBQUFBLHFDQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSx3QkFDZHBCLHVCQUFhLG1CQUFtQixzQkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsc0JBQXNCQSxhQUFhLGlDQUFpQyxFQUFFO0FBQUEsb0JBQ2pGLE1BQUs7QUFBQSxvQkFDTCxjQUFZQSxhQUFhLG1CQUFtQjtBQUFBLG9CQUUzQyxXQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFa0M7QUFBQUEsc0JBQUksQ0FBQ0MsU0FDcEI7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBRUMsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxnQkFBY0EsU0FBU2pDO0FBQUFBLDBCQUN2QixXQUFXLG1CQUFtQmlDLFFBQVFoQixlQUFlLGNBQWMsRUFBRTtBQUFBLDBCQUNyRSxTQUFTLE1BQU0sQ0FBQ25CLGNBQWNJLFVBQVUrQixJQUFJO0FBQUEsMEJBQzVDLGNBQWMsTUFBTSxDQUFDbkMsY0FBY00sZUFBZTZCLElBQUk7QUFBQSwwQkFDdEQsY0FBYyxNQUFNLENBQUNuQyxjQUFjTSxlQUFlLENBQUM7QUFBQSwwQkFDbkQsY0FBWSxHQUFHNkIsSUFBSTtBQUFBLDBCQUNuQixVQUFVbkM7QUFBQUEsMEJBQVc7QUFBQTtBQUFBLHdCQVRoQm1DO0FBQUFBLHdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBYUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFxQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ1ozQyx3QkFBYzJCLFlBQVksS0FBSyxHQUFHQSxZQUFZLFVBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2QkE7QUFBQSxjQUdDbkIsYUFDQyx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsd0JBQXVCLGlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pMLDBCQUFnQlksVUFDZix1QkFBQyxPQUFFLFdBQVUsNEJBQTJCO0FBQUE7QUFBQSxrQkFBRVosZUFBZVk7QUFBQUEsa0JBQVE7QUFBQSxxQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0UsSUFFbEUsdUJBQUMsT0FBRSxXQUFVLDZCQUE0Qiw0Q0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUUsS0FKekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNDWixnQkFBZ0J5QyxjQUNmLHVCQUFDLFNBQUksV0FBVSxzQkFBb0I7QUFBQTtBQUFBLGtCQUNiLElBQUlDLEtBQUsxQyxlQUFleUMsVUFBVSxFQUFFRSxlQUFlLFNBQVM7QUFBQSxvQkFDOUVDLFdBQVc7QUFBQSxvQkFDWEMsV0FBVztBQUFBLGtCQUNiLENBQUM7QUFBQSxrQkFBRTtBQUFBLHFCQUpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLHlDQUFDLFdBQU0sU0FBUSxrQkFBaUIsV0FBVSx3QkFBc0IsZ0RBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUscUJBQXFCakM7QUFBQUEsNEJBQVFrQztBQUFBQSxvQkFBTztBQUFBLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLHFCQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILFdBQVU7QUFBQSxvQkFDVixNQUFNO0FBQUEsb0JBQ04sV0FBVztBQUFBLG9CQUNYLGFBQVk7QUFBQSxvQkFDWixPQUFPbEM7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDSyxNQUFNSixXQUFXSSxFQUFFOEIsT0FBT0MsS0FBSztBQUFBLG9CQUMxQyxVQUFVbEM7QUFBQUE7QUFBQUEsa0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF5QjtBQUFBLG1CQWYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBSUQsQ0FBQ1QsY0FDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU87QUFBQSxnQkFDUCx1QkFBQyxVQUNDO0FBQUEseUNBQUMsWUFBTyxpQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QjtBQUFBLGtCQUFTO0FBQUEscUJBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FJRix1QkFBQyxTQUFJLFdBQVUsNkNBQ1pBLHVCQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU0g7QUFBQUEsa0JBQ1QsT0FBTyxFQUFFK0MsT0FBTyxPQUFPO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUozQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQSxJQUVBLG1DQUNFO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixTQUFTL0M7QUFBQUEsb0JBQ1QsVUFBVVk7QUFBQUEsb0JBQWE7QUFBQTtBQUFBLGtCQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFVBQVVBO0FBQUFBLG9CQUVUQSx5QkFBZSxxQkFBcUI7QUFBQTtBQUFBLGtCQUx2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQSxLQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZCQTtBQUFBLGlCQWxIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1IQTtBQUFBO0FBQUE7QUFBQSxRQWpKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrSkE7QUFBQTtBQUFBLElBekpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBKQTtBQUVKO0FBQUNWLEdBdFB1Qk4sYUFBVztBQUFBLEtBQVhBO0FBQVcsSUFBQW9EO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJzYXZlQm9va2luZ1JldmlldyIsImNyZWF0ZUJvb2tpbmdSZXZpZXciLCJ0b2FzdCIsIlJBVElOR19MQUJFTFMiLCJSZXZpZXdNb2RhbCIsImJvb2tpbmciLCJleGlzdGluZ1JldmlldyIsImlzT3BlbiIsIm9uQ2xvc2UiLCJvblN1Ym1pdFN1Y2Nlc3MiLCJfcyIsImlzVmlld01vZGUiLCJCb29sZWFuIiwicmF0aW5nIiwic3RhdHVzIiwic2V0UmF0aW5nIiwiaG92ZXJSYXRpbmciLCJzZXRIb3ZlclJhdGluZyIsImNvbW1lbnQiLCJzZXRDb21tZW50IiwiaXNTdWJtaXR0aW5nIiwic2V0SXNTdWJtaXR0aW5nIiwiaGFuZGxlS2V5RG93biIsImUiLCJrZXkiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIk51bWJlciIsImJvb2tpbmdJZCIsImN1cnJlbnRTY29yZSIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiYXBpUmVzdWx0Iiwic2F2ZWQiLCJzaXR0ZXJOYW1lIiwic2VydmljZU5hbWUiLCJyZXZpZXdJZCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIm1lc3NhZ2UiLCJyZXNwb25zZSIsImRhdGEiLCJzdG9wUHJvcGFnYXRpb24iLCJtYXAiLCJzdGFyIiwicmV2aWV3ZWRBdCIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImRhdGVTdHlsZSIsInRpbWVTdHlsZSIsImxlbmd0aCIsInRhcmdldCIsInZhbHVlIiwid2lkdGgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZXZpZXdNb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHNhdmVCb29raW5nUmV2aWV3IH0gZnJvbSBcIi4uL3V0aWxzL3Jldmlld1N0b3JhZ2UuanNcIjtcbmltcG9ydCB7IGNyZWF0ZUJvb2tpbmdSZXZpZXcgfSBmcm9tIFwiLi4vc2VydmljZXMvcmV2aWV3cy5qc1wiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwiLi4vdXRpbHMvdG9hc3QuanNcIjtcblxuY29uc3QgUkFUSU5HX0xBQkVMUyA9IHtcbiAgMTogXCLguJXguYnguK3guIfguJvguKPguLHguJrguJvguKPguLjguIcgKDEvNSlcIixcbiAgMjogXCLguJ7guK3guYPguIrguYkgKDIvNSlcIixcbiAgMzogXCLguJvguLLguJnguIHguKXguLLguIcgKDMvNSlcIixcbiAgNDogXCLguJTguLXguKHguLLguIEgKDQvNSlcIixcbiAgNTogXCLguKLguK3guJTguYDguKLguLXguYjguKLguKEg4Lib4Lij4Liw4LiX4Lix4Lia4LmD4LiI4Lih4Liy4LiBICg1LzUpXCIsXG59O1xuXG4vKipcbiAqIFJldmlld01vZGFsIENvbXBvbmVudFxuICogXG4gKiDguKvguJnguYnguLLguJXguYjguLLguIcgTW9kYWwg4Liq4Liz4Lir4Lij4Lix4Lia4LmD4Lir4LmJ4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHOlxuICogMS4g4Liq4LmI4LiH4LiE4Liw4LmB4LiZ4LiZICgxLTUg4LiU4Liy4LinKSDguYHguKXguLDguILguYnguK3guITguKfguLLguKHguKPguLXguKfguLTguKcgKOC5guC4q+C4oeC4lOC5gOC4guC4teC4ouC4meC4o+C4teC4p+C4tOC4pylcbiAqIDIuIOC5gOC4m+C4tOC4lOC4lOC4ueC4o+C4teC4p+C4tOC4p+C4guC4reC4h+C4leC4seC4p+C5gOC4reC4h+C4l+C4teC5iOC5gOC4hOC4ouC4quC5iOC4h+C5hOC4m+C5geC4peC5ieC4p+C4ouC5ieC4reC4meC4q+C4peC4seC4hyAo4LmC4Lir4Lih4LiU4Lit4LmI4Liy4LiZ4Lit4Lii4LmI4Liy4LiH4LmA4LiU4Li14Lii4LinIC0gVmlldyBNb2RlKVxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7T2JqZWN0fSBwcm9wcy5ib29raW5nIC0g4LiC4LmJ4Lit4Lih4Li54Lil4LiB4Liy4Lij4LiI4Lit4LiH4LiX4Li14LmI4LiV4LmJ4Lit4LiH4LiB4Liy4Lij4Lij4Li14Lin4Li04LinXG4gKiBAcGFyYW0ge09iamVjdH0gW3Byb3BzLmV4aXN0aW5nUmV2aWV3XSAtIOC4o+C4teC4p+C4tOC4p+C5gOC4lOC4tOC4oeC4l+C4teC5iOC5gOC4hOC4ouC4quC5iOC4h+C5hOC4p+C5ieC5geC4peC5ieC4pyAo4LiW4LmJ4Liy4Lih4Li1KVxuICogQHBhcmFtIHtib29sZWFufSBwcm9wcy5pc09wZW4gLSDguKrguJbguLLguJnguLDguIHguLLguKPguYDguJvguLTguJQv4Lib4Li04LiUIE1vZGFsXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vbkNsb3NlIC0g4Lif4Lix4LiH4LiB4LmM4LiK4Lix4LiZ4Lib4Li04LiUIE1vZGFsXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwcm9wcy5vblN1Ym1pdFN1Y2Nlc3MgLSDguJ/guLHguIfguIHguYzguIrguLHguJkgQ2FsbGJhY2sg4LmA4Lih4Li34LmI4Lit4Liq4LmI4LiH4Lij4Li14Lin4Li04Lin4Liq4Liz4LmA4Lij4LmH4LiIXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJldmlld01vZGFsKHtcbiAgYm9va2luZyxcbiAgZXhpc3RpbmdSZXZpZXcgPSBudWxsLFxuICBpc09wZW4gPSBmYWxzZSxcbiAgb25DbG9zZSxcbiAgb25TdWJtaXRTdWNjZXNzLFxufSkge1xuICBjb25zdCBpc1ZpZXdNb2RlID0gQm9vbGVhbihleGlzdGluZ1JldmlldyAmJiAoZXhpc3RpbmdSZXZpZXcucmF0aW5nIHx8IGV4aXN0aW5nUmV2aWV3LnN0YXR1cyA9PT0gXCJyZXZpZXdlZFwiKSk7XG5cbiAgY29uc3QgW3JhdGluZywgc2V0UmF0aW5nXSA9IHVzZVN0YXRlKDUpO1xuICBjb25zdCBbaG92ZXJSYXRpbmcsIHNldEhvdmVyUmF0aW5nXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbY29tbWVudCwgc2V0Q29tbWVudF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyDguKPguK3guIfguKPguLHguJrguIHguLLguKPguIHguJTguYHguJvguYnguJkgRXNjYXBlIOC5gOC4nuC4t+C5iOC4reC4m+C4tOC4lCBNb2RhbFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNPcGVuKSByZXR1cm47XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlKSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgb25DbG9zZSAmJiAhaXNTdWJtaXR0aW5nKSB7XG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24pO1xuICB9LCBbaXNPcGVuLCBvbkNsb3NlLCBpc1N1Ym1pdHRpbmddKTtcblxuICAvLyDguKPguLXguYDguIvguYfguJXguITguYjguLLguYDguKHguLfguYjguK3guYDguJvguLTguJQgTW9kYWwg4LmD4Lir4Lih4LmIXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzT3Blbikge1xuICAgICAgaWYgKGlzVmlld01vZGUgJiYgZXhpc3RpbmdSZXZpZXcpIHtcbiAgICAgICAgc2V0UmF0aW5nKE51bWJlcihleGlzdGluZ1Jldmlldy5yYXRpbmcpIHx8IDUpO1xuICAgICAgICBzZXRDb21tZW50KGV4aXN0aW5nUmV2aWV3LmNvbW1lbnQgfHwgXCJcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRSYXRpbmcoNSk7XG4gICAgICAgIHNldEhvdmVyUmF0aW5nKDApO1xuICAgICAgICBzZXRDb21tZW50KFwiXCIpO1xuICAgICAgfVxuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtpc09wZW4sIGJvb2tpbmc/LmJvb2tpbmdJZCwgaXNWaWV3TW9kZSwgZXhpc3RpbmdSZXZpZXddKTtcblxuICBpZiAoIWlzT3BlbiB8fCAhYm9va2luZykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY3VycmVudFNjb3JlID0gaXNWaWV3TW9kZSA/IChOdW1iZXIoZXhpc3RpbmdSZXZpZXc/LnJhdGluZykgfHwgNSkgOiAoaG92ZXJSYXRpbmcgfHwgcmF0aW5nKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoaXNWaWV3TW9kZSkge1xuICAgICAgaWYgKG9uQ2xvc2UpIG9uQ2xvc2UoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgLy8g4Lii4Li04LiHIFBPU1QgL2FwaS9yZXZpZXdzIOC4leC4suC4oSBkb2NzL0FQSS5tZCDCpyA3LjEgKFVTIDctMSlcbiAgICAgIGNvbnN0IGFwaVJlc3VsdCA9IGF3YWl0IGNyZWF0ZUJvb2tpbmdSZXZpZXcoe1xuICAgICAgICBib29raW5nSWQ6IGJvb2tpbmcuYm9va2luZ0lkLFxuICAgICAgICByYXRpbmcsXG4gICAgICAgIGNvbW1lbnQsXG4gICAgICB9KTtcblxuICAgICAgLy8g4LmB4LiE4LiK4Lic4Lil4Lil4Lix4Lie4LiY4LmM4Lil4LiHIGxvY2FsIGNhY2hlIOC5gOC4nuC4t+C5iOC4reC5g+C4q+C5iSBVSSDguK3guLHguJvguYDguJTguJXguJfguLHguJnguJfguLVcbiAgICAgIGNvbnN0IHNhdmVkID0gc2F2ZUJvb2tpbmdSZXZpZXcoYm9va2luZy5ib29raW5nSWQsIHtcbiAgICAgICAgcmF0aW5nLFxuICAgICAgICBjb21tZW50LFxuICAgICAgICBzaXR0ZXJOYW1lOiBib29raW5nLnNpdHRlck5hbWUsXG4gICAgICAgIHNlcnZpY2VOYW1lOiBib29raW5nLnNlcnZpY2VOYW1lLFxuICAgICAgICByZXZpZXdJZDogYXBpUmVzdWx0Py5yZXZpZXdJZCxcbiAgICAgIH0pO1xuXG4gICAgICB0b2FzdChcIuC4quC5iOC4h+C4o+C4teC4p+C4tOC4p+C5gOC4o+C4teC4ouC4muC4o+C5ieC4reC4ouC5geC4peC5ieC4pyDguILguK3guJrguITguLjguJPguKrguLPguKvguKPguLHguJrguITguKfguLLguKHguITguLTguJTguYDguKvguYfguJnguILguK3guIfguITguLjguJMhXCIsIFwic3VjY2Vzc1wiKTtcblxuICAgICAgaWYgKG9uU3VibWl0U3VjY2Vzcykge1xuICAgICAgICBvblN1Ym1pdFN1Y2Nlc3Moc2F2ZWQgfHwgYXBpUmVzdWx0KTtcbiAgICAgIH1cbiAgICAgIGlmIChvbkNsb3NlKSB7XG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdWJtaXQgcmV2aWV3IGVycm9yOlwiLCBlcnIpO1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIuC5gOC4geC4tOC4lOC4guC5ieC4reC4nOC4tOC4lOC4nuC4peC4suC4lOC5g+C4meC4geC4suC4o+C4quC5iOC4h+C4o+C4teC4p+C4tOC4pyDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIjtcbiAgICAgIHRvYXN0KG1lc3NhZ2UsIFwiZXJyb3JcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLW1vZGFsLW92ZXJsYXlcIlxuICAgICAgb25DbGljaz17KCkgPT4gIWlzU3VibWl0dGluZyAmJiBvbkNsb3NlICYmIG9uQ2xvc2UoKX1cbiAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwicmV2aWV3LW1vZGFsLXRpdGxlXCJcbiAgICA+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbCByZXZpZXctbW9kYWxcIlxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctbW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctaGVhZGVyLWJhZGdlXCI+XG4gICAgICAgICAgICB7aXNWaWV3TW9kZSA/IFwi4q2QIOC4o+C4teC4p+C4tOC4p+C4guC4reC4h+C4hOC4uOC4k1wiIDogXCLirZAg4Lij4Li14Lin4Li04Lin4LmB4Lil4Liw4LmD4Lir4LmJ4LiE4Liw4LmB4LiZ4LiZXCJ9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGlkPVwicmV2aWV3LW1vZGFsLXRpdGxlXCIgY2xhc3NOYW1lPVwicmV2aWV3LXRpdGxlXCI+XG4gICAgICAgICAgICB7aXNWaWV3TW9kZSA/IFwi4Lij4Li14Lin4Li04Lin4LiX4Li14LmI4LiE4Li44LiT4Liq4LmI4LiH4LmB4Lil4LmJ4LinXCIgOiBcIuC5g+C4q+C5ieC4hOC4sOC5geC4meC4meC4geC4suC4o+C4muC4o+C4tOC4geC4suC4o1wifVxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicmV2aWV3LXN1YnRpdGxlXCI+XG4gICAgICAgICAgICB7aXNWaWV3TW9kZVxuICAgICAgICAgICAgICA/IFwi4LiC4Lit4Lia4LiE4Li44LiT4LiX4Li14LmI4LiK4LmI4Lin4Lii4LmB4LiK4Lij4LmM4LiE4Lin4Liy4Lih4LiE4Li04LiU4LmA4Lir4LmH4LiZ4LmA4Lie4Li34LmI4Lit4LmA4Lib4LmH4LiZ4Lib4Lij4Liw4LmC4Lii4LiK4LiZ4LmM4LiV4LmI4Lit4Lic4Li54LmJ4LmD4LiK4LmJ4LiX4LmI4Liy4LiZ4Lit4Li34LmI4LiZ4LmB4Lil4Liw4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiHXCJcbiAgICAgICAgICAgICAgOiBcIuC4hOC4p+C4suC4oeC5gOC4q+C5h+C4meC4guC4reC4h+C4hOC4uOC4k+C4iuC5iOC4p+C4ouC5g+C4q+C5ieC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4nuC4seC4kuC4meC4suC4muC4o+C4tOC4geC4suC4o+C5geC4peC4sOC4iuC5iOC4p+C4ouC5g+C4q+C5ieC4nOC4ueC5ieC5g+C4iuC5ieC4reC4t+C5iOC4meC4leC4seC4lOC4quC4tOC4meC5g+C4iOC5hOC4lOC5ieC4lOC4teC4ouC4tOC5iOC4h+C4guC4tuC5ieC4mVwifVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOC4guC5ieC4reC4oeC4ueC4peC4geC4suC4o+C4iOC4reC4h+C5guC4lOC4ouC4quC4seC4h+C5gOC4guC4myAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctYm9va2luZy1zdW1tYXJ5XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctc3VtbWFyeS1yb3dcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJldmlldy1zdW1tYXJ5LXRhZ1wiPuC4geC4suC4o+C4iOC4reC4hyAje2Jvb2tpbmcuYm9va2luZ0lkfTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJldmlldy1zdW1tYXJ5LXN0YXR1c1wiPuC5gOC4quC4o+C5h+C4iOC4quC4tOC5ieC4mTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy1zdW1tYXJ5LWRldGFpbHNcIj5cbiAgICAgICAgICAgIDxwPjxzdHJvbmc+4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiHOjwvc3Ryb25nPiB7Ym9va2luZy5zaXR0ZXJOYW1lIHx8IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJ9PC9wPlxuICAgICAgICAgICAgPHA+PHN0cm9uZz7guJrguKPguLTguIHguLLguKM6PC9zdHJvbmc+IHtib29raW5nLnNlcnZpY2VOYW1lIHx8IFwi4Lia4Lij4Li04LiB4Liy4Lij4LiU4Li54LmB4Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJ9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJyZXZpZXctZm9ybVwiPlxuICAgICAgICAgIHsvKiDguKrguYjguKfguJnguYDguKXguLfguK3guIHguITguLDguYHguJnguJnguJTguLLguKcgKFN0YXIgUmF0aW5nIFNlbGVjdG9yKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy1yYXRpbmctc2VjdGlvblwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJldmlldy1zZWN0aW9uLWxhYmVsXCI+XG4gICAgICAgICAgICAgIHtpc1ZpZXdNb2RlID8gXCLguITguLDguYHguJnguJnguJfguLXguYjguITguLjguJPguYPguKvguYlcIiA6IFwi4LiE4Liw4LmB4LiZ4LiZ4LiE4Lin4Liy4Lih4Lie4Li24LiH4Lie4Lit4LmD4LiIXCJ9XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZXZpZXctc3RhcnMtZ3JvdXAgJHtpc1ZpZXdNb2RlID8gXCJyZXZpZXctc3RhcnMtZ3JvdXAtLXJlYWRvbmx5XCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgIHJvbGU9XCJyYWRpb2dyb3VwXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17aXNWaWV3TW9kZSA/IFwi4LiE4Liw4LmB4LiZ4LiZ4LiX4Li14LmI4LiE4Li44LiT4LmD4Lir4LmJXCIgOiBcIuC4hOC4sOC5geC4meC4meC4hOC4p+C4suC4oeC4nuC4tuC4h+C4nuC4reC5g+C4iFwifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7WzEsIDIsIDMsIDQsIDVdLm1hcCgoc3RhcikgPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17c3Rhcn1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgcm9sZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtY2hlY2tlZD17c3RhciA9PT0gcmF0aW5nfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmV2aWV3LXN0YXItYnRuICR7c3RhciA8PSBjdXJyZW50U2NvcmUgPyBcImlzLWFjdGl2ZVwiIDogXCJcIn1gfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gIWlzVmlld01vZGUgJiYgc2V0UmF0aW5nKHN0YXIpfVxuICAgICAgICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiAhaXNWaWV3TW9kZSAmJiBzZXRIb3ZlclJhdGluZyhzdGFyKX1cbiAgICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4gIWlzVmlld01vZGUgJiYgc2V0SG92ZXJSYXRpbmcoMCl9XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHtzdGFyfSDguJTguLLguKdgfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVmlld01vZGV9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg4piFXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy1zY29yZS1sYWJlbFwiPlxuICAgICAgICAgICAgICB7UkFUSU5HX0xBQkVMU1tjdXJyZW50U2NvcmVdIHx8IGAke2N1cnJlbnRTY29yZX0g4LiU4Liy4LinYH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIOC4quC5iOC4p+C4meC4guC5ieC4reC4hOC4p+C4suC4oeC4o+C4teC4p+C4tOC4pyAqL31cbiAgICAgICAgICB7aXNWaWV3TW9kZSA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3LWNvbW1lbnQtc2VjdGlvblwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicmV2aWV3LXNlY3Rpb24tbGFiZWxcIj7guITguKfguLLguKHguITguLTguJTguYDguKvguYfguJnguILguK3guIfguITguLjguJM8L2xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy12aWV3LWNvbW1lbnQtYm94XCI+XG4gICAgICAgICAgICAgICAge2V4aXN0aW5nUmV2aWV3Py5jb21tZW50ID8gKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicmV2aWV3LXZpZXctY29tbWVudC10ZXh0XCI+4oCce2V4aXN0aW5nUmV2aWV3LmNvbW1lbnR94oCdPC9wPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyZXZpZXctdmlldy1jb21tZW50LWVtcHR5XCI+KOC5hOC4oeC5iOC4oeC4teC4guC5ieC4reC4hOC4p+C4suC4oeC4o+C4teC4p+C4tOC4p+C5gOC4nuC4tOC5iOC4oeC5gOC4leC4tOC4oSk8L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHtleGlzdGluZ1Jldmlldz8ucmV2aWV3ZWRBdCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctcmV2aWV3ZWQtYXRcIj5cbiAgICAgICAgICAgICAgICAgIPCfl5PvuI8g4Liq4LmI4LiH4Lij4Li14Lin4Li04Lin4LmA4Lih4Li34LmI4LitOiB7bmV3IERhdGUoZXhpc3RpbmdSZXZpZXcucmV2aWV3ZWRBdCkudG9Mb2NhbGVTdHJpbmcoXCJ0aC1USFwiLCB7XG4gICAgICAgICAgICAgICAgICAgIGRhdGVTdHlsZTogXCJtZWRpdW1cIixcbiAgICAgICAgICAgICAgICAgICAgdGltZVN0eWxlOiBcInNob3J0XCIsXG4gICAgICAgICAgICAgICAgICB9KX0g4LiZLlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmV2aWV3LWNvbW1lbnQtc2VjdGlvblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy1jb21tZW50LWhlYWRlclwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicmV2aWV3LWNvbW1lbnRcIiBjbGFzc05hbWU9XCJyZXZpZXctc2VjdGlvbi1sYWJlbFwiPlxuICAgICAgICAgICAgICAgICAg4LiE4Lin4Liy4Lih4LiE4Li04LiU4LmA4Lir4LmH4LiZ4LmA4Lie4Li04LmI4Lih4LmA4LiV4Li04LihICjguYTguKHguYjguJrguLHguIfguITguLHguJopXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZXZpZXctY2hhci1jb3VudFwiPntjb21tZW50Lmxlbmd0aH0vMjAwPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgaWQ9XCJyZXZpZXctY29tbWVudFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmV2aWV3LXRleHRhcmVhXCJcbiAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjAwfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4Lia4Lit4LiB4LmA4Lil4LmI4Liy4LiE4Lin4Liy4Lih4Lib4Lij4Liw4LiX4Lix4Lia4LmD4LiIIOC5gOC4iuC5iOC4mSDguIHguLLguKPguJTguLnguYHguKXguJnguYnguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcg4LiE4Lin4Liy4Lih4LmD4Liq4LmI4LmD4LiIIOC4hOC4p+C4suC4oeC4leC4o+C4h+C4leC5iOC4reC5gOC4p+C4peC4si4uLlwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1lbnR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21tZW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiDguKvguKHguLLguKLguYDguKvguJXguLjguYDguIfguLfguYjguK3guJnguYTguIIgMTQg4Lin4Lix4LiZICjguYDguInguJ7guLLguLDguYLguKvguKHguJTguYDguILguLXguKLguJnguKPguLXguKfguLTguKcpICovfVxuICAgICAgICAgIHshaXNWaWV3TW9kZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJldmlldy1ydWxlLW5vdGljZVwiPlxuICAgICAgICAgICAgICA8c3Bhbj7ij7M8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+4LmA4LiH4Li34LmI4Lit4LiZ4LmE4LiC4LiB4Liy4Lij4Lij4Li14Lin4Li04LinOjwvc3Ryb25nPiDguITguLjguJPguKrguLLguKHguLLguKPguJbguYDguILguLXguKLguJnguKPguLXguKfguLTguKfguYTguJTguYnguKDguLLguKLguYPguJkgMTQg4Lin4Lix4LiZ4Lir4Lil4Lix4LiH4LmA4Liq4Lij4LmH4LiI4Liq4Li04LmJ4LiZ4Lia4Lij4Li04LiB4Liy4LijIOC4q+C4suC4geC5gOC4geC4tOC4meC4geC4s+C4q+C4meC4lOC4o+C4sOC4muC4muC4iOC4sOC4m+C4tOC4lOC4o+C4seC4muC4o+C4teC4p+C4tOC4p+C4reC4seC4leC5guC4meC4oeC4seC4leC4tFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIOC4m+C4uOC5iOC4oeC4geC4suC4o+C4l+C4s+C4h+C4suC4mSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbC1hY3Rpb25zIHJldmlldy1tb2RhbC1hY3Rpb25zXCI+XG4gICAgICAgICAgICB7aXNWaWV3TW9kZSA/IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtc2F2ZS1idXR0b24gcmV2aWV3LXN1Ym1pdC1idXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDguJvguLTguJTguKvguJnguYnguLLguJXguYjguLLguIdcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLWNhbmNlbC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg4Lii4LiB4LmA4Lil4Li04LiBXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLXNhdmUtYnV0dG9uIHJldmlldy1zdWJtaXQtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwi4LiB4Liz4Lil4Lix4LiH4Liq4LmI4LiH4Lij4Li14Lin4Li04LinLi4uXCIgOiBcIuC4quC5iOC4h+C4o+C4teC4p+C4tOC4p1wifVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUmV2aWV3TW9kYWwuanN4In0=