import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/careReport/CareReportFormModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import "/src/components/careReport/careReport.css";
const MAX_DETAIL_LENGTH = 1e3;
const MAX_PHOTO_SIZE = 5 * 1024 * 1024;
const ALLOWED_PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
const QUICK_NOTES = [
  { emoji: "🍚", text: "ทานอาหารเรียบร้อย" },
  { emoji: "💧", text: "ดื่มน้ำแล้ว" },
  { emoji: "🚶", text: "พาเดินเล่น" },
  { emoji: "🎾", text: "เล่นด้วยกัน" },
  { emoji: "😴", text: "นอนพักผ่อน" },
  { emoji: "💊", text: "ให้ยาตามเวลา" }
];
function validatePhoto(file) {
  if (!ALLOWED_PHOTO_TYPES.includes(file.type)) return "รองรับเฉพาะไฟล์ JPG, PNG หรือ WebP";
  if (file.size > MAX_PHOTO_SIZE) return "ไฟล์รูปต้องมีขนาดไม่เกิน 5MB";
  return "";
}
export default function CareReportFormModal({ subtitle, onClose, onSubmit, isSubmitting = false, submitError = "" }) {
  _s();
  const [detail, setDetail] = useState("");
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState("");
  const [errors, setErrors] = useState({ detail: "", photo: "" });
  const fileInputRef = useRef(null);
  useEffect(() => {
    if (!photo) {
      setPhotoPreview("");
      return void 0;
    }
    const url = URL.createObjectURL(photo);
    setPhotoPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape" && !isSubmitting) onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose, isSubmitting]);
  const appendQuickNote = (text) => {
    setDetail((prev) => {
      const base = prev.trimEnd();
      return (base ? `${base} ${text}` : text).slice(0, MAX_DETAIL_LENGTH);
    });
    setErrors((prev) => ({ ...prev, detail: "" }));
  };
  const handlePhotoChange = (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const error = validatePhoto(file);
    setErrors((prev) => ({ ...prev, photo: error }));
    if (!error) setPhoto(file);
  };
  const removePhoto = () => {
    setPhoto(null);
    setErrors((prev) => ({ ...prev, photo: "" }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const reportDetail = detail.trim();
    if (!reportDetail) {
      setErrors((prev) => ({ ...prev, detail: "กรุณาเขียนบันทึกกิจกรรมอย่างน้อย 1 ข้อความ" }));
      return;
    }
    onSubmit({ reportDetail, photo });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-overlay", onClick: isSubmitting ? void 0 : onClose, children: /* @__PURE__ */ jsxDEV(
    "form",
    {
      className: "delete-modal care-report-modal",
      onClick: (e) => e.stopPropagation(),
      onSubmit: handleSubmit,
      noValidate: true,
      children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "ส่งรายงานการดูแล" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 110,
          columnNumber: 9
        }, this),
        subtitle && /* @__PURE__ */ jsxDEV("p", { className: "care-report-sub", children: subtitle }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 111,
          columnNumber: 22
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "care-report-label", htmlFor: "care-report-detail", children: [
          "บันทึกกิจกรรม ",
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-required", children: "*" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 114,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 113,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            id: "care-report-detail",
            className: `care-report-textarea${errors.detail ? " has-error" : ""}`,
            rows: 4,
            maxLength: MAX_DETAIL_LENGTH,
            placeholder: "เช่น น้องทานอาหารเม็ดหมด อารมณ์ดี วิ่งเล่นรอบสวน",
            value: detail,
            disabled: isSubmitting,
            onChange: (e) => {
              setDetail(e.target.value);
              if (errors.detail) setErrors((prev) => ({ ...prev, detail: "" }));
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 116,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "care-report-field-foot", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-error", children: errors.detail }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 130,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-counter", children: [
            detail.length,
            "/",
            MAX_DETAIL_LENGTH
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 131,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 129,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "care-report-quick", "aria-label": "ข้อความด่วน", children: QUICK_NOTES.map(
          (q) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "chip-btn",
              disabled: isSubmitting,
              onClick: () => appendQuickNote(q.text),
              children: [
                q.emoji,
                " ",
                q.text
              ]
            },
            q.text,
            true,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
              lineNumber: 138,
              columnNumber: 11
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 136,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "care-report-label", children: [
          "รูปถ่ายกิจกรรม ",
          /* @__PURE__ */ jsxDEV("span", { className: "care-report-optional", children: "(ไม่บังคับ)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 151,
            columnNumber: 26
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 150,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            accept: ALLOWED_PHOTO_TYPES.join(","),
            capture: "environment",
            hidden: true,
            onChange: handlePhotoChange
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 153,
            columnNumber: 9
          },
          this
        ),
        photoPreview ? /* @__PURE__ */ jsxDEV("div", { className: "care-report-photo-preview", children: [
          /* @__PURE__ */ jsxDEV("img", { src: photoPreview, alt: "ตัวอย่างรูปที่จะส่ง" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 163,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "care-report-photo-actions", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", className: "chip-btn", disabled: isSubmitting, onClick: () => fileInputRef.current?.click(), children: "เปลี่ยนรูป" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
              lineNumber: 165,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "button", className: "chip-btn", disabled: isSubmitting, onClick: removePhoto, children: "ลบรูป" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
              lineNumber: 168,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 164,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 162,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: `care-report-dropzone${errors.photo ? " has-error" : ""}`,
            disabled: isSubmitting,
            onClick: () => fileInputRef.current?.click(),
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "care-report-dropzone-icon", "aria-hidden": "true", children: "📷" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
                lineNumber: 180,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "แตะเพื่อถ่ายรูปหรือเลือกจากเครื่อง" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
                lineNumber: 181,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("small", { children: "JPG, PNG, WebP · ไม่เกิน 5MB" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
                lineNumber: 182,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 174,
            columnNumber: 9
          },
          this
        ),
        errors.photo && /* @__PURE__ */ jsxDEV("p", { className: "care-report-error", children: errors.photo }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 185,
          columnNumber: 26
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "care-report-hint", children: "ส่งแล้วไม่สามารถแก้ไขได้ เจ้าของสัตว์เลี้ยงจะเห็นรายงานนี้ทันที" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 187,
          columnNumber: 9
        }, this),
        submitError && /* @__PURE__ */ jsxDEV("p", { className: "care-report-submit-error", children: submitError }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 188,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "delete-cancel-button", disabled: isSubmitting, onClick: onClose, children: "ยกเลิก" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 191,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "profile-save-button", disabled: isSubmitting, children: isSubmitting ? "กำลังส่ง…" : "ส่งรายงาน" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
            lineNumber: 194,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
          lineNumber: 190,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
      lineNumber: 104,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx",
    lineNumber: 103,
    columnNumber: 5
  }, this);
}
_s(CareReportFormModal, "/SRIkoSdpBr65ic8JXBFM8E668M=");
_c = CareReportFormModal;
var _c;
$RefreshReg$(_c, "CareReportFormModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/careReport/CareReportFormModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFGUixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsT0FBTztBQUVQLE1BQU1DLG9CQUFvQjtBQUMxQixNQUFNQyxpQkFBaUIsSUFBSSxPQUFPO0FBQ2xDLE1BQU1DLHNCQUFzQixDQUFDLGNBQWMsYUFBYSxZQUFZO0FBR3BFLE1BQU1DLGNBQWM7QUFBQSxFQUNsQixFQUFFQyxPQUFPLE1BQU1DLE1BQU0sb0JBQW9CO0FBQUEsRUFDekMsRUFBRUQsT0FBTyxNQUFNQyxNQUFNLGNBQWM7QUFBQSxFQUNuQyxFQUFFRCxPQUFPLE1BQU1DLE1BQU0sYUFBYTtBQUFBLEVBQ2xDLEVBQUVELE9BQU8sTUFBTUMsTUFBTSxjQUFjO0FBQUEsRUFDbkMsRUFBRUQsT0FBTyxNQUFNQyxNQUFNLGFBQWE7QUFBQSxFQUNsQyxFQUFFRCxPQUFPLE1BQU1DLE1BQU0sZUFBZTtBQUFDO0FBR3ZDLFNBQVNDLGNBQWNDLE1BQU07QUFDM0IsTUFBSSxDQUFDTCxvQkFBb0JNLFNBQVNELEtBQUtFLElBQUksRUFBRyxRQUFPO0FBQ3JELE1BQUlGLEtBQUtHLE9BQU9ULGVBQWdCLFFBQU87QUFDdkMsU0FBTztBQUNUO0FBSUEsd0JBQXdCVSxvQkFBb0IsRUFBRUMsVUFBVUMsU0FBU0MsVUFBVUMsZUFBZSxPQUFPQyxjQUFjLEdBQUcsR0FBRztBQUFBQyxLQUFBO0FBQ25ILFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJcEIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3FCLE9BQU9DLFFBQVEsSUFBSXRCLFNBQVMsSUFBSTtBQUN2QyxRQUFNLENBQUN1QixjQUFjQyxlQUFlLElBQUl4QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDeUIsUUFBUUMsU0FBUyxJQUFJMUIsU0FBUyxFQUFFbUIsUUFBUSxJQUFJRSxPQUFPLEdBQUcsQ0FBQztBQUM5RCxRQUFNTSxlQUFlNUIsT0FBTyxJQUFJO0FBRWhDRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUN1QixPQUFPO0FBQ1ZHLHNCQUFnQixFQUFFO0FBQ2xCLGFBQU9JO0FBQUFBLElBQ1Q7QUFDQSxVQUFNQyxNQUFNQyxJQUFJQyxnQkFBZ0JWLEtBQUs7QUFDckNHLG9CQUFnQkssR0FBRztBQUNuQixXQUFPLE1BQU1DLElBQUlFLGdCQUFnQkgsR0FBRztBQUFBLEVBQ3RDLEdBQUcsQ0FBQ1IsS0FBSyxDQUFDO0FBRVZ2QixZQUFVLE1BQU07QUFDZCxVQUFNbUMsWUFBWUEsQ0FBQ0MsTUFBTTtBQUN2QixVQUFJQSxFQUFFQyxRQUFRLFlBQVksQ0FBQ25CLGFBQWNGLFNBQVE7QUFBQSxJQUNuRDtBQUNBc0IsV0FBT0MsaUJBQWlCLFdBQVdKLFNBQVM7QUFDNUMsV0FBTyxNQUFNRyxPQUFPRSxvQkFBb0IsV0FBV0wsU0FBUztBQUFBLEVBQzlELEdBQUcsQ0FBQ25CLFNBQVNFLFlBQVksQ0FBQztBQUUxQixRQUFNdUIsa0JBQWtCQSxDQUFDakMsU0FBUztBQUNoQ2MsY0FBVSxDQUFDb0IsU0FBUztBQUNsQixZQUFNQyxPQUFPRCxLQUFLRSxRQUFRO0FBQzFCLGNBQVFELE9BQU8sR0FBR0EsSUFBSSxJQUFJbkMsSUFBSSxLQUFLQSxNQUFNcUMsTUFBTSxHQUFHMUMsaUJBQWlCO0FBQUEsSUFDckUsQ0FBQztBQUNEeUIsY0FBVSxDQUFDYyxVQUFVLEVBQUUsR0FBR0EsTUFBTXJCLFFBQVEsR0FBRyxFQUFFO0FBQUEsRUFDL0M7QUFFQSxRQUFNeUIsb0JBQW9CQSxDQUFDVixNQUFNO0FBQy9CLFVBQU0xQixPQUFPMEIsRUFBRVcsT0FBT0MsUUFBUSxDQUFDO0FBQy9CWixNQUFFVyxPQUFPRSxRQUFRO0FBQ2pCLFFBQUksQ0FBQ3ZDLEtBQU07QUFDWCxVQUFNd0MsUUFBUXpDLGNBQWNDLElBQUk7QUFDaENrQixjQUFVLENBQUNjLFVBQVUsRUFBRSxHQUFHQSxNQUFNbkIsT0FBTzJCLE1BQU0sRUFBRTtBQUMvQyxRQUFJLENBQUNBLE1BQU8xQixVQUFTZCxJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNeUMsY0FBY0EsTUFBTTtBQUN4QjNCLGFBQVMsSUFBSTtBQUNiSSxjQUFVLENBQUNjLFVBQVUsRUFBRSxHQUFHQSxNQUFNbkIsT0FBTyxHQUFHLEVBQUU7QUFBQSxFQUM5QztBQUVBLFFBQU02QixlQUFlQSxDQUFDaEIsTUFBTTtBQUMxQkEsTUFBRWlCLGVBQWU7QUFDakIsVUFBTUMsZUFBZWpDLE9BQU9rQyxLQUFLO0FBQ2pDLFFBQUksQ0FBQ0QsY0FBYztBQUNqQjFCLGdCQUFVLENBQUNjLFVBQVUsRUFBRSxHQUFHQSxNQUFNckIsUUFBUSw2Q0FBNkMsRUFBRTtBQUN2RjtBQUFBLElBQ0Y7QUFDQUosYUFBUyxFQUFFcUMsY0FBYy9CLE1BQU0sQ0FBQztBQUFBLEVBQ2xDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0JBQXVCLFNBQVNMLGVBQWVZLFNBQVlkLFNBQ3hFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFVO0FBQUEsTUFDVixTQUFTLENBQUNvQixNQUFNQSxFQUFFb0IsZ0JBQWdCO0FBQUEsTUFDbEMsVUFBVUo7QUFBQUEsTUFDVixZQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQ25CckMsWUFBWSx1QkFBQyxPQUFFLFdBQVUsbUJBQW1CQSxzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBRXRELHVCQUFDLFdBQU0sV0FBVSxxQkFBb0IsU0FBUSxzQkFBb0I7QUFBQTtBQUFBLFVBQ2pELHVCQUFDLFVBQUssV0FBVSx3QkFBdUIsaUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsV0FBVyx1QkFBdUJZLE9BQU9OLFNBQVMsZUFBZSxFQUFFO0FBQUEsWUFDbkUsTUFBTTtBQUFBLFlBQ04sV0FBV2xCO0FBQUFBLFlBQ1gsYUFBWTtBQUFBLFlBQ1osT0FBT2tCO0FBQUFBLFlBQ1AsVUFBVUg7QUFBQUEsWUFDVixVQUFVLENBQUNrQixNQUFNO0FBQ2ZkLHdCQUFVYyxFQUFFVyxPQUFPRSxLQUFLO0FBQ3hCLGtCQUFJdEIsT0FBT04sT0FBUU8sV0FBVSxDQUFDYyxVQUFVLEVBQUUsR0FBR0EsTUFBTXJCLFFBQVEsR0FBRyxFQUFFO0FBQUEsWUFDbEU7QUFBQTtBQUFBLFVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0k7QUFBQSxRQUVKLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQkFBcUJNLGlCQUFPTixVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFVBQUssV0FBVSx1QkFDYkE7QUFBQUEsbUJBQU9vQztBQUFBQSxZQUFPO0FBQUEsWUFBRXREO0FBQUFBLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUFvQixjQUFXLGVBQzNDRyxzQkFBWW9EO0FBQUFBLFVBQUksQ0FBQ0MsTUFDaEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFVBQVV6QztBQUFBQSxjQUNWLFNBQVMsTUFBTXVCLGdCQUFnQmtCLEVBQUVuRCxJQUFJO0FBQUEsY0FFcENtRDtBQUFBQSxrQkFBRXBEO0FBQUFBLGdCQUFNO0FBQUEsZ0JBQUVvRCxFQUFFbkQ7QUFBQUE7QUFBQUE7QUFBQUEsWUFOUm1ELEVBQUVuRDtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFFBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFVBQUssV0FBVSxxQkFBbUI7QUFBQTtBQUFBLFVBQ2xCLHVCQUFDLFVBQUssV0FBVSx3QkFBdUIsMkJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS3FCO0FBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsUUFBUXhCLG9CQUFvQnVELEtBQUssR0FBRztBQUFBLFlBQ3BDLFNBQVE7QUFBQSxZQUNSO0FBQUEsWUFDQSxVQUFVZDtBQUFBQTtBQUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU04QjtBQUFBLFFBRTdCckIsZUFDQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLEtBQUtBLGNBQWMsS0FBSSx5QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLFlBQVcsVUFBVVAsY0FBYyxTQUFTLE1BQU1XLGFBQWFnQyxTQUFTQyxNQUFNLEdBQUUsMEJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsWUFBVyxVQUFVNUMsY0FBYyxTQUFTaUMsYUFBWSxxQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLElBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVcsdUJBQXVCeEIsT0FBT0osUUFBUSxlQUFlLEVBQUU7QUFBQSxZQUNsRSxVQUFVTDtBQUFBQSxZQUNWLFNBQVMsTUFBTVcsYUFBYWdDLFNBQVNDLE1BQU07QUFBQSxZQUUzQztBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNEIsZUFBWSxRQUFPLGtCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLFVBQUssa0RBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN4Qyx1QkFBQyxXQUFNLDRDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUE7QUFBQTtBQUFBLFVBUnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFFRG5DLE9BQU9KLFNBQVMsdUJBQUMsT0FBRSxXQUFVLHFCQUFxQkksaUJBQU9KLFNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUVoRSx1QkFBQyxPQUFFLFdBQVUsb0JBQW1CLCtFQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStGO0FBQUEsUUFDOUZKLGVBQWUsdUJBQUMsT0FBRSxXQUFVLDRCQUE0QkEseUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUVyRSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHdCQUF1QixVQUFVRCxjQUFjLFNBQVNGLFNBQVEsc0JBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsdUJBQXNCLFVBQVVFLGNBQzdEQSx5QkFBZSxjQUFjLGVBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBO0FBQUE7QUFBQSxJQTdGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE4RkEsS0EvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdHQTtBQUVKO0FBQUNFLEdBNUp1Qk4scUJBQW1CO0FBQUEsS0FBbkJBO0FBQW1CLElBQUFpRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIk1BWF9ERVRBSUxfTEVOR1RIIiwiTUFYX1BIT1RPX1NJWkUiLCJBTExPV0VEX1BIT1RPX1RZUEVTIiwiUVVJQ0tfTk9URVMiLCJlbW9qaSIsInRleHQiLCJ2YWxpZGF0ZVBob3RvIiwiZmlsZSIsImluY2x1ZGVzIiwidHlwZSIsInNpemUiLCJDYXJlUmVwb3J0Rm9ybU1vZGFsIiwic3VidGl0bGUiLCJvbkNsb3NlIiwib25TdWJtaXQiLCJpc1N1Ym1pdHRpbmciLCJzdWJtaXRFcnJvciIsIl9zIiwiZGV0YWlsIiwic2V0RGV0YWlsIiwicGhvdG8iLCJzZXRQaG90byIsInBob3RvUHJldmlldyIsInNldFBob3RvUHJldmlldyIsImVycm9ycyIsInNldEVycm9ycyIsImZpbGVJbnB1dFJlZiIsInVuZGVmaW5lZCIsInVybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsInJldm9rZU9iamVjdFVSTCIsImhhbmRsZUtleSIsImUiLCJrZXkiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImFwcGVuZFF1aWNrTm90ZSIsInByZXYiLCJiYXNlIiwidHJpbUVuZCIsInNsaWNlIiwiaGFuZGxlUGhvdG9DaGFuZ2UiLCJ0YXJnZXQiLCJmaWxlcyIsInZhbHVlIiwiZXJyb3IiLCJyZW1vdmVQaG90byIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwicmVwb3J0RGV0YWlsIiwidHJpbSIsInN0b3BQcm9wYWdhdGlvbiIsImxlbmd0aCIsIm1hcCIsInEiLCJqb2luIiwiY3VycmVudCIsImNsaWNrIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2FyZVJlcG9ydEZvcm1Nb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgXCIuL2NhcmVSZXBvcnQuY3NzXCI7XG5cbmNvbnN0IE1BWF9ERVRBSUxfTEVOR1RIID0gMTAwMDtcbmNvbnN0IE1BWF9QSE9UT19TSVpFID0gNSAqIDEwMjQgKiAxMDI0OyAvLyA1TUIg4LiV4Liy4LihIGRvY3MvQVBJLm1kIMKnIFBBUlQgMzogNi4xXG5jb25zdCBBTExPV0VEX1BIT1RPX1RZUEVTID0gW1wiaW1hZ2UvanBlZ1wiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL3dlYnBcIl07XG5cbi8vIOC4iuC4tOC4m+C4iuC5iOC4p+C4ouC4nuC4tOC4oeC4nuC5jCDigJQg4LmB4LiV4Liw4LmB4Lil4LmJ4Lin4LiV4LmI4Lit4LiX4LmJ4Liy4Lii4LiC4LmJ4Lit4LiE4Lin4Liy4LihIOC4iuC5iOC4p+C4ouC5g+C4q+C5ieC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4o+C4suC4ouC4h+C4suC4meC4iOC4suC4geC4oeC4t+C4reC4luC4t+C4reC5hOC4lOC5ieC5gOC4o+C5h+C4p1xuY29uc3QgUVVJQ0tfTk9URVMgPSBbXG4gIHsgZW1vamk6IFwi8J+NmlwiLCB0ZXh0OiBcIuC4l+C4suC4meC4reC4suC4q+C4suC4o+C5gOC4o+C4teC4ouC4muC4o+C5ieC4reC4olwiIH0sXG4gIHsgZW1vamk6IFwi8J+Sp1wiLCB0ZXh0OiBcIuC4lOC4t+C5iOC4oeC4meC5ieC4s+C5geC4peC5ieC4p1wiIH0sXG4gIHsgZW1vamk6IFwi8J+atlwiLCB0ZXh0OiBcIuC4nuC4suC5gOC4lOC4tOC4meC5gOC4peC5iOC4mVwiIH0sXG4gIHsgZW1vamk6IFwi8J+OvlwiLCB0ZXh0OiBcIuC5gOC4peC5iOC4meC4lOC5ieC4p+C4ouC4geC4seC4mVwiIH0sXG4gIHsgZW1vamk6IFwi8J+YtFwiLCB0ZXh0OiBcIuC4meC4reC4meC4nuC4seC4geC4nOC5iOC4reC4mVwiIH0sXG4gIHsgZW1vamk6IFwi8J+SilwiLCB0ZXh0OiBcIuC5g+C4q+C5ieC4ouC4suC4leC4suC4oeC5gOC4p+C4peC4slwiIH0sXG5dO1xuXG5mdW5jdGlvbiB2YWxpZGF0ZVBob3RvKGZpbGUpIHtcbiAgaWYgKCFBTExPV0VEX1BIT1RPX1RZUEVTLmluY2x1ZGVzKGZpbGUudHlwZSkpIHJldHVybiBcIuC4o+C4reC4h+C4o+C4seC4muC5gOC4ieC4nuC4suC4sOC5hOC4n+C4peC5jCBKUEcsIFBORyDguKvguKPguLfguK0gV2ViUFwiO1xuICBpZiAoZmlsZS5zaXplID4gTUFYX1BIT1RPX1NJWkUpIHJldHVybiBcIuC5hOC4n+C4peC5jOC4o+C4ueC4m+C4leC5ieC4reC4h+C4oeC4teC4guC4meC4suC4lOC5hOC4oeC5iOC5gOC4geC4tOC4mSA1TUJcIjtcbiAgcmV0dXJuIFwiXCI7XG59XG5cbi8vIENhcmVSZXBvcnRGb3JtTW9kYWwg4oCUIOC4n+C4reC4o+C5jOC4oeC4quC5iOC4h+C4o+C4suC4ouC4h+C4suC4meC4geC4suC4o+C4lOC4ueC5geC4peC4guC4reC4h+C4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4hyAoVVM3LTMsIFVJIG9ubHkpXG4vLyDguYTguKHguYjguYDguKPguLXguKLguIEgQVBJIOC5gOC4reC4hzog4Liq4LmI4LiHIHsgcmVwb3J0RGV0YWlsLCBwaG90byB9IOC4reC4reC4geC4l+C4suC4hyBvblN1Ym1pdCDguYPguKvguYkgcGFyZW50IOC4iOC4seC4lOC4geC4suC4o1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2FyZVJlcG9ydEZvcm1Nb2RhbCh7IHN1YnRpdGxlLCBvbkNsb3NlLCBvblN1Ym1pdCwgaXNTdWJtaXR0aW5nID0gZmFsc2UsIHN1Ym1pdEVycm9yID0gXCJcIiB9KSB7XG4gIGNvbnN0IFtkZXRhaWwsIHNldERldGFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bob3RvLCBzZXRQaG90b10gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3Bob3RvUHJldmlldywgc2V0UGhvdG9QcmV2aWV3XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoeyBkZXRhaWw6IFwiXCIsIHBob3RvOiBcIlwiIH0pO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBob3RvKSB7XG4gICAgICBzZXRQaG90b1ByZXZpZXcoXCJcIik7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKHBob3RvKTtcbiAgICBzZXRQaG90b1ByZXZpZXcodXJsKTtcbiAgICByZXR1cm4gKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICB9LCBbcGhvdG9dKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUtleSA9IChlKSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIgJiYgIWlzU3VibWl0dGluZykgb25DbG9zZSgpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXkpO1xuICB9LCBbb25DbG9zZSwgaXNTdWJtaXR0aW5nXSk7XG5cbiAgY29uc3QgYXBwZW5kUXVpY2tOb3RlID0gKHRleHQpID0+IHtcbiAgICBzZXREZXRhaWwoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IGJhc2UgPSBwcmV2LnRyaW1FbmQoKTtcbiAgICAgIHJldHVybiAoYmFzZSA/IGAke2Jhc2V9ICR7dGV4dH1gIDogdGV4dCkuc2xpY2UoMCwgTUFYX0RFVEFJTF9MRU5HVEgpO1xuICAgIH0pO1xuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZGV0YWlsOiBcIlwiIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVQaG90b0NoYW5nZSA9IChlKSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgZS50YXJnZXQudmFsdWUgPSBcIlwiOyAvLyDguYPguKvguYnguYDguKXguLfguK3guIHguYTguJ/guKXguYzguYDguJTguLTguKHguIvguYnguLPguYTguJTguYnguKvguKXguLHguIfguKXguJpcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICBjb25zdCBlcnJvciA9IHZhbGlkYXRlUGhvdG8oZmlsZSk7XG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwaG90bzogZXJyb3IgfSkpO1xuICAgIGlmICghZXJyb3IpIHNldFBob3RvKGZpbGUpO1xuICB9O1xuXG4gIGNvbnN0IHJlbW92ZVBob3RvID0gKCkgPT4ge1xuICAgIHNldFBob3RvKG51bGwpO1xuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgcGhvdG86IFwiXCIgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGNvbnN0IHJlcG9ydERldGFpbCA9IGRldGFpbC50cmltKCk7XG4gICAgaWYgKCFyZXBvcnREZXRhaWwpIHtcbiAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZGV0YWlsOiBcIuC4geC4o+C4uOC4k+C4suC5gOC4guC4teC4ouC4meC4muC4seC4meC4l+C4tuC4geC4geC4tOC4iOC4geC4o+C4o+C4oeC4reC4ouC5iOC4suC4h+C4meC5ieC4reC4oiAxIOC4guC5ieC4reC4hOC4p+C4suC4oVwiIH0pKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgb25TdWJtaXQoeyByZXBvcnREZXRhaWwsIHBob3RvIH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtb3ZlcmxheVwiIG9uQ2xpY2s9e2lzU3VibWl0dGluZyA/IHVuZGVmaW5lZCA6IG9uQ2xvc2V9PlxuICAgICAgPGZvcm1cbiAgICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLW1vZGFsIGNhcmUtcmVwb3J0LW1vZGFsXCJcbiAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9XG4gICAgICAgIG5vVmFsaWRhdGVcbiAgICAgID5cbiAgICAgICAgPGgyPuC4quC5iOC4h+C4o+C4suC4ouC4h+C4suC4meC4geC4suC4o+C4lOC4ueC5geC4pTwvaDI+XG4gICAgICAgIHtzdWJ0aXRsZSAmJiA8cCBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1zdWJcIj57c3VidGl0bGV9PC9wPn1cblxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtbGFiZWxcIiBodG1sRm9yPVwiY2FyZS1yZXBvcnQtZGV0YWlsXCI+XG4gICAgICAgICAg4Lia4Lix4LiZ4LiX4Li24LiB4LiB4Li04LiI4LiB4Lij4Lij4LihIDxzcGFuIGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LXJlcXVpcmVkXCI+Kjwvc3Bhbj5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgaWQ9XCJjYXJlLXJlcG9ydC1kZXRhaWxcIlxuICAgICAgICAgIGNsYXNzTmFtZT17YGNhcmUtcmVwb3J0LXRleHRhcmVhJHtlcnJvcnMuZGV0YWlsID8gXCIgaGFzLWVycm9yXCIgOiBcIlwifWB9XG4gICAgICAgICAgcm93cz17NH1cbiAgICAgICAgICBtYXhMZW5ndGg9e01BWF9ERVRBSUxfTEVOR1RIfVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIOC4meC5ieC4reC4h+C4l+C4suC4meC4reC4suC4q+C4suC4o+C5gOC4oeC5h+C4lOC4q+C4oeC4lCDguK3guLLguKPguKHguJPguYzguJTguLUg4Lin4Li04LmI4LiH4LmA4Lil4LmI4LiZ4Lij4Lit4Lia4Liq4Lin4LiZXCJcbiAgICAgICAgICB2YWx1ZT17ZGV0YWlsfVxuICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICBzZXREZXRhaWwoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgaWYgKGVycm9ycy5kZXRhaWwpIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZGV0YWlsOiBcIlwiIH0pKTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LWZpZWxkLWZvb3RcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1lcnJvclwiPntlcnJvcnMuZGV0YWlsfTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1jb3VudGVyXCI+XG4gICAgICAgICAgICB7ZGV0YWlsLmxlbmd0aH0ve01BWF9ERVRBSUxfTEVOR1RIfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJlLXJlcG9ydC1xdWlja1wiIGFyaWEtbGFiZWw9XCLguILguYnguK3guITguKfguLLguKHguJTguYjguKfguJlcIj5cbiAgICAgICAgICB7UVVJQ0tfTk9URVMubWFwKChxKSA9PiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17cS50ZXh0fVxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2hpcC1idG5cIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHBlbmRRdWlja05vdGUocS50ZXh0KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3EuZW1vaml9IHtxLnRleHR9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtbGFiZWxcIj5cbiAgICAgICAgICDguKPguLnguJvguJbguYjguLLguKLguIHguLTguIjguIHguKPguKPguKEgPHNwYW4gY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtb3B0aW9uYWxcIj4o4LmE4Lih4LmI4Lia4Lix4LiH4LiE4Lix4LiaKTwvc3Bhbj5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgYWNjZXB0PXtBTExPV0VEX1BIT1RPX1RZUEVTLmpvaW4oXCIsXCIpfVxuICAgICAgICAgIGNhcHR1cmU9XCJlbnZpcm9ubWVudFwiXG4gICAgICAgICAgaGlkZGVuXG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBob3RvQ2hhbmdlfVxuICAgICAgICAvPlxuICAgICAgICB7cGhvdG9QcmV2aWV3ID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtcGhvdG8tcHJldmlld1wiPlxuICAgICAgICAgICAgPGltZyBzcmM9e3Bob3RvUHJldmlld30gYWx0PVwi4LiV4Lix4Lin4Lit4Lii4LmI4Liy4LiH4Lij4Li54Lib4LiX4Li14LmI4LiI4Liw4Liq4LmI4LiHXCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtcGhvdG8tYWN0aW9uc1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjaGlwLWJ0blwiIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9IG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfT5cbiAgICAgICAgICAgICAgICDguYDguJvguKXguLXguYjguKLguJnguKPguLnguJtcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNoaXAtYnRuXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30gb25DbGljaz17cmVtb3ZlUGhvdG99PlxuICAgICAgICAgICAgICAgIOC4peC4muC4o+C4ueC4m1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgY2FyZS1yZXBvcnQtZHJvcHpvbmUke2Vycm9ycy5waG90byA/IFwiIGhhcy1lcnJvclwiIDogXCJcIn1gfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LWRyb3B6b25lLWljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj7wn5O3PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+4LmB4LiV4Liw4LmA4Lie4Li34LmI4Lit4LiW4LmI4Liy4Lii4Lij4Li54Lib4Lir4Lij4Li34Lit4LmA4Lil4Li34Lit4LiB4LiI4Liy4LiB4LmA4LiE4Lij4Li34LmI4Lit4LiHPC9zcGFuPlxuICAgICAgICAgICAgPHNtYWxsPkpQRywgUE5HLCBXZWJQIMK3IOC5hOC4oeC5iOC5gOC4geC4tOC4mSA1TUI8L3NtYWxsPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgICB7ZXJyb3JzLnBob3RvICYmIDxwIGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LWVycm9yXCI+e2Vycm9ycy5waG90b308L3A+fVxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImNhcmUtcmVwb3J0LWhpbnRcIj7guKrguYjguIfguYHguKXguYnguKfguYTguKHguYjguKrguLLguKHguLLguKPguJbguYHguIHguYnguYTguILguYTguJTguYkg4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiI4Liw4LmA4Lir4LmH4LiZ4Lij4Liy4Lii4LiH4Liy4LiZ4LiZ4Li14LmJ4LiX4Lix4LiZ4LiX4Li1PC9wPlxuICAgICAgICB7c3VibWl0RXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiY2FyZS1yZXBvcnQtc3VibWl0LWVycm9yXCI+e3N1Ym1pdEVycm9yfTwvcD59XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtYWN0aW9uc1wiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImRlbGV0ZS1jYW5jZWwtYnV0dG9uXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30gb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICDguKLguIHguYDguKXguLTguIFcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJwcm9maWxlLXNhdmUtYnV0dG9uXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XG4gICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCLguIHguLPguKXguLHguIfguKrguYjguIfigKZcIiA6IFwi4Liq4LmI4LiH4Lij4Liy4Lii4LiH4Liy4LiZXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvY2FyZVJlcG9ydC9DYXJlUmVwb3J0Rm9ybU1vZGFsLmpzeCJ9