import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/RecentBookingsSection.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import SitterBookingCard from "/src/components/sitter/SitterBookingCard.tsx";
import BookingCardSkeleton from "/src/components/ui/BookingCardSkeleton.jsx";
import {
  countPendingBookings,
  getRecentPendingBookings
} from "/src/utils/sitterDashboardLogic.js";
export default function RecentBookingsSection({
  bookings = [],
  isLoading = false,
  onViewAll
}) {
  const pendingCount = countPendingBookings(bookings);
  const recentPendingBookings = getRecentPendingBookings(bookings, 3);
  const handleCardKeyDown = (event) => {
    if ((event.key === "Enter" || event.key === " ") && onViewAll) {
      event.preventDefault();
      onViewAll();
    }
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "bg-white rounded-2xl border border-slate-200 custom-shadow p-5 sm:p-6 space-y-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-slate-200 flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-base sm:text-lg font-bold text-slate-900 leading-tight", children: "คำขอจองล่าสุด (Recent Bookings)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
            lineNumber: 61,
            columnNumber: 13
          }, this),
          pendingCount > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "bg-amber-50 text-amber-800 border border-amber-200 text-xs px-2.5 py-0.5 rounded-full font-bold", children: [
            pendingCount,
            " รอดำเนินการ"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
            lineNumber: 65,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "bg-slate-100 text-slate-700 border border-slate-300 text-xs px-2.5 py-0.5 rounded-full font-bold", children: "0 รอดำเนินการ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
            lineNumber: 69,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 60,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 font-medium mt-0.5", children: "แสดงเฉพาะคำขอจองใหม่ที่เพิ่งเข้ามา (คลิกที่การ์ดหรือลิงก์ด้านขวาเพื่อไปหน้าจัดการคำขอจอง)" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onViewAll,
          className: "text-xs sm:text-sm font-bold text-[#D97706] hover:text-[#B45309] underline underline-offset-4 decoration-2 flex items-center gap-1 transition-colors py-1 cursor-pointer",
          children: "จัดการคำขอจองทั้งหมด →"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 79,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    isLoading && bookings.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [1, 2].map(
      (n) => /* @__PURE__ */ jsxDEV(BookingCardSkeleton, {}, n, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 92,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
      lineNumber: 90,
      columnNumber: 7
    }, this) : recentPendingBookings.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-10 px-6 text-center bg-[#FAFBFB] rounded-2xl border-2 border-dashed border-slate-200 space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 mx-auto rounded-2xl bg-slate-100 border border-slate-200 text-slate-400 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
        "svg",
        {
          className: "w-6 h-6",
          width: "24",
          height: "24",
          fill: "none",
          viewBox: "0 0 24 24",
          strokeWidth: 1.75,
          stroke: "currentColor",
          children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              d: "M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
              lineNumber: 107,
              columnNumber: 15
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 98,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 97,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-slate-800", children: "ยังไม่มีคำขอจองใหม่ที่รอดำเนินการ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 115,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 max-w-md mx-auto", children: "เมื่อเจ้าของสัตว์เลี้ยงส่งคำขอจองเข้ามาใหม่ รายการที่รอดำเนินการจะปรากฏที่นี่ หรือคลิก “จัดการคำขอจองทั้งหมด” เพื่อดูประวัติการจองทุกสถานะ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 118,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 114,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      recentPendingBookings.map(
        (booking) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            role: "button",
            tabIndex: 0,
            onClick: onViewAll,
            onKeyDown: handleCardKeyDown,
            title: "คลิกเพื่อไปหน้าจัดการคำขอจอง",
            className: "cursor-pointer rounded-2xl transition-all hover:ring-2 hover:ring-[#F97316]/40 focus:outline-none focus:ring-2 focus:ring-[#F97316]",
            children: /* @__PURE__ */ jsxDEV(SitterBookingCard, { booking }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
              lineNumber: 135,
              columnNumber: 15
            }, this)
          },
          booking.bookingId,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
            lineNumber: 126,
            columnNumber: 9
          },
          this
        )
      ),
      pendingCount > recentPendingBookings.length && /* @__PURE__ */ jsxDEV("div", { className: "pt-1 text-center", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onViewAll,
          className: "text-xs sm:text-sm font-bold text-[#0F766E] hover:text-[#115E59] underline underline-offset-4 decoration-2 cursor-pointer",
          children: [
            "ดูคำขอที่รอดำเนินการทั้งหมด (",
            pendingCount,
            " รายการ) →"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 141,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 140,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-slate-100 flex items-start gap-2 text-[11px] text-slate-600 bg-[#FFF7EF]/60 p-3 rounded-xl border border-amber-100", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          className: "w-4 h-4 text-emerald-600 shrink-0 mt-0.5",
          width: "16",
          height: "16",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 2,
              d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
              lineNumber: 163,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 155,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("span", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Price Snapshot Guarantee:" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
          lineNumber: 171,
          columnNumber: 11
        }, this),
        " ยอดค่าบริการในการจอง (totalprice) ถูกบันทึกแบบ Snapshot เมื่อสร้างคำขอ การปรับปรุงราคาบริการหลังจากนั้นจะไม่มีผลย้อนหลังต่อการจองที่เกิดขึ้นแล้ว"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
        lineNumber: 170,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
      lineNumber: 154,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
}
_c = RecentBookingsSection;
var _c;
$RefreshReg$(_c, "RecentBookingsSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/RecentBookingsSection.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNZOzs7Ozs7Ozs7Ozs7Ozs7O0FBekNaLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLHlCQUF5QjtBQUNoQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFjUCx3QkFBd0JDLHNCQUFzQjtBQUFBLEVBQzVDQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDO0FBQ0YsR0FBRztBQUNELFFBQU1DLGVBQWVOLHFCQUFxQkcsUUFBUTtBQUNsRCxRQUFNSSx3QkFBd0JOLHlCQUF5QkUsVUFBVSxDQUFDO0FBRWxFLFFBQU1LLG9CQUFvQkEsQ0FBQ0MsVUFBVTtBQUNuQyxTQUFLQSxNQUFNQyxRQUFRLFdBQVdELE1BQU1DLFFBQVEsUUFBUUwsV0FBVztBQUM3REksWUFBTUUsZUFBZTtBQUNyQk4sZ0JBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLG1GQUVqQjtBQUFBLDJCQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsK0RBQTZELCtDQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0MsZUFBZSxJQUNkLHVCQUFDLFVBQUssV0FBVSxtR0FDYkE7QUFBQUE7QUFBQUEsWUFBYTtBQUFBLGVBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsb0dBQWtHLDZCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw2Q0FBMkMseUdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTRDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUEwSztBQUFBO0FBQUEsUUFIdEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFHQ0QsYUFBYUQsU0FBU1MsV0FBVyxJQUNoQyx1QkFBQyxTQUFJLFdBQVUsYUFDWixXQUFDLEdBQUcsQ0FBQyxFQUFFQztBQUFBQSxNQUFJLENBQUNDLE1BQ1gsdUJBQUMseUJBQXlCQSxHQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRCO0FBQUEsSUFDN0IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsSUFDRVAsc0JBQXNCSyxXQUFXLElBQ25DLHVCQUFDLFNBQUksV0FBVSxxR0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxzSEFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTTtBQUFBLFVBQ04sUUFBTztBQUFBLFVBQ1AsTUFBSztBQUFBLFVBQ0wsU0FBUTtBQUFBLFVBQ1IsYUFBYTtBQUFBLFVBQ2IsUUFBTztBQUFBLFVBRVA7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGVBQWM7QUFBQSxjQUNkLGdCQUFlO0FBQUEsY0FDZixHQUFFO0FBQUE7QUFBQSxZQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUcyTjtBQUFBO0FBQUEsUUFaN047QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxvQ0FBa0MsaURBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUF5QywwSkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1pMO0FBQUFBLDRCQUFzQk07QUFBQUEsUUFBSSxDQUFDRSxZQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsVUFBVTtBQUFBLFlBQ1YsU0FBU1Y7QUFBQUEsWUFDVCxXQUFXRztBQUFBQSxZQUNYLE9BQU07QUFBQSxZQUNOLFdBQVU7QUFBQSxZQUVWLGlDQUFDLHFCQUFrQixXQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUEsVUFSL0JPLFFBQVFDO0FBQUFBLFVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsTUFDRDtBQUFBLE1BRUFWLGVBQWVDLHNCQUFzQkssVUFDcEMsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTUDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUEySDtBQUFBO0FBQUEsWUFFdkdDO0FBQUFBLFlBQWE7QUFBQTtBQUFBO0FBQUEsUUFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsMklBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTTtBQUFBLFVBQ04sUUFBTztBQUFBLFVBQ1AsTUFBSztBQUFBLFVBQ0wsU0FBUTtBQUFBLFVBQ1IsUUFBTztBQUFBLFVBRVA7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGVBQWM7QUFBQSxjQUNkLGdCQUFlO0FBQUEsY0FDZixhQUFhO0FBQUEsY0FDYixHQUFFO0FBQUE7QUFBQSxZQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlvTTtBQUFBO0FBQUEsUUFadE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0E7QUFBQSxNQUNBLHVCQUFDLFVBQ0M7QUFBQSwrQkFBQyxZQUFPLHlDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUFTO0FBQUEsV0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BckhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSEE7QUFFSjtBQUFDVyxLQXhJdUJmO0FBQXFCLElBQUFlO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2l0dGVyQm9va2luZ0NhcmQiLCJCb29raW5nQ2FyZFNrZWxldG9uIiwiY291bnRQZW5kaW5nQm9va2luZ3MiLCJnZXRSZWNlbnRQZW5kaW5nQm9va2luZ3MiLCJSZWNlbnRCb29raW5nc1NlY3Rpb24iLCJib29raW5ncyIsImlzTG9hZGluZyIsIm9uVmlld0FsbCIsInBlbmRpbmdDb3VudCIsInJlY2VudFBlbmRpbmdCb29raW5ncyIsImhhbmRsZUNhcmRLZXlEb3duIiwiZXZlbnQiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsImxlbmd0aCIsIm1hcCIsIm4iLCJib29raW5nIiwiYm9va2luZ0lkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVjZW50Qm9va2luZ3NTZWN0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2l0dGVyQm9va2luZ0NhcmQgZnJvbSBcIi4uL1NpdHRlckJvb2tpbmdDYXJkXCI7XG5pbXBvcnQgQm9va2luZ0NhcmRTa2VsZXRvbiBmcm9tIFwiLi4vLi4vdWkvQm9va2luZ0NhcmRTa2VsZXRvbi5qc3hcIjtcbmltcG9ydCB7XG4gIGNvdW50UGVuZGluZ0Jvb2tpbmdzLFxuICBnZXRSZWNlbnRQZW5kaW5nQm9va2luZ3MsXG59IGZyb20gXCIuLi8uLi8uLi91dGlscy9zaXR0ZXJEYXNoYm9hcmRMb2dpYy5qc1wiO1xuXG4vKipcbiAqIFJlY2VudEJvb2tpbmdzU2VjdGlvbiBDb21wb25lbnRcbiAqXG4gKiBTaXR0ZXIgRGFzaGJvYXJkIHNlY3Rpb24gZGlzcGxheWluZyBhIHJlYWQtb25seSBwcmV2aWV3IG9mIHJlY2VudCAncGVuZGluZycgYm9va2luZyByZXF1ZXN0cyAodXAgdG8gMykuXG4gKiBDbGlja2luZyBhIGNhcmQgb3IgdGhlIHRvcC1yaWdodCBsaW5rIG5hdmlnYXRlcyB0byAvc2l0dGVyL2Jvb2tpbmdzIGZvciBmdWxsIGJvb2tpbmcgbWFuYWdlbWVudCAoQWNjZXB0L1JlamVjdC9Db21wbGV0ZSkuXG4gKiBFeHBsaWNpdGx5IHByb3RlY3RzIGFuZCBkaXNwbGF5cyBoaXN0b3JpY2FsIGFncmVlZCByYXRlcyAoYm9va2luZy50b3RhbHByaWNlIHNuYXBzaG90KS5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7QXJyYXl9IHByb3BzLmJvb2tpbmdzIC0gQXJyYXkgb2Ygc2l0dGVyIGJvb2tpbmcgb2JqZWN0cy5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gcHJvcHMuaXNMb2FkaW5nIC0gTG9hZGluZyBzdGF0ZSBmbGFnLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcHJvcHMub25WaWV3QWxsIC0gQ2FsbGJhY2sgdG8gbmF2aWdhdGUgdG8gL3NpdHRlci9ib29raW5ncy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVjZW50Qm9va2luZ3NTZWN0aW9uKHtcbiAgYm9va2luZ3MgPSBbXSxcbiAgaXNMb2FkaW5nID0gZmFsc2UsXG4gIG9uVmlld0FsbCxcbn0pIHtcbiAgY29uc3QgcGVuZGluZ0NvdW50ID0gY291bnRQZW5kaW5nQm9va2luZ3MoYm9va2luZ3MpO1xuICBjb25zdCByZWNlbnRQZW5kaW5nQm9va2luZ3MgPSBnZXRSZWNlbnRQZW5kaW5nQm9va2luZ3MoYm9va2luZ3MsIDMpO1xuXG4gIGNvbnN0IGhhbmRsZUNhcmRLZXlEb3duID0gKGV2ZW50KSA9PiB7XG4gICAgaWYgKChldmVudC5rZXkgPT09IFwiRW50ZXJcIiB8fCBldmVudC5rZXkgPT09IFwiIFwiKSAmJiBvblZpZXdBbGwpIHtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBvblZpZXdBbGwoKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBjdXN0b20tc2hhZG93IHAtNSBzbTpwLTYgc3BhY2UteS00XCI+XG4gICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2Ugc206dGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbGVhZGluZy10aWdodFwiPlxuICAgICAgICAgICAgICDguITguLPguILguK3guIjguK3guIfguKXguYjguLLguKrguLjguJQgKFJlY2VudCBCb29raW5ncylcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICB7cGVuZGluZ0NvdW50ID4gMCA/IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctYW1iZXItNTAgdGV4dC1hbWJlci04MDAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICB7cGVuZGluZ0NvdW50fSDguKPguK3guJTguLPguYDguJnguLTguJnguIHguLLguKNcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQteHMgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgMCDguKPguK3guJTguLPguYDguJnguLTguJnguIHguLLguKNcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtIG10LTAuNVwiPlxuICAgICAgICAgICAg4LmB4Liq4LiU4LiH4LmA4LiJ4Lie4Liy4Liw4LiE4Liz4LiC4Lit4LiI4Lit4LiH4LmD4Lir4Lih4LmI4LiX4Li14LmI4LmA4Lie4Li04LmI4LiH4LmA4LiC4LmJ4Liy4Lih4LiyICjguITguKXguLTguIHguJfguLXguYjguIHguLLguKPguYzguJTguKvguKPguLfguK3guKXguLTguIfguIHguYzguJTguYnguLLguJnguILguKfguLLguYDguJ7guLfguYjguK3guYTguJvguKvguJnguYnguLLguIjguLHguJTguIHguLLguKPguITguLPguILguK3guIjguK3guIcpXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25WaWV3QWxsfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgdGV4dC1bI0Q5NzcwNl0gaG92ZXI6dGV4dC1bI0I0NTMwOV0gdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNCBkZWNvcmF0aW9uLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1jb2xvcnMgcHktMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgID5cbiAgICAgICAgICDguIjguLHguJTguIHguLLguKPguITguLPguILguK3guIjguK3guIfguJfguLHguYnguIfguKvguKHguJQg4oaSXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQZW5kaW5nIEJvb2tpbmdzIFByZXZpZXcgLyBMb2FkaW5nIFNrZWxldG9uIC8gQ2xlYW4gRW1wdHkgU3RhdGUgKi99XG4gICAgICB7aXNMb2FkaW5nICYmIGJvb2tpbmdzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICB7WzEsIDJdLm1hcCgobikgPT4gKFxuICAgICAgICAgICAgPEJvb2tpbmdDYXJkU2tlbGV0b24ga2V5PXtufSAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiByZWNlbnRQZW5kaW5nQm9va2luZ3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEwIHB4LTYgdGV4dC1jZW50ZXIgYmctWyNGQUZCRkJdIHJvdW5kZWQtMnhsIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTIwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBteC1hdXRvIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTEwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgPHN2Z1xuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTYgaC02XCJcbiAgICAgICAgICAgICAgd2lkdGg9XCIyNFwiXG4gICAgICAgICAgICAgIGhlaWdodD1cIjI0XCJcbiAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezEuNzV9XG4gICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBkPVwiTTYuNzUgM3YyLjI1TTE3LjI1IDN2Mi4yNU0zIDE4Ljc1VjcuNWEyLjI1IDIuMjUgMCAwMTIuMjUtMi4yNWgxMy41QTIuMjUgMi4yNSAwIDAxMjEgNy41djExLjI1bS0xOCAwQTIuMjUgMi4yNSAwIDAwNS4yNSAyMWgxMy41QTIuMjUgMi4yNSAwIDAwMjEgMTguNzVtLTE4IDB2LTcuNUEyLjI1IDIuMjUgMCAwMTUuMjUgOWgxMy41QTIuMjUgMi4yNSAwIDAxMjEgMTEuMjV2Ny41XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICDguKLguLHguIfguYTguKHguYjguKHguLXguITguLPguILguK3guIjguK3guIfguYPguKvguKHguYjguJfguLXguYjguKPguK3guJTguLPguYDguJnguLTguJnguIHguLLguKNcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWF4LXctbWQgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICDguYDguKHguLfguYjguK3guYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguKrguYjguIfguITguLPguILguK3guIjguK3guIfguYDguILguYnguLLguKHguLLguYPguKvguKHguYgg4Lij4Liy4Lii4LiB4Liy4Lij4LiX4Li14LmI4Lij4Lit4LiU4Liz4LmA4LiZ4Li04LiZ4LiB4Liy4Lij4LiI4Liw4Lib4Lij4Liy4LiB4LiP4LiX4Li14LmI4LiZ4Li14LmIIOC4q+C4o+C4t+C4reC4hOC4peC4tOC4gSAmbGRxdW874LiI4Lix4LiU4LiB4Liy4Lij4LiE4Liz4LiC4Lit4LiI4Lit4LiH4LiX4Lix4LmJ4LiH4Lir4Lih4LiUJnJkcXVvOyDguYDguJ7guLfguYjguK3guJTguLnguJvguKPguLDguKfguLHguJXguLTguIHguLLguKPguIjguK3guIfguJfguLjguIHguKrguJbguLLguJnguLBcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIHtyZWNlbnRQZW5kaW5nQm9va2luZ3MubWFwKChib29raW5nKSA9PiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGtleT17Ym9va2luZy5ib29raW5nSWR9XG4gICAgICAgICAgICAgIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICB0YWJJbmRleD17MH1cbiAgICAgICAgICAgICAgb25DbGljaz17b25WaWV3QWxsfVxuICAgICAgICAgICAgICBvbktleURvd249e2hhbmRsZUNhcmRLZXlEb3dufVxuICAgICAgICAgICAgICB0aXRsZT1cIuC4hOC4peC4tOC4geC5gOC4nuC4t+C5iOC4reC5hOC4m+C4q+C4meC5ieC4suC4iOC4seC4lOC4geC4suC4o+C4hOC4s+C4guC4reC4iOC4reC4h1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIHRyYW5zaXRpb24tYWxsIGhvdmVyOnJpbmctMiBob3ZlcjpyaW5nLVsjRjk3MzE2XS80MCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyNGOTczMTZdXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNpdHRlckJvb2tpbmdDYXJkIGJvb2tpbmc9e2Jvb2tpbmd9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cblxuICAgICAgICAgIHtwZW5kaW5nQ291bnQgPiByZWNlbnRQZW5kaW5nQm9va2luZ3MubGVuZ3RoICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25WaWV3QWxsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgdGV4dC1bIzBGNzY2RV0gaG92ZXI6dGV4dC1bIzExNUU1OV0gdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNCBkZWNvcmF0aW9uLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg4LiU4Li54LiE4Liz4LiC4Lit4LiX4Li14LmI4Lij4Lit4LiU4Liz4LmA4LiZ4Li04LiZ4LiB4Liy4Lij4LiX4Lix4LmJ4LiH4Lir4Lih4LiUICh7cGVuZGluZ0NvdW50fSDguKPguLLguKLguIHguLLguKMpIOKGklxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEhpc3RvcmljYWwgUHJpY2UgR3VhcmFudGVlIENhbGxvdXQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNjAwIGJnLVsjRkZGN0VGXS82MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWFtYmVyLTEwMFwiPlxuICAgICAgICA8c3ZnXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwIHNocmluay0wIG10LTAuNVwiXG4gICAgICAgICAgd2lkdGg9XCIxNlwiXG4gICAgICAgICAgaGVpZ2h0PVwiMTZcIlxuICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICA+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxuICAgICAgICAgICAgZD1cIk05IDEybDIgMiA0LTRtNS42MTgtNC4wMTZBMTEuOTU1IDExLjk1NSAwIDAxMTIgMi45NDRhMTEuOTU1IDExLjk1NSAwIDAxLTguNjE4IDMuMDRBMTIuMDIgMTIuMDIgMCAwMDMgOWMwIDUuNTkxIDMuODI0IDEwLjI5IDkgMTEuNjIyIDUuMTc2LTEuMzMyIDktNi4wMyA5LTExLjYyMiAwLTEuMDQyLS4xMzMtMi4wNTItLjM4Mi0zLjAxNnpcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvc3ZnPlxuICAgICAgICA8c3Bhbj5cbiAgICAgICAgICA8c3Ryb25nPlByaWNlIFNuYXBzaG90IEd1YXJhbnRlZTo8L3N0cm9uZz4g4Lii4Lit4LiU4LiE4LmI4Liy4Lia4Lij4Li04LiB4Liy4Lij4LmD4LiZ4LiB4Liy4Lij4LiI4Lit4LiHICh0b3RhbHByaWNlKSDguJbguLnguIHguJrguLHguJnguJfguLbguIHguYHguJrguJogU25hcHNob3Qg4LmA4Lih4Li34LmI4Lit4Liq4Lij4LmJ4Liy4LiH4LiE4Liz4LiC4LitIOC4geC4suC4o+C4m+C4o+C4seC4muC4m+C4o+C4uOC4h+C4o+C4suC4hOC4suC4muC4o+C4tOC4geC4suC4o+C4q+C4peC4seC4h+C4iOC4suC4geC4meC4seC5ieC4meC4iOC4sOC5hOC4oeC5iOC4oeC4teC4nOC4peC4ouC5ieC4reC4meC4q+C4peC4seC4h+C4leC5iOC4reC4geC4suC4o+C4iOC4reC4h+C4l+C4teC5iOC5gOC4geC4tOC4lOC4guC4tuC5ieC4meC5geC4peC5ieC4p1xuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL1JlY2VudEJvb2tpbmdzU2VjdGlvbi5qc3gifQ==