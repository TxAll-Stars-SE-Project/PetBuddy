import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/AlertBanner.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/AlertBanner.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function AlertBanner({ type = "error", children }) {
  const icon = type === "error" ? "⚠" : type === "success" ? "✅" : "ℹ";
  return /* @__PURE__ */ jsxDEV("div", { className: "banner banner--" + type, children: [
    icon,
    " ",
    /* @__PURE__ */ jsxDEV("span", { children }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/AlertBanner.jsx",
      lineNumber: 22,
      columnNumber: 59
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/AlertBanner.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_c = AlertBanner;
export default AlertBanner;
var _c;
$RefreshReg$(_c, "AlertBanner");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/AlertBanner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/AlertBanner.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRTBEOzs7Ozs7Ozs7Ozs7Ozs7O0FBRjFELFNBQVNBLFlBQVksRUFBRUMsT0FBTyxTQUFTQyxTQUFTLEdBQUc7QUFDakQsUUFBTUMsT0FBT0YsU0FBUyxVQUFVLE1BQU1BLFNBQVMsWUFBWSxNQUFNO0FBQ2pFLFNBQU8sdUJBQUMsU0FBSSxXQUFXLG9CQUFvQkEsTUFBT0U7QUFBQUE7QUFBQUEsSUFBSztBQUFBLElBQUMsdUJBQUMsVUFBTUQsWUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdCO0FBQUEsT0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3RTtBQUNqRjtBQUFDRSxLQUhRSjtBQUlULGVBQWVBO0FBQVksSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQWxlcnRCYW5uZXIiLCJ0eXBlIiwiY2hpbGRyZW4iLCJpY29uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWxlcnRCYW5uZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIEFsZXJ0QmFubmVyKHsgdHlwZSA9IFwiZXJyb3JcIiwgY2hpbGRyZW4gfSkge1xuICBjb25zdCBpY29uID0gdHlwZSA9PT0gXCJlcnJvclwiID8gXCLimqBcIiA6IHR5cGUgPT09IFwic3VjY2Vzc1wiID8gXCLinIVcIiA6IFwi4oS5XCI7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17XCJiYW5uZXIgYmFubmVyLS1cIiArIHR5cGV9PntpY29ufSA8c3Bhbj57Y2hpbGRyZW59PC9zcGFuPjwvZGl2Pjtcbn1cbmV4cG9ydCBkZWZhdWx0IEFsZXJ0QmFubmVyOyJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3VpL0FsZXJ0QmFubmVyLmpzeCJ9