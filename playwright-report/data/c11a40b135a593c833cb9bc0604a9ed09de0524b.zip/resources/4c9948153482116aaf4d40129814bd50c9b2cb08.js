import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceDescriptionInput({
  value,
  onChange,
  error = "",
  id = "service-description-input"
}) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "block text-xs font-semibold text-slate-700 mb-1", children: [
      "คำอธิบายบริการ ",
      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx",
        lineNumber: 42,
        columnNumber: 24
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "textarea",
      {
        id,
        rows: 3,
        value,
        onChange: (e) => onChange(e.target.value),
        placeholder: "อธิบายจุดเด่น สถานที่ กิจกรรม หรือข้อกำหนดในการดูแลสัตว์เลี้ยง...",
        className: `w-full px-3 py-2 text-sm border-2 rounded-xl focus:outline-none bg-white text-slate-800 transition-colors resize-none ${error ? "border-red-400 focus:border-red-500" : "border-slate-200 focus:border-[#F97316]"}`
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx",
        lineNumber: 44,
        columnNumber: 7
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-500 mt-1 block", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_c = ServiceDescriptionInput;
var _c;
$RefreshReg$(_c, "ServiceDescriptionInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceDescriptionInput.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0J1Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXRCdkIsT0FBT0EsV0FBVztBQWFsQix3QkFBd0JDLHdCQUF3QjtBQUFBLEVBQzlDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxRQUFRO0FBQUEsRUFDUkMsS0FBSztBQUNQLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxXQUFNLFNBQVNBLElBQUksV0FBVSxtREFBaUQ7QUFBQTtBQUFBLE1BQzlELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxNQUFNO0FBQUEsUUFDTjtBQUFBLFFBQ0EsVUFBVSxDQUFDQyxNQUFNSCxTQUFTRyxFQUFFQyxPQUFPTCxLQUFLO0FBQUEsUUFDeEMsYUFBWTtBQUFBLFFBQ1osV0FBVyx5SEFDVEUsUUFDSSx3Q0FDQSx5Q0FBeUM7QUFBQTtBQUFBLE1BVGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVLO0FBQUEsSUFFSkEsU0FDQyx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DQSxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLE9BakI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0ksS0E1QnVCUDtBQUF1QixJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNlcnZpY2VEZXNjcmlwdGlvbklucHV0IiwidmFsdWUiLCJvbkNoYW5nZSIsImVycm9yIiwiaWQiLCJlIiwidGFyZ2V0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VydmljZURlc2NyaXB0aW9uSW5wdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBTZXJ2aWNlRGVzY3JpcHRpb25JbnB1dCBDb21wb25lbnRcbiAqIFxuICogU3BlY2lhbGl6ZWQgdGV4dGFyZWEgZm9yIHNlcnZpY2UgZGVzY3JpcHRpb24gd2l0aCByZXF1aXJlZCBpbmRpY2F0b3IgYW5kIGVycm9yIG1lc3NhZ2UuXG4gKiBcbiAqIEBwYXJhbSB7T2JqZWN0fSBwcm9wc1xuICogQHBhcmFtIHtzdHJpbmd9IHByb3BzLnZhbHVlIC0gQ3VycmVudCBkZXNjcmlwdGlvbiB0ZXh0LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcHJvcHMub25DaGFuZ2UgLSBIYW5kbGVyIGNhbGxlZCB3aXRoIHVwZGF0ZWQgZGVzY3JpcHRpb24uXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmVycm9yXSAtIFZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZSBpZiBhbnkuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmlkXSAtIEVsZW1lbnQgaWQgZm9yIGFjY2Vzc2liaWxpdHkuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNlcnZpY2VEZXNjcmlwdGlvbklucHV0KHtcbiAgdmFsdWUsXG4gIG9uQ2hhbmdlLFxuICBlcnJvciA9IFwiXCIsXG4gIGlkID0gXCJzZXJ2aWNlLWRlc2NyaXB0aW9uLWlucHV0XCIsXG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxsYWJlbCBodG1sRm9yPXtpZH0gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAg4LiE4Liz4Lit4LiY4Li04Lia4Liy4Lii4Lia4Lij4Li04LiB4Liy4LijIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPHRleHRhcmVhXG4gICAgICAgIGlkPXtpZH1cbiAgICAgICAgcm93cz17M31cbiAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgcGxhY2Vob2xkZXI9XCLguK3guJjguLTguJrguLLguKLguIjguLjguJTguYDguJTguYjguJkg4Liq4LiW4Liy4LiZ4LiX4Li14LmIIOC4geC4tOC4iOC4geC4o+C4o+C4oSDguKvguKPguLfguK3guILguYnguK3guIHguLPguKvguJnguJTguYPguJnguIHguLLguKPguJTguLnguYHguKXguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcuLi5cIlxuICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIHRleHQtc20gYm9yZGVyLTIgcm91bmRlZC14bCBmb2N1czpvdXRsaW5lLW5vbmUgYmctd2hpdGUgdGV4dC1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgcmVzaXplLW5vbmUgJHtcbiAgICAgICAgICBlcnJvclxuICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNDAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCJcbiAgICAgICAgICAgIDogXCJib3JkZXItc2xhdGUtMjAwIGZvY3VzOmJvcmRlci1bI0Y5NzMxNl1cIlxuICAgICAgICB9YH1cbiAgICAgIC8+XG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTUwMCBtdC0xIGJsb2NrXCI+e2Vycm9yfTwvc3Bhbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvc2VydmljZUZvcm0vU2VydmljZURlc2NyaXB0aW9uSW5wdXQuanN4In0=