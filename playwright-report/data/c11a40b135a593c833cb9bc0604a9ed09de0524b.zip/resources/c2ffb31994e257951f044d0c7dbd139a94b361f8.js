import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProfileField.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function ProfileField({
  label,
  value,
  field,
  type = "text",
  isEditing,
  error,
  onChange
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: label }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "profile-field-container", children: isEditing ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type,
          className: `profile-input ${error ? "profile-input-error" : ""}`,
          value: value || "",
          onChange: (e) => onChange(field, e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
          lineNumber: 38,
          columnNumber: 13
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("div", { className: "profile-field-error", children: error }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
        lineNumber: 50,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "profile-value", children: value || "-" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
      lineNumber: 56,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_c = ProfileField;
export default ProfileField;
var _c;
$RefreshReg$(_c, "ProfileField");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ProfileField.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV00sU0FNSSxVQU5KOzs7Ozs7Ozs7Ozs7Ozs7O0FBWE4sU0FBU0EsYUFBYTtBQUFBLEVBQ3BCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxPQUFPO0FBQUEsRUFDUEM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSxpQkFDYk4sbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pJLHNCQUNDLG1DQUNFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxXQUFXLGlCQUNUQyxRQUFRLHdCQUF3QixFQUFFO0FBQUEsVUFFcEMsT0FBT0osU0FBUztBQUFBLFVBQ2hCLFVBQVUsQ0FBQ00sTUFDVEQsU0FBU0osT0FBT0ssRUFBRUMsT0FBT1AsS0FBSztBQUFBO0FBQUEsUUFQbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUc7QUFBQSxNQUdGSSxTQUNDLHVCQUFDLFNBQUksV0FBVSx1QkFDWkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLElBRUEsdUJBQUMsVUFBSyxXQUFVLGlCQUNiSixtQkFBUyxPQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsT0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStCQTtBQUVKO0FBQUNRLEtBM0NRVjtBQTZDVCxlQUFlQTtBQUFhLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlByb2ZpbGVGaWVsZCIsImxhYmVsIiwidmFsdWUiLCJmaWVsZCIsInR5cGUiLCJpc0VkaXRpbmciLCJlcnJvciIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb2ZpbGVGaWVsZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gUHJvZmlsZUZpZWxkKHtcbiAgbGFiZWwsXG4gIHZhbHVlLFxuICBmaWVsZCxcbiAgdHlwZSA9IFwidGV4dFwiLFxuICBpc0VkaXRpbmcsXG4gIGVycm9yLFxuICBvbkNoYW5nZSxcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCI+XG4gICAgICAgIHtsYWJlbH1cbiAgICAgIDwvc3Bhbj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWZpZWxkLWNvbnRhaW5lclwiPlxuICAgICAgICB7aXNFZGl0aW5nID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT17dHlwZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHJvZmlsZS1pbnB1dCAke1xuICAgICAgICAgICAgICAgIGVycm9yID8gXCJwcm9maWxlLWlucHV0LWVycm9yXCIgOiBcIlwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICB2YWx1ZT17dmFsdWUgfHwgXCJcIn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlKGZpZWxkLCBlLnRhcmdldC52YWx1ZSlcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWZpZWxkLWVycm9yXCI+XG4gICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS12YWx1ZVwiPlxuICAgICAgICAgICAge3ZhbHVlIHx8IFwiLVwifVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBQcm9maWxlRmllbGQ7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Qcm9maWxlRmllbGQuanN4In0=