import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/dashboard/ServiceCard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
const SERVICE_TYPE_MAP = {
  walking: { label: "พาเดินเล่น", unit: "฿ / ชม." },
  daycare: { label: "ฝากเลี้ยงรายวัน", unit: "฿ / วัน" },
  boarding: { label: "ฝากเลี้ยงค้างคืน", unit: "฿ / คืน" },
  grooming: { label: "อาบน้ำตัดขน", unit: "฿ / ครั้ง" },
  sitting: { label: "ดูแลถึงที่พัก", unit: "฿ / ครั้ง" }
};
const SPECIES_MAP = {
  dog: "สุนัข",
  cat: "แมว",
  bird: "นก",
  small_animal: "สัตว์ขนาดเล็ก",
  exotic: "สัตว์แปลก"
};
export default function ServiceCard({ service, onEdit, onDelete }) {
  const isPublished = service.status === "published";
  const typeInfo = SERVICE_TYPE_MAP[service.servicetype || service.serviceType] || {
    label: service.servicetype || service.serviceType || "บริการ",
    unit: "฿"
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `bg-white border-2 ${isPublished ? "border-slate-200 hover:border-[#0F766E]" : "border-dashed border-slate-300 bg-[#F8FAFC]"} rounded-2xl p-5 custom-shadow transition-all duration-200 flex flex-col`,
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "bg-slate-100 text-slate-800 border border-slate-300 text-xs px-2.5 py-1 rounded-lg font-bold", children: typeInfo.label }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
            lineNumber: 69,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: `text-xs font-bold flex items-center gap-1.5 ${isPublished ? "text-[#16A34A]" : "text-slate-500"}`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `w-2 h-2 rounded-full ${isPublished ? "bg-[#16A34A]" : "bg-slate-400"}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
                    lineNumber: 77,
                    columnNumber: 11
                  },
                  this
                ),
                isPublished ? "เปิดรับบริการ" : "ปิดรับชั่วคราว"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 72,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 68,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-h-[70px] mb-2", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-slate-900 text-base leading-snug line-clamp-2", children: service.servicename || service.serviceName }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
            lineNumber: 88,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1 mt-1.5", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-extrabold text-[#0F766E]", children: [
              "฿",
              Number(service.price).toLocaleString()
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 92,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-600 font-bold", children: typeInfo.unit }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 95,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
            lineNumber: 91,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 87,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5 pt-1 mb-3 min-h-[32px]", children: (service.species || []).map(
          (sp) => /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "bg-[#F1F5F9] text-slate-800 text-xs px-2.5 py-1 rounded-lg font-bold border border-slate-300",
              children: SPECIES_MAP[sp] || sp
            },
            sp,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 102,
              columnNumber: 9
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 100,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-h-[44px] mb-4", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-600 line-clamp-2 leading-relaxed", children: service.description || "ไม่มีคำอธิบายเพิ่มเติม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 113,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 112,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-auto flex items-center gap-2 pt-3 border-t border-slate-200", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onEdit(service),
              className: "flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-bold rounded-xl transition-all duration-200 flex items-center justify-center gap-1 shadow-xs cursor-pointer",
              children: "แก้ไข"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 120,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onDelete(service.serviceid || service.serviceId),
              className: "py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl transition-all duration-200 flex items-center justify-center gap-1 shadow-xs cursor-pointer",
              children: "ลบ"
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
              lineNumber: 127,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
          lineNumber: 119,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx",
      lineNumber: 60,
      columnNumber: 5
    },
    this
  );
}
_c = ServiceCard;
var _c;
$RefreshReg$(_c, "ServiceCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/dashboard/ServiceCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURROzs7Ozs7Ozs7Ozs7Ozs7O0FBakRSLE9BQU9BLFdBQVc7QUFHbEIsTUFBTUMsbUJBQW1CO0FBQUEsRUFDdkJDLFNBQVMsRUFBRUMsT0FBTyxjQUFjQyxNQUFNLFVBQVU7QUFBQSxFQUNoREMsU0FBUyxFQUFFRixPQUFPLG1CQUFtQkMsTUFBTSxVQUFVO0FBQUEsRUFDckRFLFVBQVUsRUFBRUgsT0FBTyxvQkFBb0JDLE1BQU0sVUFBVTtBQUFBLEVBQ3ZERyxVQUFVLEVBQUVKLE9BQU8sZUFBZUMsTUFBTSxZQUFZO0FBQUEsRUFDcERJLFNBQVMsRUFBRUwsT0FBTyxpQkFBaUJDLE1BQU0sWUFBWTtBQUN2RDtBQUdBLE1BQU1LLGNBQWM7QUFBQSxFQUNsQkMsS0FBSztBQUFBLEVBQ0xDLEtBQUs7QUFBQSxFQUNMQyxNQUFNO0FBQUEsRUFDTkMsY0FBYztBQUFBLEVBQ2RDLFFBQVE7QUFDVjtBQWNBLHdCQUF3QkMsWUFBWSxFQUFFQyxTQUFTQyxRQUFRQyxTQUFTLEdBQUc7QUFDakUsUUFBTUMsY0FBY0gsUUFBUUksV0FBVztBQUN2QyxRQUFNQyxXQUFXcEIsaUJBQWlCZSxRQUFRTSxlQUFlTixRQUFRTyxXQUFXLEtBQUs7QUFBQSxJQUMvRXBCLE9BQU9hLFFBQVFNLGVBQWVOLFFBQVFPLGVBQWU7QUFBQSxJQUNyRG5CLE1BQU07QUFBQSxFQUNSO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVyxxQkFDVGUsY0FDSSw0Q0FDQSw2Q0FBNkM7QUFBQSxNQUluRDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxnR0FDYkUsbUJBQVNsQixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLCtDQUNUZ0IsY0FBYyxtQkFBbUIsZ0JBQWdCO0FBQUEsY0FHbkQ7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHdCQUNUQSxjQUFjLGlCQUFpQixjQUFjO0FBQUE7QUFBQSxrQkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdLO0FBQUEsZ0JBRUpBLGNBQWMsa0JBQWtCO0FBQUE7QUFBQTtBQUFBLFlBVm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsZ0VBQ1hILGtCQUFRUSxlQUFlUixRQUFRUyxlQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsMENBQXdDO0FBQUE7QUFBQSxjQUNwREMsT0FBT1YsUUFBUVcsS0FBSyxFQUFFQyxlQUFlO0FBQUEsaUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxvQ0FBb0NQLG1CQUFTakIsUUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxlQUpwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxpREFDWFksbUJBQVFhLFdBQVcsSUFBSUM7QUFBQUEsVUFBSSxDQUFDQyxPQUM1QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBRVR0QixzQkFBWXNCLEVBQUUsS0FBS0E7QUFBQUE7QUFBQUEsWUFIZkE7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxRQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsT0FBRSxXQUFVLHVEQUNWZixrQkFBUWdCLGVBQWUsNEJBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTWYsT0FBT0QsT0FBTztBQUFBLGNBQzdCLFdBQVU7QUFBQSxjQUFrTjtBQUFBO0FBQUEsWUFIOU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1FLFNBQVNGLFFBQVFpQixhQUFhakIsUUFBUWtCLFNBQVM7QUFBQSxjQUM5RCxXQUFVO0FBQUEsY0FBc007QUFBQTtBQUFBLFlBSGxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQTtBQUFBO0FBQUEsSUExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkVBO0FBRUo7QUFBQ0MsS0FyRnVCcEI7QUFBVyxJQUFBb0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTRVJWSUNFX1RZUEVfTUFQIiwid2Fsa2luZyIsImxhYmVsIiwidW5pdCIsImRheWNhcmUiLCJib2FyZGluZyIsImdyb29taW5nIiwic2l0dGluZyIsIlNQRUNJRVNfTUFQIiwiZG9nIiwiY2F0IiwiYmlyZCIsInNtYWxsX2FuaW1hbCIsImV4b3RpYyIsIlNlcnZpY2VDYXJkIiwic2VydmljZSIsIm9uRWRpdCIsIm9uRGVsZXRlIiwiaXNQdWJsaXNoZWQiLCJzdGF0dXMiLCJ0eXBlSW5mbyIsInNlcnZpY2V0eXBlIiwic2VydmljZVR5cGUiLCJzZXJ2aWNlbmFtZSIsInNlcnZpY2VOYW1lIiwiTnVtYmVyIiwicHJpY2UiLCJ0b0xvY2FsZVN0cmluZyIsInNwZWNpZXMiLCJtYXAiLCJzcCIsImRlc2NyaXB0aW9uIiwic2VydmljZWlkIiwic2VydmljZUlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VydmljZUNhcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLy8gQ2F0ZWdvcnkgbWV0YWRhdGEgbWFwcGluZ1xuY29uc3QgU0VSVklDRV9UWVBFX01BUCA9IHtcbiAgd2Fsa2luZzogeyBsYWJlbDogXCLguJ7guLLguYDguJTguLTguJnguYDguKXguYjguJlcIiwgdW5pdDogXCLguL8gLyDguIrguKEuXCIgfSxcbiAgZGF5Y2FyZTogeyBsYWJlbDogXCLguJ3guLLguIHguYDguKXguLXguYnguKLguIfguKPguLLguKLguKfguLHguJlcIiwgdW5pdDogXCLguL8gLyDguKfguLHguJlcIiB9LFxuICBib2FyZGluZzogeyBsYWJlbDogXCLguJ3guLLguIHguYDguKXguLXguYnguKLguIfguITguYnguLLguIfguITguLfguJlcIiwgdW5pdDogXCLguL8gLyDguITguLfguJlcIiB9LFxuICBncm9vbWluZzogeyBsYWJlbDogXCLguK3guLLguJrguJnguYnguLPguJXguLHguJTguILguJlcIiwgdW5pdDogXCLguL8gLyDguITguKPguLHguYnguIdcIiB9LFxuICBzaXR0aW5nOiB7IGxhYmVsOiBcIuC4lOC4ueC5geC4peC4luC4tuC4h+C4l+C4teC5iOC4nuC4seC4gVwiLCB1bml0OiBcIuC4vyAvIOC4hOC4o+C4seC5ieC4h1wiIH0sXG59O1xuXG4vLyBTcGVjaWVzIG1hcHBpbmdcbmNvbnN0IFNQRUNJRVNfTUFQID0ge1xuICBkb2c6IFwi4Liq4Li44LiZ4Lix4LiCXCIsXG4gIGNhdDogXCLguYHguKHguKdcIixcbiAgYmlyZDogXCLguJnguIFcIixcbiAgc21hbGxfYW5pbWFsOiBcIuC4quC4seC4leC4p+C5jOC4guC4meC4suC4lOC5gOC4peC5h+C4gVwiLFxuICBleG90aWM6IFwi4Liq4Lix4LiV4Lin4LmM4LmB4Lib4Lil4LiBXCIsXG59O1xuXG4vKipcbiAqIFNlcnZpY2VDYXJkIENvbXBvbmVudFxuICogXG4gKiDwn46TIFJlYWN0IFBhdHRlcm46IFN5bW1ldHJpYyBHcmlkIENhcmQgd2l0aCBMb2NrZWQgWm9uZSBIZWlnaHRzXG4gKiAtIEVuZm9yY2VzIG1pbmltdW0gaGVpZ2h0cyBwZXIgem9uZSAoYG1pbi1oLVsuLi5dYCkgdG8gYWxpZ24gZGl2aWRlcnMgYW5kIGNhcmRzLlxuICogLSBVc2VzIGBtdC1hdXRvYCBvbiB0aGUgYWN0aW9uIGJ1dHRvbiBiYXIgdG8gZW5zdXJlIGl0IHN0aWNrcyB0byB0aGUgYm90dG9tLlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7T2JqZWN0fSBwcm9wcy5zZXJ2aWNlIC0gU2VydmljZSBkYXRhIG9iamVjdC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uRWRpdCAtIENhbGxiYWNrIHdoZW4gRWRpdCBidXR0b24gaXMgY2xpY2tlZC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uRGVsZXRlIC0gQ2FsbGJhY2sgd2hlbiBEZWxldGUgYnV0dG9uIGlzIGNsaWNrZWQuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNlcnZpY2VDYXJkKHsgc2VydmljZSwgb25FZGl0LCBvbkRlbGV0ZSB9KSB7XG4gIGNvbnN0IGlzUHVibGlzaGVkID0gc2VydmljZS5zdGF0dXMgPT09IFwicHVibGlzaGVkXCI7XG4gIGNvbnN0IHR5cGVJbmZvID0gU0VSVklDRV9UWVBFX01BUFtzZXJ2aWNlLnNlcnZpY2V0eXBlIHx8IHNlcnZpY2Uuc2VydmljZVR5cGVdIHx8IHtcbiAgICBsYWJlbDogc2VydmljZS5zZXJ2aWNldHlwZSB8fCBzZXJ2aWNlLnNlcnZpY2VUeXBlIHx8IFwi4Lia4Lij4Li04LiB4Liy4LijXCIsXG4gICAgdW5pdDogXCLguL9cIixcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIGJvcmRlci0yICR7XG4gICAgICAgIGlzUHVibGlzaGVkXG4gICAgICAgICAgPyBcImJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLVsjMEY3NjZFXVwiXG4gICAgICAgICAgOiBcImJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTMwMCBiZy1bI0Y4RkFGQ11cIlxuICAgICAgfSByb3VuZGVkLTJ4bCBwLTUgY3VzdG9tLXNoYWRvdyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBmbGV4LWNvbGB9XG4gICAgPlxuICAgICAgey8qIFpvbmUgMTogQ2F0ZWdvcnkgQmFkZ2UgJiBTdGF0dXMgSW5kaWNhdG9yICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgbWItM1wiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC14cyBweC0yLjUgcHktMSByb3VuZGVkLWxnIGZvbnQtYm9sZFwiPlxuICAgICAgICAgIHt0eXBlSW5mby5sYWJlbH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8c3BhblxuICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcbiAgICAgICAgICAgIGlzUHVibGlzaGVkID8gXCJ0ZXh0LVsjMTZBMzRBXVwiIDogXCJ0ZXh0LXNsYXRlLTUwMFwiXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0yIGgtMiByb3VuZGVkLWZ1bGwgJHtcbiAgICAgICAgICAgICAgaXNQdWJsaXNoZWQgPyBcImJnLVsjMTZBMzRBXVwiIDogXCJiZy1zbGF0ZS00MDBcIlxuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgICB7aXNQdWJsaXNoZWQgPyBcIuC5gOC4m+C4tOC4lOC4o+C4seC4muC4muC4o+C4tOC4geC4suC4o1wiIDogXCLguJvguLTguJTguKPguLHguJrguIrguLHguYjguKfguITguKPguLLguKdcIn1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBab25lIDI6IFRpdGxlICYgUHJpY2UgKE1pbi1oLVs3MHB4XSBmb3IgR3JpZCBhbGlnbm1lbnQpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1bNzBweF0gbWItMlwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHRleHQtYmFzZSBsZWFkaW5nLXNudWcgbGluZS1jbGFtcC0yXCI+XG4gICAgICAgICAge3NlcnZpY2Uuc2VydmljZW5hbWUgfHwgc2VydmljZS5zZXJ2aWNlTmFtZX1cbiAgICAgICAgPC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0xIG10LTEuNVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwRjc2NkVdXCI+XG4gICAgICAgICAgICDguL97TnVtYmVyKHNlcnZpY2UucHJpY2UpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZm9udC1ib2xkXCI+e3R5cGVJbmZvLnVuaXR9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogWm9uZSAzOiBTcGVjaWVzIENoaXBzIChNaW4taC1bMzJweF0gZm9yIEdyaWQgYWxpZ25tZW50KSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNSBwdC0xIG1iLTMgbWluLWgtWzMycHhdXCI+XG4gICAgICAgIHsoc2VydmljZS5zcGVjaWVzIHx8IFtdKS5tYXAoKHNwKSA9PiAoXG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGtleT17c3B9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1bI0YxRjVGOV0gdGV4dC1zbGF0ZS04MDAgdGV4dC14cyBweC0yLjUgcHktMSByb3VuZGVkLWxnIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge1NQRUNJRVNfTUFQW3NwXSB8fCBzcH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBab25lIDQ6IERlc2NyaXB0aW9uIChNaW4taC1bNDRweF0gZm9yIEdyaWQgYWxpZ25tZW50KSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtWzQ0cHhdIG1iLTRcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBsaW5lLWNsYW1wLTIgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAge3NlcnZpY2UuZGVzY3JpcHRpb24gfHwgXCLguYTguKHguYjguKHguLXguITguLPguK3guJjguLTguJrguLLguKLguYDguJ7guLTguYjguKHguYDguJXguLTguKFcIn1cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBab25lIDU6IEFjdGlvbiBCdXR0b25zIChtdC1hdXRvIHRvIHBpbiB0byBib3R0b20pICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25FZGl0KHNlcnZpY2UpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yIHB4LTMgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAg4LmB4LiB4LmJ4LmE4LiCXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25EZWxldGUoc2VydmljZS5zZXJ2aWNlaWQgfHwgc2VydmljZS5zZXJ2aWNlSWQpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIgcHgtMyBiZy1yb3NlLTUwIGhvdmVyOmJnLXJvc2UtMTAwIHRleHQtcm9zZS03MDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAg4Lil4LiaXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9zaXR0ZXIvZGFzaGJvYXJkL1NlcnZpY2VDYXJkLmpzeCJ9