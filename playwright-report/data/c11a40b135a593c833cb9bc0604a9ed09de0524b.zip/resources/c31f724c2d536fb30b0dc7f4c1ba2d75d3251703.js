import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DeleteAccountModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function DeleteAccountModal({
  password,
  error,
  status,
  onPasswordChange,
  onCancel,
  onConfirm
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-overlay", children: /* @__PURE__ */ jsxDEV("div", { className: "delete-modal", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
    e.preventDefault();
    onConfirm();
  }, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "ยืนยันการลบบัญชี" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
      lineNumber: 32,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "delete-modal-warning", children: "การลบบัญชีจะไม่สามารถย้อนกลับได้" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
      lineNumber: 34,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "กรุณากรอกรหัสผ่านของคุณ เพื่อยืนยันการลบบัญชี" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
      lineNumber: 38,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "password",
        className: "delete-password-input",
        placeholder: "กรอกรหัสผ่าน",
        value: password,
        onChange: (e) => onPasswordChange(e.target.value),
        disabled: status === "submitting"
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
        lineNumber: 42,
        columnNumber: 11
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV("div", { className: "delete-error", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
      lineNumber: 51,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "delete-modal-actions", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "delete-cancel-button",
          onClick: onCancel,
          disabled: status === "submitting",
          children: "ยกเลิก"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
          lineNumber: 54,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "submit",
          className: "delete-confirm-button",
          disabled: status === "submitting",
          children: status === "submitting" ? "กำลังลบ..." : "ยืนยันการลบบัญชี"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
          lineNumber: 62,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
      lineNumber: 53,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
    lineNumber: 31,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
    lineNumber: 30,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
_c = DeleteAccountModal;
export default DeleteAccountModal;
var _c;
$RefreshReg$(_c, "DeleteAccountModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/DeleteAccountModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVU7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaVixTQUFTQSxtQkFBbUI7QUFBQSxFQUMxQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2IsaUNBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFVBQUssVUFBVSxDQUFDQyxNQUFNO0FBQUVBLE1BQUVDLGVBQWU7QUFBR0YsY0FBVTtBQUFBLEVBQUcsR0FDeEQ7QUFBQSwyQkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0I7QUFBQSxJQUVwQix1QkFBQyxPQUFFLFdBQVUsd0JBQXNCLGdEQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLE9BQUMsNkRBQUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsYUFBWTtBQUFBLFFBQ1osT0FBT0w7QUFBQUEsUUFDUCxVQUFVLENBQUNNLE1BQU1ILGlCQUFpQkcsRUFBRUUsT0FBT0MsS0FBSztBQUFBLFFBQ2hELFVBQVVQLFdBQVc7QUFBQTtBQUFBLE1BTnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1vQztBQUFBLElBR25DRCxTQUFTLHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JBLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFFL0MsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVNHO0FBQUFBLFVBQ1QsVUFBVUYsV0FBVztBQUFBLFVBQWE7QUFBQTtBQUFBLFFBSnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsVUFBVUEsV0FBVztBQUFBLFVBRXBCQSxxQkFBVyxlQUFlLGVBQWU7QUFBQTtBQUFBLFFBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsT0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQSxLQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUNBLEtBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQ0E7QUFFSjtBQUFDUSxLQXREUVg7QUF3RFQsZUFBZUE7QUFBbUIsSUFBQVc7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRGVsZXRlQWNjb3VudE1vZGFsIiwicGFzc3dvcmQiLCJlcnJvciIsInN0YXR1cyIsIm9uUGFzc3dvcmRDaGFuZ2UiLCJvbkNhbmNlbCIsIm9uQ29uZmlybSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGVsZXRlQWNjb3VudE1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBEZWxldGVBY2NvdW50TW9kYWwoe1xuICBwYXNzd29yZCxcbiAgZXJyb3IsXG4gIHN0YXR1cyxcbiAgb25QYXNzd29yZENoYW5nZSxcbiAgb25DYW5jZWwsXG4gIG9uQ29uZmlybSxcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbC1vdmVybGF5XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGV0ZS1tb2RhbFwiPlxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBvbkNvbmZpcm0oKTsgfX0+XG4gICAgICAgICAgPGgyPuC4ouC4t+C4meC4ouC4seC4meC4geC4suC4o+C4peC4muC4muC4seC4jeC4iuC4tTwvaDI+XG5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkZWxldGUtbW9kYWwtd2FybmluZ1wiPlxuICAgICAgICAgICAg4LiB4Liy4Lij4Lil4Lia4Lia4Lix4LiN4LiK4Li14LiI4Liw4LmE4Lih4LmI4Liq4Liy4Lih4Liy4Lij4LiW4Lii4LmJ4Lit4LiZ4LiB4Lil4Lix4Lia4LmE4LiU4LmJXG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICDguIHguKPguLjguJPguLLguIHguKPguK3guIHguKPguKvguLHguKrguJzguYjguLLguJnguILguK3guIfguITguLjguJMg4LmA4Lie4Li34LmI4Lit4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4Lil4Lia4Lia4Lix4LiN4LiK4Li1XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLXBhc3N3b3JkLWlucHV0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LiB4Lij4Lit4LiB4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25QYXNzd29yZENoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBkaXNhYmxlZD17c3RhdHVzID09PSBcInN1Ym1pdHRpbmdcIn1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZGVsZXRlLWVycm9yXCI+e2Vycm9yfTwvZGl2Pn1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsZXRlLW1vZGFsLWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRlbGV0ZS1jYW5jZWwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DYW5jZWx9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtzdGF0dXMgPT09IFwic3VibWl0dGluZ1wifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDguKLguIHguYDguKXguLTguIFcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVsZXRlLWNvbmZpcm0tYnV0dG9uXCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N0YXR1cyA9PT0gXCJzdWJtaXR0aW5nXCJ9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtzdGF0dXMgPT09IFwic3VibWl0dGluZ1wiID8gXCLguIHguLPguKXguLHguIfguKXguJouLi5cIiA6IFwi4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4Lil4Lia4Lia4Lix4LiN4LiK4Li1XCJ9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IERlbGV0ZUFjY291bnRNb2RhbDtcblxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvRGVsZXRlQWNjb3VudE1vZGFsLmpzeCJ9