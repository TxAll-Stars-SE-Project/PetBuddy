import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/BookingConfirmModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"];
import "/src/components/sitter/BookingConfirmModal.css";
const actionMetaMap = {
  accept: {
    title: "ยืนยันการรับงานคำขอจอง",
    description: 'คุณต้องการรับงานคำขอนี้ใช่หรือไม่? เมื่อกดยืนยัน ระบบจะเปลี่ยนสถานะเป็น "รอชำระเงิน" และส่งอีเมลแจ้งเตือนไปยังเจ้าของสัตว์เลี้ยงเพื่อให้ดำเนินการชำระเงิน',
    confirmLabel: "ยืนยันรับงาน (Accept)",
    buttonClass: "booking-confirm-modal__button--accept"
  },
  reject: {
    title: "ยืนยันการปฏิเสธคำขอจอง",
    description: 'คุณต้องการปฏิเสธคำขอนี้ใช่หรือไม่? ระบบจะเปลี่ยนสถานะเป็น "ปฏิเสธแล้ว" และแจ้งเตือนเจ้าของสัตว์เลี้ยง',
    confirmLabel: "ยืนยันปฏิเสธ (Reject)",
    buttonClass: "booking-confirm-modal__button--reject",
    warningNote: "ข้อควรระวัง: การปฏิเสธคำขอเป็นการดำเนินการที่ไม่สามารถย้อนกลับได้"
  },
  complete: {
    title: "ยืนยันการส่งมอบงานเสร็จสิ้น",
    description: 'คุณได้ดูแลสัตว์เลี้ยงเสร็จสิ้นตามข้อตกลงแล้วใช่หรือไม่? ระบบจะเปลี่ยนสถานะเป็น "รอชำระส่วนที่เหลือ" เพื่อให้เจ้าของสัตว์เลี้ยงทำการชำระเงินงวดสุดท้าย',
    confirmLabel: "ยืนยันส่งงาน (Complete Job)",
    buttonClass: "booking-confirm-modal__button--complete"
  }
};
export default function BookingConfirmModal({
  isOpen,
  booking,
  action,
  isSubmitting = false,
  onConfirm,
  onCancel
}) {
  _s();
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (event) => {
      if (event.key === "Escape" && !isSubmitting) {
        onCancel();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, isSubmitting, onCancel]);
  if (!isOpen || !booking || !action) {
    return null;
  }
  const meta = actionMetaMap[action];
  const serviceName = booking.service?.title || "บริการสัตว์เลี้ยง";
  const ownerName = booking.owner?.fullname || "เจ้าของสัตว์เลี้ยง";
  const totalPrice = Number(booking.totalprice) || 0;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "booking-confirm-modal__overlay",
      onClick: isSubmitting ? void 0 : onCancel,
      role: "presentation",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "booking-confirm-modal",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "confirm-modal-title",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("header", { className: "booking-confirm-modal__header", children: [
              /* @__PURE__ */ jsxDEV("h2", { id: "confirm-modal-title", className: "booking-confirm-modal__title", children: meta.title }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                lineNumber: 108,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "booking-confirm-modal__close",
                  onClick: onCancel,
                  disabled: isSubmitting,
                  "aria-label": "ปิดหน้าต่าง",
                  children: "×"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 111,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
              lineNumber: 107,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__body", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "booking-confirm-modal__description", children: meta.description }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                lineNumber: 123,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__summary-card", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__summary-row", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-label", children: "เจ้าของสัตว์เลี้ยง:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 127,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-value", children: ownerName }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 128,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 126,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__summary-row", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-label", children: "บริการ:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 131,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-value", children: serviceName }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 132,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 130,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__summary-row", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-label", children: "ยอดรวม:" }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 135,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "booking-confirm-modal__summary-value booking-confirm-modal__summary-price", children: [
                    totalPrice.toLocaleString("th-TH"),
                    " บาท"
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                    lineNumber: 136,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 134,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                lineNumber: 125,
                columnNumber: 11
              }, this),
              meta.warningNote && /* @__PURE__ */ jsxDEV("div", { className: "booking-confirm-modal__warning", role: "alert", children: /* @__PURE__ */ jsxDEV("span", { children: meta.warningNote }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                lineNumber: 144,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                lineNumber: 143,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
              lineNumber: 122,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("footer", { className: "booking-confirm-modal__footer", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "booking-confirm-modal__button booking-confirm-modal__button--cancel",
                  onClick: onCancel,
                  disabled: isSubmitting,
                  children: "ยกเลิก"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 150,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: `booking-confirm-modal__button ${meta.buttonClass}`,
                  onClick: onConfirm,
                  disabled: isSubmitting,
                  children: isSubmitting ? "กำลังดำเนินการ..." : meta.confirmLabel
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
                  lineNumber: 158,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
              lineNumber: 149,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
          lineNumber: 100,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx",
      lineNumber: 95,
      columnNumber: 5
    },
    this
  );
}
_s(BookingConfirmModal, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = BookingConfirmModal;
var _c;
$RefreshReg$(_c, "BookingConfirmModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/BookingConfirmModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhGVixTQUFTQSxpQkFBaUI7QUFFMUIsT0FBTztBQW1CUCxNQUFNQyxnQkFBbUQ7QUFBQSxFQUN2REMsUUFBUTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLElBQ2RDLGFBQWE7QUFBQSxFQUNmO0FBQUEsRUFDQUMsUUFBUTtBQUFBLElBQ05KLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLElBQ2RDLGFBQWE7QUFBQSxJQUNiRSxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0FDLFVBQVU7QUFBQSxJQUNSTixPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxJQUNkQyxhQUFhO0FBQUEsRUFDZjtBQUNGO0FBRUEsd0JBQXdCSSxvQkFBb0I7QUFBQSxFQUMxQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsZUFBZTtBQUFBLEVBQ2ZDO0FBQUFBLEVBQ0FDO0FBQ3dCLEdBQUc7QUFBQUMsS0FBQTtBQUUzQmpCLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ1csT0FBUTtBQUViLFVBQU1PLGdCQUFnQkEsQ0FBQ0MsVUFBeUI7QUFDOUMsVUFBSUEsTUFBTUMsUUFBUSxZQUFZLENBQUNOLGNBQWM7QUFDM0NFLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFFQUssV0FBT0MsaUJBQWlCLFdBQVdKLGFBQWE7QUFDaEQsV0FBTyxNQUFNRyxPQUFPRSxvQkFBb0IsV0FBV0wsYUFBYTtBQUFBLEVBQ2xFLEdBQUcsQ0FBQ1AsUUFBUUcsY0FBY0UsUUFBUSxDQUFDO0FBRW5DLE1BQUksQ0FBQ0wsVUFBVSxDQUFDQyxXQUFXLENBQUNDLFFBQVE7QUFDbEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNVyxPQUFPdkIsY0FBY1ksTUFBTTtBQUNqQyxRQUFNWSxjQUFjYixRQUFRYyxTQUFTdkIsU0FBUztBQUM5QyxRQUFNd0IsWUFBWWYsUUFBUWdCLE9BQU9DLFlBQVk7QUFDN0MsUUFBTUMsYUFBYUMsT0FBT25CLFFBQVFvQixVQUFVLEtBQUs7QUFFakQsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsU0FBU2xCLGVBQWVtQixTQUFZakI7QUFBQUEsTUFDcEMsTUFBSztBQUFBLE1BRUw7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLG1CQUFnQjtBQUFBLFVBQ2hCLFNBQVMsQ0FBQ2tCLE1BQU1BLEVBQUVDLGdCQUFnQjtBQUFBLFVBRWxDO0FBQUEsbUNBQUMsWUFBTyxXQUFVLGlDQUNoQjtBQUFBLHFDQUFDLFFBQUcsSUFBRyx1QkFBc0IsV0FBVSxnQ0FDcENYLGVBQUtyQixTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU2E7QUFBQUEsa0JBQ1QsVUFBVUY7QUFBQUEsa0JBQ1YsY0FBVztBQUFBLGtCQUFhO0FBQUE7QUFBQSxnQkFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxpQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsc0NBQXNDVSxlQUFLcEIsZUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0U7QUFBQSxjQUVwRSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsd0NBQXVDLG1DQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRTtBQUFBLGtCQUMxRSx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDdUIsdUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtFO0FBQUEscUJBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsd0NBQXVDLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RDtBQUFBLGtCQUM5RCx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDRix5QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0U7QUFBQSxxQkFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSx3Q0FBdUMsdUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThEO0FBQUEsa0JBQzlELHVCQUFDLFVBQUssV0FBVSw2RUFDYks7QUFBQUEsK0JBQVdNLGVBQWUsT0FBTztBQUFBLG9CQUFFO0FBQUEsdUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBRUNaLEtBQUtoQixlQUNKLHVCQUFDLFNBQUksV0FBVSxrQ0FBaUMsTUFBSyxTQUNuRCxpQ0FBQyxVQUFNZ0IsZUFBS2hCLGVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBRUEsdUJBQUMsWUFBTyxXQUFVLGlDQUNoQjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU1E7QUFBQUEsa0JBQ1QsVUFBVUY7QUFBQUEsa0JBQWE7QUFBQTtBQUFBLGdCQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVcsaUNBQWlDVSxLQUFLbEIsV0FBVztBQUFBLGtCQUM1RCxTQUFTUztBQUFBQSxrQkFDVCxVQUFVRDtBQUFBQSxrQkFFVEEseUJBQWUsc0JBQXNCVSxLQUFLbkI7QUFBQUE7QUFBQUEsZ0JBTjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUE7QUFBQTtBQUFBLFFBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW1FQTtBQUFBO0FBQUEsSUF4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBeUVBO0FBRUo7QUFBQ1ksR0EzR3VCUCxxQkFBbUI7QUFBQSxLQUFuQkE7QUFBbUIsSUFBQTJCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsImFjdGlvbk1ldGFNYXAiLCJhY2NlcHQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiY29uZmlybUxhYmVsIiwiYnV0dG9uQ2xhc3MiLCJyZWplY3QiLCJ3YXJuaW5nTm90ZSIsImNvbXBsZXRlIiwiQm9va2luZ0NvbmZpcm1Nb2RhbCIsImlzT3BlbiIsImJvb2tpbmciLCJhY3Rpb24iLCJpc1N1Ym1pdHRpbmciLCJvbkNvbmZpcm0iLCJvbkNhbmNlbCIsIl9zIiwiaGFuZGxlS2V5RG93biIsImV2ZW50Iiwia2V5Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJtZXRhIiwic2VydmljZU5hbWUiLCJzZXJ2aWNlIiwib3duZXJOYW1lIiwib3duZXIiLCJmdWxsbmFtZSIsInRvdGFsUHJpY2UiLCJOdW1iZXIiLCJ0b3RhbHByaWNlIiwidW5kZWZpbmVkIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsInRvTG9jYWxlU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQm9va2luZ0NvbmZpcm1Nb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBCb29raW5nLCBCb29raW5nQWN0aW9uIH0gZnJvbSAnLi4vLi4vdHlwZXMvYm9va2luZyc7XG5pbXBvcnQgJy4vQm9va2luZ0NvbmZpcm1Nb2RhbC5jc3MnO1xuXG5pbnRlcmZhY2UgQm9va2luZ0NvbmZpcm1Nb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBib29raW5nOiBCb29raW5nIHwgbnVsbDtcbiAgYWN0aW9uOiBCb29raW5nQWN0aW9uIHwgbnVsbDtcbiAgaXNTdWJtaXR0aW5nPzogYm9vbGVhbjtcbiAgb25Db25maXJtOiAoKSA9PiB2b2lkO1xuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcbn1cblxuaW50ZXJmYWNlIEFjdGlvbk1ldGEge1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICBjb25maXJtTGFiZWw6IHN0cmluZztcbiAgYnV0dG9uQ2xhc3M6IHN0cmluZztcbiAgd2FybmluZ05vdGU/OiBzdHJpbmc7XG59XG5cbmNvbnN0IGFjdGlvbk1ldGFNYXA6IFJlY29yZDxCb29raW5nQWN0aW9uLCBBY3Rpb25NZXRhPiA9IHtcbiAgYWNjZXB0OiB7XG4gICAgdGl0bGU6ICfguKLguLfguJnguKLguLHguJnguIHguLLguKPguKPguLHguJrguIfguLLguJnguITguLPguILguK3guIjguK3guIcnLFxuICAgIGRlc2NyaXB0aW9uOiAn4LiE4Li44LiT4LiV4LmJ4Lit4LiH4LiB4Liy4Lij4Lij4Lix4Lia4LiH4Liy4LiZ4LiE4Liz4LiC4Lit4LiZ4Li14LmJ4LmD4LiK4LmI4Lir4Lij4Li34Lit4LmE4Lih4LmIPyDguYDguKHguLfguYjguK3guIHguJTguKLguLfguJnguKLguLHguJkg4Lij4Liw4Lia4Lia4LiI4Liw4LmA4Lib4Lil4Li14LmI4Lii4LiZ4Liq4LiW4Liy4LiZ4Liw4LmA4Lib4LmH4LiZIFwi4Lij4Lit4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXCIg4LmB4Lil4Liw4Liq4LmI4LiH4Lit4Li14LmA4Lih4Lil4LmB4LiI4LmJ4LiH4LmA4LiV4Li34Lit4LiZ4LmE4Lib4Lii4Lix4LiH4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LmA4Lie4Li34LmI4Lit4LmD4Lir4LmJ4LiU4Liz4LmA4LiZ4Li04LiZ4LiB4Liy4Lij4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZJyxcbiAgICBjb25maXJtTGFiZWw6ICfguKLguLfguJnguKLguLHguJnguKPguLHguJrguIfguLLguJkgKEFjY2VwdCknLFxuICAgIGJ1dHRvbkNsYXNzOiAnYm9va2luZy1jb25maXJtLW1vZGFsX19idXR0b24tLWFjY2VwdCcsXG4gIH0sXG4gIHJlamVjdDoge1xuICAgIHRpdGxlOiAn4Lii4Li34LiZ4Lii4Lix4LiZ4LiB4Liy4Lij4Lib4LiP4Li04LmA4Liq4LiY4LiE4Liz4LiC4Lit4LiI4Lit4LiHJyxcbiAgICBkZXNjcmlwdGlvbjogJ+C4hOC4uOC4k+C4leC5ieC4reC4h+C4geC4suC4o+C4m+C4j+C4tOC5gOC4quC4mOC4hOC4s+C4guC4reC4meC4teC5ieC5g+C4iuC5iOC4q+C4o+C4t+C4reC5hOC4oeC5iD8g4Lij4Liw4Lia4Lia4LiI4Liw4LmA4Lib4Lil4Li14LmI4Lii4LiZ4Liq4LiW4Liy4LiZ4Liw4LmA4Lib4LmH4LiZIFwi4Lib4LiP4Li04LmA4Liq4LiY4LmB4Lil4LmJ4LinXCIg4LmB4Lil4Liw4LmB4LiI4LmJ4LiH4LmA4LiV4Li34Lit4LiZ4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHJyxcbiAgICBjb25maXJtTGFiZWw6ICfguKLguLfguJnguKLguLHguJnguJvguI/guLTguYDguKrguJggKFJlamVjdCknLFxuICAgIGJ1dHRvbkNsYXNzOiAnYm9va2luZy1jb25maXJtLW1vZGFsX19idXR0b24tLXJlamVjdCcsXG4gICAgd2FybmluZ05vdGU6ICfguILguYnguK3guITguKfguKPguKPguLDguKfguLHguIc6IOC4geC4suC4o+C4m+C4j+C4tOC5gOC4quC4mOC4hOC4s+C4guC4reC5gOC4m+C5h+C4meC4geC4suC4o+C4lOC4s+C5gOC4meC4tOC4meC4geC4suC4o+C4l+C4teC5iOC5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4ouC5ieC4reC4meC4geC4peC4seC4muC5hOC4lOC5iScsXG4gIH0sXG4gIGNvbXBsZXRlOiB7XG4gICAgdGl0bGU6ICfguKLguLfguJnguKLguLHguJnguIHguLLguKPguKrguYjguIfguKHguK3guJrguIfguLLguJnguYDguKrguKPguYfguIjguKrguLTguYnguJknLFxuICAgIGRlc2NyaXB0aW9uOiAn4LiE4Li44LiT4LmE4LiU4LmJ4LiU4Li54LmB4Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LmA4Liq4Lij4LmH4LiI4Liq4Li04LmJ4LiZ4LiV4Liy4Lih4LiC4LmJ4Lit4LiV4LiB4Lil4LiH4LmB4Lil4LmJ4Lin4LmD4LiK4LmI4Lir4Lij4Li34Lit4LmE4Lih4LmIPyDguKPguLDguJrguJrguIjguLDguYDguJvguKXguLXguYjguKLguJnguKrguJbguLLguJnguLDguYDguJvguYfguJkgXCLguKPguK3guIrguLPguKPguLDguKrguYjguKfguJnguJfguLXguYjguYDguKvguKXguLfguK1cIiDguYDguJ7guLfguYjguK3guYPguKvguYnguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJfguLPguIHguLLguKPguIrguLPguKPguLDguYDguIfguLTguJnguIfguKfguJTguKrguLjguJTguJfguYnguLLguKInLFxuICAgIGNvbmZpcm1MYWJlbDogJ+C4ouC4t+C4meC4ouC4seC4meC4quC5iOC4h+C4h+C4suC4mSAoQ29tcGxldGUgSm9iKScsXG4gICAgYnV0dG9uQ2xhc3M6ICdib29raW5nLWNvbmZpcm0tbW9kYWxfX2J1dHRvbi0tY29tcGxldGUnLFxuICB9LFxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm9va2luZ0NvbmZpcm1Nb2RhbCh7XG4gIGlzT3BlbixcbiAgYm9va2luZyxcbiAgYWN0aW9uLFxuICBpc1N1Ym1pdHRpbmcgPSBmYWxzZSxcbiAgb25Db25maXJtLFxuICBvbkNhbmNlbCxcbn06IEJvb2tpbmdDb25maXJtTW9kYWxQcm9wcykge1xuICAvLyDguKPguK3guIfguKPguLHguJrguIHguLLguKPguIHguJTguYHguJvguYnguJkgRVNDIOC5gOC4nuC4t+C5iOC4reC4m+C4tOC4lOC4q+C4meC5ieC4suC4leC5iOC4suC4hyBNb2RhbFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNPcGVuKSByZXR1cm47XG5cbiAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGV2ZW50OiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJyAmJiAhaXNTdWJtaXR0aW5nKSB7XG4gICAgICAgIG9uQ2FuY2VsKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtpc09wZW4sIGlzU3VibWl0dGluZywgb25DYW5jZWxdKTtcblxuICBpZiAoIWlzT3BlbiB8fCAhYm9va2luZyB8fCAhYWN0aW9uKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBjb25zdCBtZXRhID0gYWN0aW9uTWV0YU1hcFthY3Rpb25dO1xuICBjb25zdCBzZXJ2aWNlTmFtZSA9IGJvb2tpbmcuc2VydmljZT8udGl0bGUgfHwgJ+C4muC4o+C4tOC4geC4suC4o+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hyc7XG4gIGNvbnN0IG93bmVyTmFtZSA9IGJvb2tpbmcub3duZXI/LmZ1bGxuYW1lIHx8ICfguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcnO1xuICBjb25zdCB0b3RhbFByaWNlID0gTnVtYmVyKGJvb2tpbmcudG90YWxwcmljZSkgfHwgMDtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9fb3ZlcmxheVwiXG4gICAgICBvbkNsaWNrPXtpc1N1Ym1pdHRpbmcgPyB1bmRlZmluZWQgOiBvbkNhbmNlbH1cbiAgICAgIHJvbGU9XCJwcmVzZW50YXRpb25cIlxuICAgID5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsXCJcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwiY29uZmlybS1tb2RhbC10aXRsZVwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9faGVhZGVyXCI+XG4gICAgICAgICAgPGgyIGlkPVwiY29uZmlybS1tb2RhbC10aXRsZVwiIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9fdGl0bGVcIj5cbiAgICAgICAgICAgIHttZXRhLnRpdGxlfVxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX2Nsb3NlXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCLguJvguLTguJTguKvguJnguYnguLLguJXguYjguLLguIdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIMOXXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvaGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19ib2R5XCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19kZXNjcmlwdGlvblwiPnttZXRhLmRlc2NyaXB0aW9ufTwvcD5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19zdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19zdW1tYXJ5LXJvd1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX3N1bW1hcnktbGFiZWxcIj7guYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIc6PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX3N1bW1hcnktdmFsdWVcIj57b3duZXJOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX3N1bW1hcnktcm93XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9fc3VtbWFyeS1sYWJlbFwiPuC4muC4o+C4tOC4geC4suC4ozo8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9fc3VtbWFyeS12YWx1ZVwiPntzZXJ2aWNlTmFtZX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19zdW1tYXJ5LXJvd1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX3N1bW1hcnktbGFiZWxcIj7guKLguK3guJTguKPguKfguKE6PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWNvbmZpcm0tbW9kYWxfX3N1bW1hcnktdmFsdWUgYm9va2luZy1jb25maXJtLW1vZGFsX19zdW1tYXJ5LXByaWNlXCI+XG4gICAgICAgICAgICAgICAge3RvdGFsUHJpY2UudG9Mb2NhbGVTdHJpbmcoJ3RoLVRIJyl9IOC4muC4suC4l1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHttZXRhLndhcm5pbmdOb3RlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX193YXJuaW5nXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgIDxzcGFuPnttZXRhLndhcm5pbmdOb3RlfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9va2luZy1jb25maXJtLW1vZGFsX19mb290ZXJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvb2tpbmctY29uZmlybS1tb2RhbF9fYnV0dG9uIGJvb2tpbmctY29uZmlybS1tb2RhbF9fYnV0dG9uLS1jYW5jZWxcIlxuICAgICAgICAgICAgb25DbGljaz17b25DYW5jZWx9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOC4ouC4geC5gOC4peC4tOC4gVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9va2luZy1jb25maXJtLW1vZGFsX19idXR0b24gJHttZXRhLmJ1dHRvbkNsYXNzfWB9XG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAn4LiB4Liz4Lil4Lix4LiH4LiU4Liz4LmA4LiZ4Li04LiZ4LiB4Liy4LijLi4uJyA6IG1ldGEuY29uZmlybUxhYmVsfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvb3Rlcj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL0Jvb2tpbmdDb25maXJtTW9kYWwudHN4In0=