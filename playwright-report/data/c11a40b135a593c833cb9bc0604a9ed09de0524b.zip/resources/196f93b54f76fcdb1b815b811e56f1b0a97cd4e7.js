import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ProfilePage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth } from "/src/context/AuthContext.jsx";
import Navbar from "/src/components/Navbar.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { api } from "/src/services/api.js";
import provincesData from "/src/assets/thai-address/province.json?import";
import districtsData from "/src/assets/thai-address/district.json?import";
import subDistrictsData from "/src/assets/thai-address/sub_district.json?import";
import ProfileField from "/src/components/ProfileField.jsx";
import DeleteAccountModal from "/src/components/DeleteAccountModal.jsx";
import PetModal from "/src/components/PetModal.jsx";
import SitterQrUpload from "/src/components/SitterQrUpload.jsx";
import { validateProfile } from "/src/utils/profileValidation.js";
import { toast } from "/src/utils/toast.js";
function ProfilePage() {
  _s();
  const navigate = useNavigate();
  const { user, logout, setUser } = useAuth();
  const isSitter = user?.role === "sitter";
  const [profile, setProfile] = useState({
    username: user?.username || "",
    email: user?.email || "",
    tel: user?.tel || "",
    address: user?.address || "",
    province: user?.province || "",
    district: user?.district || "",
    subdistrict: user?.subdistrict || "",
    postalCode: user?.postalCode || "",
    role: user?.role || "owner",
    experience: user?.experience || "",
    thaiId: user?.thaiId || "",
    accountName: user?.accountName || "",
    qrCodeUrl: user?.qrCodeUrl || ""
  });
  const [originalProfile, setOriginalProfile] = useState(profile);
  const [errors, setErrors] = useState({});
  const [savingSection, setSavingSection] = useState(null);
  const [isSavingPet, setIsSavingPet] = useState(false);
  const [isDeletingPet, setIsDeletingPet] = useState(false);
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const res = await api.get("/users/me");
        const data = res.data?.data;
        if (data) {
          const loadedProfile = {
            username: data.username || "",
            email: data.email || "",
            tel: data.tel || "",
            address: data.address || "",
            province: data.province || "",
            district: data.district || data.city || "",
            subdistrict: data.subdistrict || "",
            postalCode: data.postalCode || "",
            role: data.role || "owner",
            experience: data.experience || "",
            thaiId: data.thaiId || "",
            accountName: "",
            qrCodeUrl: ""
          };
          if (loadedProfile.role === "sitter") {
            try {
              const payRes = await api.get("/sitter/payment-info");
              const pay = payRes.data?.data;
              loadedProfile.accountName = pay?.accountName || "";
              loadedProfile.qrCodeUrl = pay?.qrCodeUrl || "";
              setHasPaymentInfo(!!pay?.hasPaymentInfo);
            } catch (payErr) {
              console.error("ดึงข้อมูลรับเงินไม่สำเร็จ:", payErr);
            }
          }
          setProfile(loadedProfile);
          setOriginalProfile(loadedProfile);
          const fullUserData = { ...user, ...loadedProfile, pets: data.pets || [] };
          if (setUser) setUser(fullUserData);
          const safeUserData = {
            id: fullUserData.id,
            username: fullUserData.username,
            email: fullUserData.email,
            role: fullUserData.role
          };
          localStorage.setItem("pb_user", JSON.stringify(safeUserData));
          if (data.pets && Array.isArray(data.pets)) {
            const mappedPets = data.pets.map((p) => ({
              petId: p.petId || p.petid || p.id || null,
              name: p.name || "",
              species: p.species || "",
              breed: p.breed || "",
              gender: p.gender || "",
              weight: p.weight || "",
              age: p.age !== null && p.age !== void 0 ? p.age : "",
              photo: p.imageUrl || "",
              notes: p.allergy ? `แพ้: ${p.allergy}` : ""
            }));
            setPets(mappedPets);
          }
        }
      } catch (err) {
        console.error("ดึงข้อมูลโปรไฟล์ไม่สำเร็จ:", err);
      }
    };
    fetchUserProfile();
  }, []);
  const [availableDistricts, setAvailableDistricts] = useState([]);
  const [availableSubdistricts, setAvailableSubdistricts] = useState([]);
  const [availableZipcodes, setAvailableZipcodes] = useState([]);
  useEffect(() => {
    if (profile.province) {
      const prov = provincesData.find((p) => p.name_th === profile.province);
      if (prov) {
        const filteredDistricts = districtsData.filter((d) => d.province_id === prov.id);
        setAvailableDistricts(filteredDistricts);
        if (profile.district) {
          const dist = filteredDistricts.find((d) => d.name_th === profile.district);
          if (dist) {
            const filteredSubdistricts = subDistrictsData.filter((s) => s.district_id === dist.id);
            setAvailableSubdistricts(filteredSubdistricts);
            if (profile.subdistrict) {
              const sub = filteredSubdistricts.find((s) => s.name_th === profile.subdistrict);
              if (sub) setAvailableZipcodes(sub.zip_code ? [sub.zip_code] : []);
            }
          }
        }
      }
    }
  }, [profile.province, profile.district, profile.subdistrict]);
  const handleProvinceChange = (e) => {
    const selectedProvince = e.target.value;
    setProfile((prev) => ({
      ...prev,
      province: selectedProvince,
      district: "",
      subdistrict: "",
      postalCode: ""
    }));
    const prov = provincesData.find((p) => p.name_th === selectedProvince);
    setAvailableDistricts(prov ? districtsData.filter((d) => d.province_id === prov.id) : []);
    setAvailableSubdistricts([]);
    setAvailableZipcodes([]);
  };
  const handleDistrictChange = (e) => {
    const selectedDistrict = e.target.value;
    setProfile((prev) => ({
      ...prev,
      district: selectedDistrict,
      subdistrict: "",
      postalCode: ""
    }));
    const dist = availableDistricts.find((d) => d.name_th === selectedDistrict);
    if (dist) {
      const filteredSubdistricts = subDistrictsData.filter((s) => s.district_id === dist.id);
      setAvailableSubdistricts(filteredSubdistricts);
      setAvailableZipcodes([]);
    } else {
      setAvailableSubdistricts([]);
      setAvailableZipcodes([]);
    }
  };
  const handleSubdistrictChange = (e) => {
    const selectedSub = e.target.value;
    const sub = availableSubdistricts.find((s) => s.name_th === selectedSub);
    setProfile((prev) => ({
      ...prev,
      subdistrict: selectedSub,
      postalCode: sub && sub.zip_code ? sub.zip_code.toString() : ""
    }));
    if (sub && sub.zip_code) {
      setAvailableZipcodes([sub.zip_code]);
    } else {
      setAvailableZipcodes([]);
    }
  };
  const [isEditingAccount, setIsEditingAccount] = useState(false);
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [isEditingSitter, setIsEditingSitter] = useState(false);
  const [qrFile, setQrFile] = useState(null);
  const [hasPaymentInfo, setHasPaymentInfo] = useState(false);
  const [pets, setPets] = useState(user?.pets || []);
  const [showPetModal, setShowPetModal] = useState(false);
  const [modalMode, setModalMode] = useState("add");
  const [currentPetIndex, setCurrentPetIndex] = useState(null);
  const [activePetForm, setActivePetForm] = useState({
    petId: null,
    name: "",
    species: "",
    breed: "",
    age: "",
    photo: "",
    notes: "",
    gender: "",
    weight: "",
    photoFile: null
  });
  const [petError, setPetError] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState("");
  const [deleteError, setDeleteError] = useState("");
  const [deleteStatus, setDeleteStatus] = useState("idle");
  const handleChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };
  const handleSaveSection = async (sectionType) => {
    const allErrors = validateProfile(profile);
    let sectionErrors = {};
    if (sectionType === "account") {
      if (allErrors.username) sectionErrors.username = allErrors.username;
      if (allErrors.email) sectionErrors.email = allErrors.email;
      if (allErrors.tel) sectionErrors.tel = allErrors.tel;
    } else if (sectionType === "address") {
      if (allErrors.address) sectionErrors.address = allErrors.address;
      if (allErrors.province) sectionErrors.province = allErrors.province;
      if (allErrors.district) sectionErrors.district = allErrors.district;
      if (allErrors.subdistrict) sectionErrors.subdistrict = allErrors.subdistrict;
      if (allErrors.postalCode) sectionErrors.postalCode = allErrors.postalCode;
    } else if (sectionType === "sitter") {
      if (allErrors.experience && profile.experience.trim() !== "") {
        sectionErrors.experience = allErrors.experience;
      }
      const accountName = (profile.accountName || "").trim();
      if (accountName.length > 100) {
        sectionErrors.accountName = "ชื่อบัญชีต้องไม่เกิน 100 ตัวอักษร";
      }
      if (!hasPaymentInfo) {
        if (qrFile || accountName) {
          if (!accountName) sectionErrors.accountName = "กรุณากรอกชื่อบัญชีรับเงิน";
          if (!qrFile) sectionErrors.qrCode = "กรุณาอัปโหลดรูป QR Code";
        }
      } else if (!accountName) {
        sectionErrors.accountName = "กรุณากรอกชื่อบัญชีรับเงิน";
      }
    }
    setErrors(sectionErrors);
    if (Object.keys(sectionErrors).length > 0) return;
    setSavingSection(sectionType);
    try {
      const payload = {
        username: profile.username,
        email: profile.email,
        tel: profile.tel,
        province: profile.province,
        district: profile.district,
        subdistrict: profile.subdistrict,
        postalCode: profile.postalCode,
        address: profile.address,
        role: profile.role
      };
      if (profile.role === "sitter") {
        payload.experience = profile.experience;
      }
      await api.put("/users/me", payload);
      setOriginalProfile((prev) => ({ ...prev, ...payload }));
      if (setUser) setUser({ ...user, ...payload, pets });
      let savedProfile = profile;
      const accountNameChanged = (profile.accountName || "").trim() !== (originalProfile.accountName || "").trim();
      if (sectionType === "sitter" && (qrFile || accountNameChanged)) {
        try {
          const formData = new FormData();
          formData.append("accountName", profile.accountName.trim());
          if (qrFile) formData.append("qrCode", qrFile);
          const payRes = hasPaymentInfo ? await api.patch("/sitter/payment-info", formData) : await api.post("/sitter/payment-info", formData);
          const pay = payRes.data?.data;
          savedProfile = {
            ...profile,
            accountName: pay?.accountName ?? profile.accountName.trim(),
            qrCodeUrl: pay?.qrCodeUrl || profile.qrCodeUrl
          };
          setProfile(savedProfile);
          setQrFile(null);
          setHasPaymentInfo(true);
        } catch (payError) {
          console.error("Payment info save error:", payError);
          toast(payError.response?.data?.message || "บันทึกข้อมูลรับเงินไม่สำเร็จ กรุณาลองใหม่อีกครั้ง", "error");
          return;
        }
      }
      const updatedUser = { ...user, ...savedProfile, pets };
      if (setUser) setUser(updatedUser);
      setOriginalProfile({ ...savedProfile });
      setErrors({});
      if (sectionType === "account") setIsEditingAccount(false);
      if (sectionType === "address") setIsEditingAddress(false);
      if (sectionType === "sitter") setIsEditingSitter(false);
      toast("บันทึกข้อมูลสำเร็จ");
    } catch (error) {
      console.error("Save error:", error);
      toast("ไม่สามารถบันทึกข้อมูลได้ กรุณาลองใหม่อีกครั้ง", "error");
    } finally {
      setSavingSection(null);
    }
  };
  const handleCancelSection = (sectionType) => {
    setProfile({ ...originalProfile });
    setErrors({});
    if (sectionType === "sitter") setQrFile(null);
    if (sectionType === "account") setIsEditingAccount(false);
    if (sectionType === "address") setIsEditingAddress(false);
    if (sectionType === "sitter") setIsEditingSitter(false);
  };
  const openAddPetModal = () => {
    setCurrentPetIndex(null);
    setModalMode("add");
    setActivePetForm({
      petId: null,
      name: "",
      species: "สุนัข",
      // Default to สุนัข
      breed: "",
      age: "",
      photo: "",
      notes: "",
      gender: "",
      weight: "",
      photoFile: null
    });
    setPetError("");
    setShowPetModal(true);
  };
  const openViewPetModal = (index) => {
    setCurrentPetIndex(index);
    setModalMode("view");
    setActivePetForm({ ...pets[index] });
    setPetError("");
    setShowPetModal(true);
  };
  const openEditPetModal = (index) => {
    setCurrentPetIndex(index);
    setModalMode("edit");
    setActivePetForm({ ...pets[index] });
    setPetError("");
    setShowPetModal(true);
  };
  const handleSavePet = async () => {
    if (!activePetForm.name.trim()) {
      setPetError("กรุณากรอกชื่อสัตว์เลี้ยง");
      return;
    }
    setIsSavingPet(true);
    try {
      const formData = new FormData();
      formData.append("name", activePetForm.name.trim());
      if (activePetForm.species) formData.append("species", activePetForm.species.trim());
      if (activePetForm.breed) formData.append("breed", activePetForm.breed.trim());
      if (activePetForm.gender) formData.append("gender", activePetForm.gender.trim());
      if (activePetForm.weight) formData.append("weight", activePetForm.weight);
      if (activePetForm.age) formData.append("age", activePetForm.age);
      if (activePetForm.notes) formData.append("notes", activePetForm.notes.trim());
      if (activePetForm.photoFile) {
        formData.append("photo", activePetForm.photoFile);
      }
      let savedPet;
      if (modalMode === "add") {
        const res = await api.post("/pets", formData);
        savedPet = res.data;
      } else if (modalMode === "edit" && activePetForm.petId) {
        const res = await api.patch(`/pets/${activePetForm.petId}`, formData);
        savedPet = res.data;
      }
      const profileRes = await api.get("/users/me");
      const latestPets = profileRes.data?.data?.pets || [];
      const mappedPets = latestPets.map((p) => ({
        petId: p.petId || p.petid || p.id || null,
        name: p.name || "",
        species: p.species || "",
        breed: p.breed || "",
        gender: p.gender || "",
        weight: p.weight || "",
        age: p.age !== null && p.age !== void 0 ? p.age : "",
        photo: p.imageUrl || p.photo || "",
        notes: p.allergy || p.notes || ""
      }));
      setPets(mappedPets);
      if (setUser) {
        setUser((prev) => ({ ...prev, pets: mappedPets }));
      }
      setShowPetModal(false);
      toast("บันทึกข้อมูลสัตว์เลี้ยงสำเร็จ");
    } catch (error) {
      console.error("Save pet error:", error);
      if (error.response?.status === 409) {
        setPetError("คุณมีสัตว์เลี้ยงชื่อนี้อยู่แล้ว กรุณาใช้ชื่ออื่น");
      } else {
        setPetError(`บันทึกไม่สำเร็จ: ${error.response?.status || "API อาจจะยังไม่พร้อม"}`);
      }
    } finally {
      setIsSavingPet(false);
    }
  };
  const handleRemoveCurrentModalPet = async () => {
    if (currentPetIndex !== null) {
      if (!window.confirm("คุณต้องการลบสัตว์เลี้ยงนี้ใช่หรือไม่?")) return;
      const targetPet = pets[currentPetIndex];
      setIsDeletingPet(true);
      try {
        if (targetPet.petId) {
          await api.delete(`/pets/${targetPet.petId}`);
        }
        const updatedPets = pets.filter((_, index) => index !== currentPetIndex);
        setPets(updatedPets);
        if (setUser) {
          setUser((prev) => ({ ...prev, pets: updatedPets }));
        }
        setShowPetModal(false);
        toast("ลบสัตว์เลี้ยงสำเร็จ");
      } catch (error) {
        console.error("Delete pet error:", error);
        toast("ไม่สามารถลบสัตว์เลี้ยงได้", "error");
      } finally {
        setIsDeletingPet(false);
      }
    }
  };
  const handleDelete = async () => {
    setDeleteError("");
    if (!deletePassword.trim()) {
      setDeleteError("กรุณากรอกรหัสผ่าน");
      return;
    }
    setDeleteStatus("submitting");
    try {
      await api.delete("/auth/account", { data: { password: deletePassword } });
      setShowDeleteModal(false);
      logout();
      navigate("/register");
    } catch (err) {
      setDeleteError(err.response?.status === 401 ? "รหัสผ่านไม่ถูกต้อง" : "ไม่สามารถลบบัญชีได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setDeleteStatus("idle");
    }
  };
  const renderSectionHeader = (title, isEditing, onEdit, onCancel, onSave, isSaving = false) => /* @__PURE__ */ jsxDEV("div", { className: "profile-section-header", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: title }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
      lineNumber: 517,
      columnNumber: 7
    }, this),
    !isEditing ? /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-save-button", onClick: onEdit, children: "แก้ไข" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
      lineNumber: 519,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "8px" }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "profile-cancel-button",
          onClick: onCancel,
          disabled: isSaving,
          children: "ยกเลิก"
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 524,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "profile-save-button",
          onClick: onSave,
          disabled: isSaving,
          style: { display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "6px", minWidth: "90px" },
          children: [
            isSaving && /* @__PURE__ */ jsxDEV("span", { className: "spinner", "aria-hidden": "true" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 539,
              columnNumber: 26
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: isSaving ? "กำลังบันทึก…" : "บันทึก" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 540,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 532,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
      lineNumber: 523,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
    lineNumber: 516,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
      lineNumber: 549,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "profile-main", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "profile-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar", children: (profile.username || "U").charAt(0).toUpperCase() }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 552,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: "โปรไฟล์ของฉัน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 555,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "profile-role", children: isSitter ? "🐾 พี่เลี้ยงสัตว์" : "🐶 เจ้าของสัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 556,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "profile-section", children: [
          renderSectionHeader(
            "ข้อมูลบัญชี",
            isEditingAccount,
            () => {
              setOriginalProfile({ ...profile });
              setIsEditingAccount(true);
            },
            () => handleCancelSection("account"),
            () => handleSaveSection("account"),
            savingSection === "account"
          ),
          /* @__PURE__ */ jsxDEV(ProfileField, { label: "ชื่อผู้ใช้", field: "username", value: profile.username, isEditing: isEditingAccount, error: errors.username, onChange: handleChange }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 569,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(ProfileField, { label: "อีเมล", field: "email", type: "email", value: profile.email, isEditing: isEditingAccount, error: errors.email, onChange: handleChange }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 570,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(ProfileField, { label: "เบอร์โทร", field: "tel", type: "tel", value: profile.tel, isEditing: isEditingAccount, error: errors.tel, onChange: handleChange }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 571,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 560,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "profile-section", children: [
          renderSectionHeader(
            "ข้อมูลที่อยู่",
            isEditingAddress,
            () => {
              setOriginalProfile({ ...profile });
              setIsEditingAddress(true);
            },
            () => handleCancelSection("address"),
            () => handleSaveSection("address"),
            savingSection === "address"
          ),
          !isEditingAddress ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(ProfileField, { label: "รายละเอียดที่อยู่", field: "address", value: profile.address, isEditing: false }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 585,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(ProfileField, { label: "จังหวัด", field: "province", value: profile.province, isEditing: false }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 586,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(ProfileField, { label: "เมือง/อำเภอ", field: "district", value: profile.district, isEditing: false }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 587,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(ProfileField, { label: "ตำบล/แขวง", field: "subdistrict", value: profile.subdistrict, isEditing: false }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 588,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(ProfileField, { label: "รหัสไปรษณีย์", field: "postalCode", value: profile.postalCode, isEditing: false }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 589,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 584,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "profile-edit-address-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "profile-row", style: { gridColumn: "1 / -1" }, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "รายละเอียดที่อยู่ (บ้านเลขที่, หมู่, ซอย, ถนน)" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 594,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "profile-input",
                  value: profile.address,
                  onChange: (e) => handleChange("address", e.target.value),
                  placeholder: "เช่น 123/45 ซ.สุขุมวิท 1 ถ.สุขุมวิท",
                  style: { width: "100%" }
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 595,
                  columnNumber: 19
                },
                this
              ),
              errors.address && /* @__PURE__ */ jsxDEV("span", { className: "profile-error", children: errors.address }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 603,
                columnNumber: 38
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 593,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "จังหวัด" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 606,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  className: "profile-input",
                  list: "province-list",
                  value: profile.province,
                  onChange: handleProvinceChange,
                  placeholder: "พิมพ์หรือเลือกจังหวัด..."
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 607,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("datalist", { id: "province-list", children: provincesData.map(
                (prov) => /* @__PURE__ */ jsxDEV("option", { value: prov.name_th }, prov.id, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 616,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 614,
                columnNumber: 19
              }, this),
              errors.province && /* @__PURE__ */ jsxDEV("span", { className: "profile-error", children: errors.province }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 619,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 605,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "เมือง/อำเภอ" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 623,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  className: "profile-input",
                  list: "district-list",
                  value: profile.district,
                  onChange: handleDistrictChange,
                  disabled: !profile.province,
                  placeholder: "พิมพ์หรือเลือกอำเภอ..."
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 624,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("datalist", { id: "district-list", children: (availableDistricts || []).map(
                (dist) => /* @__PURE__ */ jsxDEV("option", { value: dist.name_th }, dist.id, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 634,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 632,
                columnNumber: 19
              }, this),
              errors.district && /* @__PURE__ */ jsxDEV("span", { className: "profile-error", children: errors.district }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 637,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 622,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "ตำบล/แขวง" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 641,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  className: "profile-input",
                  list: "sub-list",
                  value: profile.subdistrict,
                  onChange: handleSubdistrictChange,
                  disabled: !profile.district,
                  placeholder: "พิมพ์หรือเลือกตำบล..."
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 642,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("datalist", { id: "sub-list", children: (availableSubdistricts || []).map(
                (sub) => /* @__PURE__ */ jsxDEV("option", { value: sub.name_th }, sub.id, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 652,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 650,
                columnNumber: 19
              }, this),
              errors.subdistrict && /* @__PURE__ */ jsxDEV("span", { className: "profile-error", children: errors.subdistrict }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 655,
                columnNumber: 42
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 640,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "รหัสไปรษณีย์" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 659,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  className: "profile-input",
                  list: "zip-list",
                  value: profile.postalCode,
                  onChange: (e) => handleChange("postalCode", e.target.value),
                  disabled: !profile.subdistrict,
                  placeholder: "รหัสไปรษณีย์"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 660,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("datalist", { id: "zip-list", children: (availableZipcodes || []).map(
                (zip, idx) => /* @__PURE__ */ jsxDEV("option", { value: zip }, idx, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 670,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 668,
                columnNumber: 19
              }, this),
              errors.postalCode && /* @__PURE__ */ jsxDEV("span", { className: "profile-error", children: errors.postalCode }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 673,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 658,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 592,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 574,
          columnNumber: 11
        }, this),
        isSitter && /* @__PURE__ */ jsxDEV("section", { className: "profile-section", children: [
          renderSectionHeader(
            "ข้อมูลพี่เลี้ยงสัตว์",
            isEditingSitter,
            () => {
              setOriginalProfile({ ...profile });
              setIsEditingSitter(true);
            },
            () => handleCancelSection("sitter"),
            () => handleSaveSection("sitter"),
            savingSection === "sitter"
          ),
          /* @__PURE__ */ jsxDEV(ProfileField, { label: "ประสบการณ์", field: "experience", value: profile.experience, isEditing: isEditingSitter, error: errors.experience, onChange: handleChange }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 689,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "profile-label", children: "เลขบัตรประชาชน" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 691,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "profile-value", children: profile.thaiId ? `*********${profile.thaiId.slice(-4)}` : "-" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 692,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 690,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(ProfileField, { label: "ชื่อบัญชีรับเงิน", field: "accountName", value: profile.accountName, isEditing: isEditingSitter, error: errors.accountName, onChange: handleChange }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 694,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            SitterQrUpload,
            {
              qrCodeUrl: profile.qrCodeUrl,
              isEditing: isEditingSitter,
              file: qrFile,
              error: errors.qrCode,
              onSelectFile: (f) => {
                setQrFile(f);
                setErrors((prev) => ({ ...prev, qrCode: "" }));
              },
              onRemove: () => setQrFile(null)
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 695,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 680,
          columnNumber: 11
        }, this),
        !isSitter && /* @__PURE__ */ jsxDEV("section", { className: "profile-section", style: { borderTop: "2px solid #eee", paddingTop: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "profile-section-header", children: [
            /* @__PURE__ */ jsxDEV("h2", { children: "ข้อมูลสัตว์เลี้ยง" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 709,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-save-button", onClick: openAddPetModal, children: "+ เพิ่มสัตว์เลี้ยง" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 710,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 708,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: pets && pets.length > 0 ? pets.map(
            (pet, index) => /* @__PURE__ */ jsxDEV("div", { style: { background: "#f9f9f9", padding: "10px 14px", borderRadius: "8px", marginBottom: "8px", border: "1px solid #eaeaea", display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "12px" }, children: [
                pet.photo ? /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: pet.photo,
                    alt: pet.name,
                    onError: (e) => {
                      e.target.src = "data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' style='background:%23eee;'%3E%3Ctext x='50%25' y='50%25' font-size='40' text-anchor='middle' dy='.35em'%3E%26%23128062%3B%3C/text%3E%3C/svg%3E";
                    },
                    style: { width: "40px", height: "40px", borderRadius: "50%", objectFit: "cover", border: "1px solid #ccc" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                    lineNumber: 720,
                    columnNumber: 19
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV("div", { style: { width: "40px", height: "40px", borderRadius: "50%", background: "#eee", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "20px" }, children: "🐾" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 727,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "15px", fontWeight: "600" }, children: pet.name }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 731,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 718,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-edit-button pet-btn-sm", onClick: () => openViewPetModal(index), title: "ดูข้อมูล", children: "🔍" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 734,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-edit-button pet-btn-sm pet-btn-warning", onClick: () => openEditPetModal(index), title: "แก้ไขข้อมูล", children: "🖋️" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                  lineNumber: 735,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
                lineNumber: 733,
                columnNumber: 23
              }, this)
            ] }, index, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
              lineNumber: 717,
              columnNumber: 15
            }, this)
          ) : /* @__PURE__ */ jsxDEV("div", { className: "profile-row", children: /* @__PURE__ */ jsxDEV("span", { className: "profile-value", style: { width: "100%", textAlign: "center", color: "#888" }, children: "- ยังไม่มีข้อมูลสัตว์เลี้ยง -" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 741,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 740,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 714,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 707,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "profile-actions", style: { marginTop: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "profile-actions-row", children: /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-delete-button", onClick: () => {
            setDeletePassword("");
            setDeleteError("");
            setDeleteStatus("idle");
            setShowDeleteModal(true);
          }, children: "ลบบัญชี" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 750,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 749,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "profile-confirm-button", onClick: () => navigate("/"), children: "ยืนยันหน้าหลัก" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
            lineNumber: 754,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 748,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
        lineNumber: 551,
        columnNumber: 9
      }, this),
      showPetModal && /* @__PURE__ */ jsxDEV(
        PetModal,
        {
          pet: activePetForm,
          mode: modalMode,
          error: petError,
          isSaving: isSavingPet,
          isDeleting: isDeletingPet,
          onChange: (field, value) => {
            setActivePetForm((prev) => ({ ...prev, [field]: value }));
            if (field === "name") setPetError("");
          },
          onClose: () => {
            if (!isSavingPet && !isDeletingPet) {
              setShowPetModal(false);
              setPetError("");
            }
          },
          onSave: handleSavePet,
          onDelete: handleRemoveCurrentModalPet,
          onSwitchToEdit: () => setModalMode("edit")
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 761,
          columnNumber: 9
        },
        this
      ),
      showDeleteModal && /* @__PURE__ */ jsxDEV(
        DeleteAccountModal,
        {
          password: deletePassword,
          error: deleteError,
          status: deleteStatus,
          onPasswordChange: setDeletePassword,
          onCancel: () => {
            if (deleteStatus !== "submitting") setShowDeleteModal(false);
          },
          onConfirm: handleDelete
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
          lineNumber: 784,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
      lineNumber: 550,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx",
    lineNumber: 548,
    columnNumber: 5
  }, this);
}
_s(ProfilePage, "st7rGBrEq2Jk1bsjmwiumiwWHSo=", false, function() {
  return [useNavigate, useAuth];
});
_c = ProfilePage;
export default ProfilePage;
var _c;
$RefreshReg$(_c, "ProfilePage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ProfilePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaWZNLFNBbUVRLFVBbkVSOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpmTixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxXQUFXO0FBQ3BCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxtQkFBbUI7QUFDMUIsT0FBT0Msc0JBQXNCO0FBRTdCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGFBQWE7QUFFdEIsU0FBU0MsY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU1DLFdBQVdiLFlBQVk7QUFDN0IsUUFBTSxFQUFFYyxNQUFNQyxRQUFRQyxRQUFRLElBQUlsQixRQUFRO0FBQzFDLFFBQU1tQixXQUFXSCxNQUFNSSxTQUFTO0FBRWhDLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJeEIsU0FBUztBQUFBLElBQ3JDeUIsVUFBVVAsTUFBTU8sWUFBWTtBQUFBLElBQzVCQyxPQUFPUixNQUFNUSxTQUFTO0FBQUEsSUFDdEJDLEtBQUtULE1BQU1TLE9BQU87QUFBQSxJQUNsQkMsU0FBU1YsTUFBTVUsV0FBVztBQUFBLElBQzFCQyxVQUFVWCxNQUFNVyxZQUFZO0FBQUEsSUFDNUJDLFVBQVVaLE1BQU1ZLFlBQVk7QUFBQSxJQUM1QkMsYUFBYWIsTUFBTWEsZUFBZTtBQUFBLElBQ2xDQyxZQUFZZCxNQUFNYyxjQUFjO0FBQUEsSUFDaENWLE1BQU1KLE1BQU1JLFFBQVE7QUFBQSxJQUNwQlcsWUFBWWYsTUFBTWUsY0FBYztBQUFBLElBQ2hDQyxRQUFRaEIsTUFBTWdCLFVBQVU7QUFBQSxJQUN4QkMsYUFBYWpCLE1BQU1pQixlQUFlO0FBQUEsSUFDbENDLFdBQVdsQixNQUFNa0IsYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFFRCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUl0QyxTQUFTdUIsT0FBTztBQUM5RCxRQUFNLENBQUNnQixRQUFRQyxTQUFTLElBQUl4QyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN5QyxlQUFlQyxnQkFBZ0IsSUFBSTFDLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUMyQyxhQUFhQyxjQUFjLElBQUk1QyxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDNkMsZUFBZUMsZ0JBQWdCLElBQUk5QyxTQUFTLEtBQUs7QUFHeERDLFlBQVUsTUFBTTtBQUNkLFVBQU04QyxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNM0MsSUFBSTRDLElBQUksV0FBVztBQUNyQyxjQUFNQyxPQUFPRixJQUFJRSxNQUFNQTtBQUV2QixZQUFJQSxNQUFNO0FBQ1IsZ0JBQU1DLGdCQUFnQjtBQUFBLFlBQ3BCMUIsVUFBVXlCLEtBQUt6QixZQUFZO0FBQUEsWUFDM0JDLE9BQU93QixLQUFLeEIsU0FBUztBQUFBLFlBQ3JCQyxLQUFLdUIsS0FBS3ZCLE9BQU87QUFBQSxZQUNqQkMsU0FBU3NCLEtBQUt0QixXQUFXO0FBQUEsWUFDekJDLFVBQVVxQixLQUFLckIsWUFBWTtBQUFBLFlBQzNCQyxVQUFVb0IsS0FBS3BCLFlBQVlvQixLQUFLRSxRQUFRO0FBQUEsWUFDeENyQixhQUFhbUIsS0FBS25CLGVBQWU7QUFBQSxZQUNqQ0MsWUFBWWtCLEtBQUtsQixjQUFjO0FBQUEsWUFDL0JWLE1BQU00QixLQUFLNUIsUUFBUTtBQUFBLFlBQ25CVyxZQUFZaUIsS0FBS2pCLGNBQWM7QUFBQSxZQUMvQkMsUUFBUWdCLEtBQUtoQixVQUFVO0FBQUEsWUFDdkJDLGFBQWE7QUFBQSxZQUNiQyxXQUFXO0FBQUEsVUFDYjtBQUdBLGNBQUllLGNBQWM3QixTQUFTLFVBQVU7QUFDbkMsZ0JBQUk7QUFDRixvQkFBTStCLFNBQVMsTUFBTWhELElBQUk0QyxJQUFJLHNCQUFzQjtBQUNuRCxvQkFBTUssTUFBTUQsT0FBT0gsTUFBTUE7QUFDekJDLDRCQUFjaEIsY0FBY21CLEtBQUtuQixlQUFlO0FBQ2hEZ0IsNEJBQWNmLFlBQVlrQixLQUFLbEIsYUFBYTtBQUM1Q21CLGdDQUFrQixDQUFDLENBQUNELEtBQUtFLGNBQWM7QUFBQSxZQUN6QyxTQUFTQyxRQUFRO0FBQ2ZDLHNCQUFRQyxNQUFNLDhCQUE4QkYsTUFBTTtBQUFBLFlBQ3BEO0FBQUEsVUFDRjtBQUVBakMscUJBQVcyQixhQUFhO0FBQ3hCYiw2QkFBbUJhLGFBQWE7QUFHaEMsZ0JBQU1TLGVBQWUsRUFBRSxHQUFHMUMsTUFBTSxHQUFHaUMsZUFBZVUsTUFBTVgsS0FBS1csUUFBUSxHQUFHO0FBQ3hFLGNBQUl6QyxRQUFTQSxTQUFRd0MsWUFBWTtBQUVqQyxnQkFBTUUsZUFBZTtBQUFBLFlBQ25CQyxJQUFJSCxhQUFhRztBQUFBQSxZQUNqQnRDLFVBQVVtQyxhQUFhbkM7QUFBQUEsWUFDdkJDLE9BQU9rQyxhQUFhbEM7QUFBQUEsWUFDcEJKLE1BQU1zQyxhQUFhdEM7QUFBQUEsVUFDckI7QUFDQTBDLHVCQUFhQyxRQUFRLFdBQVdDLEtBQUtDLFVBQVVMLFlBQVksQ0FBQztBQUU1RCxjQUFJWixLQUFLVyxRQUFRTyxNQUFNQyxRQUFRbkIsS0FBS1csSUFBSSxHQUFHO0FBQ3pDLGtCQUFNUyxhQUFhcEIsS0FBS1csS0FBS1UsSUFBSSxDQUFDQyxPQUFPO0FBQUEsY0FDdkNDLE9BQU9ELEVBQUVDLFNBQVNELEVBQUVFLFNBQVNGLEVBQUVULE1BQU07QUFBQSxjQUNyQ1ksTUFBTUgsRUFBRUcsUUFBUTtBQUFBLGNBQ2hCQyxTQUFTSixFQUFFSSxXQUFXO0FBQUEsY0FDdEJDLE9BQU9MLEVBQUVLLFNBQVM7QUFBQSxjQUNsQkMsUUFBUU4sRUFBRU0sVUFBVTtBQUFBLGNBQ3BCQyxRQUFRUCxFQUFFTyxVQUFVO0FBQUEsY0FDcEJDLEtBQUtSLEVBQUVRLFFBQVEsUUFBUVIsRUFBRVEsUUFBUUMsU0FBWVQsRUFBRVEsTUFBTTtBQUFBLGNBQ3JERSxPQUFPVixFQUFFVyxZQUFZO0FBQUEsY0FDckJDLE9BQU9aLEVBQUVhLFVBQVUsUUFBUWIsRUFBRWEsT0FBTyxLQUFLO0FBQUEsWUFDM0MsRUFBRTtBQUNGQyxvQkFBUWhCLFVBQVU7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVNpQixLQUFLO0FBQ1o3QixnQkFBUUMsTUFBTSw4QkFBOEI0QixHQUFHO0FBQUEsTUFDakQ7QUFBQSxJQUNGO0FBRUF4QyxxQkFBaUI7QUFBQSxFQUNuQixHQUFHLEVBQUU7QUFHTCxRQUFNLENBQUN5QyxvQkFBb0JDLHFCQUFxQixJQUFJekYsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQzBGLHVCQUF1QkMsd0JBQXdCLElBQUkzRixTQUFTLEVBQUU7QUFDckUsUUFBTSxDQUFDNEYsbUJBQW1CQyxvQkFBb0IsSUFBSTdGLFNBQVMsRUFBRTtBQUU3REMsWUFBVSxNQUFNO0FBQ2QsUUFBSXNCLFFBQVFNLFVBQVU7QUFDcEIsWUFBTWlFLE9BQU94RixjQUFjeUYsS0FBSyxDQUFBdkIsTUFBS0EsRUFBRXdCLFlBQVl6RSxRQUFRTSxRQUFRO0FBQ25FLFVBQUlpRSxNQUFNO0FBQ1IsY0FBTUcsb0JBQW9CMUYsY0FBYzJGLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsZ0JBQWdCTixLQUFLL0IsRUFBRTtBQUM3RTBCLDhCQUFzQlEsaUJBQWlCO0FBRXZDLFlBQUkxRSxRQUFRTyxVQUFVO0FBQ3BCLGdCQUFNdUUsT0FBT0osa0JBQWtCRixLQUFLLENBQUFJLE1BQUtBLEVBQUVILFlBQVl6RSxRQUFRTyxRQUFRO0FBQ3ZFLGNBQUl1RSxNQUFNO0FBQ1Isa0JBQU1DLHVCQUF1QjlGLGlCQUFpQjBGLE9BQU8sQ0FBQUssTUFBS0EsRUFBRUMsZ0JBQWdCSCxLQUFLdEMsRUFBRTtBQUNuRjRCLHFDQUF5Qlcsb0JBQW9CO0FBRTdDLGdCQUFJL0UsUUFBUVEsYUFBYTtBQUN2QixvQkFBTTBFLE1BQU1ILHFCQUFxQlAsS0FBSyxDQUFBUSxNQUFLQSxFQUFFUCxZQUFZekUsUUFBUVEsV0FBVztBQUM1RSxrQkFBSTBFLElBQUtaLHNCQUFxQlksSUFBSUMsV0FBVyxDQUFDRCxJQUFJQyxRQUFRLElBQUksRUFBRTtBQUFBLFlBQ2xFO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDbkYsUUFBUU0sVUFBVU4sUUFBUU8sVUFBVVAsUUFBUVEsV0FBVyxDQUFDO0FBRTVELFFBQU00RSx1QkFBdUJBLENBQUNDLE1BQU07QUFDbEMsVUFBTUMsbUJBQW1CRCxFQUFFRSxPQUFPQztBQUNsQ3ZGLGVBQVcsQ0FBQ3dGLFVBQVU7QUFBQSxNQUNwQixHQUFHQTtBQUFBQSxNQUNIbkYsVUFBVWdGO0FBQUFBLE1BQ1YvRSxVQUFVO0FBQUEsTUFDVkMsYUFBYTtBQUFBLE1BQ2JDLFlBQVk7QUFBQSxJQUNkLEVBQUU7QUFFRixVQUFNOEQsT0FBT3hGLGNBQWN5RixLQUFLLENBQUN2QixNQUFNQSxFQUFFd0IsWUFBWWEsZ0JBQWdCO0FBQ3JFcEIsMEJBQXNCSyxPQUFPdkYsY0FBYzJGLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsZ0JBQWdCTixLQUFLL0IsRUFBRSxJQUFJLEVBQUU7QUFDdEY0Qiw2QkFBeUIsRUFBRTtBQUMzQkUseUJBQXFCLEVBQUU7QUFBQSxFQUN6QjtBQUVBLFFBQU1vQix1QkFBdUJBLENBQUNMLE1BQU07QUFDbEMsVUFBTU0sbUJBQW1CTixFQUFFRSxPQUFPQztBQUNsQ3ZGLGVBQVcsQ0FBQ3dGLFVBQVU7QUFBQSxNQUNwQixHQUFHQTtBQUFBQSxNQUNIbEYsVUFBVW9GO0FBQUFBLE1BQ1ZuRixhQUFhO0FBQUEsTUFDYkMsWUFBWTtBQUFBLElBQ2QsRUFBRTtBQUVGLFVBQU1xRSxPQUFPYixtQkFBbUJPLEtBQUssQ0FBQ0ksTUFBTUEsRUFBRUgsWUFBWWtCLGdCQUFnQjtBQUMxRSxRQUFJYixNQUFNO0FBQ1IsWUFBTUMsdUJBQXVCOUYsaUJBQWlCMEYsT0FBTyxDQUFBSyxNQUFLQSxFQUFFQyxnQkFBZ0JILEtBQUt0QyxFQUFFO0FBQ25GNEIsK0JBQXlCVyxvQkFBb0I7QUFDN0NULDJCQUFxQixFQUFFO0FBQUEsSUFDekIsT0FBTztBQUNMRiwrQkFBeUIsRUFBRTtBQUMzQkUsMkJBQXFCLEVBQUU7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0IsMEJBQTBCQSxDQUFDUCxNQUFNO0FBQ3JDLFVBQU1RLGNBQWNSLEVBQUVFLE9BQU9DO0FBQzdCLFVBQU1OLE1BQU1mLHNCQUFzQkssS0FBSyxDQUFDUSxNQUFNQSxFQUFFUCxZQUFZb0IsV0FBVztBQUV2RTVGLGVBQVcsQ0FBQ3dGLFVBQVU7QUFBQSxNQUNwQixHQUFHQTtBQUFBQSxNQUNIakYsYUFBYXFGO0FBQUFBLE1BQ2JwRixZQUFZeUUsT0FBT0EsSUFBSUMsV0FBV0QsSUFBSUMsU0FBU1csU0FBUyxJQUFJO0FBQUEsSUFDOUQsRUFBRTtBQUVGLFFBQUlaLE9BQU9BLElBQUlDLFVBQVU7QUFDdkJiLDJCQUFxQixDQUFDWSxJQUFJQyxRQUFRLENBQUM7QUFBQSxJQUNyQyxPQUFPO0FBQ0xiLDJCQUFxQixFQUFFO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTSxDQUFDeUIsa0JBQWtCQyxtQkFBbUIsSUFBSXZILFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUN3SCxrQkFBa0JDLG1CQUFtQixJQUFJekgsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQzBILGlCQUFpQkMsa0JBQWtCLElBQUkzSCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNEgsUUFBUUMsU0FBUyxJQUFJN0gsU0FBUyxJQUFJO0FBQ3pDLFFBQU0sQ0FBQ3dELGdCQUFnQkQsaUJBQWlCLElBQUl2RCxTQUFTLEtBQUs7QUFFMUQsUUFBTSxDQUFDNkQsTUFBTXlCLE9BQU8sSUFBSXRGLFNBQVNrQixNQUFNMkMsUUFBUSxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2lFLGNBQWNDLGVBQWUsSUFBSS9ILFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNnSSxXQUFXQyxZQUFZLElBQUlqSSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDa0ksaUJBQWlCQyxrQkFBa0IsSUFBSW5JLFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNvSSxlQUFlQyxnQkFBZ0IsSUFBSXJJLFNBQVM7QUFBQSxJQUNqRHlFLE9BQU87QUFBQSxJQUFNRSxNQUFNO0FBQUEsSUFBSUMsU0FBUztBQUFBLElBQUlDLE9BQU87QUFBQSxJQUFJRyxLQUFLO0FBQUEsSUFBSUUsT0FBTztBQUFBLElBQUlFLE9BQU87QUFBQSxJQUMxRU4sUUFBUTtBQUFBLElBQUlDLFFBQVE7QUFBQSxJQUFJdUQsV0FBVztBQUFBLEVBQ3JDLENBQUM7QUFDRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXhJLFNBQVMsRUFBRTtBQUUzQyxRQUFNLENBQUN5SSxpQkFBaUJDLGtCQUFrQixJQUFJMUksU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzJJLGdCQUFnQkMsaUJBQWlCLElBQUk1SSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDNkksYUFBYUMsY0FBYyxJQUFJOUksU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQytJLGNBQWNDLGVBQWUsSUFBSWhKLFNBQVMsTUFBTTtBQUV2RCxRQUFNaUosZUFBZUEsQ0FBQ0MsT0FBT25DLFVBQVU7QUFDckN2RixlQUFXLENBQUN3RixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDa0MsS0FBSyxHQUFHbkMsTUFBTSxFQUFFO0FBQ2xEdkUsY0FBVSxDQUFDd0UsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2tDLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUNoRDtBQUVBLFFBQU1DLG9CQUFvQixPQUFPQyxnQkFBZ0I7QUFDL0MsVUFBTUMsWUFBWXhJLGdCQUFnQlUsT0FBTztBQUN6QyxRQUFJK0gsZ0JBQWdCLENBQUM7QUFFckIsUUFBSUYsZ0JBQWdCLFdBQVc7QUFDN0IsVUFBSUMsVUFBVTVILFNBQVU2SCxlQUFjN0gsV0FBVzRILFVBQVU1SDtBQUMzRCxVQUFJNEgsVUFBVTNILE1BQU80SCxlQUFjNUgsUUFBUTJILFVBQVUzSDtBQUNyRCxVQUFJMkgsVUFBVTFILElBQUsySCxlQUFjM0gsTUFBTTBILFVBQVUxSDtBQUFBQSxJQUNuRCxXQUFXeUgsZ0JBQWdCLFdBQVc7QUFDcEMsVUFBSUMsVUFBVXpILFFBQVMwSCxlQUFjMUgsVUFBVXlILFVBQVV6SDtBQUN6RCxVQUFJeUgsVUFBVXhILFNBQVV5SCxlQUFjekgsV0FBV3dILFVBQVV4SDtBQUMzRCxVQUFJd0gsVUFBVXZILFNBQVV3SCxlQUFjeEgsV0FBV3VILFVBQVV2SDtBQUMzRCxVQUFJdUgsVUFBVXRILFlBQWF1SCxlQUFjdkgsY0FBY3NILFVBQVV0SDtBQUNqRSxVQUFJc0gsVUFBVXJILFdBQVlzSCxlQUFjdEgsYUFBYXFILFVBQVVySDtBQUFBQSxJQUNqRSxXQUFXb0gsZ0JBQWdCLFVBQVU7QUFDbkMsVUFBSUMsVUFBVXBILGNBQWNWLFFBQVFVLFdBQVdzSCxLQUFLLE1BQU0sSUFBSTtBQUM1REQsc0JBQWNySCxhQUFhb0gsVUFBVXBIO0FBQUFBLE1BQ3ZDO0FBRUEsWUFBTUUsZUFBZVosUUFBUVksZUFBZSxJQUFJb0gsS0FBSztBQUNyRCxVQUFJcEgsWUFBWXFILFNBQVMsS0FBSztBQUM1QkYsc0JBQWNuSCxjQUFjO0FBQUEsTUFDOUI7QUFDQSxVQUFJLENBQUNxQixnQkFBZ0I7QUFFbkIsWUFBSW9FLFVBQVV6RixhQUFhO0FBQ3pCLGNBQUksQ0FBQ0EsWUFBYW1ILGVBQWNuSCxjQUFjO0FBQzlDLGNBQUksQ0FBQ3lGLE9BQVEwQixlQUFjRyxTQUFTO0FBQUEsUUFDdEM7QUFBQSxNQUNGLFdBQVcsQ0FBQ3RILGFBQWE7QUFFdkJtSCxzQkFBY25ILGNBQWM7QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFFQUssY0FBVThHLGFBQWE7QUFFdkIsUUFBSUksT0FBT0MsS0FBS0wsYUFBYSxFQUFFRSxTQUFTLEVBQUc7QUFDM0M5RyxxQkFBaUIwRyxXQUFXO0FBQzVCLFFBQUk7QUFDRixZQUFNUSxVQUFVO0FBQUEsUUFDZG5JLFVBQVVGLFFBQVFFO0FBQUFBLFFBQ2xCQyxPQUFPSCxRQUFRRztBQUFBQSxRQUNmQyxLQUFLSixRQUFRSTtBQUFBQSxRQUNiRSxVQUFVTixRQUFRTTtBQUFBQSxRQUNsQkMsVUFBVVAsUUFBUU87QUFBQUEsUUFDbEJDLGFBQWFSLFFBQVFRO0FBQUFBLFFBQ3JCQyxZQUFZVCxRQUFRUztBQUFBQSxRQUNwQkosU0FBU0wsUUFBUUs7QUFBQUEsUUFDakJOLE1BQU1DLFFBQVFEO0FBQUFBLE1BQ2hCO0FBRUEsVUFBSUMsUUFBUUQsU0FBUyxVQUFVO0FBQzdCc0ksZ0JBQVEzSCxhQUFhVixRQUFRVTtBQUFBQSxNQUMvQjtBQUVBLFlBQU01QixJQUFJd0osSUFBSSxhQUFhRCxPQUFPO0FBSWxDdEgseUJBQW1CLENBQUMwRSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxHQUFHNEMsUUFBUSxFQUFFO0FBQ3RELFVBQUl4SSxRQUFTQSxTQUFRLEVBQUUsR0FBR0YsTUFBTSxHQUFHMEksU0FBUy9GLEtBQUssQ0FBQztBQUdsRCxVQUFJaUcsZUFBZXZJO0FBQ25CLFlBQU13SSxzQkFDSHhJLFFBQVFZLGVBQWUsSUFBSW9ILEtBQUssT0FBT2xILGdCQUFnQkYsZUFBZSxJQUFJb0gsS0FBSztBQUNsRixVQUFJSCxnQkFBZ0IsYUFBYXhCLFVBQVVtQyxxQkFBcUI7QUFDOUQsWUFBSTtBQUNGLGdCQUFNQyxXQUFXLElBQUlDLFNBQVM7QUFDOUJELG1CQUFTRSxPQUFPLGVBQWUzSSxRQUFRWSxZQUFZb0gsS0FBSyxDQUFDO0FBQ3pELGNBQUkzQixPQUFRb0MsVUFBU0UsT0FBTyxVQUFVdEMsTUFBTTtBQUU1QyxnQkFBTXZFLFNBQVNHLGlCQUNYLE1BQU1uRCxJQUFJOEosTUFBTSx3QkFBd0JILFFBQVEsSUFDaEQsTUFBTTNKLElBQUkrSixLQUFLLHdCQUF3QkosUUFBUTtBQUNuRCxnQkFBTTFHLE1BQU1ELE9BQU9ILE1BQU1BO0FBRXpCNEcseUJBQWU7QUFBQSxZQUNiLEdBQUd2STtBQUFBQSxZQUNIWSxhQUFhbUIsS0FBS25CLGVBQWVaLFFBQVFZLFlBQVlvSCxLQUFLO0FBQUEsWUFDMURuSCxXQUFXa0IsS0FBS2xCLGFBQWFiLFFBQVFhO0FBQUFBLFVBQ3ZDO0FBQ0FaLHFCQUFXc0ksWUFBWTtBQUN2QmpDLG9CQUFVLElBQUk7QUFDZHRFLDRCQUFrQixJQUFJO0FBQUEsUUFDeEIsU0FBUzhHLFVBQVU7QUFDakIzRyxrQkFBUUMsTUFBTSw0QkFBNEIwRyxRQUFRO0FBQ2xEdkosZ0JBQU11SixTQUFTQyxVQUFVcEgsTUFBTXFILFdBQVcscURBQXFELE9BQU87QUFDdEc7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFlBQU1DLGNBQWMsRUFBRSxHQUFHdEosTUFBTSxHQUFHNEksY0FBY2pHLEtBQUs7QUFDckQsVUFBSXpDLFFBQVNBLFNBQVFvSixXQUFXO0FBQ2hDbEkseUJBQW1CLEVBQUUsR0FBR3dILGFBQWEsQ0FBQztBQUN0Q3RILGdCQUFVLENBQUMsQ0FBQztBQUVaLFVBQUk0RyxnQkFBZ0IsVUFBVzdCLHFCQUFvQixLQUFLO0FBQ3hELFVBQUk2QixnQkFBZ0IsVUFBVzNCLHFCQUFvQixLQUFLO0FBQ3hELFVBQUkyQixnQkFBZ0IsU0FBVXpCLG9CQUFtQixLQUFLO0FBRXREN0csWUFBTSxvQkFBb0I7QUFBQSxJQUU1QixTQUFTNkMsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGVBQWVBLEtBQUs7QUFDbEM3QyxZQUFNLGlEQUFpRCxPQUFPO0FBQUEsSUFDaEUsVUFBQztBQUNDNEIsdUJBQWlCLElBQUk7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0gsc0JBQXNCQSxDQUFDckIsZ0JBQWdCO0FBQzNDNUgsZUFBVyxFQUFFLEdBQUdhLGdCQUFnQixDQUFDO0FBQ2pDRyxjQUFVLENBQUMsQ0FBQztBQUNaLFFBQUk0RyxnQkFBZ0IsU0FBVXZCLFdBQVUsSUFBSTtBQUM1QyxRQUFJdUIsZ0JBQWdCLFVBQVc3QixxQkFBb0IsS0FBSztBQUN4RCxRQUFJNkIsZ0JBQWdCLFVBQVczQixxQkFBb0IsS0FBSztBQUN4RCxRQUFJMkIsZ0JBQWdCLFNBQVV6QixvQkFBbUIsS0FBSztBQUFBLEVBQ3hEO0FBRUEsUUFBTStDLGtCQUFrQkEsTUFBTTtBQUM1QnZDLHVCQUFtQixJQUFJO0FBQ3ZCRixpQkFBYSxLQUFLO0FBQ2xCSSxxQkFBaUI7QUFBQSxNQUNmNUQsT0FBTztBQUFBLE1BQ1BFLE1BQU07QUFBQSxNQUNOQyxTQUFTO0FBQUE7QUFBQSxNQUNUQyxPQUFPO0FBQUEsTUFDUEcsS0FBSztBQUFBLE1BQ0xFLE9BQU87QUFBQSxNQUNQRSxPQUFPO0FBQUEsTUFDUE4sUUFBUTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSdUQsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNERSxnQkFBWSxFQUFFO0FBQ2RULG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNNEMsbUJBQW1CQSxDQUFDQyxVQUFVO0FBQ2xDekMsdUJBQW1CeUMsS0FBSztBQUN4QjNDLGlCQUFhLE1BQU07QUFDbkJJLHFCQUFpQixFQUFFLEdBQUd4RSxLQUFLK0csS0FBSyxFQUFFLENBQUM7QUFDbkNwQyxnQkFBWSxFQUFFO0FBQ2RULG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNOEMsbUJBQW1CQSxDQUFDRCxVQUFVO0FBQ2xDekMsdUJBQW1CeUMsS0FBSztBQUN4QjNDLGlCQUFhLE1BQU07QUFDbkJJLHFCQUFpQixFQUFFLEdBQUd4RSxLQUFLK0csS0FBSyxFQUFFLENBQUM7QUFDbkNwQyxnQkFBWSxFQUFFO0FBQ2RULG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNK0MsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSSxDQUFDMUMsY0FBY3pELEtBQUs0RSxLQUFLLEdBQUc7QUFDOUJmLGtCQUFZLDBCQUEwQjtBQUN0QztBQUFBLElBQ0Y7QUFFQTVGLG1CQUFlLElBQUk7QUFDbkIsUUFBSTtBQUNGLFlBQU1vSCxXQUFXLElBQUlDLFNBQVM7QUFDOUJELGVBQVNFLE9BQU8sUUFBUTlCLGNBQWN6RCxLQUFLNEUsS0FBSyxDQUFDO0FBQ2pELFVBQUluQixjQUFjeEQsUUFBU29GLFVBQVNFLE9BQU8sV0FBVzlCLGNBQWN4RCxRQUFRMkUsS0FBSyxDQUFDO0FBQ2xGLFVBQUluQixjQUFjdkQsTUFBT21GLFVBQVNFLE9BQU8sU0FBUzlCLGNBQWN2RCxNQUFNMEUsS0FBSyxDQUFDO0FBQzVFLFVBQUluQixjQUFjdEQsT0FBUWtGLFVBQVNFLE9BQU8sVUFBVTlCLGNBQWN0RCxPQUFPeUUsS0FBSyxDQUFDO0FBQy9FLFVBQUluQixjQUFjckQsT0FBUWlGLFVBQVNFLE9BQU8sVUFBVTlCLGNBQWNyRCxNQUFNO0FBQ3hFLFVBQUlxRCxjQUFjcEQsSUFBS2dGLFVBQVNFLE9BQU8sT0FBTzlCLGNBQWNwRCxHQUFHO0FBQy9ELFVBQUlvRCxjQUFjaEQsTUFBTzRFLFVBQVNFLE9BQU8sU0FBUzlCLGNBQWNoRCxNQUFNbUUsS0FBSyxDQUFDO0FBRTVFLFVBQUluQixjQUFjRSxXQUFXO0FBQzNCMEIsaUJBQVNFLE9BQU8sU0FBUzlCLGNBQWNFLFNBQVM7QUFBQSxNQUNsRDtBQUVBLFVBQUl5QztBQUVKLFVBQUkvQyxjQUFjLE9BQU87QUFDdkIsY0FBTWhGLE1BQU0sTUFBTTNDLElBQUkrSixLQUFLLFNBQVNKLFFBQVE7QUFDNUNlLG1CQUFXL0gsSUFBSUU7QUFBQUEsTUFDakIsV0FBVzhFLGNBQWMsVUFBVUksY0FBYzNELE9BQU87QUFDdEQsY0FBTXpCLE1BQU0sTUFBTTNDLElBQUk4SixNQUFNLFNBQVMvQixjQUFjM0QsS0FBSyxJQUFJdUYsUUFBUTtBQUNwRWUsbUJBQVcvSCxJQUFJRTtBQUFBQSxNQUNqQjtBQUVBLFlBQU04SCxhQUFhLE1BQU0zSyxJQUFJNEMsSUFBSSxXQUFXO0FBQzVDLFlBQU1nSSxhQUFhRCxXQUFXOUgsTUFBTUEsTUFBTVcsUUFBUTtBQUVsRCxZQUFNUyxhQUFhMkcsV0FBVzFHLElBQUksQ0FBQ0MsT0FBTztBQUFBLFFBQ3hDQyxPQUFPRCxFQUFFQyxTQUFTRCxFQUFFRSxTQUFTRixFQUFFVCxNQUFNO0FBQUEsUUFDckNZLE1BQU1ILEVBQUVHLFFBQVE7QUFBQSxRQUNoQkMsU0FBU0osRUFBRUksV0FBVztBQUFBLFFBQ3RCQyxPQUFPTCxFQUFFSyxTQUFTO0FBQUEsUUFDbEJDLFFBQVFOLEVBQUVNLFVBQVU7QUFBQSxRQUNwQkMsUUFBUVAsRUFBRU8sVUFBVTtBQUFBLFFBQ3BCQyxLQUFLUixFQUFFUSxRQUFRLFFBQVFSLEVBQUVRLFFBQVFDLFNBQVlULEVBQUVRLE1BQU07QUFBQSxRQUNyREUsT0FBT1YsRUFBRVcsWUFBWVgsRUFBRVUsU0FBUztBQUFBLFFBQ2hDRSxPQUFPWixFQUFFYSxXQUFXYixFQUFFWSxTQUFTO0FBQUEsTUFDakMsRUFBRTtBQUVGRSxjQUFRaEIsVUFBVTtBQUNsQixVQUFJbEQsU0FBUztBQUNYQSxnQkFBUSxDQUFDNEYsVUFBVSxFQUFFLEdBQUdBLE1BQU1uRCxNQUFNUyxXQUFXLEVBQUU7QUFBQSxNQUNuRDtBQUVBeUQsc0JBQWdCLEtBQUs7QUFDckJqSCxZQUFNLCtCQUErQjtBQUFBLElBRXZDLFNBQVM2QyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sbUJBQW1CQSxLQUFLO0FBQ3RDLFVBQUlBLE1BQU0yRyxVQUFVWSxXQUFXLEtBQUs7QUFDbEMxQyxvQkFBWSxrREFBa0Q7QUFBQSxNQUNoRSxPQUFPO0FBQ0xBLG9CQUFZLG9CQUFvQjdFLE1BQU0yRyxVQUFVWSxVQUFVLHNCQUFzQixFQUFFO0FBQUEsTUFDcEY7QUFBQSxJQUNGLFVBQUM7QUFDQ3RJLHFCQUFlLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUksOEJBQThCLFlBQVk7QUFDOUMsUUFBSWpELG9CQUFvQixNQUFNO0FBQzVCLFVBQUksQ0FBQ2tELE9BQU9DLFFBQVEsdUNBQXVDLEVBQUc7QUFDOUQsWUFBTUMsWUFBWXpILEtBQUtxRSxlQUFlO0FBQ3RDcEYsdUJBQWlCLElBQUk7QUFDckIsVUFBSTtBQUVGLFlBQUl3SSxVQUFVN0csT0FBTztBQUNuQixnQkFBTXBFLElBQUlrTCxPQUFPLFNBQVNELFVBQVU3RyxLQUFLLEVBQUU7QUFBQSxRQUM3QztBQUdBLGNBQU0rRyxjQUFjM0gsS0FBS3FDLE9BQU8sQ0FBQ3VGLEdBQUdiLFVBQVVBLFVBQVUxQyxlQUFlO0FBQ3ZFNUMsZ0JBQVFrRyxXQUFXO0FBQ25CLFlBQUlwSyxTQUFTO0FBQ1hBLGtCQUFRLENBQUM0RixVQUFVLEVBQUUsR0FBR0EsTUFBTW5ELE1BQU0ySCxZQUFZLEVBQUU7QUFBQSxRQUNwRDtBQUNBekQsd0JBQWdCLEtBQUs7QUFFckJqSCxjQUFNLHFCQUFxQjtBQUFBLE1BQzdCLFNBQVM2QyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLHFCQUFxQkEsS0FBSztBQUN4QzdDLGNBQU0sNkJBQTZCLE9BQU87QUFBQSxNQUM1QyxVQUFDO0FBQ0NnQyx5QkFBaUIsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEksZUFBZSxZQUFZO0FBQy9CNUMsbUJBQWUsRUFBRTtBQUNqQixRQUFJLENBQUNILGVBQWVZLEtBQUssR0FBRztBQUMxQlQscUJBQWUsbUJBQW1CO0FBQ2xDO0FBQUEsSUFDRjtBQUNBRSxvQkFBZ0IsWUFBWTtBQUM1QixRQUFJO0FBQ0YsWUFBTTNJLElBQUlrTCxPQUFPLGlCQUFpQixFQUFFckksTUFBTSxFQUFFeUksVUFBVWhELGVBQWUsRUFBRSxDQUFDO0FBQ3hFRCx5QkFBbUIsS0FBSztBQUN4QnZILGFBQU87QUFDUEYsZUFBUyxXQUFXO0FBQUEsSUFDdEIsU0FBU3NFLEtBQUs7QUFDWnVELHFCQUFldkQsSUFBSStFLFVBQVVZLFdBQVcsTUFBTSx1QkFBdUIsMENBQTBDO0FBQUEsSUFDakgsVUFBQztBQUNDbEMsc0JBQWdCLE1BQU07QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEMsc0JBQXNCQSxDQUFDQyxPQUFPQyxXQUFXQyxRQUFRQyxVQUFVQyxRQUFRQyxXQUFXLFVBQ2xGLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJCQUFDLFFBQUlMLG1CQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVztBQUFBLElBQ1YsQ0FBQ0MsWUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHVCQUFzQixTQUFTQyxRQUFPLHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxRQUFRQyxLQUFLLE1BQU0sR0FDeEM7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBU0o7QUFBQUEsVUFDVCxVQUFVRTtBQUFBQSxVQUFTO0FBQUE7QUFBQSxRQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVNEO0FBQUFBLFVBQ1QsVUFBVUM7QUFBQUEsVUFDVixPQUFPLEVBQUVDLFNBQVMsZUFBZUUsWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVUYsS0FBSyxPQUFPRyxVQUFVLE9BQU87QUFBQSxVQUU3R0w7QUFBQUEsd0JBQVksdUJBQUMsVUFBSyxXQUFVLFdBQVUsZUFBWSxVQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzFELHVCQUFDLFVBQU1BLHFCQUFXLGlCQUFpQixZQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBO0FBQUE7QUFBQSxRQVI5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxPQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJBO0FBR0YsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFVBQUssV0FBVSxnQkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxrQkFDWDNLLG1CQUFRRSxZQUFZLEtBQUsrSyxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLE9BQUUsV0FBVSxnQkFDVnBMLHFCQUFXLHNCQUFzQiwyQkFEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxhQUFRLFdBQVUsbUJBQ2hCdUs7QUFBQUE7QUFBQUEsWUFDQztBQUFBLFlBQ0F0RTtBQUFBQSxZQUNBLE1BQU07QUFBRWhGLGlDQUFtQixFQUFFLEdBQUdmLFFBQVEsQ0FBQztBQUFHZ0csa0NBQW9CLElBQUk7QUFBQSxZQUFHO0FBQUEsWUFDdkUsTUFBTWtELG9CQUFvQixTQUFTO0FBQUEsWUFDbkMsTUFBTXRCLGtCQUFrQixTQUFTO0FBQUEsWUFDakMxRyxrQkFBa0I7QUFBQSxVQUNwQjtBQUFBLFVBQ0EsdUJBQUMsZ0JBQWEsT0FBTSxjQUFhLE9BQU0sWUFBVyxPQUFPbEIsUUFBUUUsVUFBVSxXQUFXNkYsa0JBQWtCLE9BQU8vRSxPQUFPZCxVQUFVLFVBQVV3SCxnQkFBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUo7QUFBQSxVQUN2Six1QkFBQyxnQkFBYSxPQUFNLFNBQVEsT0FBTSxTQUFRLE1BQUssU0FBUSxPQUFPMUgsUUFBUUcsT0FBTyxXQUFXNEYsa0JBQWtCLE9BQU8vRSxPQUFPYixPQUFPLFVBQVV1SCxnQkFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0o7QUFBQSxVQUN0Six1QkFBQyxnQkFBYSxPQUFNLFlBQVcsT0FBTSxPQUFNLE1BQUssT0FBTSxPQUFPMUgsUUFBUUksS0FBSyxXQUFXMkYsa0JBQWtCLE9BQU8vRSxPQUFPWixLQUFLLFVBQVVzSCxnQkFBcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUo7QUFBQSxhQVhuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLGFBQVEsV0FBVSxtQkFDaEIyQztBQUFBQTtBQUFBQSxZQUNDO0FBQUEsWUFDQXBFO0FBQUFBLFlBQ0EsTUFBTTtBQUFFbEYsaUNBQW1CLEVBQUUsR0FBR2YsUUFBUSxDQUFDO0FBQUdrRyxrQ0FBb0IsSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUN2RSxNQUFNZ0Qsb0JBQW9CLFNBQVM7QUFBQSxZQUNuQyxNQUFNdEIsa0JBQWtCLFNBQVM7QUFBQSxZQUNqQzFHLGtCQUFrQjtBQUFBLFVBQ3BCO0FBQUEsVUFDQyxDQUFDK0UsbUJBQ0EsbUNBQ0U7QUFBQSxtQ0FBQyxnQkFBYSxPQUFNLHFCQUFvQixPQUFNLFdBQVUsT0FBT2pHLFFBQVFLLFNBQVMsV0FBVyxTQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLFlBQ2pHLHVCQUFDLGdCQUFhLE9BQU0sV0FBVSxPQUFNLFlBQVcsT0FBT0wsUUFBUU0sVUFBVSxXQUFXLFNBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlGO0FBQUEsWUFDekYsdUJBQUMsZ0JBQWEsT0FBTSxlQUFjLE9BQU0sWUFBVyxPQUFPTixRQUFRTyxVQUFVLFdBQVcsU0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxZQUM3Rix1QkFBQyxnQkFBYSxPQUFNLGFBQVksT0FBTSxlQUFjLE9BQU9QLFFBQVFRLGFBQWEsV0FBVyxTQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLFlBQ2pHLHVCQUFDLGdCQUFhLE9BQU0sZ0JBQWUsT0FBTSxjQUFhLE9BQU9SLFFBQVFTLFlBQVksV0FBVyxTQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLGVBTHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUUwSyxZQUFZLFNBQVMsR0FDekQ7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLDhEQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RTtBQUFBLGNBQzlFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT25MLFFBQVFLO0FBQUFBLGtCQUNmLFVBQVUsQ0FBQ2dGLE1BQU1xQyxhQUFhLFdBQVdyQyxFQUFFRSxPQUFPQyxLQUFLO0FBQUEsa0JBQ3ZELGFBQVk7QUFBQSxrQkFDWixPQUFPLEVBQUU0RixPQUFPLE9BQU87QUFBQTtBQUFBLGdCQU56QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNMkI7QUFBQSxjQUUxQnBLLE9BQU9YLFdBQVcsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQlcsaUJBQU9YLFdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdEO0FBQUEsaUJBVnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU9MLFFBQVFNO0FBQUFBLGtCQUNmLFVBQVU4RTtBQUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLd0M7QUFBQSxjQUV4Qyx1QkFBQyxjQUFTLElBQUcsaUJBQ1ZyRyx3QkFBY2lFO0FBQUFBLGdCQUFJLENBQUN1QixTQUNsQix1QkFBQyxZQUFxQixPQUFPQSxLQUFLRSxXQUFyQkYsS0FBSy9CLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsY0FDM0MsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQ3hCLE9BQU9WLFlBQVksdUJBQUMsVUFBSyxXQUFVLGlCQUFpQlUsaUJBQU9WLFlBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsaUJBZHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQiwyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU9OLFFBQVFPO0FBQUFBLGtCQUNmLFVBQVVtRjtBQUFBQSxrQkFDVixVQUFVLENBQUMxRixRQUFRTTtBQUFBQSxrQkFDbkIsYUFBWTtBQUFBO0FBQUEsZ0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXNDO0FBQUEsY0FFdEMsdUJBQUMsY0FBUyxJQUFHLGlCQUNUMkQsaUNBQXNCLElBQUlqQjtBQUFBQSxnQkFBSSxDQUFDOEIsU0FDL0IsdUJBQUMsWUFBcUIsT0FBT0EsS0FBS0wsV0FBckJLLEtBQUt0QyxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGNBQzNDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0N4QixPQUFPVCxZQUFZLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJTLGlCQUFPVCxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBLGlCQWZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLHlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBQ3pDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBQ0wsT0FBT1AsUUFBUVE7QUFBQUEsa0JBQ2YsVUFBVW9GO0FBQUFBLGtCQUNWLFVBQVUsQ0FBQzVGLFFBQVFPO0FBQUFBLGtCQUNuQixhQUFZO0FBQUE7QUFBQSxnQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNcUM7QUFBQSxjQUVyQyx1QkFBQyxjQUFTLElBQUcsWUFDVDRELG9DQUF5QixJQUFJbkI7QUFBQUEsZ0JBQUksQ0FBQ2tDLFFBQ2xDLHVCQUFDLFlBQW9CLE9BQU9BLElBQUlULFdBQW5CUyxJQUFJMUMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0M7QUFBQSxjQUN6QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNDeEIsT0FBT1IsZUFBZSx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCUSxpQkFBT1IsZUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFmN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQiw0QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUM1QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBSztBQUFBLGtCQUNMLE9BQU9SLFFBQVFTO0FBQUFBLGtCQUNmLFVBQVUsQ0FBQzRFLE1BQU1xQyxhQUFhLGNBQWNyQyxFQUFFRSxPQUFPQyxLQUFLO0FBQUEsa0JBQzFELFVBQVUsQ0FBQ3hGLFFBQVFRO0FBQUFBLGtCQUNuQixhQUFZO0FBQUE7QUFBQSxnQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNEI7QUFBQSxjQUU1Qix1QkFBQyxjQUFTLElBQUcsWUFDVDZELGdDQUFxQixJQUFJckI7QUFBQUEsZ0JBQUksQ0FBQ3FJLEtBQUtDLFFBQ25DLHVCQUFDLFlBQWlCLE9BQU9ELE9BQVpDLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxjQUM5QixLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNDdEssT0FBT1AsY0FBYyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCTyxpQkFBT1AsY0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxpQkFmM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1GQTtBQUFBLGFBckdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1R0E7QUFBQSxRQUVDWCxZQUNDLHVCQUFDLGFBQVEsV0FBVSxtQkFDaEJ1SztBQUFBQTtBQUFBQSxZQUNDO0FBQUEsWUFDQWxFO0FBQUFBLFlBQ0EsTUFBTTtBQUFFcEYsaUNBQW1CLEVBQUUsR0FBR2YsUUFBUSxDQUFDO0FBQUdvRyxpQ0FBbUIsSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUN0RSxNQUFNOEMsb0JBQW9CLFFBQVE7QUFBQSxZQUNsQyxNQUFNdEIsa0JBQWtCLFFBQVE7QUFBQSxZQUNoQzFHLGtCQUFrQjtBQUFBLFVBQ3BCO0FBQUEsVUFDQSx1QkFBQyxnQkFBYSxPQUFNLGNBQWEsT0FBTSxjQUFhLE9BQU9sQixRQUFRVSxZQUFZLFdBQVd5RixpQkFBaUIsT0FBT25GLE9BQU9OLFlBQVksVUFBVWdILGdCQUEvSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0SjtBQUFBLFVBQzVKLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGlCQUFnQiw4QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM5Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCMUgsa0JBQVFXLFNBQVMsWUFBWVgsUUFBUVcsT0FBTzRLLE1BQU0sRUFBRSxDQUFDLEtBQUssT0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Y7QUFBQSxlQUZqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxnQkFBYSxPQUFNLG9CQUFtQixPQUFNLGVBQWMsT0FBT3ZMLFFBQVFZLGFBQWEsV0FBV3VGLGlCQUFpQixPQUFPbkYsT0FBT0osYUFBYSxVQUFVOEcsZ0JBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFLO0FBQUEsVUFDcks7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcxSCxRQUFRYTtBQUFBQSxjQUNuQixXQUFXc0Y7QUFBQUEsY0FDWCxNQUFNRTtBQUFBQSxjQUNOLE9BQU9yRixPQUFPa0g7QUFBQUEsY0FDZCxjQUFjLENBQUNzRCxNQUFNO0FBQUVsRiwwQkFBVWtGLENBQUM7QUFBR3ZLLDBCQUFVLENBQUN3RSxVQUFVLEVBQUUsR0FBR0EsTUFBTXlDLFFBQVEsR0FBRyxFQUFFO0FBQUEsY0FBRztBQUFBLGNBQ3JGLFVBQVUsTUFBTTVCLFVBQVUsSUFBSTtBQUFBO0FBQUEsWUFOaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTWtDO0FBQUEsYUFyQnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUdELENBQUN4RyxZQUNBLHVCQUFDLGFBQVEsV0FBVSxtQkFBa0IsT0FBTyxFQUFFMkwsV0FBVyxrQkFBa0JDLFlBQVksT0FBTyxHQUM1RjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxZQUNyQix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHVCQUFzQixTQUFTdkMsaUJBQWdCLGtDQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUNFN0csa0JBQVFBLEtBQUsyRixTQUFTLElBQ3JCM0YsS0FBS1U7QUFBQUEsWUFBSSxDQUFDMkksS0FBS3RDLFVBQ2IsdUJBQUMsU0FBZ0IsT0FBTyxFQUFFdUMsWUFBWSxXQUFXQyxTQUFTLGFBQWFDLGNBQWMsT0FBT0MsY0FBYyxPQUFPQyxRQUFRLHFCQUFxQnBCLFNBQVMsUUFBUUcsZ0JBQWdCLGlCQUFpQkQsWUFBWSxTQUFTLEdBQ25OO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVGLFNBQVMsUUFBUUUsWUFBWSxVQUFVRCxLQUFLLE9BQU8sR0FDOURjO0FBQUFBLG9CQUFJaEksUUFDSDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxLQUFLZ0ksSUFBSWhJO0FBQUFBLG9CQUNULEtBQUtnSSxJQUFJdkk7QUFBQUEsb0JBQ1QsU0FBUyxDQUFDaUMsTUFBTTtBQUFFQSx3QkFBRUUsT0FBTzBHLE1BQU07QUFBQSxvQkFBc1A7QUFBQSxvQkFDdlIsT0FBTyxFQUFFYixPQUFPLFFBQVFjLFFBQVEsUUFBUUosY0FBYyxPQUFPSyxXQUFXLFNBQVNILFFBQVEsaUJBQWlCO0FBQUE7QUFBQSxrQkFKNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUk4RyxJQUc5Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRVosT0FBTyxRQUFRYyxRQUFRLFFBQVFKLGNBQWMsT0FBT0YsWUFBWSxRQUFRaEIsU0FBUyxRQUFRRSxZQUFZLFVBQVVDLGdCQUFnQixVQUFVcUIsVUFBVSxPQUFPLEdBQUUsa0JBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFRix1QkFBQyxVQUFLLE9BQU8sRUFBRUEsVUFBVSxRQUFRQyxZQUFZLE1BQU0sR0FBSVYsY0FBSXZJLFFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsbUJBYmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFd0gsU0FBUyxRQUFRQyxLQUFLLE1BQU0sR0FDeEM7QUFBQSx1Q0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGtDQUFpQyxTQUFTLE1BQU16QixpQkFBaUJDLEtBQUssR0FBRyxPQUFNLFlBQVcsa0JBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRIO0FBQUEsZ0JBQzVILHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsa0RBQWlELFNBQVMsTUFBTUMsaUJBQWlCRCxLQUFLLEdBQUcsT0FBTSxlQUFjLG1CQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSjtBQUFBLG1CQUZsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBbkJRQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsVUFDRCxJQUVELHVCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFVBQUssV0FBVSxpQkFBZ0IsT0FBTyxFQUFFK0IsT0FBTyxRQUFRa0IsV0FBVyxVQUFVQyxPQUFPLE9BQU8sR0FBRyw2Q0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkgsS0FEN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLGFBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0E7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTyxFQUFFQyxXQUFXLE9BQU8sR0FDMUQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsdUJBQ2IsaUNBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSx5QkFBd0IsU0FBUyxNQUFNO0FBQUVuRiw4QkFBa0IsRUFBRTtBQUFHRSwyQkFBZSxFQUFFO0FBQUdFLDRCQUFnQixNQUFNO0FBQUdOLCtCQUFtQixJQUFJO0FBQUEsVUFBRyxHQUFFLHVCQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSwwQkFBeUIsU0FBUyxNQUFNekgsU0FBUyxHQUFHLEdBQUUsOEJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBOU1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErTUE7QUFBQSxNQUVDNkcsZ0JBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUtNO0FBQUFBLFVBQ0wsTUFBTUo7QUFBQUEsVUFDTixPQUFPTztBQUFBQSxVQUNQLFVBQVU1RjtBQUFBQSxVQUNWLFlBQVlFO0FBQUFBLFVBQ1osVUFBVSxDQUFDcUcsT0FBT25DLFVBQVU7QUFDMUJzQiw2QkFBaUIsQ0FBQ3JCLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNrQyxLQUFLLEdBQUduQyxNQUFNLEVBQUU7QUFDeEQsZ0JBQUltQyxVQUFVLE9BQVFWLGFBQVksRUFBRTtBQUFBLFVBQ3RDO0FBQUEsVUFDQSxTQUFTLE1BQU07QUFDYixnQkFBSSxDQUFDN0YsZUFBZSxDQUFDRSxlQUFlO0FBQ2xDa0YsOEJBQWdCLEtBQUs7QUFDckJTLDBCQUFZLEVBQUU7QUFBQSxZQUNoQjtBQUFBLFVBQ0Y7QUFBQSxVQUNBLFFBQVFzQztBQUFBQSxVQUNSLFVBQVVLO0FBQUFBLFVBQ1YsZ0JBQWdCLE1BQU1sRCxhQUFhLE1BQU07QUFBQTtBQUFBLFFBbEIzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQjZDO0FBQUEsTUFJOUNRLG1CQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVRTtBQUFBQSxVQUNWLE9BQU9FO0FBQUFBLFVBQ1AsUUFBUUU7QUFBQUEsVUFDUixrQkFBa0JIO0FBQUFBLFVBQ2xCLFVBQVUsTUFBTTtBQUFFLGdCQUFJRyxpQkFBaUIsYUFBY0wsb0JBQW1CLEtBQUs7QUFBQSxVQUFHO0FBQUEsVUFDaEYsV0FBV2dEO0FBQUFBO0FBQUFBLFFBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTTBCO0FBQUEsU0FoUDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtUEE7QUFBQSxPQXJQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc1BBO0FBRUo7QUFBQzFLLEdBeHZCUUQsYUFBVztBQUFBLFVBQ0RYLGFBQ2lCRixPQUFPO0FBQUE7QUFBQSxLQUZsQ2E7QUEwdkJULGVBQWVBO0FBQVksSUFBQWlOO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQXV0aCIsIk5hdmJhciIsInVzZU5hdmlnYXRlIiwiYXBpIiwicHJvdmluY2VzRGF0YSIsImRpc3RyaWN0c0RhdGEiLCJzdWJEaXN0cmljdHNEYXRhIiwiUHJvZmlsZUZpZWxkIiwiRGVsZXRlQWNjb3VudE1vZGFsIiwiUGV0TW9kYWwiLCJTaXR0ZXJRclVwbG9hZCIsInZhbGlkYXRlUHJvZmlsZSIsInRvYXN0IiwiUHJvZmlsZVBhZ2UiLCJfcyIsIm5hdmlnYXRlIiwidXNlciIsImxvZ291dCIsInNldFVzZXIiLCJpc1NpdHRlciIsInJvbGUiLCJwcm9maWxlIiwic2V0UHJvZmlsZSIsInVzZXJuYW1lIiwiZW1haWwiLCJ0ZWwiLCJhZGRyZXNzIiwicHJvdmluY2UiLCJkaXN0cmljdCIsInN1YmRpc3RyaWN0IiwicG9zdGFsQ29kZSIsImV4cGVyaWVuY2UiLCJ0aGFpSWQiLCJhY2NvdW50TmFtZSIsInFyQ29kZVVybCIsIm9yaWdpbmFsUHJvZmlsZSIsInNldE9yaWdpbmFsUHJvZmlsZSIsImVycm9ycyIsInNldEVycm9ycyIsInNhdmluZ1NlY3Rpb24iLCJzZXRTYXZpbmdTZWN0aW9uIiwiaXNTYXZpbmdQZXQiLCJzZXRJc1NhdmluZ1BldCIsImlzRGVsZXRpbmdQZXQiLCJzZXRJc0RlbGV0aW5nUGV0IiwiZmV0Y2hVc2VyUHJvZmlsZSIsInJlcyIsImdldCIsImRhdGEiLCJsb2FkZWRQcm9maWxlIiwiY2l0eSIsInBheVJlcyIsInBheSIsInNldEhhc1BheW1lbnRJbmZvIiwiaGFzUGF5bWVudEluZm8iLCJwYXlFcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmdWxsVXNlckRhdGEiLCJwZXRzIiwic2FmZVVzZXJEYXRhIiwiaWQiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiSlNPTiIsInN0cmluZ2lmeSIsIkFycmF5IiwiaXNBcnJheSIsIm1hcHBlZFBldHMiLCJtYXAiLCJwIiwicGV0SWQiLCJwZXRpZCIsIm5hbWUiLCJzcGVjaWVzIiwiYnJlZWQiLCJnZW5kZXIiLCJ3ZWlnaHQiLCJhZ2UiLCJ1bmRlZmluZWQiLCJwaG90byIsImltYWdlVXJsIiwibm90ZXMiLCJhbGxlcmd5Iiwic2V0UGV0cyIsImVyciIsImF2YWlsYWJsZURpc3RyaWN0cyIsInNldEF2YWlsYWJsZURpc3RyaWN0cyIsImF2YWlsYWJsZVN1YmRpc3RyaWN0cyIsInNldEF2YWlsYWJsZVN1YmRpc3RyaWN0cyIsImF2YWlsYWJsZVppcGNvZGVzIiwic2V0QXZhaWxhYmxlWmlwY29kZXMiLCJwcm92IiwiZmluZCIsIm5hbWVfdGgiLCJmaWx0ZXJlZERpc3RyaWN0cyIsImZpbHRlciIsImQiLCJwcm92aW5jZV9pZCIsImRpc3QiLCJmaWx0ZXJlZFN1YmRpc3RyaWN0cyIsInMiLCJkaXN0cmljdF9pZCIsInN1YiIsInppcF9jb2RlIiwiaGFuZGxlUHJvdmluY2VDaGFuZ2UiLCJlIiwic2VsZWN0ZWRQcm92aW5jZSIsInRhcmdldCIsInZhbHVlIiwicHJldiIsImhhbmRsZURpc3RyaWN0Q2hhbmdlIiwic2VsZWN0ZWREaXN0cmljdCIsImhhbmRsZVN1YmRpc3RyaWN0Q2hhbmdlIiwic2VsZWN0ZWRTdWIiLCJ0b1N0cmluZyIsImlzRWRpdGluZ0FjY291bnQiLCJzZXRJc0VkaXRpbmdBY2NvdW50IiwiaXNFZGl0aW5nQWRkcmVzcyIsInNldElzRWRpdGluZ0FkZHJlc3MiLCJpc0VkaXRpbmdTaXR0ZXIiLCJzZXRJc0VkaXRpbmdTaXR0ZXIiLCJxckZpbGUiLCJzZXRRckZpbGUiLCJzaG93UGV0TW9kYWwiLCJzZXRTaG93UGV0TW9kYWwiLCJtb2RhbE1vZGUiLCJzZXRNb2RhbE1vZGUiLCJjdXJyZW50UGV0SW5kZXgiLCJzZXRDdXJyZW50UGV0SW5kZXgiLCJhY3RpdmVQZXRGb3JtIiwic2V0QWN0aXZlUGV0Rm9ybSIsInBob3RvRmlsZSIsInBldEVycm9yIiwic2V0UGV0RXJyb3IiLCJzaG93RGVsZXRlTW9kYWwiLCJzZXRTaG93RGVsZXRlTW9kYWwiLCJkZWxldGVQYXNzd29yZCIsInNldERlbGV0ZVBhc3N3b3JkIiwiZGVsZXRlRXJyb3IiLCJzZXREZWxldGVFcnJvciIsImRlbGV0ZVN0YXR1cyIsInNldERlbGV0ZVN0YXR1cyIsImhhbmRsZUNoYW5nZSIsImZpZWxkIiwiaGFuZGxlU2F2ZVNlY3Rpb24iLCJzZWN0aW9uVHlwZSIsImFsbEVycm9ycyIsInNlY3Rpb25FcnJvcnMiLCJ0cmltIiwibGVuZ3RoIiwicXJDb2RlIiwiT2JqZWN0Iiwia2V5cyIsInBheWxvYWQiLCJwdXQiLCJzYXZlZFByb2ZpbGUiLCJhY2NvdW50TmFtZUNoYW5nZWQiLCJmb3JtRGF0YSIsIkZvcm1EYXRhIiwiYXBwZW5kIiwicGF0Y2giLCJwb3N0IiwicGF5RXJyb3IiLCJyZXNwb25zZSIsIm1lc3NhZ2UiLCJ1cGRhdGVkVXNlciIsImhhbmRsZUNhbmNlbFNlY3Rpb24iLCJvcGVuQWRkUGV0TW9kYWwiLCJvcGVuVmlld1BldE1vZGFsIiwiaW5kZXgiLCJvcGVuRWRpdFBldE1vZGFsIiwiaGFuZGxlU2F2ZVBldCIsInNhdmVkUGV0IiwicHJvZmlsZVJlcyIsImxhdGVzdFBldHMiLCJzdGF0dXMiLCJoYW5kbGVSZW1vdmVDdXJyZW50TW9kYWxQZXQiLCJ3aW5kb3ciLCJjb25maXJtIiwidGFyZ2V0UGV0IiwiZGVsZXRlIiwidXBkYXRlZFBldHMiLCJfIiwiaGFuZGxlRGVsZXRlIiwicGFzc3dvcmQiLCJyZW5kZXJTZWN0aW9uSGVhZGVyIiwidGl0bGUiLCJpc0VkaXRpbmciLCJvbkVkaXQiLCJvbkNhbmNlbCIsIm9uU2F2ZSIsImlzU2F2aW5nIiwiZGlzcGxheSIsImdhcCIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsIm1pbldpZHRoIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJncmlkQ29sdW1uIiwid2lkdGgiLCJ6aXAiLCJpZHgiLCJzbGljZSIsImYiLCJib3JkZXJUb3AiLCJwYWRkaW5nVG9wIiwicGV0IiwiYmFja2dyb3VuZCIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJtYXJnaW5Cb3R0b20iLCJib3JkZXIiLCJzcmMiLCJoZWlnaHQiLCJvYmplY3RGaXQiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJ0ZXh0QWxpZ24iLCJjb2xvciIsIm1hcmdpblRvcCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb2ZpbGVQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHQvQXV0aENvbnRleHQuanN4XCI7XG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL05hdmJhci5qc3hcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGkuanNcIjtcbmltcG9ydCBwcm92aW5jZXNEYXRhIGZyb20gXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL3Byb3ZpbmNlLmpzb25cIjtcbmltcG9ydCBkaXN0cmljdHNEYXRhIGZyb20gXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL2Rpc3RyaWN0Lmpzb25cIjtcbmltcG9ydCBzdWJEaXN0cmljdHNEYXRhIGZyb20gXCIuLi9hc3NldHMvdGhhaS1hZGRyZXNzL3N1Yl9kaXN0cmljdC5qc29uXCI7XG5cbmltcG9ydCBQcm9maWxlRmllbGQgZnJvbSBcIi4uL2NvbXBvbmVudHMvUHJvZmlsZUZpZWxkLmpzeFwiO1xuaW1wb3J0IERlbGV0ZUFjY291bnRNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9EZWxldGVBY2NvdW50TW9kYWwuanN4XCI7XG5pbXBvcnQgUGV0TW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvUGV0TW9kYWwuanN4XCI7XG5pbXBvcnQgU2l0dGVyUXJVcGxvYWQgZnJvbSBcIi4uL2NvbXBvbmVudHMvU2l0dGVyUXJVcGxvYWQuanN4XCI7XG5pbXBvcnQgeyB2YWxpZGF0ZVByb2ZpbGUgfSBmcm9tIFwiLi4vdXRpbHMvcHJvZmlsZVZhbGlkYXRpb24uanNcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcIi4uL3V0aWxzL3RvYXN0LmpzXCI7XG5cbmZ1bmN0aW9uIFByb2ZpbGVQYWdlKCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgdXNlciwgbG9nb3V0LCBzZXRVc2VyIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGlzU2l0dGVyID0gdXNlcj8ucm9sZSA9PT0gXCJzaXR0ZXJcIjtcblxuICBjb25zdCBbcHJvZmlsZSwgc2V0UHJvZmlsZV0gPSB1c2VTdGF0ZSh7XG4gICAgdXNlcm5hbWU6IHVzZXI/LnVzZXJuYW1lIHx8IFwiXCIsXG4gICAgZW1haWw6IHVzZXI/LmVtYWlsIHx8IFwiXCIsXG4gICAgdGVsOiB1c2VyPy50ZWwgfHwgXCJcIixcbiAgICBhZGRyZXNzOiB1c2VyPy5hZGRyZXNzIHx8IFwiXCIsXG4gICAgcHJvdmluY2U6IHVzZXI/LnByb3ZpbmNlIHx8IFwiXCIsXG4gICAgZGlzdHJpY3Q6IHVzZXI/LmRpc3RyaWN0IHx8IFwiXCIsICAgICAgXG4gICAgc3ViZGlzdHJpY3Q6IHVzZXI/LnN1YmRpc3RyaWN0IHx8IFwiXCIsIFxuICAgIHBvc3RhbENvZGU6IHVzZXI/LnBvc3RhbENvZGUgfHwgXCJcIixcbiAgICByb2xlOiB1c2VyPy5yb2xlIHx8IFwib3duZXJcIixcbiAgICBleHBlcmllbmNlOiB1c2VyPy5leHBlcmllbmNlIHx8IFwiXCIsXG4gICAgdGhhaUlkOiB1c2VyPy50aGFpSWQgfHwgXCJcIixcbiAgICBhY2NvdW50TmFtZTogdXNlcj8uYWNjb3VudE5hbWUgfHwgXCJcIixcbiAgICBxckNvZGVVcmw6IHVzZXI/LnFyQ29kZVVybCB8fCBcIlwiLFxuICB9KTtcblxuICBjb25zdCBbb3JpZ2luYWxQcm9maWxlLCBzZXRPcmlnaW5hbFByb2ZpbGVdID0gdXNlU3RhdGUocHJvZmlsZSk7XG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XG4gIGNvbnN0IFtzYXZpbmdTZWN0aW9uLCBzZXRTYXZpbmdTZWN0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbaXNTYXZpbmdQZXQsIHNldElzU2F2aW5nUGV0XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRGVsZXRpbmdQZXQsIHNldElzRGVsZXRpbmdQZXRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIEdFVCAvYXBpL3VzZXJzL21lXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZmV0Y2hVc2VyUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlcnMvbWVcIik7XG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXMuZGF0YT8uZGF0YTtcblxuICAgICAgICBpZiAoZGF0YSkge1xuICAgICAgICAgIGNvbnN0IGxvYWRlZFByb2ZpbGUgPSB7XG4gICAgICAgICAgICB1c2VybmFtZTogZGF0YS51c2VybmFtZSB8fCBcIlwiLFxuICAgICAgICAgICAgZW1haWw6IGRhdGEuZW1haWwgfHwgXCJcIixcbiAgICAgICAgICAgIHRlbDogZGF0YS50ZWwgfHwgXCJcIixcbiAgICAgICAgICAgIGFkZHJlc3M6IGRhdGEuYWRkcmVzcyB8fCBcIlwiLFxuICAgICAgICAgICAgcHJvdmluY2U6IGRhdGEucHJvdmluY2UgfHwgXCJcIixcbiAgICAgICAgICAgIGRpc3RyaWN0OiBkYXRhLmRpc3RyaWN0IHx8IGRhdGEuY2l0eSB8fCBcIlwiLFxuICAgICAgICAgICAgc3ViZGlzdHJpY3Q6IGRhdGEuc3ViZGlzdHJpY3QgfHwgXCJcIixcbiAgICAgICAgICAgIHBvc3RhbENvZGU6IGRhdGEucG9zdGFsQ29kZSB8fCBcIlwiLFxuICAgICAgICAgICAgcm9sZTogZGF0YS5yb2xlIHx8IFwib3duZXJcIixcbiAgICAgICAgICAgIGV4cGVyaWVuY2U6IGRhdGEuZXhwZXJpZW5jZSB8fCBcIlwiLFxuICAgICAgICAgICAgdGhhaUlkOiBkYXRhLnRoYWlJZCB8fCBcIlwiLFxuICAgICAgICAgICAgYWNjb3VudE5hbWU6IFwiXCIsXG4gICAgICAgICAgICBxckNvZGVVcmw6IFwiXCIsXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIOC4guC5ieC4reC4oeC4ueC4peC4o+C4seC4muC5gOC4h+C4tOC4meC4guC4reC4hyBzaXR0ZXIgKOC4iuC4t+C5iOC4reC4muC4seC4jeC4iuC4tSArIFFSKSDguK3guKLguLnguYjguITguJnguKXguLAgZW5kcG9pbnQg4LiB4Lix4LiaIC91c2Vycy9tZVxuICAgICAgICAgIGlmIChsb2FkZWRQcm9maWxlLnJvbGUgPT09IFwic2l0dGVyXCIpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGNvbnN0IHBheVJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvc2l0dGVyL3BheW1lbnQtaW5mb1wiKTtcbiAgICAgICAgICAgICAgY29uc3QgcGF5ID0gcGF5UmVzLmRhdGE/LmRhdGE7XG4gICAgICAgICAgICAgIGxvYWRlZFByb2ZpbGUuYWNjb3VudE5hbWUgPSBwYXk/LmFjY291bnROYW1lIHx8IFwiXCI7XG4gICAgICAgICAgICAgIGxvYWRlZFByb2ZpbGUucXJDb2RlVXJsID0gcGF5Py5xckNvZGVVcmwgfHwgXCJcIjtcbiAgICAgICAgICAgICAgc2V0SGFzUGF5bWVudEluZm8oISFwYXk/Lmhhc1BheW1lbnRJbmZvKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKHBheUVycikge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwi4LiU4Li24LiH4LiC4LmJ4Lit4Lih4Li54Lil4Lij4Lix4Lia4LmA4LiH4Li04LiZ4LmE4Lih4LmI4Liq4Liz4LmA4Lij4LmH4LiIOlwiLCBwYXlFcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHNldFByb2ZpbGUobG9hZGVkUHJvZmlsZSk7XG4gICAgICAgICAgc2V0T3JpZ2luYWxQcm9maWxlKGxvYWRlZFByb2ZpbGUpO1xuICAgICAgICAgIFxuXG4gICAgICAgICAgY29uc3QgZnVsbFVzZXJEYXRhID0geyAuLi51c2VyLCAuLi5sb2FkZWRQcm9maWxlLCBwZXRzOiBkYXRhLnBldHMgfHwgW10gfTtcbiAgICAgICAgICBpZiAoc2V0VXNlcikgc2V0VXNlcihmdWxsVXNlckRhdGEpO1xuXG4gICAgICAgICAgY29uc3Qgc2FmZVVzZXJEYXRhID0ge1xuICAgICAgICAgICAgaWQ6IGZ1bGxVc2VyRGF0YS5pZCxcbiAgICAgICAgICAgIHVzZXJuYW1lOiBmdWxsVXNlckRhdGEudXNlcm5hbWUsXG4gICAgICAgICAgICBlbWFpbDogZnVsbFVzZXJEYXRhLmVtYWlsLFxuICAgICAgICAgICAgcm9sZTogZnVsbFVzZXJEYXRhLnJvbGUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInBiX3VzZXJcIiwgSlNPTi5zdHJpbmdpZnkoc2FmZVVzZXJEYXRhKSlcblxuICAgICAgICAgIGlmIChkYXRhLnBldHMgJiYgQXJyYXkuaXNBcnJheShkYXRhLnBldHMpKSB7XG4gICAgICAgICAgICBjb25zdCBtYXBwZWRQZXRzID0gZGF0YS5wZXRzLm1hcCgocCkgPT4gKHtcbiAgICAgICAgICAgICAgcGV0SWQ6IHAucGV0SWQgfHwgcC5wZXRpZCB8fCBwLmlkIHx8IG51bGwsXG4gICAgICAgICAgICAgIG5hbWU6IHAubmFtZSB8fCBcIlwiLFxuICAgICAgICAgICAgICBzcGVjaWVzOiBwLnNwZWNpZXMgfHwgXCJcIixcbiAgICAgICAgICAgICAgYnJlZWQ6IHAuYnJlZWQgfHwgXCJcIixcbiAgICAgICAgICAgICAgZ2VuZGVyOiBwLmdlbmRlciB8fCBcIlwiLCBcbiAgICAgICAgICAgICAgd2VpZ2h0OiBwLndlaWdodCB8fCBcIlwiLFxuICAgICAgICAgICAgICBhZ2U6IHAuYWdlICE9PSBudWxsICYmIHAuYWdlICE9PSB1bmRlZmluZWQgPyBwLmFnZSA6IFwiXCIsXG4gICAgICAgICAgICAgIHBob3RvOiBwLmltYWdlVXJsIHx8IFwiXCIsXG4gICAgICAgICAgICAgIG5vdGVzOiBwLmFsbGVyZ3kgPyBg4LmB4Lie4LmJOiAke3AuYWxsZXJneX1gIDogXCJcIixcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIHNldFBldHMobWFwcGVkUGV0cyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIuC4lOC4tuC4h+C4guC5ieC4reC4oeC4ueC4peC5guC4m+C4o+C5hOC4n+C4peC5jOC5hOC4oeC5iOC4quC4s+C5gOC4o+C5h+C4iDpcIiwgZXJyKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgZmV0Y2hVc2VyUHJvZmlsZSgpO1xuICB9LCBbXSk7XG5cbiAgLy8gRHJvcCBkb3duIGFkZHJlc3Mgc3RhdGVzXG4gIGNvbnN0IFthdmFpbGFibGVEaXN0cmljdHMsIHNldEF2YWlsYWJsZURpc3RyaWN0c10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFthdmFpbGFibGVTdWJkaXN0cmljdHMsIHNldEF2YWlsYWJsZVN1YmRpc3RyaWN0c10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFthdmFpbGFibGVaaXBjb2Rlcywgc2V0QXZhaWxhYmxlWmlwY29kZXNdID0gdXNlU3RhdGUoW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHByb2ZpbGUucHJvdmluY2UpIHtcbiAgICAgIGNvbnN0IHByb3YgPSBwcm92aW5jZXNEYXRhLmZpbmQocCA9PiBwLm5hbWVfdGggPT09IHByb2ZpbGUucHJvdmluY2UpO1xuICAgICAgaWYgKHByb3YpIHtcbiAgICAgICAgY29uc3QgZmlsdGVyZWREaXN0cmljdHMgPSBkaXN0cmljdHNEYXRhLmZpbHRlcihkID0+IGQucHJvdmluY2VfaWQgPT09IHByb3YuaWQpO1xuICAgICAgICBzZXRBdmFpbGFibGVEaXN0cmljdHMoZmlsdGVyZWREaXN0cmljdHMpO1xuICAgICAgICBcbiAgICAgICAgaWYgKHByb2ZpbGUuZGlzdHJpY3QpIHtcbiAgICAgICAgICBjb25zdCBkaXN0ID0gZmlsdGVyZWREaXN0cmljdHMuZmluZChkID0+IGQubmFtZV90aCA9PT0gcHJvZmlsZS5kaXN0cmljdCk7XG4gICAgICAgICAgaWYgKGRpc3QpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbHRlcmVkU3ViZGlzdHJpY3RzID0gc3ViRGlzdHJpY3RzRGF0YS5maWx0ZXIocyA9PiBzLmRpc3RyaWN0X2lkID09PSBkaXN0LmlkKTtcbiAgICAgICAgICAgIHNldEF2YWlsYWJsZVN1YmRpc3RyaWN0cyhmaWx0ZXJlZFN1YmRpc3RyaWN0cyk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChwcm9maWxlLnN1YmRpc3RyaWN0KSB7XG4gICAgICAgICAgICAgIGNvbnN0IHN1YiA9IGZpbHRlcmVkU3ViZGlzdHJpY3RzLmZpbmQocyA9PiBzLm5hbWVfdGggPT09IHByb2ZpbGUuc3ViZGlzdHJpY3QpO1xuICAgICAgICAgICAgICBpZiAoc3ViKSBzZXRBdmFpbGFibGVaaXBjb2RlcyhzdWIuemlwX2NvZGUgPyBbc3ViLnppcF9jb2RlXSA6IFtdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0sIFtwcm9maWxlLnByb3ZpbmNlLCBwcm9maWxlLmRpc3RyaWN0LCBwcm9maWxlLnN1YmRpc3RyaWN0XSk7XG5cbiAgY29uc3QgaGFuZGxlUHJvdmluY2VDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IHNlbGVjdGVkUHJvdmluY2UgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBzZXRQcm9maWxlKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIHByb3ZpbmNlOiBzZWxlY3RlZFByb3ZpbmNlLFxuICAgICAgZGlzdHJpY3Q6IFwiXCIsIFxuICAgICAgc3ViZGlzdHJpY3Q6IFwiXCIsXG4gICAgICBwb3N0YWxDb2RlOiBcIlwiXG4gICAgfSkpO1xuXG4gICAgY29uc3QgcHJvdiA9IHByb3ZpbmNlc0RhdGEuZmluZCgocCkgPT4gcC5uYW1lX3RoID09PSBzZWxlY3RlZFByb3ZpbmNlKTtcbiAgICBzZXRBdmFpbGFibGVEaXN0cmljdHMocHJvdiA/IGRpc3RyaWN0c0RhdGEuZmlsdGVyKGQgPT4gZC5wcm92aW5jZV9pZCA9PT0gcHJvdi5pZCkgOiBbXSk7XG4gICAgc2V0QXZhaWxhYmxlU3ViZGlzdHJpY3RzKFtdKTtcbiAgICBzZXRBdmFpbGFibGVaaXBjb2RlcyhbXSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGlzdHJpY3RDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGNvbnN0IHNlbGVjdGVkRGlzdHJpY3QgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBzZXRQcm9maWxlKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGRpc3RyaWN0OiBzZWxlY3RlZERpc3RyaWN0LFxuICAgICAgc3ViZGlzdHJpY3Q6IFwiXCIsXG4gICAgICBwb3N0YWxDb2RlOiBcIlwiXG4gICAgfSkpO1xuXG4gICAgY29uc3QgZGlzdCA9IGF2YWlsYWJsZURpc3RyaWN0cy5maW5kKChkKSA9PiBkLm5hbWVfdGggPT09IHNlbGVjdGVkRGlzdHJpY3QpO1xuICAgIGlmIChkaXN0KSB7XG4gICAgICBjb25zdCBmaWx0ZXJlZFN1YmRpc3RyaWN0cyA9IHN1YkRpc3RyaWN0c0RhdGEuZmlsdGVyKHMgPT4gcy5kaXN0cmljdF9pZCA9PT0gZGlzdC5pZCk7XG4gICAgICBzZXRBdmFpbGFibGVTdWJkaXN0cmljdHMoZmlsdGVyZWRTdWJkaXN0cmljdHMpO1xuICAgICAgc2V0QXZhaWxhYmxlWmlwY29kZXMoW10pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRBdmFpbGFibGVTdWJkaXN0cmljdHMoW10pO1xuICAgICAgc2V0QXZhaWxhYmxlWmlwY29kZXMoW10pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJkaXN0cmljdENoYW5nZSA9IChlKSA9PiB7XG4gICAgY29uc3Qgc2VsZWN0ZWRTdWIgPSBlLnRhcmdldC52YWx1ZTtcbiAgICBjb25zdCBzdWIgPSBhdmFpbGFibGVTdWJkaXN0cmljdHMuZmluZCgocykgPT4gcy5uYW1lX3RoID09PSBzZWxlY3RlZFN1Yik7XG5cbiAgICBzZXRQcm9maWxlKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIHN1YmRpc3RyaWN0OiBzZWxlY3RlZFN1YixcbiAgICAgIHBvc3RhbENvZGU6IHN1YiAmJiBzdWIuemlwX2NvZGUgPyBzdWIuemlwX2NvZGUudG9TdHJpbmcoKSA6IFwiXCJcbiAgICB9KSk7XG5cbiAgICBpZiAoc3ViICYmIHN1Yi56aXBfY29kZSkge1xuICAgICAgc2V0QXZhaWxhYmxlWmlwY29kZXMoW3N1Yi56aXBfY29kZV0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRBdmFpbGFibGVaaXBjb2RlcyhbXSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IFtpc0VkaXRpbmdBY2NvdW50LCBzZXRJc0VkaXRpbmdBY2NvdW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRWRpdGluZ0FkZHJlc3MsIHNldElzRWRpdGluZ0FkZHJlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNFZGl0aW5nU2l0dGVyLCBzZXRJc0VkaXRpbmdTaXR0ZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcXJGaWxlLCBzZXRRckZpbGVdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtoYXNQYXltZW50SW5mbywgc2V0SGFzUGF5bWVudEluZm9dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtwZXRzLCBzZXRQZXRzXSA9IHVzZVN0YXRlKHVzZXI/LnBldHMgfHwgW10pO1xuICBjb25zdCBbc2hvd1BldE1vZGFsLCBzZXRTaG93UGV0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbW9kYWxNb2RlLCBzZXRNb2RhbE1vZGVdID0gdXNlU3RhdGUoXCJhZGRcIik7XG4gIGNvbnN0IFtjdXJyZW50UGV0SW5kZXgsIHNldEN1cnJlbnRQZXRJbmRleF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2FjdGl2ZVBldEZvcm0sIHNldEFjdGl2ZVBldEZvcm1dID0gdXNlU3RhdGUoe1xuICAgIHBldElkOiBudWxsLCBuYW1lOiBcIlwiLCBzcGVjaWVzOiBcIlwiLCBicmVlZDogXCJcIiwgYWdlOiBcIlwiLCBwaG90bzogXCJcIiwgbm90ZXM6IFwiXCIsXG4gICAgZ2VuZGVyOiBcIlwiLCB3ZWlnaHQ6IFwiXCIsIHBob3RvRmlsZTogbnVsbFxuICB9KTtcbiAgY29uc3QgW3BldEVycm9yLCBzZXRQZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBbc2hvd0RlbGV0ZU1vZGFsLCBzZXRTaG93RGVsZXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZGVsZXRlUGFzc3dvcmQsIHNldERlbGV0ZVBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZGVsZXRlRXJyb3IsIHNldERlbGV0ZUVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZGVsZXRlU3RhdHVzLCBzZXREZWxldGVTdGF0dXNdID0gdXNlU3RhdGUoXCJpZGxlXCIpO1xuXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcbiAgICBzZXRQcm9maWxlKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB2YWx1ZSB9KSk7XG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBcIlwiIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTYXZlU2VjdGlvbiA9IGFzeW5jIChzZWN0aW9uVHlwZSkgPT4ge1xuICAgIGNvbnN0IGFsbEVycm9ycyA9IHZhbGlkYXRlUHJvZmlsZShwcm9maWxlKTtcbiAgICBsZXQgc2VjdGlvbkVycm9ycyA9IHt9O1xuXG4gICAgaWYgKHNlY3Rpb25UeXBlID09PSBcImFjY291bnRcIikge1xuICAgICAgaWYgKGFsbEVycm9ycy51c2VybmFtZSkgc2VjdGlvbkVycm9ycy51c2VybmFtZSA9IGFsbEVycm9ycy51c2VybmFtZTtcbiAgICAgIGlmIChhbGxFcnJvcnMuZW1haWwpIHNlY3Rpb25FcnJvcnMuZW1haWwgPSBhbGxFcnJvcnMuZW1haWw7XG4gICAgICBpZiAoYWxsRXJyb3JzLnRlbCkgc2VjdGlvbkVycm9ycy50ZWwgPSBhbGxFcnJvcnMudGVsO1xuICAgIH0gZWxzZSBpZiAoc2VjdGlvblR5cGUgPT09IFwiYWRkcmVzc1wiKSB7XG4gICAgICBpZiAoYWxsRXJyb3JzLmFkZHJlc3MpIHNlY3Rpb25FcnJvcnMuYWRkcmVzcyA9IGFsbEVycm9ycy5hZGRyZXNzO1xuICAgICAgaWYgKGFsbEVycm9ycy5wcm92aW5jZSkgc2VjdGlvbkVycm9ycy5wcm92aW5jZSA9IGFsbEVycm9ycy5wcm92aW5jZTtcbiAgICAgIGlmIChhbGxFcnJvcnMuZGlzdHJpY3QpIHNlY3Rpb25FcnJvcnMuZGlzdHJpY3QgPSBhbGxFcnJvcnMuZGlzdHJpY3Q7XG4gICAgICBpZiAoYWxsRXJyb3JzLnN1YmRpc3RyaWN0KSBzZWN0aW9uRXJyb3JzLnN1YmRpc3RyaWN0ID0gYWxsRXJyb3JzLnN1YmRpc3RyaWN0O1xuICAgICAgaWYgKGFsbEVycm9ycy5wb3N0YWxDb2RlKSBzZWN0aW9uRXJyb3JzLnBvc3RhbENvZGUgPSBhbGxFcnJvcnMucG9zdGFsQ29kZTtcbiAgICB9IGVsc2UgaWYgKHNlY3Rpb25UeXBlID09PSBcInNpdHRlclwiKSB7XG4gICAgICBpZiAoYWxsRXJyb3JzLmV4cGVyaWVuY2UgJiYgcHJvZmlsZS5leHBlcmllbmNlLnRyaW0oKSAhPT0gXCJcIikge1xuICAgICAgICBzZWN0aW9uRXJyb3JzLmV4cGVyaWVuY2UgPSBhbGxFcnJvcnMuZXhwZXJpZW5jZTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgYWNjb3VudE5hbWUgPSAocHJvZmlsZS5hY2NvdW50TmFtZSB8fCBcIlwiKS50cmltKCk7XG4gICAgICBpZiAoYWNjb3VudE5hbWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHNlY3Rpb25FcnJvcnMuYWNjb3VudE5hbWUgPSBcIuC4iuC4t+C5iOC4reC4muC4seC4jeC4iuC4teC4leC5ieC4reC4h+C5hOC4oeC5iOC5gOC4geC4tOC4mSAxMDAg4LiV4Lix4Lin4Lit4Lix4LiB4Lip4LijXCI7XG4gICAgICB9XG4gICAgICBpZiAoIWhhc1BheW1lbnRJbmZvKSB7XG4gICAgICAgIC8vIFBPU1QgL3NpdHRlci9wYXltZW50LWluZm8g4LiV4LmJ4Lit4LiH4Lih4Li14LiX4Lix4LmJ4LiH4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14LmB4Lil4LiwIFFSICjguJbguYnguLLguIHguKPguK3guIHguK3guKLguYjguLLguIfguYPguJTguK3guKLguYjguLLguIfguKvguJnguLbguYjguIfguYHguKXguYnguKcpXG4gICAgICAgIGlmIChxckZpbGUgfHwgYWNjb3VudE5hbWUpIHtcbiAgICAgICAgICBpZiAoIWFjY291bnROYW1lKSBzZWN0aW9uRXJyb3JzLmFjY291bnROYW1lID0gXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguIrguLfguYjguK3guJrguLHguI3guIrguLXguKPguLHguJrguYDguIfguLTguJlcIjtcbiAgICAgICAgICBpZiAoIXFyRmlsZSkgc2VjdGlvbkVycm9ycy5xckNvZGUgPSBcIuC4geC4o+C4uOC4k+C4suC4reC4seC4m+C5guC4q+C4peC4lOC4o+C4ueC4myBRUiBDb2RlXCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoIWFjY291bnROYW1lKSB7XG4gICAgICAgIC8vIFBBVENIIOC4leC5ieC4reC4h+C5hOC4oeC5iOC4peC5ieC4suC4h+C4iuC4t+C5iOC4reC4muC4seC4jeC4iuC4teC5g+C4q+C5ieC4p+C5iOC4suC4h1xuICAgICAgICBzZWN0aW9uRXJyb3JzLmFjY291bnROYW1lID0gXCLguIHguKPguLjguJPguLLguIHguKPguK3guIHguIrguLfguYjguK3guJrguLHguI3guIrguLXguKPguLHguJrguYDguIfguLTguJlcIjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzZXRFcnJvcnMoc2VjdGlvbkVycm9ycyk7XG5cbiAgICBpZiAoT2JqZWN0LmtleXMoc2VjdGlvbkVycm9ycykubGVuZ3RoID4gMCkgcmV0dXJuO1xuICAgIHNldFNhdmluZ1NlY3Rpb24oc2VjdGlvblR5cGUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICB1c2VybmFtZTogcHJvZmlsZS51c2VybmFtZSxcbiAgICAgICAgZW1haWw6IHByb2ZpbGUuZW1haWwsXG4gICAgICAgIHRlbDogcHJvZmlsZS50ZWwsXG4gICAgICAgIHByb3ZpbmNlOiBwcm9maWxlLnByb3ZpbmNlLFxuICAgICAgICBkaXN0cmljdDogcHJvZmlsZS5kaXN0cmljdCwgIFxuICAgICAgICBzdWJkaXN0cmljdDogcHJvZmlsZS5zdWJkaXN0cmljdCxcbiAgICAgICAgcG9zdGFsQ29kZTogcHJvZmlsZS5wb3N0YWxDb2RlLFxuICAgICAgICBhZGRyZXNzOiBwcm9maWxlLmFkZHJlc3MsXG4gICAgICAgIHJvbGU6IHByb2ZpbGUucm9sZSwgICAgICAgIFxuICAgICAgfTtcblxuICAgICAgaWYgKHByb2ZpbGUucm9sZSA9PT0gXCJzaXR0ZXJcIikge1xuICAgICAgICBwYXlsb2FkLmV4cGVyaWVuY2UgPSBwcm9maWxlLmV4cGVyaWVuY2U7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IGFwaS5wdXQoXCIvdXNlcnMvbWVcIiwgcGF5bG9hZCk7XG5cbiAgICAgIC8vIC91c2Vycy9tZSDguJrguLHguJnguJfguLbguIHguYHguKXguYnguKc6IHN5bmMgc25hcHNob3Qg4LiX4Lix4LiZ4LiX4Li1IOC5gOC4nuC4t+C5iOC4reC5g+C4q+C5iSBDYW5jZWwg4LmE4Lih4LmI4Lii4LmJ4Lit4LiZ4LiB4Lil4Lix4Lia4LmA4Lib4LmH4LiZ4LiE4LmI4Liy4LmA4LiB4LmI4LiyXG4gICAgICAvLyDguJbguYnguLLguJrguLHguJnguJfguLbguIHguILguYnguK3guKHguLnguKXguKPguLHguJrguYDguIfguLTguJnguKXguYnguKHguYDguKvguKXguKfguYPguJnguILguLHguYnguJnguJbguLHguJTguYTguJsgKOC5hOC4oeC5iOC5geC4leC4sCBhY2NvdW50TmFtZS9xckNvZGVVcmwg4LiX4Li14LmI4LmD4LiK4LmJ4LmA4LiX4Li14Lii4Lia4LiB4Liy4Lij4LmA4Lib4Lil4Li14LmI4Lii4LiZ4LmB4Lib4Lil4LiHKVxuICAgICAgc2V0T3JpZ2luYWxQcm9maWxlKChwcmV2KSA9PiAoeyAuLi5wcmV2LCAuLi5wYXlsb2FkIH0pKTtcbiAgICAgIGlmIChzZXRVc2VyKSBzZXRVc2VyKHsgLi4udXNlciwgLi4ucGF5bG9hZCwgcGV0cyB9KTtcblxuICAgICAgLy8g4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li1ICsgUVIg4Liq4LmI4LiH4LmB4Lii4LiBIGVuZHBvaW50IChtdWx0aXBhcnQpIOC4q+C4peC4seC4h+C4muC4seC4meC4l+C4tuC4geC4guC5ieC4reC4oeC4ueC4peC4q+C4peC4seC4geC4quC4s+C5gOC4o+C5h+C4iFxuICAgICAgbGV0IHNhdmVkUHJvZmlsZSA9IHByb2ZpbGU7XG4gICAgICBjb25zdCBhY2NvdW50TmFtZUNoYW5nZWQgPVxuICAgICAgICAocHJvZmlsZS5hY2NvdW50TmFtZSB8fCBcIlwiKS50cmltKCkgIT09IChvcmlnaW5hbFByb2ZpbGUuYWNjb3VudE5hbWUgfHwgXCJcIikudHJpbSgpO1xuICAgICAgaWYgKHNlY3Rpb25UeXBlID09PSBcInNpdHRlclwiICYmIChxckZpbGUgfHwgYWNjb3VudE5hbWVDaGFuZ2VkKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAgICAgZm9ybURhdGEuYXBwZW5kKFwiYWNjb3VudE5hbWVcIiwgcHJvZmlsZS5hY2NvdW50TmFtZS50cmltKCkpO1xuICAgICAgICAgIGlmIChxckZpbGUpIGZvcm1EYXRhLmFwcGVuZChcInFyQ29kZVwiLCBxckZpbGUpO1xuXG4gICAgICAgICAgY29uc3QgcGF5UmVzID0gaGFzUGF5bWVudEluZm9cbiAgICAgICAgICAgID8gYXdhaXQgYXBpLnBhdGNoKFwiL3NpdHRlci9wYXltZW50LWluZm9cIiwgZm9ybURhdGEpXG4gICAgICAgICAgICA6IGF3YWl0IGFwaS5wb3N0KFwiL3NpdHRlci9wYXltZW50LWluZm9cIiwgZm9ybURhdGEpO1xuICAgICAgICAgIGNvbnN0IHBheSA9IHBheVJlcy5kYXRhPy5kYXRhO1xuXG4gICAgICAgICAgc2F2ZWRQcm9maWxlID0ge1xuICAgICAgICAgICAgLi4ucHJvZmlsZSxcbiAgICAgICAgICAgIGFjY291bnROYW1lOiBwYXk/LmFjY291bnROYW1lID8/IHByb2ZpbGUuYWNjb3VudE5hbWUudHJpbSgpLFxuICAgICAgICAgICAgcXJDb2RlVXJsOiBwYXk/LnFyQ29kZVVybCB8fCBwcm9maWxlLnFyQ29kZVVybCxcbiAgICAgICAgICB9O1xuICAgICAgICAgIHNldFByb2ZpbGUoc2F2ZWRQcm9maWxlKTtcbiAgICAgICAgICBzZXRRckZpbGUobnVsbCk7XG4gICAgICAgICAgc2V0SGFzUGF5bWVudEluZm8odHJ1ZSk7XG4gICAgICAgIH0gY2F0Y2ggKHBheUVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIlBheW1lbnQgaW5mbyBzYXZlIGVycm9yOlwiLCBwYXlFcnJvcik7XG4gICAgICAgICAgdG9hc3QocGF5RXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCLguJrguLHguJnguJfguLbguIHguILguYnguK3guKHguLnguKXguKPguLHguJrguYDguIfguLTguJnguYTguKHguYjguKrguLPguYDguKPguYfguIgg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiHXCIsIFwiZXJyb3JcIik7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHVwZGF0ZWRVc2VyID0geyAuLi51c2VyLCAuLi5zYXZlZFByb2ZpbGUsIHBldHMgfTtcbiAgICAgIGlmIChzZXRVc2VyKSBzZXRVc2VyKHVwZGF0ZWRVc2VyKTtcbiAgICAgIHNldE9yaWdpbmFsUHJvZmlsZSh7IC4uLnNhdmVkUHJvZmlsZSB9KTtcbiAgICAgIHNldEVycm9ycyh7fSk7XG5cbiAgICAgIGlmIChzZWN0aW9uVHlwZSA9PT0gXCJhY2NvdW50XCIpIHNldElzRWRpdGluZ0FjY291bnQoZmFsc2UpO1xuICAgICAgaWYgKHNlY3Rpb25UeXBlID09PSBcImFkZHJlc3NcIikgc2V0SXNFZGl0aW5nQWRkcmVzcyhmYWxzZSk7XG4gICAgICBpZiAoc2VjdGlvblR5cGUgPT09IFwic2l0dGVyXCIpIHNldElzRWRpdGluZ1NpdHRlcihmYWxzZSk7XG4gICAgICBcbiAgICAgIHRvYXN0KFwi4Lia4Lix4LiZ4LiX4Li24LiB4LiC4LmJ4Lit4Lih4Li54Lil4Liq4Liz4LmA4Lij4LmH4LiIXCIpO1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTYXZlIGVycm9yOlwiLCBlcnJvcik7XG4gICAgICB0b2FzdChcIuC5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4muC4seC4meC4l+C4tuC4geC4guC5ieC4reC4oeC4ueC4peC5hOC4lOC5iSDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIiwgXCJlcnJvclwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nU2VjdGlvbihudWxsKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2FuY2VsU2VjdGlvbiA9IChzZWN0aW9uVHlwZSkgPT4ge1xuICAgIHNldFByb2ZpbGUoeyAuLi5vcmlnaW5hbFByb2ZpbGUgfSk7XG4gICAgc2V0RXJyb3JzKHt9KTtcbiAgICBpZiAoc2VjdGlvblR5cGUgPT09IFwic2l0dGVyXCIpIHNldFFyRmlsZShudWxsKTtcbiAgICBpZiAoc2VjdGlvblR5cGUgPT09IFwiYWNjb3VudFwiKSBzZXRJc0VkaXRpbmdBY2NvdW50KGZhbHNlKTtcbiAgICBpZiAoc2VjdGlvblR5cGUgPT09IFwiYWRkcmVzc1wiKSBzZXRJc0VkaXRpbmdBZGRyZXNzKGZhbHNlKTtcbiAgICBpZiAoc2VjdGlvblR5cGUgPT09IFwic2l0dGVyXCIpIHNldElzRWRpdGluZ1NpdHRlcihmYWxzZSk7XG4gIH07XG5cbiAgY29uc3Qgb3BlbkFkZFBldE1vZGFsID0gKCkgPT4ge1xuICAgIHNldEN1cnJlbnRQZXRJbmRleChudWxsKTtcbiAgICBzZXRNb2RhbE1vZGUoXCJhZGRcIik7XG4gICAgc2V0QWN0aXZlUGV0Rm9ybSh7XG4gICAgICBwZXRJZDogbnVsbCxcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICBzcGVjaWVzOiBcIuC4quC4uOC4meC4seC4glwiLCAvLyBEZWZhdWx0IHRvIOC4quC4uOC4meC4seC4glxuICAgICAgYnJlZWQ6IFwiXCIsXG4gICAgICBhZ2U6IFwiXCIsXG4gICAgICBwaG90bzogXCJcIixcbiAgICAgIG5vdGVzOiBcIlwiLFxuICAgICAgZ2VuZGVyOiBcIlwiLFxuICAgICAgd2VpZ2h0OiBcIlwiLFxuICAgICAgcGhvdG9GaWxlOiBudWxsLFxuICAgIH0pO1xuICAgIHNldFBldEVycm9yKFwiXCIpO1xuICAgIHNldFNob3dQZXRNb2RhbCh0cnVlKTtcbiAgfTtcblxuICBjb25zdCBvcGVuVmlld1BldE1vZGFsID0gKGluZGV4KSA9PiB7XG4gICAgc2V0Q3VycmVudFBldEluZGV4KGluZGV4KTtcbiAgICBzZXRNb2RhbE1vZGUoXCJ2aWV3XCIpO1xuICAgIHNldEFjdGl2ZVBldEZvcm0oeyAuLi5wZXRzW2luZGV4XSB9KTtcbiAgICBzZXRQZXRFcnJvcihcIlwiKTtcbiAgICBzZXRTaG93UGV0TW9kYWwodHJ1ZSk7XG4gIH07XG5cbiAgY29uc3Qgb3BlbkVkaXRQZXRNb2RhbCA9IChpbmRleCkgPT4ge1xuICAgIHNldEN1cnJlbnRQZXRJbmRleChpbmRleCk7XG4gICAgc2V0TW9kYWxNb2RlKFwiZWRpdFwiKTtcbiAgICBzZXRBY3RpdmVQZXRGb3JtKHsgLi4ucGV0c1tpbmRleF0gfSk7XG4gICAgc2V0UGV0RXJyb3IoXCJcIik7XG4gICAgc2V0U2hvd1BldE1vZGFsKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVQZXQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFhY3RpdmVQZXRGb3JtLm5hbWUudHJpbSgpKSB7XG4gICAgICBzZXRQZXRFcnJvcihcIuC4geC4o+C4uOC4k+C4suC4geC4o+C4reC4geC4iuC4t+C5iOC4reC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h1wiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1NhdmluZ1BldCh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgICAgIGZvcm1EYXRhLmFwcGVuZChcIm5hbWVcIiwgYWN0aXZlUGV0Rm9ybS5uYW1lLnRyaW0oKSk7XG4gICAgICBpZiAoYWN0aXZlUGV0Rm9ybS5zcGVjaWVzKSBmb3JtRGF0YS5hcHBlbmQoXCJzcGVjaWVzXCIsIGFjdGl2ZVBldEZvcm0uc3BlY2llcy50cmltKCkpO1xuICAgICAgaWYgKGFjdGl2ZVBldEZvcm0uYnJlZWQpIGZvcm1EYXRhLmFwcGVuZChcImJyZWVkXCIsIGFjdGl2ZVBldEZvcm0uYnJlZWQudHJpbSgpKTtcbiAgICAgIGlmIChhY3RpdmVQZXRGb3JtLmdlbmRlcikgZm9ybURhdGEuYXBwZW5kKFwiZ2VuZGVyXCIsIGFjdGl2ZVBldEZvcm0uZ2VuZGVyLnRyaW0oKSk7XG4gICAgICBpZiAoYWN0aXZlUGV0Rm9ybS53ZWlnaHQpIGZvcm1EYXRhLmFwcGVuZChcIndlaWdodFwiLCBhY3RpdmVQZXRGb3JtLndlaWdodCk7IFxuICAgICAgaWYgKGFjdGl2ZVBldEZvcm0uYWdlKSBmb3JtRGF0YS5hcHBlbmQoXCJhZ2VcIiwgYWN0aXZlUGV0Rm9ybS5hZ2UpO1xuICAgICAgaWYgKGFjdGl2ZVBldEZvcm0ubm90ZXMpIGZvcm1EYXRhLmFwcGVuZChcIm5vdGVzXCIsIGFjdGl2ZVBldEZvcm0ubm90ZXMudHJpbSgpKTtcblxuICAgICAgaWYgKGFjdGl2ZVBldEZvcm0ucGhvdG9GaWxlKSB7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZChcInBob3RvXCIsIGFjdGl2ZVBldEZvcm0ucGhvdG9GaWxlKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHNhdmVkUGV0O1xuXG4gICAgICBpZiAobW9kYWxNb2RlID09PSBcImFkZFwiKSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5wb3N0KFwiL3BldHNcIiwgZm9ybURhdGEpO1xuICAgICAgICBzYXZlZFBldCA9IHJlcy5kYXRhO1xuICAgICAgfSBlbHNlIGlmIChtb2RhbE1vZGUgPT09IFwiZWRpdFwiICYmIGFjdGl2ZVBldEZvcm0ucGV0SWQpIHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBhdGNoKGAvcGV0cy8ke2FjdGl2ZVBldEZvcm0ucGV0SWR9YCwgZm9ybURhdGEpO1xuICAgICAgICBzYXZlZFBldCA9IHJlcy5kYXRhO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBwcm9maWxlUmVzID0gYXdhaXQgYXBpLmdldChcIi91c2Vycy9tZVwiKTtcbiAgICAgIGNvbnN0IGxhdGVzdFBldHMgPSBwcm9maWxlUmVzLmRhdGE/LmRhdGE/LnBldHMgfHwgW107XG4gICAgICBcbiAgICAgIGNvbnN0IG1hcHBlZFBldHMgPSBsYXRlc3RQZXRzLm1hcCgocCkgPT4gKHtcbiAgICAgICAgcGV0SWQ6IHAucGV0SWQgfHwgcC5wZXRpZCB8fCBwLmlkIHx8IG51bGwsXG4gICAgICAgIG5hbWU6IHAubmFtZSB8fCBcIlwiLFxuICAgICAgICBzcGVjaWVzOiBwLnNwZWNpZXMgfHwgXCJcIixcbiAgICAgICAgYnJlZWQ6IHAuYnJlZWQgfHwgXCJcIixcbiAgICAgICAgZ2VuZGVyOiBwLmdlbmRlciB8fCBcIlwiLCBcbiAgICAgICAgd2VpZ2h0OiBwLndlaWdodCB8fCBcIlwiLFxuICAgICAgICBhZ2U6IHAuYWdlICE9PSBudWxsICYmIHAuYWdlICE9PSB1bmRlZmluZWQgPyBwLmFnZSA6IFwiXCIsXG4gICAgICAgIHBob3RvOiBwLmltYWdlVXJsIHx8IHAucGhvdG8gfHwgXCJcIixcbiAgICAgICAgbm90ZXM6IHAuYWxsZXJneSB8fCBwLm5vdGVzIHx8IFwiXCIsXG4gICAgICB9KSk7XG5cbiAgICAgIHNldFBldHMobWFwcGVkUGV0cyk7XG4gICAgICBpZiAoc2V0VXNlcikge1xuICAgICAgICBzZXRVc2VyKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwZXRzOiBtYXBwZWRQZXRzIH0pKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgc2V0U2hvd1BldE1vZGFsKGZhbHNlKTtcbiAgICAgIHRvYXN0KFwi4Lia4Lix4LiZ4LiX4Li24LiB4LiC4LmJ4Lit4Lih4Li54Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Liz4LmA4Lij4LmH4LiIXCIpO1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJTYXZlIHBldCBlcnJvcjpcIiwgZXJyb3IpO1xuICAgICAgaWYgKGVycm9yLnJlc3BvbnNlPy5zdGF0dXMgPT09IDQwOSkge1xuICAgICAgICBzZXRQZXRFcnJvcihcIuC4hOC4uOC4k+C4oeC4teC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4iuC4t+C5iOC4reC4meC4teC5ieC4reC4ouC4ueC5iOC5geC4peC5ieC4pyDguIHguKPguLjguJPguLLguYPguIrguYnguIrguLfguYjguK3guK3guLfguYjguJlcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRQZXRFcnJvcihg4Lia4Lix4LiZ4LiX4Li24LiB4LmE4Lih4LmI4Liq4Liz4LmA4Lij4LmH4LiIOiAke2Vycm9yLnJlc3BvbnNlPy5zdGF0dXMgfHwgXCJBUEkg4Lit4Liy4LiI4LiI4Liw4Lii4Lix4LiH4LmE4Lih4LmI4Lie4Lij4LmJ4Lit4LihXCJ9YCk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzU2F2aW5nUGV0KGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVtb3ZlQ3VycmVudE1vZGFsUGV0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChjdXJyZW50UGV0SW5kZXggIT09IG51bGwpIHtcbiAgICAgIGlmICghd2luZG93LmNvbmZpcm0oXCLguITguLjguJPguJXguYnguK3guIfguIHguLLguKPguKXguJrguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguJnguLXguYnguYPguIrguYjguKvguKPguLfguK3guYTguKHguYg/XCIpKSByZXR1cm47XG4gICAgICBjb25zdCB0YXJnZXRQZXQgPSBwZXRzW2N1cnJlbnRQZXRJbmRleF07XG4gICAgICBzZXRJc0RlbGV0aW5nUGV0KHRydWUpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8g4Lii4Li04LiHIEFQSSDguKXguJrguILguYnguK3guKHguLnguKXguKvguKXguLHguIfguJrguYnguLLguJkgKOC4luC5ieC4suC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4meC4teC5ieC5gOC4hOC4ouC4luC4ueC4geC4muC4seC4meC4l+C4tuC4geC5geC4peC5ieC4p+C5geC4peC4sOC4oeC4tSBwZXRJZClcbiAgICAgICAgaWYgKHRhcmdldFBldC5wZXRJZCkge1xuICAgICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9wZXRzLyR7dGFyZ2V0UGV0LnBldElkfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g4Lil4Lia4Lit4Lit4LiB4LiI4Liy4LiB4Lir4LiZ4LmJ4Liy4LiI4LitXG4gICAgICAgIGNvbnN0IHVwZGF0ZWRQZXRzID0gcGV0cy5maWx0ZXIoKF8sIGluZGV4KSA9PiBpbmRleCAhPT0gY3VycmVudFBldEluZGV4KTtcbiAgICAgICAgc2V0UGV0cyh1cGRhdGVkUGV0cyk7XG4gICAgICAgIGlmIChzZXRVc2VyKSB7XG4gICAgICAgICAgc2V0VXNlcigocHJldikgPT4gKHsgLi4ucHJldiwgcGV0czogdXBkYXRlZFBldHMgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHNldFNob3dQZXRNb2RhbChmYWxzZSk7XG4gICAgICAgIFxuICAgICAgICB0b2FzdChcIuC4peC4muC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4quC4s+C5gOC4o+C5h+C4iFwiKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJEZWxldGUgcGV0IGVycm9yOlwiLCBlcnJvcik7XG4gICAgICAgIHRvYXN0KFwi4LmE4Lih4LmI4Liq4Liy4Lih4Liy4Lij4LiW4Lil4Lia4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LmE4LiU4LmJXCIsIFwiZXJyb3JcIik7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzZXRJc0RlbGV0aW5nUGV0KGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldERlbGV0ZUVycm9yKFwiXCIpO1xuICAgIGlmICghZGVsZXRlUGFzc3dvcmQudHJpbSgpKSB7XG4gICAgICBzZXREZWxldGVFcnJvcihcIuC4geC4o+C4uOC4k+C4suC4geC4o+C4reC4geC4o+C4q+C4seC4quC4nOC5iOC4suC4mVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0RGVsZXRlU3RhdHVzKFwic3VibWl0dGluZ1wiKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShcIi9hdXRoL2FjY291bnRcIiwgeyBkYXRhOiB7IHBhc3N3b3JkOiBkZWxldGVQYXNzd29yZCB9IH0pO1xuICAgICAgc2V0U2hvd0RlbGV0ZU1vZGFsKGZhbHNlKTtcbiAgICAgIGxvZ291dCgpOyBcbiAgICAgIG5hdmlnYXRlKFwiL3JlZ2lzdGVyXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RGVsZXRlRXJyb3IoZXJyLnJlc3BvbnNlPy5zdGF0dXMgPT09IDQwMSA/IFwi4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4LmE4Lih4LmI4LiW4Li54LiB4LiV4LmJ4Lit4LiHXCIgOiBcIuC5hOC4oeC5iOC4quC4suC4oeC4suC4o+C4luC4peC4muC4muC4seC4jeC4iuC4teC5hOC4lOC5iSDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldERlbGV0ZVN0YXR1cyhcImlkbGVcIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHJlbmRlclNlY3Rpb25IZWFkZXIgPSAodGl0bGUsIGlzRWRpdGluZywgb25FZGl0LCBvbkNhbmNlbCwgb25TYXZlLCBpc1NhdmluZyA9IGZhbHNlKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXNlY3Rpb24taGVhZGVyXCI+XG4gICAgICA8aDI+e3RpdGxlfTwvaDI+XG4gICAgICB7IWlzRWRpdGluZyA/IChcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1zYXZlLWJ1dHRvblwiIG9uQ2xpY2s9e29uRWRpdH0+XG4gICAgICAgICAg4LmB4LiB4LmJ4LmE4LiCXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjhweFwiIH19PlxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWNhbmNlbC1idXR0b25cIiBcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOC4ouC4geC5gOC4peC4tOC4gVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLXNhdmUtYnV0dG9uXCIgXG4gICAgICAgICAgICBvbkNsaWNrPXtvblNhdmV9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNTYXZpbmd9XG4gICAgICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiBcImlubGluZS1mbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLCBnYXA6IFwiNnB4XCIsIG1pbldpZHRoOiBcIjkwcHhcIiB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc1NhdmluZyAmJiA8c3BhbiBjbGFzc05hbWU9XCJzcGlubmVyXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PC9zcGFuPn1cbiAgICAgICAgICAgIDxzcGFuPntpc1NhdmluZyA/IFwi4LiB4Liz4Lil4Lix4LiH4Lia4Lix4LiZ4LiX4Li24LiB4oCmXCIgOiBcIuC4muC4seC4meC4l+C4tuC4gVwifTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxOYXZiYXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInByb2ZpbGUtbWFpblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtY2FyZFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXJcIj5cbiAgICAgICAgICAgIHsocHJvZmlsZS51c2VybmFtZSB8fCBcIlVcIikuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgxPuC5guC4m+C4o+C5hOC4n+C4peC5jOC4guC4reC4h+C4ieC4seC4mTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJvZmlsZS1yb2xlXCI+XG4gICAgICAgICAgICB7aXNTaXR0ZXIgPyBcIvCfkL4g4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmMXCIgOiBcIvCfkLYg4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCJ9XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uXCI+XG4gICAgICAgICAgICB7cmVuZGVyU2VjdGlvbkhlYWRlcihcbiAgICAgICAgICAgICAgXCLguILguYnguK3guKHguLnguKXguJrguLHguI3guIrguLVcIixcbiAgICAgICAgICAgICAgaXNFZGl0aW5nQWNjb3VudCxcbiAgICAgICAgICAgICAgKCkgPT4geyBzZXRPcmlnaW5hbFByb2ZpbGUoeyAuLi5wcm9maWxlIH0pOyBzZXRJc0VkaXRpbmdBY2NvdW50KHRydWUpOyB9LFxuICAgICAgICAgICAgICAoKSA9PiBoYW5kbGVDYW5jZWxTZWN0aW9uKFwiYWNjb3VudFwiKSxcbiAgICAgICAgICAgICAgKCkgPT4gaGFuZGxlU2F2ZVNlY3Rpb24oXCJhY2NvdW50XCIpLFxuICAgICAgICAgICAgICBzYXZpbmdTZWN0aW9uID09PSBcImFjY291bnRcIlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguIrguLfguYjguK3guJzguLnguYnguYPguIrguYlcIiBmaWVsZD1cInVzZXJuYW1lXCIgdmFsdWU9e3Byb2ZpbGUudXNlcm5hbWV9IGlzRWRpdGluZz17aXNFZGl0aW5nQWNjb3VudH0gZXJyb3I9e2Vycm9ycy51c2VybmFtZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gLz5cbiAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguK3guLXguYDguKHguKVcIiBmaWVsZD1cImVtYWlsXCIgdHlwZT1cImVtYWlsXCIgdmFsdWU9e3Byb2ZpbGUuZW1haWx9IGlzRWRpdGluZz17aXNFZGl0aW5nQWNjb3VudH0gZXJyb3I9e2Vycm9ycy5lbWFpbH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gLz5cbiAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguYDguJrguK3guKPguYzguYLguJfguKNcIiBmaWVsZD1cInRlbFwiIHR5cGU9XCJ0ZWxcIiB2YWx1ZT17cHJvZmlsZS50ZWx9IGlzRWRpdGluZz17aXNFZGl0aW5nQWNjb3VudH0gZXJyb3I9e2Vycm9ycy50ZWx9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IC8+XG4gICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uXCI+XG4gICAgICAgICAgICB7cmVuZGVyU2VjdGlvbkhlYWRlcihcbiAgICAgICAgICAgICAgXCLguILguYnguK3guKHguLnguKXguJfguLXguYjguK3guKLguLnguYhcIixcbiAgICAgICAgICAgICAgaXNFZGl0aW5nQWRkcmVzcyxcbiAgICAgICAgICAgICAgKCkgPT4geyBzZXRPcmlnaW5hbFByb2ZpbGUoeyAuLi5wcm9maWxlIH0pOyBzZXRJc0VkaXRpbmdBZGRyZXNzKHRydWUpOyB9LFxuICAgICAgICAgICAgICAoKSA9PiBoYW5kbGVDYW5jZWxTZWN0aW9uKFwiYWRkcmVzc1wiKSxcbiAgICAgICAgICAgICAgKCkgPT4gaGFuZGxlU2F2ZVNlY3Rpb24oXCJhZGRyZXNzXCIpLFxuICAgICAgICAgICAgICBzYXZpbmdTZWN0aW9uID09PSBcImFkZHJlc3NcIlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHshaXNFZGl0aW5nQWRkcmVzcyA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8UHJvZmlsZUZpZWxkIGxhYmVsPVwi4Lij4Liy4Lii4Lil4Liw4LmA4Lit4Li14Lii4LiU4LiX4Li14LmI4Lit4Lii4Li54LmIXCIgZmllbGQ9XCJhZGRyZXNzXCIgdmFsdWU9e3Byb2ZpbGUuYWRkcmVzc30gaXNFZGl0aW5nPXtmYWxzZX0gLz5cbiAgICAgICAgICAgICAgICA8UHJvZmlsZUZpZWxkIGxhYmVsPVwi4LiI4Lix4LiH4Lir4Lin4Lix4LiUXCIgZmllbGQ9XCJwcm92aW5jZVwiIHZhbHVlPXtwcm9maWxlLnByb3ZpbmNlfSBpc0VkaXRpbmc9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguYDguKHguLfguK3guIcv4Lit4Liz4LmA4Lig4LitXCIgZmllbGQ9XCJkaXN0cmljdFwiIHZhbHVlPXtwcm9maWxlLmRpc3RyaWN0fSBpc0VkaXRpbmc9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguJXguLPguJrguKUv4LmB4LiC4Lin4LiHXCIgZmllbGQ9XCJzdWJkaXN0cmljdFwiIHZhbHVlPXtwcm9maWxlLnN1YmRpc3RyaWN0fSBpc0VkaXRpbmc9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguKPguKvguLHguKrguYTguJvguKPguKnguJPguLXguKLguYxcIiBmaWVsZD1cInBvc3RhbENvZGVcIiB2YWx1ZT17cHJvZmlsZS5wb3N0YWxDb2RlfSBpc0VkaXRpbmc9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1lZGl0LWFkZHJlc3MtZ3JpZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1yb3dcIiBzdHlsZT17eyBncmlkQ29sdW1uOiBcIjEgLyAtMVwiIH19PiBcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbGFiZWxcIj7guKPguLLguKLguKXguLDguYDguK3guLXguKLguJTguJfguLXguYjguK3guKLguLnguYggKOC4muC5ieC4suC4meC5gOC4peC4guC4l+C4teC5iCwg4Lir4Lih4Li54LmILCDguIvguK3guKIsIOC4luC4meC4mSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHJvZmlsZS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJvZmlsZS5hZGRyZXNzfSBcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoXCJhZGRyZXNzXCIsIGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4LmA4LiK4LmI4LiZIDEyMy80NSDguIsu4Liq4Li44LiC4Li44Lih4Lin4Li04LiXIDEg4LiWLuC4quC4uOC4guC4uOC4oeC4p+C4tOC4l1wiIFxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkZHJlc3MgJiYgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1lcnJvclwiPntlcnJvcnMuYWRkcmVzc308L3NwYW4+fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1yb3dcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbGFiZWxcIj7guIjguLHguIfguKvguKfguLHguJQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtaW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgbGlzdD1cInByb3ZpbmNlLWxpc3RcIiBcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGUucHJvdmluY2V9IFxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUHJvdmluY2VDaGFuZ2V9IFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC4nuC4tOC4oeC4nuC5jOC4q+C4o+C4t+C4reC5gOC4peC4t+C4reC4geC4iOC4seC4h+C4q+C4p+C4seC4lC4uLlwiIFxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkYXRhbGlzdCBpZD1cInByb3ZpbmNlLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgICAge3Byb3ZpbmNlc0RhdGEubWFwKChwcm92KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Byb3YuaWR9IHZhbHVlPXtwcm92Lm5hbWVfdGh9IC8+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kYXRhbGlzdD5cbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucHJvdmluY2UgJiYgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1lcnJvclwiPntlcnJvcnMucHJvdmluY2V9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1yb3dcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtbGFiZWxcIj7guYDguKHguLfguK3guIcv4Lit4Liz4LmA4Lig4LitPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgIGxpc3Q9XCJkaXN0cmljdC1saXN0XCIgXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwcm9maWxlLmRpc3RyaWN0fSBcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURpc3RyaWN0Q2hhbmdlfSBcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFwcm9maWxlLnByb3ZpbmNlfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuC4nuC4tOC4oeC4nuC5jOC4q+C4o+C4t+C4reC5gOC4peC4t+C4reC4geC4reC4s+C5gOC4oOC4rS4uLlwiIFxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxkYXRhbGlzdCBpZD1cImRpc3RyaWN0LWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgeyhhdmFpbGFibGVEaXN0cmljdHMgfHwgW10pLm1hcCgoZGlzdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtkaXN0LmlkfSB2YWx1ZT17ZGlzdC5uYW1lX3RofSAvPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGF0YWxpc3Q+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRpc3RyaWN0ICYmIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtZXJyb3JcIj57ZXJyb3JzLmRpc3RyaWN0fTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCI+4LiV4Liz4Lia4LilL+C5geC4guC4p+C4hzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHJvZmlsZS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICBsaXN0PVwic3ViLWxpc3RcIiBcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Byb2ZpbGUuc3ViZGlzdHJpY3R9IFxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU3ViZGlzdHJpY3RDaGFuZ2V9IFxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXByb2ZpbGUuZGlzdHJpY3R9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4Lie4Li04Lih4Lie4LmM4Lir4Lij4Li34Lit4LmA4Lil4Li34Lit4LiB4LiV4Liz4Lia4LilLi4uXCIgXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRhdGFsaXN0IGlkPVwic3ViLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgeyhhdmFpbGFibGVTdWJkaXN0cmljdHMgfHwgW10pLm1hcCgoc3ViKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N1Yi5pZH0gdmFsdWU9e3N1Yi5uYW1lX3RofSAvPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGF0YWxpc3Q+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN1YmRpc3RyaWN0ICYmIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtZXJyb3JcIj57ZXJyb3JzLnN1YmRpc3RyaWN0fTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLWxhYmVsXCI+4Lij4Lir4Lix4Liq4LmE4Lib4Lij4Lip4LiT4Li14Lii4LmMPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgIGxpc3Q9XCJ6aXAtbGlzdFwiIFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJvZmlsZS5wb3N0YWxDb2RlfSBcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoXCJwb3N0YWxDb2RlXCIsIGUudGFyZ2V0LnZhbHVlKX0gXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshcHJvZmlsZS5zdWJkaXN0cmljdH1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLguKPguKvguLHguKrguYTguJvguKPguKnguJPguLXguKLguYxcIiBcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGF0YWxpc3QgaWQ9XCJ6aXAtbGlzdFwiPlxuICAgICAgICAgICAgICAgICAgICB7KGF2YWlsYWJsZVppcGNvZGVzIHx8IFtdKS5tYXAoKHppcCwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2lkeH0gdmFsdWU9e3ppcH0gLz5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2RhdGFsaXN0PlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wb3N0YWxDb2RlICYmIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtZXJyb3JcIj57ZXJyb3JzLnBvc3RhbENvZGV9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgIHtpc1NpdHRlciAmJiAoXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwcm9maWxlLXNlY3Rpb25cIj5cbiAgICAgICAgICAgICAge3JlbmRlclNlY3Rpb25IZWFkZXIoXG4gICAgICAgICAgICAgICAgXCLguILguYnguK3guKHguLnguKXguJ7guLXguYjguYDguKXguLXguYnguKLguIfguKrguLHguJXguKfguYxcIixcbiAgICAgICAgICAgICAgICBpc0VkaXRpbmdTaXR0ZXIsXG4gICAgICAgICAgICAgICAgKCkgPT4geyBzZXRPcmlnaW5hbFByb2ZpbGUoeyAuLi5wcm9maWxlIH0pOyBzZXRJc0VkaXRpbmdTaXR0ZXIodHJ1ZSk7IH0sXG4gICAgICAgICAgICAgICAgKCkgPT4gaGFuZGxlQ2FuY2VsU2VjdGlvbihcInNpdHRlclwiKSxcbiAgICAgICAgICAgICAgICAoKSA9PiBoYW5kbGVTYXZlU2VjdGlvbihcInNpdHRlclwiKSxcbiAgICAgICAgICAgICAgICBzYXZpbmdTZWN0aW9uID09PSBcInNpdHRlclwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxQcm9maWxlRmllbGQgbGFiZWw9XCLguJvguKPguLDguKrguJrguIHguLLguKPguJPguYxcIiBmaWVsZD1cImV4cGVyaWVuY2VcIiB2YWx1ZT17cHJvZmlsZS5leHBlcmllbmNlfSBpc0VkaXRpbmc9e2lzRWRpdGluZ1NpdHRlcn0gZXJyb3I9e2Vycm9ycy5leHBlcmllbmNlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHJvZmlsZS1sYWJlbFwiPuC5gOC4peC4guC4muC4seC4leC4o+C4m+C4o+C4sOC4iuC4suC4iuC4mTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwcm9maWxlLXZhbHVlXCI+e3Byb2ZpbGUudGhhaUlkID8gYCoqKioqKioqKiR7cHJvZmlsZS50aGFpSWQuc2xpY2UoLTQpfWAgOiBcIi1cIn08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8UHJvZmlsZUZpZWxkIGxhYmVsPVwi4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14Lij4Lix4Lia4LmA4LiH4Li04LiZXCIgZmllbGQ9XCJhY2NvdW50TmFtZVwiIHZhbHVlPXtwcm9maWxlLmFjY291bnROYW1lfSBpc0VkaXRpbmc9e2lzRWRpdGluZ1NpdHRlcn0gZXJyb3I9e2Vycm9ycy5hY2NvdW50TmFtZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gLz5cbiAgICAgICAgICAgICAgPFNpdHRlclFyVXBsb2FkXG4gICAgICAgICAgICAgICAgcXJDb2RlVXJsPXtwcm9maWxlLnFyQ29kZVVybH1cbiAgICAgICAgICAgICAgICBpc0VkaXRpbmc9e2lzRWRpdGluZ1NpdHRlcn1cbiAgICAgICAgICAgICAgICBmaWxlPXtxckZpbGV9XG4gICAgICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5xckNvZGV9XG4gICAgICAgICAgICAgICAgb25TZWxlY3RGaWxlPXsoZikgPT4geyBzZXRRckZpbGUoZik7IHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgcXJDb2RlOiBcIlwiIH0pKTsgfX1cbiAgICAgICAgICAgICAgICBvblJlbW92ZT17KCkgPT4gc2V0UXJGaWxlKG51bGwpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7IWlzU2l0dGVyICYmIChcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInByb2ZpbGUtc2VjdGlvblwiIHN0eWxlPXt7IGJvcmRlclRvcDogXCIycHggc29saWQgI2VlZVwiLCBwYWRkaW5nVG9wOiBcIjIwcHhcIiB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgPGgyPuC4guC5ieC4reC4oeC4ueC4peC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4hzwvaDI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1zYXZlLWJ1dHRvblwiIG9uQ2xpY2s9e29wZW5BZGRQZXRNb2RhbH0+XG4gICAgICAgICAgICAgICAgICArIOC5gOC4nuC4tOC5iOC4oeC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICB7cGV0cyAmJiBwZXRzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICBwZXRzLm1hcCgocGV0LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IHN0eWxlPXt7IGJhY2tncm91bmQ6IFwiI2Y5ZjlmOVwiLCBwYWRkaW5nOiBcIjEwcHggMTRweFwiLCBib3JkZXJSYWRpdXM6IFwiOHB4XCIsIG1hcmdpbkJvdHRvbTogXCI4cHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjZWFlYWVhXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiBcIjEycHhcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXQucGhvdG8gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtwZXQucGhvdG99IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17cGV0Lm5hbWV9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7IGUudGFyZ2V0LnNyYyA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2NoYXJzZXQ9VVRGLTgsJTNDc3ZnIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Zycgd2lkdGg9JzEwMCcgaGVpZ2h0PScxMDAnIHN0eWxlPSdiYWNrZ3JvdW5kOiUyM2VlZTsnJTNFJTNDdGV4dCB4PSc1MCUyNScgeT0nNTAlMjUnIGZvbnQtc2l6ZT0nNDAnIHRleHQtYW5jaG9yPSdtaWRkbGUnIGR5PScuMzVlbSclM0UlMjYlMjMxMjgwNjIlM0IlM0MvdGV4dCUzRSUzQy9zdmclM0VcIjsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCI0MHB4XCIsIGhlaWdodDogXCI0MHB4XCIsIGJvcmRlclJhZGl1czogXCI1MCVcIiwgb2JqZWN0Rml0OiBcImNvdmVyXCIsIGJvcmRlcjogXCIxcHggc29saWQgI2NjY1wiIH19IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogXCI0MHB4XCIsIGhlaWdodDogXCI0MHB4XCIsIGJvcmRlclJhZGl1czogXCI1MCVcIiwgYmFja2dyb3VuZDogXCIjZWVlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiwgZm9udFNpemU6IFwiMjBweFwiIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfkL5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMTVweFwiLCBmb250V2VpZ2h0OiBcIjYwMFwiIH19PntwZXQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjZweFwiIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1lZGl0LWJ1dHRvbiBwZXQtYnRuLXNtXCIgb25DbGljaz17KCkgPT4gb3BlblZpZXdQZXRNb2RhbChpbmRleCl9IHRpdGxlPVwi4LiU4Li54LiC4LmJ4Lit4Lih4Li54LilXCI+8J+UjTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1lZGl0LWJ1dHRvbiBwZXQtYnRuLXNtIHBldC1idG4td2FybmluZ1wiIG9uQ2xpY2s9eygpID0+IG9wZW5FZGl0UGV0TW9kYWwoaW5kZXgpfSB0aXRsZT1cIuC5geC4geC5ieC5hOC4guC4guC5ieC4reC4oeC4ueC4pVwiPvCflovvuI88L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtdmFsdWVcIiBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIHRleHRBbGlnbjogXCJjZW50ZXJcIiwgY29sb3I6IFwiIzg4OFwiIH19Pi0g4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14LiC4LmJ4Lit4Lih4Li54Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHIC08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWFjdGlvbnNcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiMjBweFwiIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWFjdGlvbnMtcm93XCI+XG4gICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInByb2ZpbGUtZGVsZXRlLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RGVsZXRlUGFzc3dvcmQoXCJcIik7IHNldERlbGV0ZUVycm9yKFwiXCIpOyBzZXREZWxldGVTdGF0dXMoXCJpZGxlXCIpOyBzZXRTaG93RGVsZXRlTW9kYWwodHJ1ZSk7IH19PlxuICAgICAgICAgICAgICAgIOC4peC4muC4muC4seC4jeC4iuC4tVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicHJvZmlsZS1jb25maXJtLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFwiL1wiKX0+XG4gICAgICAgICAgICAgIOC4ouC4t+C4meC4ouC4seC4meC4q+C4meC5ieC4suC4q+C4peC4seC4gVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtzaG93UGV0TW9kYWwgJiYgKFxuICAgICAgICAgIDxQZXRNb2RhbFxuICAgICAgICAgICAgcGV0PXthY3RpdmVQZXRGb3JtfVxuICAgICAgICAgICAgbW9kZT17bW9kYWxNb2RlfVxuICAgICAgICAgICAgZXJyb3I9e3BldEVycm9yfVxuICAgICAgICAgICAgaXNTYXZpbmc9e2lzU2F2aW5nUGV0fVxuICAgICAgICAgICAgaXNEZWxldGluZz17aXNEZWxldGluZ1BldH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgIHNldEFjdGl2ZVBldEZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IHZhbHVlIH0pKTtcbiAgICAgICAgICAgICAgaWYgKGZpZWxkID09PSBcIm5hbWVcIikgc2V0UGV0RXJyb3IoXCJcIik7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoIWlzU2F2aW5nUGV0ICYmICFpc0RlbGV0aW5nUGV0KSB7XG4gICAgICAgICAgICAgICAgc2V0U2hvd1BldE1vZGFsKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBzZXRQZXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uU2F2ZT17aGFuZGxlU2F2ZVBldH1cbiAgICAgICAgICAgIG9uRGVsZXRlPXtoYW5kbGVSZW1vdmVDdXJyZW50TW9kYWxQZXR9XG4gICAgICAgICAgICBvblN3aXRjaFRvRWRpdD17KCkgPT4gc2V0TW9kYWxNb2RlKFwiZWRpdFwiKX1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuXG4gICAgICAgIHtzaG93RGVsZXRlTW9kYWwgJiYgKFxuICAgICAgICAgIDxEZWxldGVBY2NvdW50TW9kYWxcbiAgICAgICAgICAgIHBhc3N3b3JkPXtkZWxldGVQYXNzd29yZH1cbiAgICAgICAgICAgIGVycm9yPXtkZWxldGVFcnJvcn1cbiAgICAgICAgICAgIHN0YXR1cz17ZGVsZXRlU3RhdHVzfVxuICAgICAgICAgICAgb25QYXNzd29yZENoYW5nZT17c2V0RGVsZXRlUGFzc3dvcmR9XG4gICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4geyBpZiAoZGVsZXRlU3RhdHVzICE9PSBcInN1Ym1pdHRpbmdcIikgc2V0U2hvd0RlbGV0ZU1vZGFsKGZhbHNlKTsgfX1cbiAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlRGVsZXRlfVxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVQYWdlOyJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9Qcm9maWxlUGFnZS5qc3gifQ==