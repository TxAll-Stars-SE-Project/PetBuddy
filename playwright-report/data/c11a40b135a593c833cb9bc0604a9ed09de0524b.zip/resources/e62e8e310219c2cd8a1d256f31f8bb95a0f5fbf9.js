import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OwnerBookingPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/Navbar.jsx";
import PaymentModal from "/src/components/payment/PaymentModal.jsx";
import ConfirmModal from "/src/components/ui/ConfirmModal.jsx";
import ReviewModal from "/src/components/ReviewModal.jsx";
import { cancelBooking, getOwnerBookings } from "/src/services/bookings.js";
import { getBookingReviewState, getSavedReviews } from "/src/utils/reviewStorage.js";
import { getBookingPayments } from "/src/services/payment.api.js";
import { toast } from "/src/utils/toast.js";
const STATUS_META = {
  pending: { label: "รอพี่เลี้ยงตอบรับ", tone: "muted" },
  waiting_payment: { label: "รอชำระมัดจำ", tone: "warning" },
  deposit_paid: { label: "ชำระมัดจำแล้ว", tone: "success" },
  confirmed: { label: "ยืนยันแล้ว", tone: "success" },
  waiting_final_payment: { label: "รอชำระส่วนที่เหลือ", tone: "warning" },
  completed: { label: "เสร็จสิ้น", tone: "muted" },
  rejected: { label: "ถูกปฏิเสธ", tone: "error" },
  cancelled: { label: "ยกเลิกแล้ว", tone: "error" }
};
const FILTER_TABS = [
  { key: "all", label: "ทั้งหมด" },
  { key: "waiting_payment", label: "รอชำระเงิน" },
  { key: "confirmed", label: "ยืนยันแล้ว" },
  { key: "completed", label: "เสร็จสิ้น" }
];
const PAYABLE_STATUSES = ["waiting_payment", "waiting_final_payment"];
const CANCELLABLE_STATUSES = ["pending", "waiting_payment", "deposit_paid"];
function formatDateRange(start, end) {
  const s = new Date(start);
  const e = new Date(end);
  const dateFmt = { day: "numeric", month: "short", year: "numeric" };
  const timeFmt = { hour: "2-digit", minute: "2-digit" };
  const sameDay = s.toDateString() === e.toDateString();
  if (sameDay) {
    return `${s.toLocaleDateString("th-TH", dateFmt)} · ${s.toLocaleTimeString("th-TH", timeFmt)} - ${e.toLocaleTimeString("th-TH", timeFmt)}`;
  }
  return `${s.toLocaleDateString("th-TH", dateFmt)} - ${e.toLocaleDateString("th-TH", dateFmt)}`;
}
export default function OwnerBookingPage() {
  _s();
  const [activeTab, setActiveTab] = useState("all");
  const [reloadKey, setReloadKey] = useState(0);
  const [result, setResult] = useState({ status: "loading", bookings: [] });
  const [payingBooking, setPayingBooking] = useState(null);
  const [paymentSummary, setPaymentSummary] = useState(null);
  const [isPaymentSummaryLoading, setIsPaymentSummaryLoading] = useState(false);
  const [paymentSummaryError, setPaymentSummaryError] = useState(false);
  const [paymentSummaryReloadKey, setPaymentSummaryReloadKey] = useState(0);
  const [cancellingBooking, setCancellingBooking] = useState(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const [reviewingBooking, setReviewingBooking] = useState(null);
  const [savedReviews, setSavedReviews] = useState(() => getSavedReviews());
  const payingBookingId = payingBooking?.bookingId || payingBooking?.id;
  useEffect(() => {
    const controller = new AbortController();
    setResult((r) => ({ ...r, status: "loading" }));
    getOwnerBookings(activeTab === "all" ? "" : activeTab, { signal: controller.signal }).then((bookings2) => setResult({ status: "success", bookings: bookings2 })).catch(() => {
      if (controller.signal.aborted) return;
      setResult((r) => ({ ...r, status: "error" }));
    });
    return () => controller.abort();
  }, [activeTab, reloadKey]);
  useEffect(() => {
    if (!payingBooking) {
      setPaymentSummary(null);
      setIsPaymentSummaryLoading(false);
      setPaymentSummaryError(false);
      return void 0;
    }
    let isCurrent = true;
    setPaymentSummary(null);
    setIsPaymentSummaryLoading(true);
    setPaymentSummaryError(false);
    getBookingPayments(payingBookingId).then((response) => {
      const summary = response?.data?.data ?? response?.data;
      if (!summary || typeof summary !== "object" || !Array.isArray(summary.payments)) {
        throw new Error("รูปแบบข้อมูลสรุปการชำระเงินไม่ถูกต้อง");
      }
      if (isCurrent) setPaymentSummary(summary);
    }).catch(() => {
      if (!isCurrent) return;
      const fallbackAmount = payingBooking?.totalprice || payingBooking?.totalPrice || 0;
      setPaymentSummaryError(true);
      setPaymentSummary({
        bookingId: payingBookingId,
        bookingstatus: payingBooking?.bookingstatus,
        totalPrice: fallbackAmount,
        depositAmount: fallbackAmount,
        remainingAmount: fallbackAmount,
        paymentplan: "full",
        payment_stage: "full",
        payments: []
      });
    }).finally(() => {
      if (isCurrent) setIsPaymentSummaryLoading(false);
    });
    return () => {
      isCurrent = false;
    };
  }, [payingBooking, payingBookingId, paymentSummaryReloadKey]);
  const { status, bookings } = result;
  async function handleConfirmCancel() {
    setIsCancelling(true);
    try {
      await cancelBooking(cancellingBooking.bookingId);
      toast("ยกเลิกการจองเรียบร้อยแล้ว", "success");
      setCancellingBooking(null);
      setReloadKey((k) => k + 1);
    } catch (err) {
      const message = err.response?.status === 409 ? "ไม่สามารถยกเลิกได้ในสถานะนี้" : err.response?.data?.message || "ยกเลิกการจองไม่สำเร็จ กรุณาลองใหม่อีกครั้ง";
      toast(message, "error");
      setCancellingBooking(null);
      setReloadKey((k) => k + 1);
    } finally {
      setIsCancelling(false);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "home-main booking-page", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "page-title", children: "การจองของฉัน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 165,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "ติดตามสถานะการจอง ชำระเงิน และรีวิวให้พี่เลี้ยงที่คุณเลือกไว้" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 166,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "booking-tabs", children: FILTER_TABS.map(
        (t) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: `chip-btn${activeTab === t.key ? " active" : ""}`,
            onClick: () => setActiveTab(t.key),
            children: t.label
          },
          t.key,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 170,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 168,
        columnNumber: 9
      }, this),
      status === "loading" && bookings.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "state-box", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emoji", children: "⏳" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 183,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "กำลังโหลดรายการจอง…" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 184,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 182,
        columnNumber: 9
      }, this),
      status === "error" && /* @__PURE__ */ jsxDEV("div", { className: "state-box state-box--error", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emoji", children: "⚠️" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 190,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "โหลดรายการจองไม่สำเร็จ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 191,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่อีกครั้ง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 192,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn", onClick: () => setReloadKey((k) => k + 1), children: "ลองใหม่" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 193,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 189,
        columnNumber: 9
      }, this),
      status === "success" && bookings.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "state-box", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "emoji", children: "📅" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 199,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "ไม่มีรายการจองในหมวดนี้" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 200,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "ลองเลือกแท็บอื่น หรือเริ่มค้นหาพี่เลี้ยงเพื่อจองใหม่" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 201,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 198,
        columnNumber: 9
      }, this),
      bookings.length > 0 && status !== "error" && /* @__PURE__ */ jsxDEV("div", { className: `booking-list${status === "loading" ? " is-loading" : ""}`, children: bookings.map((b) => {
        const meta = STATUS_META[b.bookingstatus] ?? { label: b.bookingstatus, tone: "muted" };
        const canPay = PAYABLE_STATUSES.includes(b.bookingstatus);
        const canCancel = CANCELLABLE_STATUSES.includes(b.bookingstatus);
        const isCompleted = b.bookingstatus === "completed";
        const reviewState = isCompleted ? getBookingReviewState(b, savedReviews) : null;
        const hasActions = canCancel || canPay || isCompleted;
        return /* @__PURE__ */ jsxDEV("article", { className: "booking-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "booking-card-top", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "booking-id-tag", children: [
                "การจอง #",
                b.bookingId
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 220,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "booking-sitter-name", children: b.sitterName }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 221,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "booking-service-name", children: b.serviceName }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 222,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 219,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `booking-badge booking-badge--${meta.tone}`, children: meta.label }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 224,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 218,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "booking-datetime", children: [
            "🗓️ ",
            formatDateRange(b.starttime, b.endtime)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 227,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "booking-pets", children: b.pets.map(
            (p) => /* @__PURE__ */ jsxDEV("span", { className: "tag", children: [
              "🐾 ",
              p.petName,
              p.petNote ? ` · ${p.petNote}` : ""
            ] }, p.petId, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 231,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 229,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "booking-card-foot", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "booking-price", children: [
              /* @__PURE__ */ jsxDEV("small", { children: "ราคารวม" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 240,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("strong", { children: [
                "฿",
                Number(b.totalPrice).toLocaleString("th-TH")
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 241,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 239,
              columnNumber: 21
            }, this),
            hasActions && /* @__PURE__ */ jsxDEV("div", { className: "booking-actions", children: [
              canCancel && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "btn btn--small btn--danger-outline",
                  onClick: () => setCancellingBooking(b),
                  children: "ยกเลิกการจอง"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                  lineNumber: 247,
                  columnNumber: 21
                },
                this
              ),
              canPay && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "btn btn--small",
                  onClick: () => {
                    setPaymentSummary(null);
                    setPayingBooking(b);
                  },
                  children: "ชำระเงิน"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                  lineNumber: 256,
                  columnNumber: 21
                },
                this
              ),
              isCompleted && reviewState && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                reviewState.canReview && /* @__PURE__ */ jsxDEV("div", { className: "booking-review-action-wrap", children: [
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `booking-review-time-hint ${reviewState.isUrgent ? "booking-review-time-hint--urgent" : ""}`,
                      children: reviewState.isUrgent ? `⚠️ เหลือเวลาอีก ${reviewState.daysRemaining} วันสุดท้าย!` : `⏳ เหลือเวลารีวิว ${reviewState.daysRemaining} วัน`
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                      lineNumber: 274,
                      columnNumber: 33
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      className: "btn btn--small",
                      onClick: () => setReviewingBooking(b),
                      children: "⭐ ให้คะแนนและรีวิว"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                      lineNumber: 283,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                  lineNumber: 273,
                  columnNumber: 23
                }, this),
                reviewState.state === "reviewed" && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "booking-badge booking-badge--review-done booking-badge--clickable",
                    title: "คลิกเพื่อดูรีวิวที่คุณส่งไว้",
                    onClick: () => setReviewingBooking(b),
                    children: [
                      "✓ รีวิวแล้ว (",
                      reviewState.rating,
                      " ★) · ดูรีวิว"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                    lineNumber: 295,
                    columnNumber: 23
                  },
                  this
                ),
                reviewState.state === "expired_auto_reviewed" && /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "booking-badge booking-badge--review-expired",
                    title: "สามารถส่งรีวิวได้ภายใน 14 วันหลังเสร็จสิ้นบริการ เพื่อความแม่นยำของข้อมูล",
                    children: "⏳ หมดเวลารีวิว (เกิน 14 วัน)"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                    lineNumber: 307,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 270,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 245,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 238,
            columnNumber: 19
          }, this)
        ] }, b.bookingId, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
          lineNumber: 217,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 207,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
      lineNumber: 164,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      PaymentModal,
      {
        isOpen: Boolean(payingBooking),
        booking: payingBooking,
        summary: paymentSummary,
        isLoading: isPaymentSummaryLoading,
        isError: paymentSummaryError,
        onRetry: () => setPaymentSummaryReloadKey((key) => key + 1),
        onClose: () => setPayingBooking(null),
        onSuccess: () => {
          setPayingBooking(null);
          setReloadKey((k) => k + 1);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 327,
        columnNumber: 7
      },
      this
    ),
    cancellingBooking && /* @__PURE__ */ jsxDEV(
      ConfirmModal,
      {
        title: "ยืนยันการยกเลิกการจอง",
        message: "คุณต้องการยกเลิกการจองนี้ใช่หรือไม่? ระบบจะแจ้งพี่เลี้ยงทางอีเมล และไม่สามารถย้อนกลับได้",
        confirmText: "ยืนยันยกเลิกการจอง",
        cancelText: "ไม่ยกเลิก",
        isDanger: true,
        isLoading: isCancelling,
        onConfirm: handleConfirmCancel,
        onCancel: () => !isCancelling && setCancellingBooking(null),
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "cancel-summary", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: cancellingBooking.sitterName }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 355,
              columnNumber: 13
            }, this),
            " · ",
            cancellingBooking.serviceName,
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 356,
              columnNumber: 13
            }, this),
            "🗓️ ",
            formatDateRange(cancellingBooking.starttime, cancellingBooking.endtime),
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 358,
              columnNumber: 13
            }, this),
            "ราคารวม ฿",
            Number(cancellingBooking.totalPrice).toLocaleString("th-TH")
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 354,
            columnNumber: 11
          }, this),
          cancellingBooking.bookingstatus === "deposit_paid" && /* @__PURE__ */ jsxDEV("div", { className: "cancel-notice", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "⚠️" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 363,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "ค่ามัดจำที่ชำระแล้วจะไม่ได้รับเงินคืน" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 365,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
                lineNumber: 366,
                columnNumber: 17
              }, this),
              "คุณได้ชำระมัดจำไปแล้ว หากยกเลิกตอนนี้จะไม่มีการคืนเงินส่วนนี้"
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
              lineNumber: 364,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
            lineNumber: 362,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 344,
        columnNumber: 7
      },
      this
    ),
    reviewingBooking && /* @__PURE__ */ jsxDEV(
      ReviewModal,
      {
        booking: reviewingBooking,
        isOpen: !!reviewingBooking,
        existingReview: reviewingBooking.review || savedReviews[reviewingBooking.bookingId] || null,
        onClose: () => setReviewingBooking(null),
        onSubmitSuccess: () => {
          setSavedReviews(getSavedReviews());
          setReloadKey((k) => k + 1);
          setReviewingBooking(null);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
        lineNumber: 376,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx",
    lineNumber: 162,
    columnNumber: 5
  }, this);
}
_s(OwnerBookingPage, "W+nczt7JW6W/zy42tfJkIXwkl+o=");
_c = OwnerBookingPage;
var _c;
$RefreshReg$(_c, "OwnerBookingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/OwnerBookingPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0lNLFNBMkdvQixVQTNHcEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBL0lOLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGVBQWVDLHdCQUF3QjtBQUNoRCxTQUFTQyx1QkFBdUJDLHVCQUF1QjtBQUN2RCxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsYUFBYTtBQUV0QixNQUFNQyxjQUFjO0FBQUEsRUFDbEJDLFNBQVMsRUFBRUMsT0FBTyxxQkFBcUJDLE1BQU0sUUFBUTtBQUFBLEVBQ3JEQyxpQkFBaUIsRUFBRUYsT0FBTyxlQUFlQyxNQUFNLFVBQVU7QUFBQSxFQUN6REUsY0FBYyxFQUFFSCxPQUFPLGlCQUFpQkMsTUFBTSxVQUFVO0FBQUEsRUFDeERHLFdBQVcsRUFBRUosT0FBTyxjQUFjQyxNQUFNLFVBQVU7QUFBQSxFQUNsREksdUJBQXVCLEVBQUVMLE9BQU8sc0JBQXNCQyxNQUFNLFVBQVU7QUFBQSxFQUN0RUssV0FBVyxFQUFFTixPQUFPLGFBQWFDLE1BQU0sUUFBUTtBQUFBLEVBQy9DTSxVQUFVLEVBQUVQLE9BQU8sYUFBYUMsTUFBTSxRQUFRO0FBQUEsRUFDOUNPLFdBQVcsRUFBRVIsT0FBTyxjQUFjQyxNQUFNLFFBQVE7QUFDbEQ7QUFFQSxNQUFNUSxjQUFjO0FBQUEsRUFDbEIsRUFBRUMsS0FBSyxPQUFPVixPQUFPLFVBQVU7QUFBQSxFQUMvQixFQUFFVSxLQUFLLG1CQUFtQlYsT0FBTyxhQUFhO0FBQUEsRUFDOUMsRUFBRVUsS0FBSyxhQUFhVixPQUFPLGFBQWE7QUFBQSxFQUN4QyxFQUFFVSxLQUFLLGFBQWFWLE9BQU8sWUFBWTtBQUFDO0FBRzFDLE1BQU1XLG1CQUFtQixDQUFDLG1CQUFtQix1QkFBdUI7QUFFcEUsTUFBTUMsdUJBQXVCLENBQUMsV0FBVyxtQkFBbUIsY0FBYztBQUUxRSxTQUFTQyxnQkFBZ0JDLE9BQU9DLEtBQUs7QUFDbkMsUUFBTUMsSUFBSSxJQUFJQyxLQUFLSCxLQUFLO0FBQ3hCLFFBQU1JLElBQUksSUFBSUQsS0FBS0YsR0FBRztBQUN0QixRQUFNSSxVQUFVLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxTQUFTQyxNQUFNLFVBQVU7QUFDbEUsUUFBTUMsVUFBVSxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVTtBQUNyRCxRQUFNQyxVQUFVVixFQUFFVyxhQUFhLE1BQU1ULEVBQUVTLGFBQWE7QUFDcEQsTUFBSUQsU0FBUztBQUNYLFdBQU8sR0FBR1YsRUFBRVksbUJBQW1CLFNBQVNULE9BQU8sQ0FBQyxNQUFNSCxFQUFFYSxtQkFBbUIsU0FBU04sT0FBTyxDQUFDLE1BQU1MLEVBQUVXLG1CQUFtQixTQUFTTixPQUFPLENBQUM7QUFBQSxFQUMxSTtBQUNBLFNBQU8sR0FBR1AsRUFBRVksbUJBQW1CLFNBQVNULE9BQU8sQ0FBQyxNQUFNRCxFQUFFVSxtQkFBbUIsU0FBU1QsT0FBTyxDQUFDO0FBQzlGO0FBSUEsd0JBQXdCVyxtQkFBbUI7QUFBQUMsS0FBQTtBQUN6QyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTlDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrQyxXQUFXQyxZQUFZLElBQUloRCxTQUFTLENBQUM7QUFDNUMsUUFBTSxDQUFDaUQsUUFBUUMsU0FBUyxJQUFJbEQsU0FBUyxFQUFFbUQsUUFBUSxXQUFXQyxVQUFVLEdBQUcsQ0FBQztBQUN4RSxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJdEQsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3VELGdCQUFnQkMsaUJBQWlCLElBQUl4RCxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDeUQseUJBQXlCQywwQkFBMEIsSUFBSTFELFNBQVMsS0FBSztBQUM1RSxRQUFNLENBQUMyRCxxQkFBcUJDLHNCQUFzQixJQUFJNUQsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzZELHlCQUF5QkMsMEJBQTBCLElBQUk5RCxTQUFTLENBQUM7QUFDeEUsUUFBTSxDQUFDK0QsbUJBQW1CQyxvQkFBb0IsSUFBSWhFLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNpRSxjQUFjQyxlQUFlLElBQUlsRSxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDbUUsa0JBQWtCQyxtQkFBbUIsSUFBSXBFLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUNxRSxjQUFjQyxlQUFlLElBQUl0RSxTQUFTLE1BQU1RLGdCQUFnQixDQUFDO0FBRXhFLFFBQU0rRCxrQkFBa0JsQixlQUFlbUIsYUFBYW5CLGVBQWVvQjtBQUVuRTFFLFlBQVUsTUFBTTtBQUNkLFVBQU0yRSxhQUFhLElBQUlDLGdCQUFnQjtBQUN2Q3pCLGNBQVUsQ0FBQzBCLE9BQU8sRUFBRSxHQUFHQSxHQUFHekIsUUFBUSxVQUFVLEVBQUU7QUFDOUM3QyxxQkFBaUJ1QyxjQUFjLFFBQVEsS0FBS0EsV0FBVyxFQUFFZ0MsUUFBUUgsV0FBV0csT0FBTyxDQUFDLEVBQ2pGQyxLQUFLLENBQUMxQixjQUFhRixVQUFVLEVBQUVDLFFBQVEsV0FBV0Msb0JBQVMsQ0FBQyxDQUFDLEVBQzdEMkIsTUFBTSxNQUFNO0FBQ1gsVUFBSUwsV0FBV0csT0FBT0csUUFBUztBQUMvQjlCLGdCQUFVLENBQUMwQixPQUFPLEVBQUUsR0FBR0EsR0FBR3pCLFFBQVEsUUFBUSxFQUFFO0FBQUEsSUFDOUMsQ0FBQztBQUNILFdBQU8sTUFBTXVCLFdBQVdPLE1BQU07QUFBQSxFQUNoQyxHQUFHLENBQUNwQyxXQUFXRSxTQUFTLENBQUM7QUFFekJoRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNzRCxlQUFlO0FBQ2xCRyx3QkFBa0IsSUFBSTtBQUN0QkUsaUNBQTJCLEtBQUs7QUFDaENFLDZCQUF1QixLQUFLO0FBQzVCLGFBQU9zQjtBQUFBQSxJQUNUO0FBRUEsUUFBSUMsWUFBWTtBQUNoQjNCLHNCQUFrQixJQUFJO0FBQ3RCRSwrQkFBMkIsSUFBSTtBQUMvQkUsMkJBQXVCLEtBQUs7QUFFNUJuRCx1QkFBbUI4RCxlQUFlLEVBQy9CTyxLQUFLLENBQUNNLGFBQWE7QUFDbEIsWUFBTUMsVUFBVUQsVUFBVUUsTUFBTUEsUUFBUUYsVUFBVUU7QUFDbEQsVUFBSSxDQUFDRCxXQUFXLE9BQU9BLFlBQVksWUFBWSxDQUFDRSxNQUFNQyxRQUFRSCxRQUFRSSxRQUFRLEdBQUc7QUFDL0UsY0FBTSxJQUFJQyxNQUFNLHVDQUF1QztBQUFBLE1BQ3pEO0FBQ0EsVUFBSVAsVUFBVzNCLG1CQUFrQjZCLE9BQU87QUFBQSxJQUMxQyxDQUFDLEVBQ0FOLE1BQU0sTUFBTTtBQUNYLFVBQUksQ0FBQ0ksVUFBVztBQUNoQixZQUFNUSxpQkFBaUJ0QyxlQUFldUMsY0FBY3ZDLGVBQWV3QyxjQUFjO0FBQ2pGakMsNkJBQXVCLElBQUk7QUFDM0JKLHdCQUFrQjtBQUFBLFFBQ2hCZ0IsV0FBV0Q7QUFBQUEsUUFDWHVCLGVBQWV6QyxlQUFleUM7QUFBQUEsUUFDOUJELFlBQVlGO0FBQUFBLFFBQ1pJLGVBQWVKO0FBQUFBLFFBQ2ZLLGlCQUFpQkw7QUFBQUEsUUFDakJNLGFBQWE7QUFBQSxRQUNiQyxlQUFlO0FBQUEsUUFDZlQsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsQ0FBQyxFQUNBVSxRQUFRLE1BQU07QUFDYixVQUFJaEIsVUFBV3pCLDRCQUEyQixLQUFLO0FBQUEsSUFDakQsQ0FBQztBQUVILFdBQU8sTUFBTTtBQUNYeUIsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLENBQUM5QixlQUFla0IsaUJBQWlCVix1QkFBdUIsQ0FBQztBQUU1RCxRQUFNLEVBQUVWLFFBQVFDLFNBQVMsSUFBSUg7QUFFN0IsaUJBQWVtRCxzQkFBc0I7QUFDbkNsQyxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsWUFBTTdELGNBQWMwRCxrQkFBa0JTLFNBQVM7QUFDL0M5RCxZQUFNLDZCQUE2QixTQUFTO0FBQzVDc0QsMkJBQXFCLElBQUk7QUFDekJoQixtQkFBYSxDQUFDcUQsTUFBTUEsSUFBSSxDQUFDO0FBQUEsSUFDM0IsU0FBU0MsS0FBSztBQUNaLFlBQU1DLFVBQ0pELElBQUlsQixVQUFVakMsV0FBVyxNQUNyQixpQ0FDQW1ELElBQUlsQixVQUFVRSxNQUFNaUIsV0FBVztBQUNyQzdGLFlBQU02RixTQUFTLE9BQU87QUFDdEJ2QywyQkFBcUIsSUFBSTtBQUN6QmhCLG1CQUFhLENBQUNxRCxNQUFNQSxJQUFJLENBQUM7QUFBQSxJQUMzQixVQUFDO0FBQ0NuQyxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxVQUFLLFdBQVUsMEJBQ2Q7QUFBQSw2QkFBQyxRQUFHLFdBQVUsY0FBYSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDLHVCQUFDLE9BQUUsV0FBVSxlQUFjLDZFQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdGO0FBQUEsTUFFeEYsdUJBQUMsU0FBSSxXQUFVLGdCQUNaNUMsc0JBQVlrRjtBQUFBQSxRQUFJLENBQUNDLE1BQ2hCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxNQUFLO0FBQUEsWUFDTCxXQUFXLFdBQVc1RCxjQUFjNEQsRUFBRWxGLE1BQU0sWUFBWSxFQUFFO0FBQUEsWUFDMUQsU0FBUyxNQUFNdUIsYUFBYTJELEVBQUVsRixHQUFHO0FBQUEsWUFFaENrRixZQUFFNUY7QUFBQUE7QUFBQUEsVUFMRTRGLEVBQUVsRjtBQUFBQSxVQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLE1BQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVDNEIsV0FBVyxhQUFhQyxTQUFTc0QsV0FBVyxLQUMzQyx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUFRLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDeEIsdUJBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsV0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHRHZELFdBQVcsV0FDVix1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FBUSxrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFFBQUcsc0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQzFCLHVCQUFDLE9BQUUsaUVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsT0FBTSxTQUFTLE1BQU1ILGFBQWEsQ0FBQ3FELE1BQU1BLElBQUksQ0FBQyxHQUFHLHVCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsV0FKMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFHRGxELFdBQVcsYUFBYUMsU0FBU3NELFdBQVcsS0FDM0MsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FBUSxrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFFBQUcsdUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFFBQzNCLHVCQUFDLE9BQUUsb0VBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFdBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BSUR0RCxTQUFTc0QsU0FBUyxLQUFLdkQsV0FBVyxXQUNqQyx1QkFBQyxTQUFJLFdBQVcsZUFBZUEsV0FBVyxZQUFZLGdCQUFnQixFQUFFLElBQ3JFQyxtQkFBU29ELElBQUksQ0FBQ0csTUFBTTtBQUNuQixjQUFNQyxPQUFPakcsWUFBWWdHLEVBQUViLGFBQWEsS0FBSyxFQUFFakYsT0FBTzhGLEVBQUViLGVBQWVoRixNQUFNLFFBQVE7QUFDckYsY0FBTStGLFNBQVNyRixpQkFBaUJzRixTQUFTSCxFQUFFYixhQUFhO0FBQ3hELGNBQU1pQixZQUFZdEYscUJBQXFCcUYsU0FBU0gsRUFBRWIsYUFBYTtBQUMvRCxjQUFNa0IsY0FBY0wsRUFBRWIsa0JBQWtCO0FBQ3hDLGNBQU1tQixjQUFjRCxjQUFjekcsc0JBQXNCb0csR0FBR3RDLFlBQVksSUFBSTtBQUMzRSxjQUFNNkMsYUFBYUgsYUFBYUYsVUFBVUc7QUFFMUMsZUFDRSx1QkFBQyxhQUEwQixXQUFVLGdCQUNuQztBQUFBLGlDQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsa0JBQWlCO0FBQUE7QUFBQSxnQkFBU0wsRUFBRW5DO0FBQUFBLG1CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGNBQ3RELHVCQUFDLFFBQUcsV0FBVSx1QkFBdUJtQyxZQUFFUSxjQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQ2xELHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JSLFlBQUVTLGVBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVyxnQ0FBZ0NSLEtBQUs5RixJQUFJLElBQUs4RixlQUFLL0YsU0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxlQU41RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsb0JBQW1CO0FBQUE7QUFBQSxZQUFLYSxnQkFBZ0JpRixFQUFFVSxXQUFXVixFQUFFVyxPQUFPO0FBQUEsZUFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkU7QUFBQSxVQUU3RSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ1pYLFlBQUVZLEtBQUtmO0FBQUFBLFlBQUksQ0FBQ2dCLE1BQ1gsdUJBQUMsVUFBbUIsV0FBVSxPQUFLO0FBQUE7QUFBQSxjQUM3QkEsRUFBRUM7QUFBQUEsY0FDTEQsRUFBRUUsVUFBVSxNQUFNRixFQUFFRSxPQUFPLEtBQUs7QUFBQSxpQkFGeEJGLEVBQUVHLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWM7QUFBQSxjQUNkLHVCQUFDLFlBQU87QUFBQTtBQUFBLGdCQUFFQyxPQUFPakIsRUFBRWQsVUFBVSxFQUFFZ0MsZUFBZSxPQUFPO0FBQUEsbUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsaUJBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVDWCxjQUNDLHVCQUFDLFNBQUksV0FBVSxtQkFDWkg7QUFBQUEsMkJBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU0vQyxxQkFBcUIyQyxDQUFDO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUh6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBRURFLFVBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU07QUFDYnJELHNDQUFrQixJQUFJO0FBQ3RCRixxQ0FBaUJxRCxDQUFDO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNBO0FBQUEsY0FJREssZUFBZUMsZUFDZCxtQ0FFR0E7QUFBQUEsNEJBQVlhLGFBQ1gsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyw0QkFDVGIsWUFBWWMsV0FBVyxxQ0FBcUMsRUFBRTtBQUFBLHNCQUcvRGQsc0JBQVljLFdBQ1QsbUJBQW1CZCxZQUFZZSxhQUFhLGlCQUM1QyxvQkFBb0JmLFlBQVllLGFBQWE7QUFBQTtBQUFBLG9CQVBuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTTVELG9CQUFvQnVDLENBQUM7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLHFCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUlETSxZQUFZZ0IsVUFBVSxjQUNyQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFDTixTQUFTLE1BQU03RCxvQkFBb0J1QyxDQUFDO0FBQUEsb0JBQUU7QUFBQTtBQUFBLHNCQUV4Qk0sWUFBWWlCO0FBQUFBLHNCQUFPO0FBQUE7QUFBQTtBQUFBLGtCQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxnQkFJRGpCLFlBQVlnQixVQUFVLDJCQUNyQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUEyRTtBQUFBO0FBQUEsa0JBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGlCQXJFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVFQTtBQUFBLGVBOUVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0ZBO0FBQUEsYUFyR1l0QixFQUFFbkMsV0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNHQTtBQUFBLE1BRUosQ0FBQyxLQWxISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUhBO0FBQUEsU0E5Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdLQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFFBQVEyRCxRQUFROUUsYUFBYTtBQUFBLFFBQzdCLFNBQVNBO0FBQUFBLFFBQ1QsU0FBU0U7QUFBQUEsUUFDVCxXQUFXRTtBQUFBQSxRQUNYLFNBQVNFO0FBQUFBLFFBQ1QsU0FBUyxNQUFNRywyQkFBMkIsQ0FBQ3ZDLFFBQVFBLE1BQU0sQ0FBQztBQUFBLFFBQzFELFNBQVMsTUFBTStCLGlCQUFpQixJQUFJO0FBQUEsUUFDcEMsV0FBVyxNQUFNO0FBQ2ZBLDJCQUFpQixJQUFJO0FBQ3JCTix1QkFBYSxDQUFDcUQsTUFBTUEsSUFBSSxDQUFDO0FBQUEsUUFDM0I7QUFBQTtBQUFBLE1BWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0k7QUFBQSxJQUtIdEMscUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFNBQVE7QUFBQSxRQUNSLGFBQVk7QUFBQSxRQUNaLFlBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxRQUNWLFdBQVdFO0FBQUFBLFFBQ1gsV0FBV21DO0FBQUFBLFFBQ1gsVUFBVSxNQUFNLENBQUNuQyxnQkFBZ0JELHFCQUFxQixJQUFJO0FBQUEsUUFFMUQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxZQUFRRCw0QkFBa0JvRCxjQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQztBQUFBLFlBQVM7QUFBQSxZQUFJcEQsa0JBQWtCcUQ7QUFBQUEsWUFDckUsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFHO0FBQUE7QUFBQSxZQUNFMUYsZ0JBQWdCcUMsa0JBQWtCc0QsV0FBV3RELGtCQUFrQnVELE9BQU87QUFBQSxZQUMzRSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQUc7QUFBQTtBQUFBLFlBQ09NLE9BQU83RCxrQkFBa0I4QixVQUFVLEVBQUVnQyxlQUFlLE9BQU87QUFBQSxlQUx2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQzlELGtCQUFrQitCLGtCQUFrQixrQkFDbkMsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsVUFBSyxrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFRO0FBQUEsWUFDUix1QkFBQyxVQUNDO0FBQUEscUNBQUMsWUFBTyxxREFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGNBQzdDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBRztBQUFBO0FBQUEsaUJBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBO0FBQUE7QUFBQSxNQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEyQkE7QUFBQSxJQUlEM0Isb0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNBO0FBQUFBLFFBQ1QsUUFBUSxDQUFDLENBQUNBO0FBQUFBLFFBQ1YsZ0JBQWdCQSxpQkFBaUJpRSxVQUFVL0QsYUFBYUYsaUJBQWlCSyxTQUFTLEtBQUs7QUFBQSxRQUN2RixTQUFTLE1BQU1KLG9CQUFvQixJQUFJO0FBQUEsUUFDdkMsaUJBQWlCLE1BQU07QUFDckJFLDBCQUFnQjlELGdCQUFnQixDQUFDO0FBQ2pDd0MsdUJBQWEsQ0FBQ3FELE1BQU1BLElBQUksQ0FBQztBQUN6QmpDLDhCQUFvQixJQUFJO0FBQUEsUUFDMUI7QUFBQTtBQUFBLE1BVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU0k7QUFBQSxPQS9OUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa09BO0FBRUo7QUFBQ3hCLEdBcFV1QkQsa0JBQWdCO0FBQUEsS0FBaEJBO0FBQWdCLElBQUEwRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIk5hdmJhciIsIlBheW1lbnRNb2RhbCIsIkNvbmZpcm1Nb2RhbCIsIlJldmlld01vZGFsIiwiY2FuY2VsQm9va2luZyIsImdldE93bmVyQm9va2luZ3MiLCJnZXRCb29raW5nUmV2aWV3U3RhdGUiLCJnZXRTYXZlZFJldmlld3MiLCJnZXRCb29raW5nUGF5bWVudHMiLCJ0b2FzdCIsIlNUQVRVU19NRVRBIiwicGVuZGluZyIsImxhYmVsIiwidG9uZSIsIndhaXRpbmdfcGF5bWVudCIsImRlcG9zaXRfcGFpZCIsImNvbmZpcm1lZCIsIndhaXRpbmdfZmluYWxfcGF5bWVudCIsImNvbXBsZXRlZCIsInJlamVjdGVkIiwiY2FuY2VsbGVkIiwiRklMVEVSX1RBQlMiLCJrZXkiLCJQQVlBQkxFX1NUQVRVU0VTIiwiQ0FOQ0VMTEFCTEVfU1RBVFVTRVMiLCJmb3JtYXREYXRlUmFuZ2UiLCJzdGFydCIsImVuZCIsInMiLCJEYXRlIiwiZSIsImRhdGVGbXQiLCJkYXkiLCJtb250aCIsInllYXIiLCJ0aW1lRm10IiwiaG91ciIsIm1pbnV0ZSIsInNhbWVEYXkiLCJ0b0RhdGVTdHJpbmciLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJPd25lckJvb2tpbmdQYWdlIiwiX3MiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJyZWxvYWRLZXkiLCJzZXRSZWxvYWRLZXkiLCJyZXN1bHQiLCJzZXRSZXN1bHQiLCJzdGF0dXMiLCJib29raW5ncyIsInBheWluZ0Jvb2tpbmciLCJzZXRQYXlpbmdCb29raW5nIiwicGF5bWVudFN1bW1hcnkiLCJzZXRQYXltZW50U3VtbWFyeSIsImlzUGF5bWVudFN1bW1hcnlMb2FkaW5nIiwic2V0SXNQYXltZW50U3VtbWFyeUxvYWRpbmciLCJwYXltZW50U3VtbWFyeUVycm9yIiwic2V0UGF5bWVudFN1bW1hcnlFcnJvciIsInBheW1lbnRTdW1tYXJ5UmVsb2FkS2V5Iiwic2V0UGF5bWVudFN1bW1hcnlSZWxvYWRLZXkiLCJjYW5jZWxsaW5nQm9va2luZyIsInNldENhbmNlbGxpbmdCb29raW5nIiwiaXNDYW5jZWxsaW5nIiwic2V0SXNDYW5jZWxsaW5nIiwicmV2aWV3aW5nQm9va2luZyIsInNldFJldmlld2luZ0Jvb2tpbmciLCJzYXZlZFJldmlld3MiLCJzZXRTYXZlZFJldmlld3MiLCJwYXlpbmdCb29raW5nSWQiLCJib29raW5nSWQiLCJpZCIsImNvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJyIiwic2lnbmFsIiwidGhlbiIsImNhdGNoIiwiYWJvcnRlZCIsImFib3J0IiwidW5kZWZpbmVkIiwiaXNDdXJyZW50IiwicmVzcG9uc2UiLCJzdW1tYXJ5IiwiZGF0YSIsIkFycmF5IiwiaXNBcnJheSIsInBheW1lbnRzIiwiRXJyb3IiLCJmYWxsYmFja0Ftb3VudCIsInRvdGFscHJpY2UiLCJ0b3RhbFByaWNlIiwiYm9va2luZ3N0YXR1cyIsImRlcG9zaXRBbW91bnQiLCJyZW1haW5pbmdBbW91bnQiLCJwYXltZW50cGxhbiIsInBheW1lbnRfc3RhZ2UiLCJmaW5hbGx5IiwiaGFuZGxlQ29uZmlybUNhbmNlbCIsImsiLCJlcnIiLCJtZXNzYWdlIiwibWFwIiwidCIsImxlbmd0aCIsImIiLCJtZXRhIiwiY2FuUGF5IiwiaW5jbHVkZXMiLCJjYW5DYW5jZWwiLCJpc0NvbXBsZXRlZCIsInJldmlld1N0YXRlIiwiaGFzQWN0aW9ucyIsInNpdHRlck5hbWUiLCJzZXJ2aWNlTmFtZSIsInN0YXJ0dGltZSIsImVuZHRpbWUiLCJwZXRzIiwicCIsInBldE5hbWUiLCJwZXROb3RlIiwicGV0SWQiLCJOdW1iZXIiLCJ0b0xvY2FsZVN0cmluZyIsImNhblJldmlldyIsImlzVXJnZW50IiwiZGF5c1JlbWFpbmluZyIsInN0YXRlIiwicmF0aW5nIiwiQm9vbGVhbiIsInJldmlldyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk93bmVyQm9va2luZ1BhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvTmF2YmFyLmpzeFwiO1xuaW1wb3J0IFBheW1lbnRNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9wYXltZW50L1BheW1lbnRNb2RhbC5qc3hcIjtcbmltcG9ydCBDb25maXJtTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQ29uZmlybU1vZGFsLmpzeFwiO1xuaW1wb3J0IFJldmlld01vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL1Jldmlld01vZGFsLmpzeFwiO1xuaW1wb3J0IHsgY2FuY2VsQm9va2luZywgZ2V0T3duZXJCb29raW5ncyB9IGZyb20gXCIuLi9zZXJ2aWNlcy9ib29raW5ncy5qc1wiO1xuaW1wb3J0IHsgZ2V0Qm9va2luZ1Jldmlld1N0YXRlLCBnZXRTYXZlZFJldmlld3MgfSBmcm9tIFwiLi4vdXRpbHMvcmV2aWV3U3RvcmFnZS5qc1wiO1xuaW1wb3J0IHsgZ2V0Qm9va2luZ1BheW1lbnRzIH0gZnJvbSBcIi4uL3NlcnZpY2VzL3BheW1lbnQuYXBpLmpzXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCIuLi91dGlscy90b2FzdC5qc1wiO1xuXG5jb25zdCBTVEFUVVNfTUVUQSA9IHtcbiAgcGVuZGluZzogeyBsYWJlbDogXCLguKPguK3guJ7guLXguYjguYDguKXguLXguYnguKLguIfguJXguK3guJrguKPguLHguJpcIiwgdG9uZTogXCJtdXRlZFwiIH0sXG4gIHdhaXRpbmdfcGF5bWVudDogeyBsYWJlbDogXCLguKPguK3guIrguLPguKPguLDguKHguLHguJTguIjguLNcIiwgdG9uZTogXCJ3YXJuaW5nXCIgfSxcbiAgZGVwb3NpdF9wYWlkOiB7IGxhYmVsOiBcIuC4iuC4s+C4o+C4sOC4oeC4seC4lOC4iOC4s+C5geC4peC5ieC4p1wiLCB0b25lOiBcInN1Y2Nlc3NcIiB9LFxuICBjb25maXJtZWQ6IHsgbGFiZWw6IFwi4Lii4Li34LiZ4Lii4Lix4LiZ4LmB4Lil4LmJ4LinXCIsIHRvbmU6IFwic3VjY2Vzc1wiIH0sXG4gIHdhaXRpbmdfZmluYWxfcGF5bWVudDogeyBsYWJlbDogXCLguKPguK3guIrguLPguKPguLDguKrguYjguKfguJnguJfguLXguYjguYDguKvguKXguLfguK1cIiwgdG9uZTogXCJ3YXJuaW5nXCIgfSxcbiAgY29tcGxldGVkOiB7IGxhYmVsOiBcIuC5gOC4quC4o+C5h+C4iOC4quC4tOC5ieC4mVwiLCB0b25lOiBcIm11dGVkXCIgfSxcbiAgcmVqZWN0ZWQ6IHsgbGFiZWw6IFwi4LiW4Li54LiB4Lib4LiP4Li04LmA4Liq4LiYXCIsIHRvbmU6IFwiZXJyb3JcIiB9LFxuICBjYW5jZWxsZWQ6IHsgbGFiZWw6IFwi4Lii4LiB4LmA4Lil4Li04LiB4LmB4Lil4LmJ4LinXCIsIHRvbmU6IFwiZXJyb3JcIiB9LFxufTtcblxuY29uc3QgRklMVEVSX1RBQlMgPSBbXG4gIHsga2V5OiBcImFsbFwiLCBsYWJlbDogXCLguJfguLHguYnguIfguKvguKHguJRcIiB9LFxuICB7IGtleTogXCJ3YWl0aW5nX3BheW1lbnRcIiwgbGFiZWw6IFwi4Lij4Lit4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXCIgfSxcbiAgeyBrZXk6IFwiY29uZmlybWVkXCIsIGxhYmVsOiBcIuC4ouC4t+C4meC4ouC4seC4meC5geC4peC5ieC4p1wiIH0sXG4gIHsga2V5OiBcImNvbXBsZXRlZFwiLCBsYWJlbDogXCLguYDguKrguKPguYfguIjguKrguLTguYnguJlcIiB9LFxuXTtcblxuY29uc3QgUEFZQUJMRV9TVEFUVVNFUyA9IFtcIndhaXRpbmdfcGF5bWVudFwiLCBcIndhaXRpbmdfZmluYWxfcGF5bWVudFwiXTtcbi8vIOC4ouC4geC5gOC4peC4tOC4geC5hOC4lOC5ieC4geC5iOC4reC4meC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C5gOC4o+C4tOC5iOC4oeC4h+C4suC4mSDigJQg4LiW4LmJ4Liy4LiI4LmI4Liy4Lii4Lih4Lix4LiU4LiI4Liz4LmB4Lil4LmJ4LinIChkZXBvc2l0X3BhaWQpIOC5hOC4oeC5iOC4hOC4t+C4meC5gOC4h+C4tOC4mSAoVVM2LTMpXG5jb25zdCBDQU5DRUxMQUJMRV9TVEFUVVNFUyA9IFtcInBlbmRpbmdcIiwgXCJ3YWl0aW5nX3BheW1lbnRcIiwgXCJkZXBvc2l0X3BhaWRcIl07XG5cbmZ1bmN0aW9uIGZvcm1hdERhdGVSYW5nZShzdGFydCwgZW5kKSB7XG4gIGNvbnN0IHMgPSBuZXcgRGF0ZShzdGFydCk7XG4gIGNvbnN0IGUgPSBuZXcgRGF0ZShlbmQpO1xuICBjb25zdCBkYXRlRm10ID0geyBkYXk6IFwibnVtZXJpY1wiLCBtb250aDogXCJzaG9ydFwiLCB5ZWFyOiBcIm51bWVyaWNcIiB9O1xuICBjb25zdCB0aW1lRm10ID0geyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiB9O1xuICBjb25zdCBzYW1lRGF5ID0gcy50b0RhdGVTdHJpbmcoKSA9PT0gZS50b0RhdGVTdHJpbmcoKTtcbiAgaWYgKHNhbWVEYXkpIHtcbiAgICByZXR1cm4gYCR7cy50b0xvY2FsZURhdGVTdHJpbmcoXCJ0aC1USFwiLCBkYXRlRm10KX0gwrcgJHtzLnRvTG9jYWxlVGltZVN0cmluZyhcInRoLVRIXCIsIHRpbWVGbXQpfSAtICR7ZS50b0xvY2FsZVRpbWVTdHJpbmcoXCJ0aC1USFwiLCB0aW1lRm10KX1gO1xuICB9XG4gIHJldHVybiBgJHtzLnRvTG9jYWxlRGF0ZVN0cmluZyhcInRoLVRIXCIsIGRhdGVGbXQpfSAtICR7ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJ0aC1USFwiLCBkYXRlRm10KX1gO1xufVxuXG4vLyBPd25lckJvb2tpbmdQYWdlIOKAlCDguKPguLLguKLguIHguLLguKMgYm9va2luZyDguILguK3guIfguYDguIjguYnguLLguILguK3guIfguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIcgKyDguJvguLjguYjguKHguIrguLPguKPguLDguYDguIfguLTguJkgKFVTNi0xKSArIOC4m+C4uOC5iOC4oeC4o+C4teC4p+C4tOC4p+C4muC4o+C4tOC4geC4suC4o1xuLy8g4LiU4Li24LiH4LiI4Liy4LiBIEdFVCAvYXBpL293bmVyL2Jvb2tpbmdzIOC5guC4lOC4ouC5g+C4q+C5iSBiYWNrZW5kIOC4geC4o+C4reC4h+C4leC4suC4oeC5geC4l+C5h+C4miAoP3N0YXR1cz0pXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPd25lckJvb2tpbmdQYWdlKCkge1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJhbGxcIik7XG4gIGNvbnN0IFtyZWxvYWRLZXksIHNldFJlbG9hZEtleV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Jlc3VsdCwgc2V0UmVzdWx0XSA9IHVzZVN0YXRlKHsgc3RhdHVzOiBcImxvYWRpbmdcIiwgYm9va2luZ3M6IFtdIH0pO1xuICBjb25zdCBbcGF5aW5nQm9va2luZywgc2V0UGF5aW5nQm9va2luZ10gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3BheW1lbnRTdW1tYXJ5LCBzZXRQYXltZW50U3VtbWFyeV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2lzUGF5bWVudFN1bW1hcnlMb2FkaW5nLCBzZXRJc1BheW1lbnRTdW1tYXJ5TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtwYXltZW50U3VtbWFyeUVycm9yLCBzZXRQYXltZW50U3VtbWFyeUVycm9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BheW1lbnRTdW1tYXJ5UmVsb2FkS2V5LCBzZXRQYXltZW50U3VtbWFyeVJlbG9hZEtleV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2NhbmNlbGxpbmdCb29raW5nLCBzZXRDYW5jZWxsaW5nQm9va2luZ10gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2lzQ2FuY2VsbGluZywgc2V0SXNDYW5jZWxsaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Jldmlld2luZ0Jvb2tpbmcsIHNldFJldmlld2luZ0Jvb2tpbmddID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtzYXZlZFJldmlld3MsIHNldFNhdmVkUmV2aWV3c10gPSB1c2VTdGF0ZSgoKSA9PiBnZXRTYXZlZFJldmlld3MoKSk7XG5cbiAgY29uc3QgcGF5aW5nQm9va2luZ0lkID0gcGF5aW5nQm9va2luZz8uYm9va2luZ0lkIHx8IHBheWluZ0Jvb2tpbmc/LmlkO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBzZXRSZXN1bHQoKHIpID0+ICh7IC4uLnIsIHN0YXR1czogXCJsb2FkaW5nXCIgfSkpO1xuICAgIGdldE93bmVyQm9va2luZ3MoYWN0aXZlVGFiID09PSBcImFsbFwiID8gXCJcIiA6IGFjdGl2ZVRhYiwgeyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIH0pXG4gICAgICAudGhlbigoYm9va2luZ3MpID0+IHNldFJlc3VsdCh7IHN0YXR1czogXCJzdWNjZXNzXCIsIGJvb2tpbmdzIH0pKVxuICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHJldHVybjsgLy8g4LmA4Lib4Lil4Li14LmI4Lii4LiZ4LmB4LiX4LmH4Lia4Lij4Liw4Lir4Lin4LmI4Liy4LiH4LmC4Lir4Lil4LiUXG4gICAgICAgIHNldFJlc3VsdCgocikgPT4gKHsgLi4uciwgc3RhdHVzOiBcImVycm9yXCIgfSkpO1xuICAgICAgfSk7XG4gICAgcmV0dXJuICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgfSwgW2FjdGl2ZVRhYiwgcmVsb2FkS2V5XSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBheWluZ0Jvb2tpbmcpIHtcbiAgICAgIHNldFBheW1lbnRTdW1tYXJ5KG51bGwpO1xuICAgICAgc2V0SXNQYXltZW50U3VtbWFyeUxvYWRpbmcoZmFsc2UpO1xuICAgICAgc2V0UGF5bWVudFN1bW1hcnlFcnJvcihmYWxzZSk7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIGxldCBpc0N1cnJlbnQgPSB0cnVlO1xuICAgIHNldFBheW1lbnRTdW1tYXJ5KG51bGwpO1xuICAgIHNldElzUGF5bWVudFN1bW1hcnlMb2FkaW5nKHRydWUpO1xuICAgIHNldFBheW1lbnRTdW1tYXJ5RXJyb3IoZmFsc2UpO1xuXG4gICAgZ2V0Qm9va2luZ1BheW1lbnRzKHBheWluZ0Jvb2tpbmdJZClcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gcmVzcG9uc2U/LmRhdGE/LmRhdGEgPz8gcmVzcG9uc2U/LmRhdGE7XG4gICAgICAgIGlmICghc3VtbWFyeSB8fCB0eXBlb2Ygc3VtbWFyeSAhPT0gXCJvYmplY3RcIiB8fCAhQXJyYXkuaXNBcnJheShzdW1tYXJ5LnBheW1lbnRzKSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIuC4o+C4ueC4m+C5geC4muC4muC4guC5ieC4reC4oeC4ueC4peC4quC4o+C4uOC4m+C4geC4suC4o+C4iuC4s+C4o+C4sOC5gOC4h+C4tOC4meC5hOC4oeC5iOC4luC4ueC4geC4leC5ieC4reC4h1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNDdXJyZW50KSBzZXRQYXltZW50U3VtbWFyeShzdW1tYXJ5KTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBpZiAoIWlzQ3VycmVudCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBmYWxsYmFja0Ftb3VudCA9IHBheWluZ0Jvb2tpbmc/LnRvdGFscHJpY2UgfHwgcGF5aW5nQm9va2luZz8udG90YWxQcmljZSB8fCAwO1xuICAgICAgICBzZXRQYXltZW50U3VtbWFyeUVycm9yKHRydWUpO1xuICAgICAgICBzZXRQYXltZW50U3VtbWFyeSh7XG4gICAgICAgICAgYm9va2luZ0lkOiBwYXlpbmdCb29raW5nSWQsXG4gICAgICAgICAgYm9va2luZ3N0YXR1czogcGF5aW5nQm9va2luZz8uYm9va2luZ3N0YXR1cyxcbiAgICAgICAgICB0b3RhbFByaWNlOiBmYWxsYmFja0Ftb3VudCxcbiAgICAgICAgICBkZXBvc2l0QW1vdW50OiBmYWxsYmFja0Ftb3VudCxcbiAgICAgICAgICByZW1haW5pbmdBbW91bnQ6IGZhbGxiYWNrQW1vdW50LFxuICAgICAgICAgIHBheW1lbnRwbGFuOiBcImZ1bGxcIixcbiAgICAgICAgICBwYXltZW50X3N0YWdlOiBcImZ1bGxcIixcbiAgICAgICAgICBwYXltZW50czogW10sXG4gICAgICAgIH0pO1xuICAgICAgfSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgaWYgKGlzQ3VycmVudCkgc2V0SXNQYXltZW50U3VtbWFyeUxvYWRpbmcoZmFsc2UpO1xuICAgICAgfSk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNDdXJyZW50ID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW3BheWluZ0Jvb2tpbmcsIHBheWluZ0Jvb2tpbmdJZCwgcGF5bWVudFN1bW1hcnlSZWxvYWRLZXldKTtcblxuICBjb25zdCB7IHN0YXR1cywgYm9va2luZ3MgfSA9IHJlc3VsdDtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVDb25maXJtQ2FuY2VsKCkge1xuICAgIHNldElzQ2FuY2VsbGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2FuY2VsQm9va2luZyhjYW5jZWxsaW5nQm9va2luZy5ib29raW5nSWQpO1xuICAgICAgdG9hc3QoXCLguKLguIHguYDguKXguLTguIHguIHguLLguKPguIjguK3guIfguYDguKPguLXguKLguJrguKPguYnguK3guKLguYHguKXguYnguKdcIiwgXCJzdWNjZXNzXCIpO1xuICAgICAgc2V0Q2FuY2VsbGluZ0Jvb2tpbmcobnVsbCk7XG4gICAgICBzZXRSZWxvYWRLZXkoKGspID0+IGsgKyAxKTsgLy8g4LmC4Lir4Lil4LiU4LiL4LmJ4Liz4LmA4Lie4Li34LmI4Lit4Lit4Lix4Lib4LmA4LiU4LiV4Liq4LiW4Liy4LiZ4LiwL+C4o+C4suC4ouC4geC4suC4o+C4leC4suC4oeC5geC4l+C5h+C4muC4l+C4teC5iOC5gOC4peC4t+C4reC4gVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVyci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDlcbiAgICAgICAgICA/IFwi4LmE4Lih4LmI4Liq4Liy4Lih4Liy4Lij4LiW4Lii4LiB4LmA4Lil4Li04LiB4LmE4LiU4LmJ4LmD4LiZ4Liq4LiW4Liy4LiZ4Liw4LiZ4Li14LmJXCJcbiAgICAgICAgICA6IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIuC4ouC4geC5gOC4peC4tOC4geC4geC4suC4o+C4iOC4reC4h+C5hOC4oeC5iOC4quC4s+C5gOC4o+C5h+C4iCDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIjtcbiAgICAgIHRvYXN0KG1lc3NhZ2UsIFwiZXJyb3JcIik7XG4gICAgICBzZXRDYW5jZWxsaW5nQm9va2luZyhudWxsKTtcbiAgICAgIHNldFJlbG9hZEtleSgoaykgPT4gayArIDEpOyAvLyDguKrguJbguLLguJnguLDguK3guLLguIjguYDguJvguKXguLXguYjguKLguJnguYTguJvguYHguKXguYnguKcgKOC5gOC4iuC5iOC4mSDguJ7guLXguYjguYDguKXguLXguYnguKLguIfguYDguKPguLTguYjguKHguIfguLLguJkpIOC4iOC4tuC4h+C4o+C4teC5gOC4n+C4o+C4iuC4o+C4suC4ouC4geC4suC4o1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0NhbmNlbGxpbmcoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxOYXZiYXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImhvbWUtbWFpbiBib29raW5nLXBhZ2VcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInBhZ2UtdGl0bGVcIj7guIHguLLguKPguIjguK3guIfguILguK3guIfguInguLHguJk8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJzZWN0aW9uLXN1YlwiPuC4leC4tOC4lOC4leC4suC4oeC4quC4luC4suC4meC4sOC4geC4suC4o+C4iOC4reC4hyDguIrguLPguKPguLDguYDguIfguLTguJkg4LmB4Lil4Liw4Lij4Li14Lin4Li04Lin4LmD4Lir4LmJ4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4LiE4Li44LiT4LmA4Lil4Li34Lit4LiB4LmE4Lin4LmJPC9wPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy10YWJzXCI+XG4gICAgICAgICAge0ZJTFRFUl9UQUJTLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3Qua2V5fVxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY2hpcC1idG4ke2FjdGl2ZVRhYiA9PT0gdC5rZXkgPyBcIiBhY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHQua2V5KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3QubGFiZWx9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge3N0YXR1cyA9PT0gXCJsb2FkaW5nXCIgJiYgYm9va2luZ3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRlLWJveFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbW9qaVwiPuKPszwvZGl2PlxuICAgICAgICAgICAgPGgzPuC4geC4s+C4peC4seC4h+C5guC4q+C4peC4lOC4o+C4suC4ouC4geC4suC4o+C4iOC4reC4h+KApjwvaDM+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge3N0YXR1cyA9PT0gXCJlcnJvclwiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRlLWJveCBzdGF0ZS1ib3gtLWVycm9yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtb2ppXCI+4pqg77iPPC9kaXY+XG4gICAgICAgICAgICA8aDM+4LmC4Lir4Lil4LiU4Lij4Liy4Lii4LiB4Liy4Lij4LiI4Lit4LiH4LmE4Lih4LmI4Liq4Liz4LmA4Lij4LmH4LiIPC9oMz5cbiAgICAgICAgICAgIDxwPuC5gOC4geC4tOC4lOC4guC5ieC4reC4nOC4tOC4lOC4nuC4peC4suC4lOC5g+C4meC4geC4suC4o+C5gOC4iuC4t+C5iOC4reC4oeC4leC5iOC4rSDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIc8L3A+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG5cIiBvbkNsaWNrPXsoKSA9PiBzZXRSZWxvYWRLZXkoKGspID0+IGsgKyAxKX0+4Lil4Lit4LiH4LmD4Lir4Lih4LmIPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge3N0YXR1cyA9PT0gXCJzdWNjZXNzXCIgJiYgYm9va2luZ3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRlLWJveFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbW9qaVwiPvCfk4U8L2Rpdj5cbiAgICAgICAgICAgIDxoMz7guYTguKHguYjguKHguLXguKPguLLguKLguIHguLLguKPguIjguK3guIfguYPguJnguKvguKHguKfguJTguJnguLXguYk8L2gzPlxuICAgICAgICAgICAgPHA+4Lil4Lit4LiH4LmA4Lil4Li34Lit4LiB4LmB4LiX4LmH4Lia4Lit4Li34LmI4LiZIOC4q+C4o+C4t+C4reC5gOC4o+C4tOC5iOC4oeC4hOC5ieC4meC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C5gOC4nuC4t+C5iOC4reC4iOC4reC4h+C5g+C4q+C4oeC5iDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7Lyog4Lij4Liw4Lir4Lin4LmI4Liy4LiH4LmA4Lib4Lil4Li14LmI4Lii4LiZ4LmB4LiX4LmH4Lia4Lii4Lix4LiH4LmB4Liq4LiU4LiH4Lij4Liy4Lii4LiB4Liy4Lij4LmA4LiU4Li04Lih4LmB4Lia4Lia4LiI4Liy4LiHIOC5hiDguYHguJfguJnguIHguLLguKPguIHguKPguLDguJ7guKPguLTguJogKi99XG4gICAgICAgIHtib29raW5ncy5sZW5ndGggPiAwICYmIHN0YXR1cyAhPT0gXCJlcnJvclwiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGJvb2tpbmctbGlzdCR7c3RhdHVzID09PSBcImxvYWRpbmdcIiA/IFwiIGlzLWxvYWRpbmdcIiA6IFwiXCJ9YH0+XG4gICAgICAgICAgICB7Ym9va2luZ3MubWFwKChiKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG1ldGEgPSBTVEFUVVNfTUVUQVtiLmJvb2tpbmdzdGF0dXNdID8/IHsgbGFiZWw6IGIuYm9va2luZ3N0YXR1cywgdG9uZTogXCJtdXRlZFwiIH07XG4gICAgICAgICAgICAgIGNvbnN0IGNhblBheSA9IFBBWUFCTEVfU1RBVFVTRVMuaW5jbHVkZXMoYi5ib29raW5nc3RhdHVzKTtcbiAgICAgICAgICAgICAgY29uc3QgY2FuQ2FuY2VsID0gQ0FOQ0VMTEFCTEVfU1RBVFVTRVMuaW5jbHVkZXMoYi5ib29raW5nc3RhdHVzKTtcbiAgICAgICAgICAgICAgY29uc3QgaXNDb21wbGV0ZWQgPSBiLmJvb2tpbmdzdGF0dXMgPT09IFwiY29tcGxldGVkXCI7XG4gICAgICAgICAgICAgIGNvbnN0IHJldmlld1N0YXRlID0gaXNDb21wbGV0ZWQgPyBnZXRCb29raW5nUmV2aWV3U3RhdGUoYiwgc2F2ZWRSZXZpZXdzKSA6IG51bGw7XG4gICAgICAgICAgICAgIGNvbnN0IGhhc0FjdGlvbnMgPSBjYW5DYW5jZWwgfHwgY2FuUGF5IHx8IGlzQ29tcGxldGVkO1xuXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGFydGljbGUga2V5PXtiLmJvb2tpbmdJZH0gY2xhc3NOYW1lPVwiYm9va2luZy1jYXJkXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctY2FyZC10b3BcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib29raW5nLWlkLXRhZ1wiPuC4geC4suC4o+C4iOC4reC4hyAje2IuYm9va2luZ0lkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiYm9va2luZy1zaXR0ZXItbmFtZVwiPntiLnNpdHRlck5hbWV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJib29raW5nLXNlcnZpY2UtbmFtZVwiPntiLnNlcnZpY2VOYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGJvb2tpbmctYmFkZ2UgYm9va2luZy1iYWRnZS0tJHttZXRhLnRvbmV9YH0+e21ldGEubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJvb2tpbmctZGF0ZXRpbWVcIj7wn5eT77iPIHtmb3JtYXREYXRlUmFuZ2UoYi5zdGFydHRpbWUsIGIuZW5kdGltZSl9PC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctcGV0c1wiPlxuICAgICAgICAgICAgICAgICAgICB7Yi5wZXRzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17cC5wZXRJZH0gY2xhc3NOYW1lPVwidGFnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDwn5C+IHtwLnBldE5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICB7cC5wZXROb3RlID8gYCDCtyAke3AucGV0Tm90ZX1gIDogXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jYXJkLWZvb3RcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib29raW5nLXByaWNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNtYWxsPuC4o+C4suC4hOC4suC4o+C4p+C4oTwvc21hbGw+XG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz7guL97TnVtYmVyKGIudG90YWxQcmljZSkudG9Mb2NhbGVTdHJpbmcoXCJ0aC1USFwiKX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge2hhc0FjdGlvbnMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FuQ2FuY2VsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tLXNtYWxsIGJ0bi0tZGFuZ2VyLW91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhbmNlbGxpbmdCb29raW5nKGIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4Lii4LiB4LmA4Lil4Li04LiB4LiB4Liy4Lij4LiI4Lit4LiHXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYW5QYXkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tc21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRTdW1tYXJ5KG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGF5aW5nQm9va2luZyhiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4LiK4Liz4Lij4Liw4LmA4LiH4Li04LiZXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIOC4quC5iOC4p+C4meC4geC4suC4o+C4o+C4teC4p+C4tOC4p+C4quC4s+C4q+C4o+C4seC4muC4h+C4suC4meC4l+C4teC5iOC5gOC4quC4o+C5h+C4iOC4quC4tOC5ieC4mSAoQ29tcGxldGVkKSAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0NvbXBsZXRlZCAmJiByZXZpZXdTdGF0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDEuIOC4ouC4seC4h+C5hOC4oeC5iOC5gOC4hOC4ouC4o+C4teC4p+C4tOC4pyDguYHguKXguLDguKLguLHguIfguYTguKHguYjguYDguIHguLTguJkgMTQg4Lin4Lix4LiZIC0+IOC5geC4quC4lOC4h+C4m+C4uOC5iOC4oeC5g+C4q+C5ieC4geC4lOC4o+C4teC4p+C4tOC4pyDguJ7guKPguYnguK3guKHguYDguJXguLfguK3guJnguYDguKHguLfguYjguK3guYPguIHguKXguYnguKvguKHguJTguYDguKfguKXguLIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlld1N0YXRlLmNhblJldmlldyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvb2tpbmctcmV2aWV3LWFjdGlvbi13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9va2luZy1yZXZpZXctdGltZS1oaW50ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXZpZXdTdGF0ZS5pc1VyZ2VudCA/IFwiYm9va2luZy1yZXZpZXctdGltZS1oaW50LS11cmdlbnRcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXZpZXdTdGF0ZS5pc1VyZ2VudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBg4pqg77iPIOC5gOC4q+C4peC4t+C4reC5gOC4p+C4peC4suC4reC4teC4gSAke3Jldmlld1N0YXRlLmRheXNSZW1haW5pbmd9IOC4p+C4seC4meC4quC4uOC4lOC4l+C5ieC4suC4oiFgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGDij7Mg4LmA4Lir4Lil4Li34Lit4LmA4Lin4Lil4Liy4Lij4Li14Lin4Li04LinICR7cmV2aWV3U3RhdGUuZGF5c1JlbWFpbmluZ30g4Lin4Lix4LiZYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tc21hbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJldmlld2luZ0Jvb2tpbmcoYil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDirZAg4LmD4Lir4LmJ4LiE4Liw4LmB4LiZ4LiZ4LmB4Lil4Liw4Lij4Li14Lin4Li04LinXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAyLiDguJbguYnguLIgcmV2aWV3IOC5geC4peC5ieC4pyAtPiDguYHguKrguJTguIfguJvguYnguLLguKLguKrguJbguLLguJnguLDguKPguLXguKfguLTguKfguYHguKXguYnguKcg4LmB4Lil4Liw4LiE4Lil4Li04LiB4LmA4Lie4Li34LmI4Lit4LiU4Li54Lij4Li14Lin4Li04Lin4LiX4Li14LmI4LmA4LiE4Lii4LmA4LiC4Li14Lii4LiZ4LmE4LiU4LmJICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXZpZXdTdGF0ZS5zdGF0ZSA9PT0gXCJyZXZpZXdlZFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvb2tpbmctYmFkZ2UgYm9va2luZy1iYWRnZS0tcmV2aWV3LWRvbmUgYm9va2luZy1iYWRnZS0tY2xpY2thYmxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCLguITguKXguLTguIHguYDguJ7guLfguYjguK3guJTguLnguKPguLXguKfguLTguKfguJfguLXguYjguITguLjguJPguKrguYjguIfguYTguKfguYlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXZpZXdpbmdCb29raW5nKGIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDinJMg4Lij4Li14Lin4Li04Lin4LmB4Lil4LmJ4LinICh7cmV2aWV3U3RhdGUucmF0aW5nfSDimIUpIMK3IOC4lOC4ueC4o+C4teC4p+C4tOC4p1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAzLiDguJbguYnguLLguYDguKfguKXguLLguJzguYjguLLguJnguYTguJvguYDguIHguLTguJkgMTQg4Lin4Lix4LiZIC0+IOC5geC4quC4lOC4h+C4m+C5ieC4suC4ouC4q+C4oeC4lOC5gOC4p+C4peC4suC4o+C4teC4p+C4tOC4pyDguYTguKHguYjguYPguKvguYnguJvguLjguYjguKHguKvguLLguKLguYTguJvguJTguLfguYnguK3guYYgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Jldmlld1N0YXRlLnN0YXRlID09PSBcImV4cGlyZWRfYXV0b19yZXZpZXdlZFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvb2tpbmctYmFkZ2UgYm9va2luZy1iYWRnZS0tcmV2aWV3LWV4cGlyZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIuC4quC4suC4oeC4suC4o+C4luC4quC5iOC4h+C4o+C4teC4p+C4tOC4p+C5hOC4lOC5ieC4oOC4suC4ouC5g+C4mSAxNCDguKfguLHguJnguKvguKXguLHguIfguYDguKrguKPguYfguIjguKrguLTguYnguJnguJrguKPguLTguIHguLLguKMg4LmA4Lie4Li34LmI4Lit4LiE4Lin4Liy4Lih4LmB4Lih4LmI4LiZ4Lii4Liz4LiC4Lit4LiH4LiC4LmJ4Lit4Lih4Li54LilXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4o+zIOC4q+C4oeC4lOC5gOC4p+C4peC4suC4o+C4teC4p+C4tOC4pyAo4LmA4LiB4Li04LiZIDE0IOC4p+C4seC4mSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2FydGljbGU+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIE1vZGFsIOC4iuC4s+C4o+C4sOC5gOC4h+C4tOC4mSAqL31cbiAgICAgIDxQYXltZW50TW9kYWxcbiAgICAgICAgaXNPcGVuPXtCb29sZWFuKHBheWluZ0Jvb2tpbmcpfVxuICAgICAgICBib29raW5nPXtwYXlpbmdCb29raW5nfVxuICAgICAgICBzdW1tYXJ5PXtwYXltZW50U3VtbWFyeX1cbiAgICAgICAgaXNMb2FkaW5nPXtpc1BheW1lbnRTdW1tYXJ5TG9hZGluZ31cbiAgICAgICAgaXNFcnJvcj17cGF5bWVudFN1bW1hcnlFcnJvcn1cbiAgICAgICAgb25SZXRyeT17KCkgPT4gc2V0UGF5bWVudFN1bW1hcnlSZWxvYWRLZXkoKGtleSkgPT4ga2V5ICsgMSl9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFBheWluZ0Jvb2tpbmcobnVsbCl9XG4gICAgICAgIG9uU3VjY2Vzcz17KCkgPT4ge1xuICAgICAgICAgIHNldFBheWluZ0Jvb2tpbmcobnVsbCk7XG4gICAgICAgICAgc2V0UmVsb2FkS2V5KChrKSA9PiBrICsgMSk7XG4gICAgICAgIH19XG4gICAgICAvPlxuXG5cbiAgICAgIHsvKiBNb2RhbCDguKLguIHguYDguKXguLTguIHguIHguLLguKPguIjguK3guIcgKi99XG4gICAgICB7Y2FuY2VsbGluZ0Jvb2tpbmcgJiYgKFxuICAgICAgICA8Q29uZmlybU1vZGFsXG4gICAgICAgICAgdGl0bGU9XCLguKLguLfguJnguKLguLHguJnguIHguLLguKPguKLguIHguYDguKXguLTguIHguIHguLLguKPguIjguK3guIdcIlxuICAgICAgICAgIG1lc3NhZ2U9XCLguITguLjguJPguJXguYnguK3guIfguIHguLLguKPguKLguIHguYDguKXguLTguIHguIHguLLguKPguIjguK3guIfguJnguLXguYnguYPguIrguYjguKvguKPguLfguK3guYTguKHguYg/IOC4o+C4sOC4muC4muC4iOC4sOC5geC4iOC5ieC4h+C4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C4suC4h+C4reC4teC5gOC4oeC4pSDguYHguKXguLDguYTguKHguYjguKrguLLguKHguLLguKPguJbguKLguYnguK3guJnguIHguKXguLHguJrguYTguJTguYlcIlxuICAgICAgICAgIGNvbmZpcm1UZXh0PVwi4Lii4Li34LiZ4Lii4Lix4LiZ4Lii4LiB4LmA4Lil4Li04LiB4LiB4Liy4Lij4LiI4Lit4LiHXCJcbiAgICAgICAgICBjYW5jZWxUZXh0PVwi4LmE4Lih4LmI4Lii4LiB4LmA4Lil4Li04LiBXCJcbiAgICAgICAgICBpc0Rhbmdlcj17dHJ1ZX1cbiAgICAgICAgICBpc0xvYWRpbmc9e2lzQ2FuY2VsbGluZ31cbiAgICAgICAgICBvbkNvbmZpcm09e2hhbmRsZUNvbmZpcm1DYW5jZWx9XG4gICAgICAgICAgb25DYW5jZWw9eygpID0+ICFpc0NhbmNlbGxpbmcgJiYgc2V0Q2FuY2VsbGluZ0Jvb2tpbmcobnVsbCl9XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbmNlbC1zdW1tYXJ5XCI+XG4gICAgICAgICAgICA8c3Ryb25nPntjYW5jZWxsaW5nQm9va2luZy5zaXR0ZXJOYW1lfTwvc3Ryb25nPiDCtyB7Y2FuY2VsbGluZ0Jvb2tpbmcuc2VydmljZU5hbWV9XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIPCfl5PvuI8ge2Zvcm1hdERhdGVSYW5nZShjYW5jZWxsaW5nQm9va2luZy5zdGFydHRpbWUsIGNhbmNlbGxpbmdCb29raW5nLmVuZHRpbWUpfVxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICDguKPguLLguITguLLguKPguKfguKEg4Li/e051bWJlcihjYW5jZWxsaW5nQm9va2luZy50b3RhbFByaWNlKS50b0xvY2FsZVN0cmluZyhcInRoLVRIXCIpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtjYW5jZWxsaW5nQm9va2luZy5ib29raW5nc3RhdHVzID09PSBcImRlcG9zaXRfcGFpZFwiICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FuY2VsLW5vdGljZVwiPlxuICAgICAgICAgICAgICA8c3Bhbj7imqDvuI88L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+4LiE4LmI4Liy4Lih4Lix4LiU4LiI4Liz4LiX4Li14LmI4LiK4Liz4Lij4Liw4LmB4Lil4LmJ4Lin4LiI4Liw4LmE4Lih4LmI4LmE4LiU4LmJ4Lij4Lix4Lia4LmA4LiH4Li04LiZ4LiE4Li34LiZPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAg4LiE4Li44LiT4LmE4LiU4LmJ4LiK4Liz4Lij4Liw4Lih4Lix4LiU4LiI4Liz4LmE4Lib4LmB4Lil4LmJ4LinIOC4q+C4suC4geC4ouC4geC5gOC4peC4tOC4geC4leC4reC4meC4meC4teC5ieC4iOC4sOC5hOC4oeC5iOC4oeC4teC4geC4suC4o+C4hOC4t+C4meC5gOC4h+C4tOC4meC4quC5iOC4p+C4meC4meC4teC5iVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L0NvbmZpcm1Nb2RhbD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNb2RhbCDguKPguLXguKfguLTguKfguYHguKXguLDguYPguKvguYnguITguLDguYHguJnguJnguIHguLLguKPguJrguKPguLTguIHguLLguKMgKi99XG4gICAgICB7cmV2aWV3aW5nQm9va2luZyAmJiAoXG4gICAgICAgIDxSZXZpZXdNb2RhbFxuICAgICAgICAgIGJvb2tpbmc9e3Jldmlld2luZ0Jvb2tpbmd9XG4gICAgICAgICAgaXNPcGVuPXshIXJldmlld2luZ0Jvb2tpbmd9XG4gICAgICAgICAgZXhpc3RpbmdSZXZpZXc9e3Jldmlld2luZ0Jvb2tpbmcucmV2aWV3IHx8IHNhdmVkUmV2aWV3c1tyZXZpZXdpbmdCb29raW5nLmJvb2tpbmdJZF0gfHwgbnVsbH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRSZXZpZXdpbmdCb29raW5nKG51bGwpfVxuICAgICAgICAgIG9uU3VibWl0U3VjY2Vzcz17KCkgPT4ge1xuICAgICAgICAgICAgc2V0U2F2ZWRSZXZpZXdzKGdldFNhdmVkUmV2aWV3cygpKTtcbiAgICAgICAgICAgIHNldFJlbG9hZEtleSgoaykgPT4gayArIDEpOyAvLyDguKPguLXguYDguJ/guKPguIrguKPguLLguKLguIHguLLguKPguIjguK3guIfguYDguJ7guLfguYjguK3guJTguLbguIcgYm9va2luZy5yZXZpZXcg4Lil4LmI4Liy4Liq4Li44LiU4LiI4Liy4LiBIFNlcnZlclxuICAgICAgICAgICAgc2V0UmV2aWV3aW5nQm9va2luZyhudWxsKTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9wYWdlcy9Pd25lckJvb2tpbmdQYWdlLmpzeCJ9