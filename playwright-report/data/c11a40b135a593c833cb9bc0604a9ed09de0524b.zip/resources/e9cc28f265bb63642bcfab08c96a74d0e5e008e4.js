import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Skeleton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Skeleton.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function Skeleton({ className = "" }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `bg-slate-200 animate-pulse rounded ${className}` }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Skeleton.jsx",
    lineNumber: 31,
    columnNumber: 10
  }, this);
}
_c = Skeleton;
var _c;
$RefreshReg$(_c, "Skeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Skeleton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/Skeleton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYVCxPQUFPQSxXQUFXO0FBVWxCLHdCQUF3QkMsU0FBUyxFQUFFQyxZQUFZLEdBQUcsR0FBRztBQUNuRCxTQUFPLHVCQUFDLFNBQUksV0FBVyxzQ0FBc0NBLFNBQVMsTUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrRTtBQUMzRTtBQUFDQyxLQUZ1QkY7QUFBUSxJQUFBRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNrZWxldG9uIiwiY2xhc3NOYW1lIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2tlbGV0b24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBCYXNlIFNrZWxldG9uIENvbXBvbmVudFxuICogXG4gKiBSZXVzYWJsZSBhbmltYXRlZCBwbGFjZWhvbGRlciBib3ggd2l0aCBhIHNoaW1tZXIgcHVsc2UgZWZmZWN0LlxuICogXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvcHNcbiAqIEBwYXJhbSB7c3RyaW5nfSBbcHJvcHMuY2xhc3NOYW1lPVwiXCJdIC0gQWRkaXRpb25hbCBUYWlsd2luZCBjbGFzc2VzIGZvciB3aWR0aCwgaGVpZ2h0LCBib3JkZXIgcmFkaXVzLCBldGMuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNrZWxldG9uKHsgY2xhc3NOYW1lID0gXCJcIiB9KSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17YGJnLXNsYXRlLTIwMCBhbmltYXRlLXB1bHNlIHJvdW5kZWQgJHtjbGFzc05hbWV9YH0gLz47XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9Ta2VsZXRvbi5qc3gifQ==