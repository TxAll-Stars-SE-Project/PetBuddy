import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/PasswordInput.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
const EyeIcon = () => /* @__PURE__ */ jsxDEV(
  "svg",
  {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    children: [
      /* @__PURE__ */ jsxDEV("path", { d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 25,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "3" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 26,
        columnNumber: 5
      }, this)
    ]
  },
  void 0,
  true,
  {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
    lineNumber: 23,
    columnNumber: 1
  },
  this
);
_c = EyeIcon;
const EyeOffIcon = () => /* @__PURE__ */ jsxDEV(
  "svg",
  {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    children: [
      /* @__PURE__ */ jsxDEV("path", { d: "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 33,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("path", { d: "M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 34,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("line", { x1: "1", y1: "1", x2: "23", y2: "23" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 35,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("path", { d: "M14.12 14.12a3 3 0 1 1-4.24-4.24" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 36,
        columnNumber: 5
      }, this)
    ]
  },
  void 0,
  true,
  {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
    lineNumber: 31,
    columnNumber: 1
  },
  this
);
_c2 = EyeOffIcon;
export default function PasswordInput({ label, required = false, error, ...rest }) {
  _s();
  const [show, setShow] = useState(false);
  return /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: [
      label,
      required && /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
        lineNumber: 47,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          className: "input" + (error ? " input--error" : ""),
          type: show ? "text" : "password",
          ...rest
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
          lineNumber: 51,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "pw-toggle",
          onClick: () => setShow((s) => !s),
          "aria-label": show ? "ซ่อนรหัสผ่าน" : "แสดงรหัสผ่าน",
          tabIndex: -1,
          children: show ? /* @__PURE__ */ jsxDEV(EyeOffIcon, {}, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
            lineNumber: 64,
            columnNumber: 19
          }, this) : /* @__PURE__ */ jsxDEV(EyeIcon, {}, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
            lineNumber: 64,
            columnNumber: 36
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
          lineNumber: 57,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
      lineNumber: 68,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
}
_s(PasswordInput, "NKb1ZOdhT+qUsWLXSgjSS2bk2C4=");
_c3 = PasswordInput;
var _c, _c2, _c3;
$RefreshReg$(_c, "EyeIcon");
$RefreshReg$(_c2, "EyeOffIcon");
$RefreshReg$(_c3, "PasswordInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/PasswordInput.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0k7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTEosU0FBU0EsZ0JBQWdCO0FBRXpCLE1BQU1DLFVBQVVBLE1BQ2Q7QUFBQSxFQUFDO0FBQUE7QUFBQSxJQUFJLE9BQU07QUFBQSxJQUFLLFFBQU87QUFBQSxJQUFLLFNBQVE7QUFBQSxJQUFZLE1BQUs7QUFBQSxJQUFPLFFBQU87QUFBQSxJQUNqRSxhQUFZO0FBQUEsSUFBSSxlQUFjO0FBQUEsSUFBUSxnQkFBZTtBQUFBLElBQ3JEO0FBQUEsNkJBQUMsVUFBSyxHQUFFLGtEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxNQUN0RCx1QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxPQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUE7QUFBQTtBQUFBLEVBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUNBQyxLQU5JRDtBQVFOLE1BQU1FLGFBQWFBLE1BQ2pCO0FBQUEsRUFBQztBQUFBO0FBQUEsSUFBSSxPQUFNO0FBQUEsSUFBSyxRQUFPO0FBQUEsSUFBSyxTQUFRO0FBQUEsSUFBWSxNQUFLO0FBQUEsSUFBTyxRQUFPO0FBQUEsSUFDakUsYUFBWTtBQUFBLElBQUksZUFBYztBQUFBLElBQVEsZ0JBQWU7QUFBQSxJQUNyRDtBQUFBLDZCQUFDLFVBQUssR0FBRSxxRkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlGO0FBQUEsTUFDekYsdUJBQUMsVUFBSyxHQUFFLDRFQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUNoRix1QkFBQyxVQUFLLElBQUcsS0FBSSxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLE1BQ25DLHVCQUFDLFVBQUssR0FBRSxzQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUE7QUFBQTtBQUFBLEVBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNQTtBQUNBQyxNQVJJRDtBQVVOLHdCQUF3QkUsY0FBYyxFQUFFQyxPQUFPQyxXQUFXLE9BQU9DLE9BQU8sR0FBR0MsS0FBSyxHQUFHO0FBQUFDLEtBQUE7QUFDakYsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlaLFNBQVMsS0FBSztBQUV0QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkJBQUMsV0FBTSxXQUFVLGVBQ2RNO0FBQUFBO0FBQUFBLE1BQ0FDLFlBQVksdUJBQUMsVUFBSyxXQUFVLE9BQU0saUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxTQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVcsV0FBV0MsUUFBUSxrQkFBa0I7QUFBQSxVQUNoRCxNQUFNRyxPQUFPLFNBQVM7QUFBQSxVQUN0QixHQUFJRjtBQUFBQTtBQUFBQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdXO0FBQUEsTUFHWDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBUyxNQUFNRyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0EsQ0FBQztBQUFBLFVBQ2hDLGNBQVlGLE9BQU8saUJBQWlCO0FBQUEsVUFDcEMsVUFBVTtBQUFBLFVBRVRBLGlCQUFPLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVcsSUFBTSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQTtBQUFBLFFBUG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFFQ0gsU0FBUyx1QkFBQyxTQUFJLFdBQVUsZUFBZUEsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxPQXhCaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQTtBQUVKO0FBQUNFLEdBL0J1QkwsZUFBYTtBQUFBLE1BQWJBO0FBQWEsSUFBQUgsSUFBQUUsS0FBQVU7QUFBQSxhQUFBWixJQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFVLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkV5ZUljb24iLCJfYyIsIkV5ZU9mZkljb24iLCJfYzIiLCJQYXNzd29yZElucHV0IiwibGFiZWwiLCJyZXF1aXJlZCIsImVycm9yIiwicmVzdCIsIl9zIiwic2hvdyIsInNldFNob3ciLCJzIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBhc3N3b3JkSW5wdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmNvbnN0IEV5ZUljb24gPSAoKSA9PiAoXG4gIDxzdmcgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+XG4gICAgPHBhdGggZD1cIk0xIDEyczQtOCAxMS04IDExIDggMTEgOC00IDgtMTEgOC0xMS04LTExLTh6XCIgLz5cbiAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjNcIiAvPlxuICA8L3N2Zz5cbik7XG5cbmNvbnN0IEV5ZU9mZkljb24gPSAoKSA9PiAoXG4gIDxzdmcgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+XG4gICAgPHBhdGggZD1cIk0xNy45NCAxNy45NEExMC4wNyAxMC4wNyAwIDAgMSAxMiAyMGMtNyAwLTExLTgtMTEtOGExOC40NSAxOC40NSAwIDAgMSA1LjA2LTUuOTRcIiAvPlxuICAgIDxwYXRoIGQ9XCJNOS45IDQuMjRBOS4xMiA5LjEyIDAgMCAxIDEyIDRjNyAwIDExIDggMTEgOGExOC41IDE4LjUgMCAwIDEtMi4xNiAzLjE5XCIgLz5cbiAgICA8bGluZSB4MT1cIjFcIiB5MT1cIjFcIiB4Mj1cIjIzXCIgeTI9XCIyM1wiIC8+XG4gICAgPHBhdGggZD1cIk0xNC4xMiAxNC4xMmEzIDMgMCAxIDEtNC4yNC00LjI0XCIgLz5cbiAgPC9zdmc+XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYXNzd29yZElucHV0KHsgbGFiZWwsIHJlcXVpcmVkID0gZmFsc2UsIGVycm9yLCAuLi5yZXN0IH0pIHtcbiAgY29uc3QgW3Nob3csIHNldFNob3ddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCI+XG4gICAgICAgIHtsYWJlbH1cbiAgICAgICAge3JlcXVpcmVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInJlcVwiPio8L3NwYW4+fVxuICAgICAgPC9sYWJlbD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdy13cmFwXCI+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGNsYXNzTmFtZT17XCJpbnB1dFwiICsgKGVycm9yID8gXCIgaW5wdXQtLWVycm9yXCIgOiBcIlwiKX1cbiAgICAgICAgICB0eXBlPXtzaG93ID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9XG4gICAgICAgICAgey4uLnJlc3R9XG4gICAgICAgIC8+XG4gICAgICAgIHsvKiDwn5GHIOC5gOC4o+C4meC5gOC4lOC4reC4o+C5jOC5geC4hOC5iOC4leC4seC4p+C5gOC4lOC4teC4ouC4p+C4leC4suC4oeC4quC4luC4suC4meC4sCDigJQg4LmB4LiB4LmJ4Lia4Lix4LiE4LmE4Lit4LiE4Lit4LiZ4LiL4LmJ4Lit4LiZICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHctdG9nZ2xlXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93KChzKSA9PiAhcyl9XG4gICAgICAgICAgYXJpYS1sYWJlbD17c2hvdyA/IFwi4LiL4LmI4Lit4LiZ4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZXCIgOiBcIuC5geC4quC4lOC4h+C4o+C4q+C4seC4quC4nOC5iOC4suC4mVwifVxuICAgICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgPlxuICAgICAgICAgIHtzaG93ID8gPEV5ZU9mZkljb24gLz4gOiA8RXllSWNvbiAvPn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxuICAgIDwvZGl2PlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3VpL1Bhc3N3b3JkSW5wdXQuanN4In0=