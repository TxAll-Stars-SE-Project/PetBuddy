import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceFormAlert.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceFormAlert() {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs animate-fade-in", children: [
    /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-4 h-4 text-red-500 shrink-0",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx",
            lineNumber: 37,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx",
        lineNumber: 31,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { children: "ข้อมูลยังไม่ครบถ้วน กรุณากรอกช่องที่มีเครื่องหมายดอกจัน (*) และเลือกสัตว์เลี้ยงอย่างน้อย 1 ชนิด" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_c = ServiceFormAlert;
var _c;
$RefreshReg$(_c, "ServiceFormAlert");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormAlert.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBakJSLE9BQU9BLFdBQVc7QUFRbEIsd0JBQXdCQyxtQkFBbUI7QUFDekMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUhBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsTUFBSztBQUFBLFFBQ0wsU0FBUTtBQUFBLFFBQ1IsUUFBTztBQUFBLFFBRVA7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQWM7QUFBQSxZQUNkLGdCQUFlO0FBQUEsWUFDZixhQUFhO0FBQUEsWUFDYixHQUFFO0FBQUE7QUFBQSxVQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkwSTtBQUFBO0FBQUEsTUFWNUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxJQUNBLHVCQUFDLFVBQUksK0dBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQTtBQUVKO0FBQUNDLEtBckJ1QkQ7QUFBZ0IsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTZXJ2aWNlRm9ybUFsZXJ0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VydmljZUZvcm1BbGVydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG4vKipcbiAqIFNlcnZpY2VGb3JtQWxlcnQgQ29tcG9uZW50XG4gKiBcbiAqIFZhbGlkYXRpb24gZXJyb3IgYmFubmVyIGRpc3BsYXllZCBhdCB0aGUgdG9wIG9mIHRoZSBmb3JtIHdoZW4gc3VibWlzc2lvbiBmYWlscy5cbiAqIENvbXBsaWVzIHdpdGggWmVybyBFbW9qaXMgcnVsZSB1c2luZyBhbiBhbGVydCB0cmlhbmdsZSBTVkcgaWNvbi5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2VydmljZUZvcm1BbGVydCgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcC0zIHJvdW5kZWQteGwgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCB0ZXh0LXJlZC03MDAgdGV4dC14cyBhbmltYXRlLWZhZGUtaW5cIj5cbiAgICAgIDxzdmdcbiAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJlZC01MDAgc2hyaW5rLTBcIlxuICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XG4gICAgICAgICAgZD1cIk0xMiA5djJtMCA0aC4wMW0tNi45MzggNGgxMy44NTZjMS41NCAwIDIuNTAyLTEuNjY3IDEuNzMyLTNMMTMuNzMyIDRjLS43Ny0xLjMzMy0yLjY5NC0xLjMzMy0zLjQ2NCAwTDMuMzQgMTZjLS43NyAxLjMzMy4xOTIgMyAxLjczMiAzelwiXG4gICAgICAgIC8+XG4gICAgICA8L3N2Zz5cbiAgICAgIDxzcGFuPlxuICAgICAgICDguILguYnguK3guKHguLnguKXguKLguLHguIfguYTguKHguYjguITguKPguJrguJbguYnguKfguJkg4LiB4Lij4Li44LiT4Liy4LiB4Lij4Lit4LiB4LiK4LmI4Lit4LiH4LiX4Li14LmI4Lih4Li14LmA4LiE4Lij4Li34LmI4Lit4LiH4Lir4Lih4Liy4Lii4LiU4Lit4LiB4LiI4Lix4LiZICgqKSDguYHguKXguLDguYDguKXguLfguK3guIHguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguK3guKLguYjguLLguIfguJnguYnguK3guKIgMSDguIrguJnguLTguJRcbiAgICAgIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3NpdHRlci9zZXJ2aWNlRm9ybS9TZXJ2aWNlRm9ybUFsZXJ0LmpzeCJ9