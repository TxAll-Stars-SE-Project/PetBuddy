import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LandingPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import Logo from "/src/components/ui/Logo.jsx";
import heroPets from "/src/assets/hero-pets.png?import";
import sitterFah from "/src/assets/sitter-fah.png?import";
import sitterNew from "/src/assets/sitter-new.png?import";
import sitterPoom from "/src/assets/sitter-poom.png?import";
import "/src/styles/landing.css";
const HOW_STEPS = [
  { icon: "🔍", title: "Search & Match", desc: "ค้นหาพี่เลี้ยงโดยกรองตามพื้นที่ ประเภทสัตว์ ช่วงราคา และคะแนนประเมิน" },
  { icon: "📅", title: "Booking Request", desc: "ส่งคำขอจองโดยระบุวัน เวลา และสัตว์เลี้ยงที่ต้องการฝากดูแล" },
  { icon: "✅", title: "Confirmation", desc: "พี่เลี้ยงตรวจสอบรายละเอียดแล้วตอบรับหรือปฏิเสธงานได้ด้วยตัวเอง" },
  { icon: "💳", title: "Payment", desc: "ชำระมัดจำ 30% หรือเต็มจำนวน พร้อมแนบหลักฐานการโอนเงินในระบบ" },
  { icon: "🐾", title: "Service & Update", desc: "พี่เลี้ยงดูแลสัตว์เลี้ยงพร้อมอัปเดตสถานะ เช่น เริ่มงาน กำลังดูแล ส่งมอบคืน" },
  { icon: "⭐", title: "Final Payment & Review", desc: "ชำระส่วนที่เหลือเมื่อจบบริการ และรีวิวเพื่อช่วยผู้ใช้งานคนอื่น" }
];
const TOP_SITTERS = [
  { img: sitterFah, name: "พี่ฟ้า", area: "Bangkok", price: "฿450/วัน", tags: ["พาเดินเล่น", "รับฝากเลี้ยง"], locked: false },
  { img: sitterNew, name: "พี่นิว", area: "Chiang Mai", price: "฿350/วัน", tags: ["พาเดินเล่น", "เยี่ยมบ้าน"], locked: false },
  { img: sitterPoom, name: "พี่ภูมิ", area: "Bangkok", price: "฿500/วัน", tags: [], locked: true }
];
export default function LandingPage() {
  return /* @__PURE__ */ jsxDEV("div", { className: "landing", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "landing-nav", children: /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-inner", children: [
      /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "landing-nav-actions", children: [
        /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--ghost btn--small", to: "/login", children: "เข้าสู่ระบบ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--small", to: "/register", children: "สมัครสมาชิก" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 51,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 49,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "hero", children: /* @__PURE__ */ jsxDEV("div", { className: "hero-inner", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hero-copy", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "hero-badge", children: "🐾 แพลตฟอร์มพี่เลี้ยงสัตว์เลี้ยงที่ไว้ใจได้" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 59,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: [
          "ฝากสัตว์เลี้ยงไว้กับ",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 62,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hero-highlight", children: "พี่เลี้ยงที่ไว้ใจได้" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 63,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 60,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "hero-sub", children: "PetBuddy จับคู่เจ้าของสัตว์เลี้ยงกับพี่เลี้ยงใกล้บ้านที่ผ่านการตรวจสอบ ค้นหา จอง ชำระเงิน และติดตามการดูแล ครบจบในที่เดียว" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 65,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-ctas", children: [
          /* @__PURE__ */ jsxDEV(Link, { className: "btn", to: "/register", children: "สมัครสมาชิกฟรี" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 70,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--ghost", to: "/login", children: "เข้าสู่ระบบ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 71,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 69,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-stats", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🐾 120+" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 74,
              columnNumber: 20
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "พี่เลี้ยงที่ผ่านการตรวจสอบ" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 74,
              columnNumber: 44
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 74,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🐾 4.8/5" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 75,
              columnNumber: 20
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "คะแนนรีวิวเฉลี่ย" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 75,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 75,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "🐾 1,200+" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 76,
              columnNumber: 20
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "การจองที่สำเร็จ" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 76,
              columnNumber: 46
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 76,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 73,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "hero-note", children: "* ข้อมูลตัวอย่างสำหรับการเดโม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 78,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 58,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("img", { className: "hero-img", src: heroPets, alt: "น้องหมาและน้องแมวบนเบาะนุ่ม" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 80,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 57,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "sitters", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "พบกับพี่เลี้ยงเด่นของเรา" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "ดูตัวอย่างได้ฟรี — ล็อกอินเพื่อเปิดโปรไฟล์และค้นหาพี่เลี้ยงทั้งหมด" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 86,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sitter-grid", children: TOP_SITTERS.map(
        (s) => /* @__PURE__ */ jsxDEV("div", { className: "sitter-card", children: [
          /* @__PURE__ */ jsxDEV("img", { className: "sitter-avatar", src: s.img, alt: `รูปโปรไฟล์ของ${s.name}` }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 90,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: s.name }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 91,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "sitter-area", children: s.area }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 92,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "stars", "aria-label": "คะแนน 5 ดาว", children: "★★★★★" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 93,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "sitter-price", children: s.price }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 94,
            columnNumber: 15
          }, this),
          s.locked ? /* @__PURE__ */ jsxDEV(Link, { className: "lock-row", to: "/login", children: "🔒 ล็อกอินเพื่อดูโปรไฟล์เต็ม" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 96,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "tags", children: s.tags.map((t) => /* @__PURE__ */ jsxDEV("span", { className: "tag", children: t }, t, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 99,
            columnNumber: 38
          }, this)) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 98,
            columnNumber: 13
          }, this)
        ] }, s.name, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 89,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { className: "sitters-more", to: "/login", children: "เข้าสู่ระบบเพื่อดูพี่เลี้ยงทั้งหมด →" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 84,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "how", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "ใช้งานยังไง?" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 109,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "section-sub", children: "6 ขั้นตอนง่าย ๆ ตั้งแต่ค้นหาจนถึงรีวิว" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "how-grid", children: HOW_STEPS.map(
        (s, i) => /* @__PURE__ */ jsxDEV("div", { className: "how-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "how-top", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "how-icon", children: s.icon }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 115,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "how-step", children: [
              "ขั้นตอนที่ ",
              i + 1
            ] }, void 0, true, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
              lineNumber: 116,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 114,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: s.title }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 118,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: s.desc }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 119,
            columnNumber: 15
          }, this)
        ] }, s.title, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 113,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "audience", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "audience-card", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "🐶 สำหรับเจ้าของสัตว์เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 127,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { children: [
          /* @__PURE__ */ jsxDEV("li", { children: "ค้นหาและกรองพี่เลี้ยงตามพื้นที่ ราคา และคะแนน" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 129,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "จองบริการและแนบหลักฐานการโอนเงินในระบบ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 130,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "ติดตามสถานะการดูแลสัตว์เลี้ยงได้ตลอด" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 131,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "รีวิวหลังจบบริการเพื่อช่วยชุมชนคนรักสัตว์" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 132,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 128,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 126,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "audience-card", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "🧡 สำหรับพี่เลี้ยงสัตว์" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 136,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { children: [
          /* @__PURE__ */ jsxDEV("li", { children: "สร้างบริการและกำหนดอัตราค่าบริการได้ด้วยตัวเอง" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 138,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: 'จัดการตารางเวลา "ว่าง / ไม่ว่าง" ตามวันและเวลา' }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "ตอบรับหรือปฏิเสธงานได้อย่างอิสระ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 140,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "ส่งอัปเดตสถานะให้เจ้าของระหว่างดูแล" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
            lineNumber: 141,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 125,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "cta-banner", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "พร้อมเข้าร่วมครอบครัว PetBuddy หรือยัง?" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 147,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "สมัครฟรีได้ทั้งเจ้าของสัตว์เลี้ยงและพี่เลี้ยงสัตว์" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 148,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--inverse", to: "/register", children: "เริ่มเลย →" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 149,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 146,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "landing-footer", children: [
      /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 153,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "© 2026 PetBuddy — โครงการรายวิชา Software Engineering" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
        lineNumber: 154,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
      lineNumber: 152,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
}
_c = LandingPage;
var _c;
$RefreshReg$(_c, "LandingPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/LandingPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJWLFNBQVNBLFlBQVk7QUFDckIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBTztBQUVQLE1BQU1DLFlBQVk7QUFBQSxFQUNoQixFQUFFQyxNQUFNLE1BQU1DLE9BQU8sa0JBQTBCQyxNQUFNLHVFQUF1RTtBQUFBLEVBQzVILEVBQUVGLE1BQU0sTUFBTUMsT0FBTyxtQkFBMEJDLE1BQU0sNERBQTREO0FBQUEsRUFDakgsRUFBRUYsTUFBTSxLQUFLQyxPQUFPLGdCQUEwQkMsTUFBTSxpRUFBaUU7QUFBQSxFQUNySCxFQUFFRixNQUFNLE1BQU1DLE9BQU8sV0FBMEJDLE1BQU0sOERBQThEO0FBQUEsRUFDbkgsRUFBRUYsTUFBTSxNQUFNQyxPQUFPLG9CQUEwQkMsTUFBTSw2RUFBNkU7QUFBQSxFQUNsSSxFQUFFRixNQUFNLEtBQUtDLE9BQU8sMEJBQTBCQyxNQUFNLGlFQUFpRTtBQUFDO0FBR3hILE1BQU1DLGNBQWM7QUFBQSxFQUNsQixFQUFFQyxLQUFLUixXQUFZUyxNQUFNLFVBQVdDLE1BQU0sV0FBYUMsT0FBTyxZQUFZQyxNQUFNLENBQUMsY0FBYyxjQUFjLEdBQUdDLFFBQVEsTUFBTTtBQUFBLEVBQzlILEVBQUVMLEtBQUtQLFdBQVlRLE1BQU0sVUFBV0MsTUFBTSxjQUFjQyxPQUFPLFlBQVlDLE1BQU0sQ0FBQyxjQUFjLFlBQVksR0FBS0MsUUFBUSxNQUFNO0FBQUEsRUFDL0gsRUFBRUwsS0FBS04sWUFBWU8sTUFBTSxXQUFXQyxNQUFNLFdBQWFDLE9BQU8sWUFBWUMsTUFBTSxJQUErQkMsUUFBUSxLQUFNO0FBQUM7QUFHaEksd0JBQXdCQyxjQUFjO0FBQ3BDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSwyQkFBQyxZQUFPLFdBQVUsZUFDaEIsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUs7QUFBQSxNQUNMLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSw2QkFBNEIsSUFBRyxVQUFTLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFDbkUsdUJBQUMsUUFBSyxXQUFVLGtCQUFpQixJQUFHLGFBQVksMkJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxXQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLFFBQ2pCLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsY0FBYSwyREFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFLHVCQUFDLFFBQUU7QUFBQTtBQUFBLFVBRUQsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFHO0FBQUEsVUFDSCx1QkFBQyxVQUFLLFdBQVUsa0JBQWlCLG9DQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLGFBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLFlBQVUsMElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsT0FBTSxJQUFHLGFBQVksOEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsUUFBSyxXQUFVLGtCQUFpQixJQUFHLFVBQVMsMkJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUFTLHVCQUFDLFVBQUssMENBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFBUyx1QkFBQyxVQUFLLGdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsZUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxVQUMzRCx1QkFBQyxTQUFJO0FBQUEsbUNBQUMsWUFBTyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQVMsdUJBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLGVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsYUFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsYUFBWSw2Q0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFdBcEJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsWUFBVyxLQUFLZixVQUFVLEtBQUksaUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEU7QUFBQSxTQXZCNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsV0FDakI7QUFBQSw2QkFBQyxRQUFHLHdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUM1Qix1QkFBQyxPQUFFLFdBQVUsZUFBYyxrRkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RjtBQUFBLE1BQzdGLHVCQUFDLFNBQUksV0FBVSxlQUNaUSxzQkFBWVE7QUFBQUEsUUFBSSxDQUFDQyxNQUNoQix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFBZ0IsS0FBS0EsRUFBRVIsS0FBSyxLQUFLLGdCQUFnQlEsRUFBRVAsSUFBSSxNQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLFFBQUlPLFlBQUVQLFFBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLFVBQ1osdUJBQUMsT0FBRSxXQUFVLGVBQWVPLFlBQUVOLFFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQUEsVUFDbkMsdUJBQUMsU0FBSSxXQUFVLFNBQVEsY0FBVyxlQUFjLHFCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQ3JELHVCQUFDLFNBQUksV0FBVSxnQkFBZ0JNLFlBQUVMLFNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFDdENLLEVBQUVILFNBQ0QsdUJBQUMsUUFBSyxXQUFVLFlBQVcsSUFBRyxVQUFTLDRDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRSxJQUVuRSx1QkFBQyxTQUFJLFdBQVUsUUFDWkcsWUFBRUosS0FBS0csSUFBSSxDQUFDRSxNQUFNLHVCQUFDLFVBQUssV0FBVSxPQUFlQSxlQUFKQSxHQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQyxDQUFPLEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVg4QkQsRUFBRVAsTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsTUFDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLFdBQVUsZ0JBQWUsSUFBRyxVQUFTLG9EQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsU0FyQmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSxPQUNqQjtBQUFBLDZCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLE1BQ2hCLHVCQUFDLE9BQUUsV0FBVSxlQUFjLHNEQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsU0FBSSxXQUFVLFlBQ1pOLG9CQUFVWTtBQUFBQSxRQUFJLENBQUNDLEdBQUdFLE1BQ2pCLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsWUFBWUYsWUFBRVosUUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUNuQyx1QkFBQyxVQUFLLFdBQVUsWUFBVztBQUFBO0FBQUEsY0FBWWMsSUFBSTtBQUFBLGlCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLGVBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFFBQUlGLFlBQUVYLFNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQ2IsdUJBQUMsT0FBR1csWUFBRVYsUUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsYUFOa0JVLEVBQUVYLE9BQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLE1BQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLFlBQ2pCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsUUFBRywyQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFDL0IsdUJBQUMsUUFDQztBQUFBLGlDQUFDLFFBQUcsNkRBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxRQUFHLHNEQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsVUFDMUMsdUJBQUMsUUFBRyxvREFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQ3hDLHVCQUFDLFFBQUcseURBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxhQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsUUFBRyx1Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDM0IsdUJBQUMsUUFDQztBQUFBLGlDQUFDLFFBQUcsOERBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxRQUFHLDhEQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsUUFBRyxnREFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQ3BDLHVCQUFDLFFBQUcsbURBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxhQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUVBLHVCQUFDLGFBQVEsV0FBVSxjQUNqQjtBQUFBLDZCQUFDLFFBQUcsdURBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLE1BQzNDLHVCQUFDLE9BQUUsa0VBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQ3JELHVCQUFDLFFBQUssV0FBVSxvQkFBbUIsSUFBRyxhQUFZLDBCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsU0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFFQSx1QkFBQyxZQUFPLFdBQVUsa0JBQ2hCO0FBQUEsNkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUs7QUFBQSxNQUNMLHVCQUFDLE9BQUUscUVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLFNBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BOUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErR0E7QUFFSjtBQUFDYyxLQW5IdUJMO0FBQVcsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGluayIsIkxvZ28iLCJoZXJvUGV0cyIsInNpdHRlckZhaCIsInNpdHRlck5ldyIsInNpdHRlclBvb20iLCJIT1dfU1RFUFMiLCJpY29uIiwidGl0bGUiLCJkZXNjIiwiVE9QX1NJVFRFUlMiLCJpbWciLCJuYW1lIiwiYXJlYSIsInByaWNlIiwidGFncyIsImxvY2tlZCIsIkxhbmRpbmdQYWdlIiwibWFwIiwicyIsInQiLCJpIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGFuZGluZ1BhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IExvZ28gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvTG9nby5qc3hcIjtcbmltcG9ydCBoZXJvUGV0cyBmcm9tIFwiLi4vYXNzZXRzL2hlcm8tcGV0cy5wbmdcIjtcbmltcG9ydCBzaXR0ZXJGYWggZnJvbSBcIi4uL2Fzc2V0cy9zaXR0ZXItZmFoLnBuZ1wiO1xuaW1wb3J0IHNpdHRlck5ldyBmcm9tIFwiLi4vYXNzZXRzL3NpdHRlci1uZXcucG5nXCI7XG5pbXBvcnQgc2l0dGVyUG9vbSBmcm9tIFwiLi4vYXNzZXRzL3NpdHRlci1wb29tLnBuZ1wiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL2xhbmRpbmcuY3NzXCI7XG5cbmNvbnN0IEhPV19TVEVQUyA9IFtcbiAgeyBpY29uOiBcIvCflI1cIiwgdGl0bGU6IFwiU2VhcmNoICYgTWF0Y2hcIiwgICAgICAgICBkZXNjOiBcIuC4hOC5ieC4meC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C5guC4lOC4ouC4geC4o+C4reC4h+C4leC4suC4oeC4nuC4t+C5ieC4meC4l+C4teC5iCDguJvguKPguLDguYDguKDguJfguKrguLHguJXguKfguYwg4LiK4LmI4Lin4LiH4Lij4Liy4LiE4LiyIOC5geC4peC4sOC4hOC4sOC5geC4meC4meC4m+C4o+C4sOC5gOC4oeC4tOC4mVwiIH0sXG4gIHsgaWNvbjogXCLwn5OFXCIsIHRpdGxlOiBcIkJvb2tpbmcgUmVxdWVzdFwiLCAgICAgICAgZGVzYzogXCLguKrguYjguIfguITguLPguILguK3guIjguK3guIfguYLguJTguKLguKPguLDguJrguLjguKfguLHguJkg4LmA4Lin4Lil4LiyIOC5geC4peC4sOC4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4l+C4teC5iOC4leC5ieC4reC4h+C4geC4suC4o+C4neC4suC4geC4lOC4ueC5geC4pVwiIH0sXG4gIHsgaWNvbjogXCLinIVcIiwgdGl0bGU6IFwiQ29uZmlybWF0aW9uXCIsICAgICAgICAgICBkZXNjOiBcIuC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4leC4o+C4p+C4iOC4quC4reC4muC4o+C4suC4ouC4peC4sOC5gOC4reC4teC4ouC4lOC5geC4peC5ieC4p+C4leC4reC4muC4o+C4seC4muC4q+C4o+C4t+C4reC4m+C4j+C4tOC5gOC4quC4mOC4h+C4suC4meC5hOC4lOC5ieC4lOC5ieC4p+C4ouC4leC4seC4p+C5gOC4reC4h1wiIH0sXG4gIHsgaWNvbjogXCLwn5KzXCIsIHRpdGxlOiBcIlBheW1lbnRcIiwgICAgICAgICAgICAgICAgZGVzYzogXCLguIrguLPguKPguLDguKHguLHguJTguIjguLMgMzAlIOC4q+C4o+C4t+C4reC5gOC4leC5h+C4oeC4iOC4s+C4meC4p+C4mSDguJ7guKPguYnguK3guKHguYHguJnguJrguKvguKXguLHguIHguJDguLLguJnguIHguLLguKPguYLguK3guJnguYDguIfguLTguJnguYPguJnguKPguLDguJrguJpcIiB9LFxuICB7IGljb246IFwi8J+QvlwiLCB0aXRsZTogXCJTZXJ2aWNlICYgVXBkYXRlXCIsICAgICAgIGRlc2M6IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiU4Li54LmB4Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4Lie4Lij4LmJ4Lit4Lih4Lit4Lix4Lib4LmA4LiU4LiV4Liq4LiW4Liy4LiZ4LiwIOC5gOC4iuC5iOC4mSDguYDguKPguLTguYjguKHguIfguLLguJkg4LiB4Liz4Lil4Lix4LiH4LiU4Li54LmB4LilIOC4quC5iOC4h+C4oeC4reC4muC4hOC4t+C4mVwiIH0sXG4gIHsgaWNvbjogXCLirZBcIiwgdGl0bGU6IFwiRmluYWwgUGF5bWVudCAmIFJldmlld1wiLCBkZXNjOiBcIuC4iuC4s+C4o+C4sOC4quC5iOC4p+C4meC4l+C4teC5iOC5gOC4q+C4peC4t+C4reC5gOC4oeC4t+C5iOC4reC4iOC4muC4muC4o+C4tOC4geC4suC4oyDguYHguKXguLDguKPguLXguKfguLTguKfguYDguJ7guLfguYjguK3guIrguYjguKfguKLguJzguLnguYnguYPguIrguYnguIfguLLguJnguITguJnguK3guLfguYjguJlcIiB9LFxuXTtcblxuY29uc3QgVE9QX1NJVFRFUlMgPSBbXG4gIHsgaW1nOiBzaXR0ZXJGYWgsICBuYW1lOiBcIuC4nuC4teC5iOC4n+C5ieC4slwiLCAgYXJlYTogXCJCYW5na29rXCIsICAgcHJpY2U6IFwi4Li/NDUwL+C4p+C4seC4mVwiLCB0YWdzOiBbXCLguJ7guLLguYDguJTguLTguJnguYDguKXguYjguJlcIiwgXCLguKPguLHguJrguJ3guLLguIHguYDguKXguLXguYnguKLguIdcIl0sIGxvY2tlZDogZmFsc2UgfSxcbiAgeyBpbWc6IHNpdHRlck5ldywgIG5hbWU6IFwi4Lie4Li14LmI4LiZ4Li04LinXCIsICBhcmVhOiBcIkNoaWFuZyBNYWlcIiwgcHJpY2U6IFwi4Li/MzUwL+C4p+C4seC4mVwiLCB0YWdzOiBbXCLguJ7guLLguYDguJTguLTguJnguYDguKXguYjguJlcIiwgXCLguYDguKLguLXguYjguKLguKHguJrguYnguLLguJlcIl0sICAgbG9ja2VkOiBmYWxzZSB9LFxuICB7IGltZzogc2l0dGVyUG9vbSwgbmFtZTogXCLguJ7guLXguYjguKDguLnguKHguLRcIiwgYXJlYTogXCJCYW5na29rXCIsICAgcHJpY2U6IFwi4Li/NTAwL+C4p+C4seC4mVwiLCB0YWdzOiBbXSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9ja2VkOiB0cnVlICB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGFuZGluZ1BhZ2UoKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImxhbmRpbmctbmF2XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtaW5uZXJcIj5cbiAgICAgICAgICA8TG9nbyAvPlxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtYWN0aW9uc1wiPlxuICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tZ2hvc3QgYnRuLS1zbWFsbFwiIHRvPVwiL2xvZ2luXCI+4LmA4LiC4LmJ4Liy4Liq4Li54LmI4Lij4Liw4Lia4LiaPC9MaW5rPlxuICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tc21hbGxcIiB0bz1cIi9yZWdpc3RlclwiPuC4quC4oeC4seC4hOC4o+C4quC4oeC4suC4iuC4tOC4gTwvTGluaz5cbiAgICAgICAgICA8L25hdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiaGVyb1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8taW5uZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY29weVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGVyby1iYWRnZVwiPvCfkL4g4LmB4Lie4Lil4LiV4Lif4Lit4Lij4LmM4Lih4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4LmE4Lin4LmJ4LmD4LiI4LmE4LiU4LmJPC9zcGFuPlxuICAgICAgICAgICAgPGgxPlxuICAgICAgICAgICAgICDguJ3guLLguIHguKrguLHguJXguKfguYzguYDguKXguLXguYnguKLguIfguYTguKfguYnguIHguLHguJpcbiAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhlcm8taGlnaGxpZ2h0XCI+4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4LmE4Lin4LmJ4LmD4LiI4LmE4LiU4LmJPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8tc3ViXCI+XG4gICAgICAgICAgICAgIFBldEJ1ZGR5IOC4iOC4seC4muC4hOC4ueC5iOC5gOC4iOC5ieC4suC4guC4reC4h+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C4geC4seC4muC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C5g+C4geC4peC5ieC4muC5ieC4suC4meC4l+C4teC5iOC4nOC5iOC4suC4meC4geC4suC4o+C4leC4o+C4p+C4iOC4quC4reC4mlxuICAgICAgICAgICAgICDguITguYnguJnguKvguLIg4LiI4Lit4LiHIOC4iuC4s+C4o+C4sOC5gOC4h+C4tOC4mSDguYHguKXguLDguJXguLTguJTguJXguLLguKHguIHguLLguKPguJTguLnguYHguKUg4LiE4Lij4Lia4LiI4Lia4LmD4LiZ4LiX4Li14LmI4LmA4LiU4Li14Lii4LinXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY3Rhc1wiPlxuICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJidG5cIiB0bz1cIi9yZWdpc3RlclwiPuC4quC4oeC4seC4hOC4o+C4quC4oeC4suC4iuC4tOC4geC4n+C4o+C4tTwvTGluaz5cbiAgICAgICAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tZ2hvc3RcIiB0bz1cIi9sb2dpblwiPuC5gOC4guC5ieC4suC4quC4ueC5iOC4o+C4sOC4muC4mjwvTGluaz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLXN0YXRzXCI+XG4gICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz7wn5C+IDEyMCs8L3N0cm9uZz48c3Bhbj7guJ7guLXguYjguYDguKXguLXguYnguKLguIfguJfguLXguYjguJzguYjguLLguJnguIHguLLguKPguJXguKPguKfguIjguKrguK3guJo8L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz7wn5C+IDQuOC81PC9zdHJvbmc+PHNwYW4+4LiE4Liw4LmB4LiZ4LiZ4Lij4Li14Lin4Li04Lin4LmA4LiJ4Lil4Li14LmI4LiiPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+8J+QviAxLDIwMCs8L3N0cm9uZz48c3Bhbj7guIHguLLguKPguIjguK3guIfguJfguLXguYjguKrguLPguYDguKPguYfguIg8L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8tbm90ZVwiPiog4LiC4LmJ4Lit4Lih4Li54Lil4LiV4Lix4Lin4Lit4Lii4LmI4Liy4LiH4Liq4Liz4Lir4Lij4Lix4Lia4LiB4Liy4Lij4LmA4LiU4LmC4LihPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwiaGVyby1pbWdcIiBzcmM9e2hlcm9QZXRzfSBhbHQ9XCLguJnguYnguK3guIfguKvguKHguLLguYHguKXguLDguJnguYnguK3guIfguYHguKHguKfguJrguJnguYDguJrguLLguLDguJnguLjguYjguKFcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2l0dGVyc1wiPlxuICAgICAgICA8aDI+4Lie4Lia4LiB4Lix4Lia4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LmA4LiU4LmI4LiZ4LiC4Lit4LiH4LmA4Lij4LiyPC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic2VjdGlvbi1zdWJcIj7guJTguLnguJXguLHguKfguK3guKLguYjguLLguIfguYTguJTguYnguJ/guKPguLUg4oCUIOC4peC5h+C4reC4geC4reC4tOC4meC5gOC4nuC4t+C5iOC4reC5gOC4m+C4tOC4lOC5guC4m+C4o+C5hOC4n+C4peC5jOC5geC4peC4sOC4hOC5ieC4meC4q+C4suC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C4seC5ieC4h+C4q+C4oeC4lDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaXR0ZXItZ3JpZFwiPlxuICAgICAgICAgIHtUT1BfU0lUVEVSUy5tYXAoKHMpID0+IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLWNhcmRcIiBrZXk9e3MubmFtZX0+XG4gICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwic2l0dGVyLWF2YXRhclwiIHNyYz17cy5pbWd9IGFsdD17YOC4o+C4ueC4m+C5guC4m+C4o+C5hOC4n+C4peC5jOC4guC4reC4hyR7cy5uYW1lfWB9IC8+XG4gICAgICAgICAgICAgIDxoMz57cy5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpdHRlci1hcmVhXCI+e3MuYXJlYX08L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhcnNcIiBhcmlhLWxhYmVsPVwi4LiE4Liw4LmB4LiZ4LiZIDUg4LiU4Liy4LinXCI+4piF4piF4piF4piF4piFPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0dGVyLXByaWNlXCI+e3MucHJpY2V9PC9kaXY+XG4gICAgICAgICAgICAgIHtzLmxvY2tlZCA/IChcbiAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJsb2NrLXJvd1wiIHRvPVwiL2xvZ2luXCI+8J+UkiDguKXguYfguK3guIHguK3guLTguJnguYDguJ7guLfguYjguK3guJTguLnguYLguJvguKPguYTguJ/guKXguYzguYDguJXguYfguKE8L0xpbms+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWdzXCI+XG4gICAgICAgICAgICAgICAgICB7cy50YWdzLm1hcCgodCkgPT4gPHNwYW4gY2xhc3NOYW1lPVwidGFnXCIga2V5PXt0fT57dH08L3NwYW4+KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwic2l0dGVycy1tb3JlXCIgdG89XCIvbG9naW5cIj7guYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJrguYDguJ7guLfguYjguK3guJTguLnguJ7guLXguYjguYDguKXguLXguYnguKLguIfguJfguLHguYnguIfguKvguKHguJQg4oaSPC9MaW5rPlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJob3dcIj5cbiAgICAgICAgPGgyPuC5g+C4iuC5ieC4h+C4suC4meC4ouC4seC4h+C5hOC4hz88L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJzZWN0aW9uLXN1YlwiPjYg4LiC4Lix4LmJ4LiZ4LiV4Lit4LiZ4LiH4LmI4Liy4LiiIOC5hiDguJXguLHguYnguIfguYHguJXguYjguITguYnguJnguKvguLLguIjguJnguJbguLbguIfguKPguLXguKfguLTguKc8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG93LWdyaWRcIj5cbiAgICAgICAgICB7SE9XX1NURVBTLm1hcCgocywgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob3ctY2FyZFwiIGtleT17cy50aXRsZX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG93LXRvcFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhvdy1pY29uXCI+e3MuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaG93LXN0ZXBcIj7guILguLHguYnguJnguJXguK3guJnguJfguLXguYgge2kgKyAxfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxoMz57cy50aXRsZX08L2gzPlxuICAgICAgICAgICAgICA8cD57cy5kZXNjfTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYXVkaWVuY2VcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdWRpZW5jZS1jYXJkXCI+XG4gICAgICAgICAgPGgzPvCfkLYg4Liq4Liz4Lir4Lij4Lix4Lia4LmA4LiI4LmJ4Liy4LiC4Lit4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHPC9oMz5cbiAgICAgICAgICA8dWw+XG4gICAgICAgICAgICA8bGk+4LiE4LmJ4LiZ4Lir4Liy4LmB4Lil4Liw4LiB4Lij4Lit4LiH4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LiV4Liy4Lih4Lie4Li34LmJ4LiZ4LiX4Li14LmIIOC4o+C4suC4hOC4siDguYHguKXguLDguITguLDguYHguJnguJk8L2xpPlxuICAgICAgICAgICAgPGxpPuC4iOC4reC4h+C4muC4o+C4tOC4geC4suC4o+C5geC4peC4sOC5geC4meC4muC4q+C4peC4seC4geC4kOC4suC4meC4geC4suC4o+C5guC4reC4meC5gOC4h+C4tOC4meC5g+C4meC4o+C4sOC4muC4mjwvbGk+XG4gICAgICAgICAgICA8bGk+4LiV4Li04LiU4LiV4Liy4Lih4Liq4LiW4Liy4LiZ4Liw4LiB4Liy4Lij4LiU4Li54LmB4Lil4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LmE4LiU4LmJ4LiV4Lil4Lit4LiUPC9saT5cbiAgICAgICAgICAgIDxsaT7guKPguLXguKfguLTguKfguKvguKXguLHguIfguIjguJrguJrguKPguLTguIHguLLguKPguYDguJ7guLfguYjguK3guIrguYjguKfguKLguIrguLjguKHguIrguJnguITguJnguKPguLHguIHguKrguLHguJXguKfguYw8L2xpPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1ZGllbmNlLWNhcmRcIj5cbiAgICAgICAgICA8aDM+8J+noSDguKrguLPguKvguKPguLHguJrguJ7guLXguYjguYDguKXguLXguYnguKLguIfguKrguLHguJXguKfguYw8L2gzPlxuICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgIDxsaT7guKrguKPguYnguLLguIfguJrguKPguLTguIHguLLguKPguYHguKXguLDguIHguLPguKvguJnguJTguK3guLHguJXguKPguLLguITguYjguLLguJrguKPguLTguIHguLLguKPguYTguJTguYnguJTguYnguKfguKLguJXguLHguKfguYDguK3guIc8L2xpPlxuICAgICAgICAgICAgPGxpPuC4iOC4seC4lOC4geC4suC4o+C4leC4suC4o+C4suC4h+C5gOC4p+C4peC4siBcIuC4p+C5iOC4suC4hyAvIOC5hOC4oeC5iOC4p+C5iOC4suC4h1wiIOC4leC4suC4oeC4p+C4seC4meC5geC4peC4sOC5gOC4p+C4peC4sjwvbGk+XG4gICAgICAgICAgICA8bGk+4LiV4Lit4Lia4Lij4Lix4Lia4Lir4Lij4Li34Lit4Lib4LiP4Li04LmA4Liq4LiY4LiH4Liy4LiZ4LmE4LiU4LmJ4Lit4Lii4LmI4Liy4LiH4Lit4Li04Liq4Lij4LiwPC9saT5cbiAgICAgICAgICAgIDxsaT7guKrguYjguIfguK3guLHguJvguYDguJTguJXguKrguJbguLLguJnguLDguYPguKvguYnguYDguIjguYnguLLguILguK3guIfguKPguLDguKvguKfguYjguLLguIfguJTguLnguYHguKU8L2xpPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjdGEtYmFubmVyXCI+XG4gICAgICAgIDxoMj7guJ7guKPguYnguK3guKHguYDguILguYnguLLguKPguYjguKfguKHguITguKPguK3guJrguITguKPguLHguKcgUGV0QnVkZHkg4Lir4Lij4Li34Lit4Lii4Lix4LiHPzwvaDI+XG4gICAgICAgIDxwPuC4quC4oeC4seC4hOC4o+C4n+C4o+C4teC5hOC4lOC5ieC4l+C4seC5ieC4h+C5gOC4iOC5ieC4suC4guC4reC4h+C4quC4seC4leC4p+C5jOC5gOC4peC4teC5ieC4ouC4h+C5geC4peC4sOC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4quC4seC4leC4p+C5jDwvcD5cbiAgICAgICAgPExpbmsgY2xhc3NOYW1lPVwiYnRuIGJ0bi0taW52ZXJzZVwiIHRvPVwiL3JlZ2lzdGVyXCI+4LmA4Lij4Li04LmI4Lih4LmA4Lil4LiiIOKGkjwvTGluaz5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJsYW5kaW5nLWZvb3RlclwiPlxuICAgICAgICA8TG9nbyAvPlxuICAgICAgICA8cD7CqSAyMDI2IFBldEJ1ZGR5IOKAlCDguYLguITguKPguIfguIHguLLguKPguKPguLLguKLguKfguLTguIrguLIgU29mdHdhcmUgRW5naW5lZXJpbmc8L3A+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvcGFnZXMvTGFuZGluZ1BhZ2UuanN4In0=