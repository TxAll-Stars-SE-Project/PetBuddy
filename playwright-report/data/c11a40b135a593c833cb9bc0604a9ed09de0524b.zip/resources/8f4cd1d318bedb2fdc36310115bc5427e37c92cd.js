import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/PriceStepperInput.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function PriceStepperInput({
  value,
  onChange,
  unitHint = "฿ / ชม.",
  error = "",
  id = "price-stepper-input",
  step = 10
}) {
  const handleStep = (delta) => {
    const current = Number(value) || 0;
    const nextVal = Math.max(0, current + delta);
    if (onChange) onChange(nextVal);
  };
  const handleInputChange = (e) => {
    if (onChange) onChange(e.target.value);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1", children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: id, className: "text-xs font-semibold text-slate-700", children: [
        "อัตราค่าบริการ ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
          lineNumber: 61,
          columnNumber: 26
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-[#0F766E]", children: unitHint }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "absolute left-3 text-slate-400 font-bold text-sm pointer-events-none select-none", children: "฿" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
        lineNumber: 68,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          id,
          type: "number",
          min: "0",
          step,
          value,
          onChange: handleInputChange,
          placeholder: "0",
          className: `w-full pl-8 pr-12 py-2 text-sm border-2 rounded-xl focus:outline-none bg-white text-slate-800 transition-colors [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${error ? "border-red-400 focus:border-red-500" : "border-slate-200 focus:border-[#F97316]"}`
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "absolute right-1 top-1 bottom-1 flex flex-col w-7 border-l border-slate-200", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleStep(step),
            className: "flex-1 flex items-center justify-center text-slate-500 hover:text-[#EA580C] hover:bg-[#FFF3E8] rounded-tr-lg transition-colors text-[9px] cursor-pointer select-none leading-none",
            title: `เพิ่ม ${step} บาท`,
            "aria-label": `เพิ่ม ${step} บาท`,
            children: "▲"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
            lineNumber: 90,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "h-[1px] bg-slate-200 w-full" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
          lineNumber: 99,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handleStep(-step),
            className: "flex-1 flex items-center justify-center text-slate-500 hover:text-[#EA580C] hover:bg-[#FFF3E8] rounded-br-lg transition-colors text-[9px] cursor-pointer select-none leading-none",
            title: `ลด ${step} บาท`,
            "aria-label": `ลด ${step} บาท`,
            children: "▼"
          },
          void 0,
          false,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
            lineNumber: 100,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
        lineNumber: 89,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-red-500 mt-1 block", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
}
_c = PriceStepperInput;
var _c;
$RefreshReg$(_c, "PriceStepperInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/PriceStepperInput.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUN5Qjs7Ozs7Ozs7Ozs7Ozs7OztBQXpDekIsT0FBT0EsV0FBVztBQWtCbEIsd0JBQXdCQyxrQkFBa0I7QUFBQSxFQUN4Q0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsV0FBVztBQUFBLEVBQ1hDLFFBQVE7QUFBQSxFQUNSQyxLQUFLO0FBQUEsRUFDTEMsT0FBTztBQUNULEdBQUc7QUFFRCxRQUFNQyxhQUFhQSxDQUFDQyxVQUFVO0FBQzVCLFVBQU1DLFVBQVVDLE9BQU9ULEtBQUssS0FBSztBQUNqQyxVQUFNVSxVQUFVQyxLQUFLQyxJQUFJLEdBQUdKLFVBQVVELEtBQUs7QUFDM0MsUUFBSU4sU0FBVUEsVUFBU1MsT0FBTztBQUFBLEVBQ2hDO0FBRUEsUUFBTUcsb0JBQW9CQSxDQUFDQyxNQUFNO0FBQy9CLFFBQUliLFNBQVVBLFVBQVNhLEVBQUVDLE9BQU9mLEtBQUs7QUFBQSxFQUN2QztBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLFdBQU0sU0FBU0ksSUFBSSxXQUFVLHdDQUFzQztBQUFBO0FBQUEsUUFDbkQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsb0NBQW9DRixzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLFNBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhCQUViO0FBQUEsNkJBQUMsVUFBSyxXQUFVLG9GQUFrRixpQkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLE1BQUs7QUFBQSxVQUNMLEtBQUk7QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0EsVUFBVVc7QUFBQUEsVUFDVixhQUFZO0FBQUEsVUFDWixXQUFXLHdPQUNUVixRQUNJLHdDQUNBLHlDQUF5QztBQUFBO0FBQUEsUUFYakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUs7QUFBQSxNQUlMLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1HLFdBQVdELElBQUk7QUFBQSxZQUM5QixXQUFVO0FBQUEsWUFDVixPQUFPLFNBQVNBLElBQUk7QUFBQSxZQUNwQixjQUFZLFNBQVNBLElBQUk7QUFBQSxZQUFPO0FBQUE7QUFBQSxVQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUM1QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNQyxXQUFXLENBQUNELElBQUk7QUFBQSxZQUMvQixXQUFVO0FBQUEsWUFDVixPQUFPLE1BQU1BLElBQUk7QUFBQSxZQUNqQixjQUFZLE1BQU1BLElBQUk7QUFBQSxZQUFPO0FBQUE7QUFBQSxVQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNENBO0FBQUEsSUFFQ0YsU0FDQyx1QkFBQyxVQUFLLFdBQVUsbUNBQ2JBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyREE7QUFFSjtBQUFDYSxLQWpGdUJqQjtBQUFpQixJQUFBaUI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJQcmljZVN0ZXBwZXJJbnB1dCIsInZhbHVlIiwib25DaGFuZ2UiLCJ1bml0SGludCIsImVycm9yIiwiaWQiLCJzdGVwIiwiaGFuZGxlU3RlcCIsImRlbHRhIiwiY3VycmVudCIsIk51bWJlciIsIm5leHRWYWwiLCJNYXRoIiwibWF4IiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJlIiwidGFyZ2V0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJpY2VTdGVwcGVySW5wdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBQcmljZVN0ZXBwZXJJbnB1dCBDb21wb25lbnRcbiAqIFxuICogU2VsZi1jb250YWluZWQgQ29udHJvbGxlZCBTdGVwcGVyIElucHV0OlxuICogLSBFbmNhcHN1bGF0ZXMgc3RlcHBpbmcgY2FsY3VsYXRpb25zICgrMTAgLyAtMTApIGludGVybmFsbHkuXG4gKiAtIFBhcmVudCBvbmx5IHN1cHBsaWVzIGB2YWx1ZWAgYW5kIGEgc2luZ2xlIGBvbkNoYW5nZShuZXdWYWx1ZSlgIGNhbGxiYWNrLlxuICogLSBTdXBwcmVzc2VzIG5hdGl2ZSBicm93c2VyIHNwaW5uZXJzIGZvciBjbGVhbiBjcm9zcy1icm93c2VyIGRlc2lnbi5cbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge251bWJlcnxzdHJpbmd9IHByb3BzLnZhbHVlIC0gQ3VycmVudCBwcmljZSB2YWx1ZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2hhbmdlIC0gVW5pZmllZCBjYWxsYmFjayByZXR1cm5pbmcgdGhlIHVwZGF0ZWQgcHJpY2UgdmFsdWUuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLnVuaXRIaW50XSAtIERpc3BsYXkgdW5pdCBoaW50IChlLmcuLCBcIuC4vyAvIOC4iuC4oS5cIiwgXCLguL8gLyDguKfguLHguJlcIikuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmVycm9yXSAtIFZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZSBpZiBhbnkuXG4gKiBAcGFyYW0ge3N0cmluZ30gW3Byb3BzLmlkXSAtIElucHV0IGlkIGZvciBsYWJlbCBhY2Nlc3NpYmlsaXR5LlxuICogQHBhcmFtIHtudW1iZXJ9IFtwcm9wcy5zdGVwXSAtIFN0ZXAgZGVsdGEgdmFsdWUgKGRlZmF1bHQ6IDEwKS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJpY2VTdGVwcGVySW5wdXQoe1xuICB2YWx1ZSxcbiAgb25DaGFuZ2UsXG4gIHVuaXRIaW50ID0gXCLguL8gLyDguIrguKEuXCIsXG4gIGVycm9yID0gXCJcIixcbiAgaWQgPSBcInByaWNlLXN0ZXBwZXItaW5wdXRcIixcbiAgc3RlcCA9IDEwLFxufSkge1xuICAvLyBJbnRlcm5hbCBTdGVwIEhhbmRsZXIgKENhbGN1bGF0ZXMgbmV3IHByaWNlIGFuZCBpbmZvcm1zIHBhcmVudCB2aWEgb25DaGFuZ2UpXG4gIGNvbnN0IGhhbmRsZVN0ZXAgPSAoZGVsdGEpID0+IHtcbiAgICBjb25zdCBjdXJyZW50ID0gTnVtYmVyKHZhbHVlKSB8fCAwO1xuICAgIGNvbnN0IG5leHRWYWwgPSBNYXRoLm1heCgwLCBjdXJyZW50ICsgZGVsdGEpO1xuICAgIGlmIChvbkNoYW5nZSkgb25DaGFuZ2UobmV4dFZhbCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIGlmIChvbkNoYW5nZSkgb25DaGFuZ2UoZS50YXJnZXQudmFsdWUpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTFcIj5cbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2lkfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICDguK3guLHguJXguKPguLLguITguYjguLLguJrguKPguLTguIHguLLguKMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzBGNzY2RV1cIj57dW5pdEhpbnR9PC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgey8qIEN1cnJlbmN5IFByZWZpeCAqL31cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB0ZXh0LXNtIHBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICDguL9cbiAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgIHsvKiBOdW1lcmljIElucHV0IHdpdGggc3VwcHJlc3NlZCBkZWZhdWx0IGJyb3dzZXIgc3Bpbm5lciAqL31cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgaWQ9e2lkfVxuICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgIHN0ZXA9e3N0ZXB9XG4gICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBwbC04IHByLTEyIHB5LTIgdGV4dC1zbSBib3JkZXItMiByb3VuZGVkLXhsIGZvY3VzOm91dGxpbmUtbm9uZSBiZy13aGl0ZSB0ZXh0LXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBbYXBwZWFyYW5jZTp0ZXh0ZmllbGRdIFsmOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uXTphcHBlYXJhbmNlLW5vbmUgWyY6Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b25dOmFwcGVhcmFuY2Utbm9uZSAke1xuICAgICAgICAgICAgZXJyb3JcbiAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNDAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCJcbiAgICAgICAgICAgICAgOiBcImJvcmRlci1zbGF0ZS0yMDAgZm9jdXM6Ym9yZGVyLVsjRjk3MzE2XVwiXG4gICAgICAgICAgfWB9XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIEN1c3RvbSBQbGFpbiBTdGVwcGVyIEJ1dHRvbnMgKOKWsiAvIOKWvCkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMSB0b3AtMSBib3R0b20tMSBmbGV4IGZsZXgtY29sIHctNyBib3JkZXItbCBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdGVwKHN0ZXApfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtWyNFQTU4MENdIGhvdmVyOmJnLVsjRkZGM0U4XSByb3VuZGVkLXRyLWxnIHRyYW5zaXRpb24tY29sb3JzIHRleHQtWzlweF0gY3Vyc29yLXBvaW50ZXIgc2VsZWN0LW5vbmUgbGVhZGluZy1ub25lXCJcbiAgICAgICAgICAgIHRpdGxlPXtg4LmA4Lie4Li04LmI4LihICR7c3RlcH0g4Lia4Liy4LiXYH1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2DguYDguJ7guLTguYjguKEgJHtzdGVwfSDguJrguLLguJdgfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKWslxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1bMXB4XSBiZy1zbGF0ZS0yMDAgdy1mdWxsXCIgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN0ZXAoLXN0ZXApfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtWyNFQTU4MENdIGhvdmVyOmJnLVsjRkZGM0U4XSByb3VuZGVkLWJyLWxnIHRyYW5zaXRpb24tY29sb3JzIHRleHQtWzlweF0gY3Vyc29yLXBvaW50ZXIgc2VsZWN0LW5vbmUgbGVhZGluZy1ub25lXCJcbiAgICAgICAgICAgIHRpdGxlPXtg4Lil4LiUICR7c3RlcH0g4Lia4Liy4LiXYH1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2DguKXguJQgJHtzdGVwfSDguJrguLLguJdgfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKWvFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTUwMCBtdC0xIGJsb2NrXCI+XG4gICAgICAgICAge2Vycm9yfVxuICAgICAgICA8L3NwYW4+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvc2l0dGVyL3NlcnZpY2VGb3JtL1ByaWNlU3RlcHBlcklucHV0LmpzeCJ9