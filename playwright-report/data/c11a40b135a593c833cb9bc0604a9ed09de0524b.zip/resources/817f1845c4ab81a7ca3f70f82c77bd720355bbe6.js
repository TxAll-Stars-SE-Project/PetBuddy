import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/context/AuthContext.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { api } from "/src/services/api.js";
import { toast } from "/src/utils/toast.js";
const AuthContext = createContext(null);
export const useAuth = () => {
  _s();
  return useContext(AuthContext);
};
_s(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export function AuthProvider({ children }) {
  _s2();
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("pb_user"));
    } catch {
      return null;
    }
  });
  const navigate = useNavigate();
  const login = useCallback(async (email, password, rememberMe = false) => {
    try {
      const { data } = await api.post("/auth/login", { email, password, rememberMe });
      localStorage.setItem("pb_token", data.token);
      localStorage.setItem("token", data.token);
      localStorage.setItem("pb_user", JSON.stringify(data.user));
      setUser(data.user);
      return data;
    } catch (err) {
      const status = err.response?.status;
      const errorData = err.response?.data;
      throw { status, data: errorData };
    }
  }, []);
  const logout = useCallback(async () => {
    try {
      await api.post("/auth/logout");
    } catch (e) {
    }
    localStorage.removeItem("pb_token");
    localStorage.removeItem("token");
    localStorage.removeItem("pb_user");
    setUser(null);
    navigate("/");
    toast("ออกจากระบบแล้ว");
  }, [navigate]);
  useEffect(() => {
    const onExpired = () => {
      localStorage.removeItem("pb_token");
      localStorage.removeItem("pb_user");
      setUser(null);
      navigate("/login?expired=1");
    };
    window.addEventListener("pb:session-expired", onExpired);
    return () => window.removeEventListener("pb:session-expired", onExpired);
  }, [navigate]);
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: { user, login, logout }, children }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/context/AuthContext.jsx",
    lineNumber: 78,
    columnNumber: 5
  }, this);
}
_s2(AuthProvider, "Z6I+2wpJyf0eEosGT6n407yWe1I=", false, function() {
  return [useNavigate];
});
_c = AuthProvider;
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERJOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFESixTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxnQkFBZ0I7QUFDNUUsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsYUFBYTtBQUV0QixNQUFNQyxjQUFjUixjQUFjLElBQUk7QUFRL0IsYUFBTVMsVUFBVUEsTUFBQTtBQUFBQyxLQUFBO0FBQUEsU0FBTVIsV0FBV00sV0FBVztBQUFDO0FBQUNFLEdBQXhDRCxTQUFPO0FBRWIsZ0JBQVNFLGFBQWEsRUFBRUMsU0FBUyxHQUFHO0FBQUFDLE1BQUE7QUFDekMsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlYLFNBQVMsTUFBTTtBQUNyQyxRQUFJO0FBQUUsYUFBT1ksS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxTQUFTLENBQUM7QUFBQSxJQUFHLFFBQVE7QUFBRSxhQUFPO0FBQUEsSUFBTTtBQUFBLEVBQ25GLENBQUM7QUFDRCxRQUFNQyxXQUFXZixZQUFZO0FBRTdCLFFBQU1nQixRQUFRcEIsWUFBWSxPQUFPcUIsT0FBT0MsVUFBVUMsYUFBYSxVQUFVO0FBQ3ZFLFFBQUk7QUFDRixZQUFNLEVBQUVDLEtBQUssSUFBSSxNQUFNbkIsSUFBSW9CLEtBQUssZUFBZSxFQUFFSixPQUFPQyxVQUFVQyxXQUFXLENBQUM7QUFDOUVOLG1CQUFhUyxRQUFRLFlBQVlGLEtBQUtHLEtBQUs7QUFDM0NWLG1CQUFhUyxRQUFRLFNBQVNGLEtBQUtHLEtBQUs7QUFDeENWLG1CQUFhUyxRQUFRLFdBQVdYLEtBQUthLFVBQVVKLEtBQUtYLElBQUksQ0FBQztBQUN6REMsY0FBUVUsS0FBS1gsSUFBSTtBQUNqQixhQUFPVztBQUFBQSxJQUNULFNBQVNLLEtBQUs7QUFDWixZQUFNQyxTQUFTRCxJQUFJRSxVQUFVRDtBQUM3QixZQUFNRSxZQUFZSCxJQUFJRSxVQUFVUDtBQUNoQyxZQUFNLEVBQUVNLFFBQVFOLE1BQU1RLFVBQVU7QUFBQSxJQUNsQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsU0FBU2pDLFlBQVksWUFBWTtBQUNyQyxRQUFJO0FBQUUsWUFBTUssSUFBSW9CLEtBQUssY0FBYztBQUFBLElBQUcsU0FBU1MsR0FBRztBQUFBLElBQUU7QUFDcERqQixpQkFBYWtCLFdBQVcsVUFBVTtBQUNsQ2xCLGlCQUFha0IsV0FBVyxPQUFPO0FBQy9CbEIsaUJBQWFrQixXQUFXLFNBQVM7QUFDakNyQixZQUFRLElBQUk7QUFDWkssYUFBUyxHQUFHO0FBQ1piLFVBQU0sZ0JBQWdCO0FBQUEsRUFDeEIsR0FBRyxDQUFDYSxRQUFRLENBQUM7QUFFYmpCLFlBQVUsTUFBTTtBQUNkLFVBQU1rQyxZQUFZQSxNQUFNO0FBQ3RCbkIsbUJBQWFrQixXQUFXLFVBQVU7QUFDbENsQixtQkFBYWtCLFdBQVcsU0FBUztBQUNqQ3JCLGNBQVEsSUFBSTtBQUNaSyxlQUFTLGtCQUFrQjtBQUFBLElBQzdCO0FBQ0FrQixXQUFPQyxpQkFBaUIsc0JBQXNCRixTQUFTO0FBQ3ZELFdBQU8sTUFBTUMsT0FBT0Usb0JBQW9CLHNCQUFzQkgsU0FBUztBQUFBLEVBQ3pFLEdBQUcsQ0FBQ2pCLFFBQVEsQ0FBQztBQUViLFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU8sRUFBRU4sTUFBTU8sT0FBT2EsT0FBTyxHQUNoRHRCLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0MsSUEvQ2VGLGNBQVk7QUFBQSxVQUlUTixXQUFXO0FBQUE7QUFBQSxLQUpkTTtBQUFZLElBQUE4QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VOYXZpZ2F0ZSIsImFwaSIsInRvYXN0IiwiQXV0aENvbnRleHQiLCJ1c2VBdXRoIiwiX3MiLCJBdXRoUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zMiIsInVzZXIiLCJzZXRVc2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIm5hdmlnYXRlIiwibG9naW4iLCJlbWFpbCIsInBhc3N3b3JkIiwicmVtZW1iZXJNZSIsImRhdGEiLCJwb3N0Iiwic2V0SXRlbSIsInRva2VuIiwic3RyaW5naWZ5IiwiZXJyIiwic3RhdHVzIiwicmVzcG9uc2UiLCJlcnJvckRhdGEiLCJsb2dvdXQiLCJlIiwicmVtb3ZlSXRlbSIsIm9uRXhwaXJlZCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aENvbnRleHQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpLmpzXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCIuLi91dGlscy90b2FzdC5qc1wiO1xuXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQobnVsbCk7XG4vKipcbiAqIEByZXR1cm5zIHt7XG4gKiAgIHVzZXI6IHsgdXNlcm5hbWU/OiBzdHJpbmcsIHJvbGU/OiBzdHJpbmcgfSB8IG51bGwsXG4gKiAgIGxvZ2luOiAoZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZywgcmVtZW1iZXJNZT86IGJvb2xlYW4pID0+IFByb21pc2U8dW5rbm93bj4sXG4gKiAgIGxvZ291dDogKCkgPT4gUHJvbWlzZTx2b2lkPlxuICogfX1cbiAqL1xuZXhwb3J0IGNvbnN0IHVzZUF1dGggPSAoKSA9PiB1c2VDb250ZXh0KEF1dGhDb250ZXh0KTtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dGhQcm92aWRlcih7IGNoaWxkcmVuIH0pIHtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIHRyeSB7IHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicGJfdXNlclwiKSk7IH0gY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxuICB9KTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGNvbnN0IGxvZ2luID0gdXNlQ2FsbGJhY2soYXN5bmMgKGVtYWlsLCBwYXNzd29yZCwgcmVtZW1iZXJNZSA9IGZhbHNlKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoXCIvYXV0aC9sb2dpblwiLCB7IGVtYWlsLCBwYXNzd29yZCwgcmVtZW1iZXJNZSB9KTtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwicGJfdG9rZW5cIiwgZGF0YS50b2tlbik7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInRva2VuXCIsIGRhdGEudG9rZW4pO1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJwYl91c2VyXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEudXNlcikpO1xuICAgICAgc2V0VXNlcihkYXRhLnVzZXIpO1xuICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBzdGF0dXMgPSBlcnIucmVzcG9uc2U/LnN0YXR1cztcbiAgICAgIGNvbnN0IGVycm9yRGF0YSA9IGVyci5yZXNwb25zZT8uZGF0YTtcbiAgICAgIHRocm93IHsgc3RhdHVzLCBkYXRhOiBlcnJvckRhdGEgfTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2dvdXQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHsgYXdhaXQgYXBpLnBvc3QoXCIvYXV0aC9sb2dvdXRcIik7IH0gY2F0Y2ggKGUpIHsgLyog4LmE4Lih4LmI4Liq4LiZICovIH1cbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcInBiX3Rva2VuXCIpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidG9rZW5cIik7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJwYl91c2VyXCIpO1xuICAgIHNldFVzZXIobnVsbCk7XG4gICAgbmF2aWdhdGUoXCIvXCIpO1xuICAgIHRvYXN0KFwi4Lit4Lit4LiB4LiI4Liy4LiB4Lij4Liw4Lia4Lia4LmB4Lil4LmJ4LinXCIpO1xuICB9LCBbbmF2aWdhdGVdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG9uRXhwaXJlZCA9ICgpID0+IHtcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwicGJfdG9rZW5cIik7XG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcInBiX3VzZXJcIik7XG4gICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgbmF2aWdhdGUoXCIvbG9naW4/ZXhwaXJlZD0xXCIpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwYjpzZXNzaW9uLWV4cGlyZWRcIiwgb25FeHBpcmVkKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwYjpzZXNzaW9uLWV4cGlyZWRcIiwgb25FeHBpcmVkKTtcbiAgfSwgW25hdmlnYXRlXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgdXNlciwgbG9naW4sIGxvZ291dCB9fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0F1dGhDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb250ZXh0L0F1dGhDb250ZXh0LmpzeCJ9