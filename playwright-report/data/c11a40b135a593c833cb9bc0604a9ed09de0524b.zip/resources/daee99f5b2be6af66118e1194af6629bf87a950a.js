import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SitterDetailPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { useParams, useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { api } from "/src/services/api.js";
import { getSitterServices } from "/src/services/sitters.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import BookingModal from "/src/components/BookingModal.jsx";
import Button from "/src/components/ui/Button.jsx";
const extractArray = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.data?.data)) return res.data.data;
  if (Array.isArray(res.data?.items)) return res.data.items;
  if (Array.isArray(res.data?.bookings)) return res.data.bookings;
  if (Array.isArray(res.items)) return res.items;
  if (Array.isArray(res.bookings)) return res.bookings;
  return [];
};
const formatSpeciesName = (species) => {
  if (!species) return "";
  const s = String(species).trim().toLowerCase();
  if (s === "dog" || s === "สุนัข") return "สุนัข";
  if (s === "cat" || s === "แมว") return "แมว";
  if (s === "bird" || s === "นก") return "นก";
  if (s === "exotic" || s === "สัตว์แปลก" || s === "สัตว์มหัศจรรย์") return "สัตว์แปลก";
  return species;
};
const formatServiceType = (type) => {
  if (!type) return "ทั่วไป";
  const t = String(type).trim().toLowerCase();
  if (t === "daycare" || t.includes("รายวัน")) return "ฝากเลี้ยงรายวัน";
  if (t === "boarding" || t.includes("ค้างคืน")) return "ฝากเลี้ยงค้างคืน";
  if (t === "walking" || t.includes("เดิน")) return "พาเดินเล่น";
  if (t === "grooming" || t.includes("อาบน้ำ")) return "อาบน้ำตัดขน";
  if (t === "sitting" || t.includes("ที่พัก")) return "ดูแลถึงที่พัก";
  return type;
};
const getServiceUnit = (svc) => {
  if (!svc) return "฿";
  const rawType = String(svc.serviceType || svc.serviceName || "").toLowerCase();
  if (rawType.includes("walking") || rawType.includes("เดินเล่น") || rawType.includes("พาเดิน")) {
    return "/ ชม.";
  }
  if (rawType.includes("daycare") || rawType.includes("รายวัน")) {
    return "/ วัน";
  }
  if (rawType.includes("boarding") || rawType.includes("ค้างคืน")) {
    return "/ คืน";
  }
  if (rawType.includes("grooming") || rawType.includes("อาบน้ำ") || rawType.includes("sitting")) {
    return "/ ครั้ง";
  }
  return "";
};
export default function SitterDetailPage() {
  _s();
  const { sitterId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const auth = useAuth() || {};
  const user = auth.user;
  const token = auth.token;
  const passedSitter = location.state?.sitter || null;
  const initialServiceId = String(
    location.state?.serviceId ?? location.state?.serviceid ?? location.state?.selectedServiceId ?? location.state?.service?.serviceId ?? location.state?.service?.serviceid ?? location.state?.service?.id ?? ""
  );
  const [sitter, setSitter] = useState(passedSitter);
  const [services, setServices] = useState([]);
  const [, setUserBookings] = useState([]);
  const [selectedServiceId, setSelectedServiceId] = useState(initialServiceId);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  useEffect(() => {
    async function fetchSitterData() {
      setLoading(true);
      try {
        const servicesRes = await getSitterServices(sitterId);
        const serviceList = extractArray(servicesRes);
        setServices(serviceList);
        if (!passedSitter) {
          const sitterRes = await api.get(`/sitters/${sitterId}`);
          const currentSitter = sitterRes?.data?.data || sitterRes?.data?.sitter || sitterRes?.data || null;
          if (currentSitter && typeof currentSitter === "object" && !Array.isArray(currentSitter)) {
            setSitter(currentSitter);
          } else {
            setSitter({
              sitterId: Number(sitterId),
              username: serviceList[0]?.serviceName ? `พี่เลี้ยง (${serviceList[0].serviceName})` : "พี่เลี้ยงสัตว์เลี้ยง",
              province: "",
              district: "",
              rating: null,
              reviewCount: 0
            });
          }
        }
      } catch (err) {
        console.error("Failed to load sitter details:", err);
        setError("ไม่สามารถโหลดข้อมูลพี่เลี้ยงได้");
      } finally {
        setLoading(false);
      }
    }
    if (sitterId) fetchSitterData();
  }, [sitterId, passedSitter]);
  const fetchUserBookings = useCallback(async () => {
    const authToken = token || localStorage.getItem("token") || localStorage.getItem("accessToken");
    const reqHeaders = authToken ? { Authorization: `Bearer ${authToken}` } : {};
    try {
      const res = await api.get("/bookings", { headers: reqHeaders });
      const list = extractArray(res);
      setUserBookings(list);
    } catch (err) {
      console.error("Failed to fetch bookings:", err);
    }
  }, [token]);
  useEffect(() => {
    fetchUserBookings();
  }, [fetchUserBookings, user]);
  const availableServices = useMemo(() => {
    return (services || []).filter((svc) => {
      if (!svc) return false;
      if (svc.status && ["draft", "inactive", "disabled", "ปิดรับบริการ"].includes(String(svc.status).toLowerCase())) {
        return false;
      }
      if (svc.isActive === false || svc.is_active === false) {
        return false;
      }
      return true;
    });
  }, [services]);
  useEffect(() => {
    if (availableServices.length > 0) {
      const isStillAvailable = availableServices.some(
        (s) => String(s?.serviceId || s?.serviceid || s?.id) === String(selectedServiceId)
      );
      if (!selectedServiceId || !isStillAvailable) {
        const defaultId = availableServices[0]?.serviceId || availableServices[0]?.serviceid || availableServices[0]?.id;
        setSelectedServiceId(String(defaultId || ""));
      }
    }
  }, [availableServices, selectedServiceId]);
  const activeService = useMemo(() => {
    return availableServices.find(
      (s) => String(s?.serviceId || s?.serviceid || s?.id) === String(selectedServiceId)
    );
  }, [availableServices, selectedServiceId]);
  if (loading) return /* @__PURE__ */ jsxDEV("div", { style: { padding: "40px", textAlign: "center" }, children: "กำลังโหลดข้อมูล..." }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
    lineNumber: 211,
    columnNumber: 23
  }, this);
  if (error || !sitter) {
    return /* @__PURE__ */ jsxDEV("div", { style: { padding: "40px", textAlign: "center" }, children: [
      /* @__PURE__ */ jsxDEV("p", { children: error || "ไม่พบข้อมูลพี่เลี้ยง" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 215,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), children: "กลับหน้าหลัก" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 216,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
      lineNumber: 214,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "800px", margin: "0 auto", padding: "24px 16px" }, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => navigate(-1),
        style: { background: "none", border: "none", cursor: "pointer", color: "#6b7280", marginBottom: "16px", fontSize: "14px" },
        children: "← กลับไปหน้าค้นหา"
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 223,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { background: "#fff", borderRadius: "16px", padding: "24px", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", marginBottom: "24px", border: "1px solid #e5e7eb" }, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "16px" }, children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { style: { margin: "0 0 8px 0", fontSize: "24px", color: "#111827" }, children: sitter.username || sitter.fullname }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 234,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { margin: "0 0 8px 0", color: "#6b7280", fontSize: "14px" }, children: [
        "📍 ",
        [sitter.province, sitter.district].filter(Boolean).join(" · ") || "ไม่ระบุพื้นที่"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 237,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "14px", color: "#d97706", fontWeight: "500" }, children: [
        "⭐ ",
        sitter.rating !== null && sitter.rating !== void 0 ? Number(sitter.rating).toFixed(1) : "ไม่มีรีวิว",
        " (",
        sitter.reviewCount || 0,
        " รีวิว)"
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 240,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
      lineNumber: 233,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
      lineNumber: 232,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
      lineNumber: 231,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { background: "#fff", borderRadius: "16px", padding: "24px", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", border: "1px solid #e5e7eb" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "18px", margin: "0 0 16px 0", color: "#374151" }, children: "เลือกบริการที่ต้องการดูรายละเอียด" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 249,
        columnNumber: 9
      }, this),
      availableServices.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { padding: "16px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "12px", color: "#991b1b", fontSize: "14px" }, children: services.length === 0 ? "พี่เลี้ยงท่านนี้ยังไม่ได้เปิดให้บริการในขณะนี้" : "ℹ️ ไม่มีบริการที่เปิดรับอยู่ในขณะนี้" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 252,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "14px", fontWeight: "500", color: "#4b5563", marginBottom: "6px" }, children: [
            "รายการบริการที่พร้อมให้บริการ (",
            availableServices.length,
            " รายการ)"
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
            lineNumber: 260,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "input",
              style: { width: "100%", padding: "10px 12px", borderRadius: "8px", border: "1px solid #d1d5db", fontSize: "15px" },
              value: selectedServiceId,
              onChange: (e) => setSelectedServiceId(e.target.value),
              children: availableServices.map((svc) => {
                const sId = svc.serviceId || svc.serviceid || svc.id;
                const sName = svc.serviceName || svc.servicename;
                const price = Number(svc.price || 0).toLocaleString();
                const unit = getServiceUnit(svc);
                return /* @__PURE__ */ jsxDEV("option", { value: sId, children: [
                  sName,
                  " — ฿",
                  price,
                  " ",
                  unit
                ] }, sId, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 276,
                  columnNumber: 19
                }, this);
              })
            },
            void 0,
            false,
            {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
              lineNumber: 263,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
          lineNumber: 259,
          columnNumber: 13
        }, this),
        activeService && /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              background: "#f9fafb",
              borderRadius: "12px",
              padding: "20px",
              border: "1px solid #e5e7eb",
              marginTop: "16px"
            },
            children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "12px", marginBottom: "12px" }, children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { style: { margin: "0 0 4px 0", fontSize: "18px", color: "#111827" }, children: activeService.serviceName || activeService.servicename }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                    lineNumber: 296,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "13px", color: "#6b7280" }, children: [
                    "หมวดหมู่: ",
                    formatServiceType(activeService.serviceType || activeService.servicetype)
                  ] }, void 0, true, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                    lineNumber: 299,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 295,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "22px", fontWeight: "700", color: "var(--primary, #f97316)" }, children: [
                  "฿",
                  Number(activeService.price || 0).toLocaleString(),
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "14px", fontWeight: "500", color: "#6b7280" }, children: getServiceUnit(activeService) }, void 0, false, {
                    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                    lineNumber: 304,
                    columnNumber: 74
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 303,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                lineNumber: 294,
                columnNumber: 17
              }, this),
              activeService.description && /* @__PURE__ */ jsxDEV("div", { style: { margin: "12px 0", color: "#4b5563", fontSize: "14px", lineHeight: "1.5" }, children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "รายละเอียดบริการ:" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 310,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { margin: "4px 0 0 0" }, children: activeService.description }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 311,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                lineNumber: 309,
                columnNumber: 13
              }, this),
              activeService.species && activeService.species.length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "12px", display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "13px", color: "#6b7280" }, children: "ประเภทสัตว์เลี้ยงที่รับฝาก:" }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                  lineNumber: 317,
                  columnNumber: 21
                }, this),
                activeService.species.map(
                  (sp, idx) => /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      style: {
                        background: "#eff6ff",
                        color: "#1d4ed8",
                        padding: "3px 10px",
                        borderRadius: "12px",
                        fontSize: "12px",
                        fontWeight: "500"
                      },
                      children: formatSpeciesName(sp)
                    },
                    idx,
                    false,
                    {
                      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                      lineNumber: 319,
                      columnNumber: 15
                    },
                    this
                  )
                )
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                lineNumber: 316,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "20px", display: "flex", justifyContent: "flex-end" }, children: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setIsBookingOpen(true), children: "จองบริการนี้" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                lineNumber: 337,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
                lineNumber: 336,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
            lineNumber: 285,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 258,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
      lineNumber: 248,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      BookingModal,
      {
        sitter,
        selectedService: activeService,
        isOpen: isBookingOpen,
        onClose: () => setIsBookingOpen(false),
        onSuccess: () => {
          setIsBookingOpen(false);
          fetchUserBookings();
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
        lineNumber: 347,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx",
    lineNumber: 222,
    columnNumber: 5
  }, this);
}
_s(SitterDetailPage, "JZZNZAikbmKzRyojAUcCtKrkVBE=", false, function() {
  return [useParams, useNavigate, useLocation, useAuth];
});
_c = SitterDetailPage;
var _c;
$RefreshReg$(_c, "SitterDetailPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/SitterDetailPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0xzQixTQStDWixVQS9DWTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvTHRCLFNBQVNBLFVBQVVDLFdBQVdDLFNBQVNDLG1CQUFtQjtBQUMxRCxTQUFTQyxXQUFXQyxhQUFhQyxtQkFBbUI7QUFDcEQsU0FBU0MsV0FBVztBQUNwQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsWUFBWTtBQUduQixNQUFNQyxlQUFlQSxDQUFDQyxRQUFRO0FBQzVCLE1BQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLE1BQUlDLE1BQU1DLFFBQVFGLEdBQUcsRUFBRyxRQUFPQTtBQUMvQixNQUFJQyxNQUFNQyxRQUFRRixJQUFJRyxJQUFJLEVBQUcsUUFBT0gsSUFBSUc7QUFDeEMsTUFBSUYsTUFBTUMsUUFBUUYsSUFBSUcsTUFBTUEsSUFBSSxFQUFHLFFBQU9ILElBQUlHLEtBQUtBO0FBQ25ELE1BQUlGLE1BQU1DLFFBQVFGLElBQUlHLE1BQU1DLEtBQUssRUFBRyxRQUFPSixJQUFJRyxLQUFLQztBQUNwRCxNQUFJSCxNQUFNQyxRQUFRRixJQUFJRyxNQUFNRSxRQUFRLEVBQUcsUUFBT0wsSUFBSUcsS0FBS0U7QUFDdkQsTUFBSUosTUFBTUMsUUFBUUYsSUFBSUksS0FBSyxFQUFHLFFBQU9KLElBQUlJO0FBQ3pDLE1BQUlILE1BQU1DLFFBQVFGLElBQUlLLFFBQVEsRUFBRyxRQUFPTCxJQUFJSztBQUM1QyxTQUFPO0FBQ1Q7QUFHQSxNQUFNQyxvQkFBb0JBLENBQUNDLFlBQVk7QUFDckMsTUFBSSxDQUFDQSxRQUFTLFFBQU87QUFDckIsUUFBTUMsSUFBSUMsT0FBT0YsT0FBTyxFQUFFRyxLQUFLLEVBQUVDLFlBQVk7QUFFN0MsTUFBSUgsTUFBTSxTQUFTQSxNQUFNLFFBQVMsUUFBTztBQUN6QyxNQUFJQSxNQUFNLFNBQVNBLE1BQU0sTUFBTyxRQUFPO0FBQ3ZDLE1BQUlBLE1BQU0sVUFBVUEsTUFBTSxLQUFNLFFBQU87QUFDdkMsTUFBSUEsTUFBTSxZQUFZQSxNQUFNLGVBQWVBLE1BQU0saUJBQWtCLFFBQU87QUFFMUUsU0FBT0Q7QUFDVDtBQUdBLE1BQU1LLG9CQUFvQkEsQ0FBQ0MsU0FBUztBQUNsQyxNQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixRQUFNQyxJQUFJTCxPQUFPSSxJQUFJLEVBQUVILEtBQUssRUFBRUMsWUFBWTtBQUUxQyxNQUFJRyxNQUFNLGFBQWFBLEVBQUVDLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDcEQsTUFBSUQsTUFBTSxjQUFjQSxFQUFFQyxTQUFTLFNBQVMsRUFBRyxRQUFPO0FBQ3RELE1BQUlELE1BQU0sYUFBYUEsRUFBRUMsU0FBUyxNQUFNLEVBQUcsUUFBTztBQUNsRCxNQUFJRCxNQUFNLGNBQWNBLEVBQUVDLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDckQsTUFBSUQsTUFBTSxhQUFhQSxFQUFFQyxTQUFTLFFBQVEsRUFBRyxRQUFPO0FBRXBELFNBQU9GO0FBQ1Q7QUFHQSxNQUFNRyxpQkFBaUJBLENBQUNDLFFBQVE7QUFDOUIsTUFBSSxDQUFDQSxJQUFLLFFBQU87QUFDakIsUUFBTUMsVUFBVVQsT0FBT1EsSUFBSUUsZUFBZUYsSUFBSUcsZUFBZSxFQUFFLEVBQUVULFlBQVk7QUFFN0UsTUFBSU8sUUFBUUgsU0FBUyxTQUFTLEtBQUtHLFFBQVFILFNBQVMsVUFBVSxLQUFLRyxRQUFRSCxTQUFTLFFBQVEsR0FBRztBQUM3RixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUlHLFFBQVFILFNBQVMsU0FBUyxLQUFLRyxRQUFRSCxTQUFTLFFBQVEsR0FBRztBQUM3RCxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUlHLFFBQVFILFNBQVMsVUFBVSxLQUFLRyxRQUFRSCxTQUFTLFNBQVMsR0FBRztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUlHLFFBQVFILFNBQVMsVUFBVSxLQUFLRyxRQUFRSCxTQUFTLFFBQVEsS0FBS0csUUFBUUgsU0FBUyxTQUFTLEdBQUc7QUFDN0YsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSx3QkFBd0JNLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ3pDLFFBQU0sRUFBRUMsU0FBUyxJQUFJaEMsVUFBVTtBQUMvQixRQUFNaUMsV0FBV2hDLFlBQVk7QUFDN0IsUUFBTWlDLFdBQVdoQyxZQUFZO0FBRTdCLFFBQU1pQyxPQUFPOUIsUUFBUSxLQUFLLENBQUM7QUFDM0IsUUFBTStCLE9BQU9ELEtBQUtDO0FBQ2xCLFFBQU1DLFFBQVFGLEtBQUtFO0FBRW5CLFFBQU1DLGVBQWVKLFNBQVNLLE9BQU9DLFVBQVU7QUFDL0MsUUFBTUMsbUJBQW1CdkI7QUFBQUEsSUFDdkJnQixTQUFTSyxPQUFPRyxhQUNoQlIsU0FBU0ssT0FBT0ksYUFDaEJULFNBQVNLLE9BQU9LLHFCQUNoQlYsU0FBU0ssT0FBT00sU0FBU0gsYUFDekJSLFNBQVNLLE9BQU9NLFNBQVNGLGFBQ3pCVCxTQUFTSyxPQUFPTSxTQUFTQyxNQUN6QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLENBQUNOLFFBQVFPLFNBQVMsSUFBSW5ELFNBQVMwQyxZQUFZO0FBQ2pELFFBQU0sQ0FBQ1UsVUFBVUMsV0FBVyxJQUFJckQsU0FBUyxFQUFFO0FBQzNDLFFBQU0sR0FBR3NELGVBQWUsSUFBSXRELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNnRCxtQkFBbUJPLG9CQUFvQixJQUFJdkQsU0FBUzZDLGdCQUFnQjtBQUMzRSxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSXpELFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMwRCxPQUFPQyxRQUFRLElBQUkzRCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDNEQsZUFBZUMsZ0JBQWdCLElBQUk3RCxTQUFTLEtBQUs7QUFHeERDLFlBQVUsTUFBTTtBQUNkLG1CQUFlNkQsa0JBQWtCO0FBQy9CTCxpQkFBVyxJQUFJO0FBQ2YsVUFBSTtBQUNGLGNBQU1NLGNBQWMsTUFBTXZELGtCQUFrQjRCLFFBQVE7QUFDcEQsY0FBTTRCLGNBQWNwRCxhQUFhbUQsV0FBVztBQUU1Q1Ysb0JBQVlXLFdBQVc7QUFFdkIsWUFBSSxDQUFDdEIsY0FBYztBQUNqQixnQkFBTXVCLFlBQVksTUFBTTFELElBQUkyRCxJQUFJLFlBQVk5QixRQUFRLEVBQUU7QUFDdEQsZ0JBQU0rQixnQkFDSkYsV0FBV2pELE1BQU1BLFFBQVFpRCxXQUFXakQsTUFBTTRCLFVBQVVxQixXQUFXakQsUUFBUTtBQUV6RSxjQUFJbUQsaUJBQWlCLE9BQU9BLGtCQUFrQixZQUFZLENBQUNyRCxNQUFNQyxRQUFRb0QsYUFBYSxHQUFHO0FBQ3ZGaEIsc0JBQVVnQixhQUFhO0FBQUEsVUFDekIsT0FBTztBQUNMaEIsc0JBQVU7QUFBQSxjQUNSZixVQUFVZ0MsT0FBT2hDLFFBQVE7QUFBQSxjQUN6QmlDLFVBQVVMLFlBQVksQ0FBQyxHQUFHL0IsY0FBYyxjQUFjK0IsWUFBWSxDQUFDLEVBQUUvQixXQUFXLE1BQU07QUFBQSxjQUN0RnFDLFVBQVU7QUFBQSxjQUNWQyxVQUFVO0FBQUEsY0FDVkMsUUFBUTtBQUFBLGNBQ1JDLGFBQWE7QUFBQSxZQUNmLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBU0MsS0FBSztBQUNaQyxnQkFBUWpCLE1BQU0sa0NBQWtDZ0IsR0FBRztBQUNuRGYsaUJBQVMsaUNBQWlDO0FBQUEsTUFDNUMsVUFBQztBQUNDRixtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUEsUUFBSXJCLFNBQVUwQixpQkFBZ0I7QUFBQSxFQUNoQyxHQUFHLENBQUMxQixVQUFVTSxZQUFZLENBQUM7QUFHM0IsUUFBTWtDLG9CQUFvQnpFLFlBQVksWUFBWTtBQUNoRCxVQUFNMEUsWUFBWXBDLFNBQVNxQyxhQUFhQyxRQUFRLE9BQU8sS0FBS0QsYUFBYUMsUUFBUSxhQUFhO0FBQzlGLFVBQU1DLGFBQWFILFlBQVksRUFBRUksZUFBZSxVQUFVSixTQUFTLEdBQUcsSUFBSSxDQUFDO0FBRTNFLFFBQUk7QUFDRixZQUFNaEUsTUFBTSxNQUFNTixJQUFJMkQsSUFBSSxhQUFhLEVBQUVnQixTQUFTRixXQUFXLENBQUM7QUFDOUQsWUFBTUcsT0FBT3ZFLGFBQWFDLEdBQUc7QUFDN0J5QyxzQkFBZ0I2QixJQUFJO0FBQUEsSUFDdEIsU0FBU1QsS0FBSztBQUNaQyxjQUFRakIsTUFBTSw2QkFBNkJnQixHQUFHO0FBQUEsSUFDaEQ7QUFBQSxFQUNGLEdBQUcsQ0FBQ2pDLEtBQUssQ0FBQztBQUVWeEMsWUFBVSxNQUFNO0FBQ2QyRSxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLENBQUNBLG1CQUFtQnBDLElBQUksQ0FBQztBQUc1QixRQUFNNEMsb0JBQW9CbEYsUUFBUSxNQUFNO0FBQ3RDLFlBQVFrRCxZQUFZLElBQUlpQyxPQUFPLENBQUN2RCxRQUFRO0FBQ3RDLFVBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBRWpCLFVBQ0VBLElBQUl3RCxVQUNKLENBQUMsU0FBUyxZQUFZLFlBQVksY0FBYyxFQUFFMUQsU0FBU04sT0FBT1EsSUFBSXdELE1BQU0sRUFBRTlELFlBQVksQ0FBQyxHQUMzRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSU0sSUFBSXlELGFBQWEsU0FBU3pELElBQUkwRCxjQUFjLE9BQU87QUFDckQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNwQyxRQUFRLENBQUM7QUFHYm5ELFlBQVUsTUFBTTtBQUNkLFFBQUltRixrQkFBa0JLLFNBQVMsR0FBRztBQUNoQyxZQUFNQyxtQkFBbUJOLGtCQUFrQk87QUFBQUEsUUFDekMsQ0FBQ3RFLE1BQU1DLE9BQU9ELEdBQUd5QixhQUFhekIsR0FBRzBCLGFBQWExQixHQUFHNkIsRUFBRSxNQUFNNUIsT0FBTzBCLGlCQUFpQjtBQUFBLE1BQ25GO0FBQ0EsVUFBSSxDQUFDQSxxQkFBcUIsQ0FBQzBDLGtCQUFrQjtBQUMzQyxjQUFNRSxZQUFZUixrQkFBa0IsQ0FBQyxHQUFHdEMsYUFBYXNDLGtCQUFrQixDQUFDLEdBQUdyQyxhQUFhcUMsa0JBQWtCLENBQUMsR0FBR2xDO0FBQzlHSyw2QkFBcUJqQyxPQUFPc0UsYUFBYSxFQUFFLENBQUM7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ1IsbUJBQW1CcEMsaUJBQWlCLENBQUM7QUFFekMsUUFBTTZDLGdCQUFnQjNGLFFBQVEsTUFBTTtBQUNsQyxXQUFPa0Ysa0JBQWtCVTtBQUFBQSxNQUN2QixDQUFDekUsTUFBTUMsT0FBT0QsR0FBR3lCLGFBQWF6QixHQUFHMEIsYUFBYTFCLEdBQUc2QixFQUFFLE1BQU01QixPQUFPMEIsaUJBQWlCO0FBQUEsSUFDbkY7QUFBQSxFQUNGLEdBQUcsQ0FBQ29DLG1CQUFtQnBDLGlCQUFpQixDQUFDO0FBRXpDLE1BQUlRLFFBQVMsUUFBTyx1QkFBQyxTQUFJLE9BQU8sRUFBRXVDLFNBQVMsUUFBUUMsV0FBVyxTQUFTLEdBQUcsa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0U7QUFDNUYsTUFBSXRDLFNBQVMsQ0FBQ2QsUUFBUTtBQUNwQixXQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFbUQsU0FBUyxRQUFRQyxXQUFXLFNBQVMsR0FDakQ7QUFBQSw2QkFBQyxPQUFHdEMsbUJBQVMsMEJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQ3BDLHVCQUFDLFlBQU8sU0FBUyxNQUFNckIsU0FBUyxFQUFFLEdBQUcsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxTQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRTRELFVBQVUsU0FBU0MsUUFBUSxVQUFVSCxTQUFTLFlBQVksR0FDdEU7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUyxNQUFNMUQsU0FBUyxFQUFFO0FBQUEsUUFDMUIsT0FBTyxFQUFFOEQsWUFBWSxRQUFRQyxRQUFRLFFBQVFDLFFBQVEsV0FBV0MsT0FBTyxXQUFXQyxjQUFjLFFBQVFDLFVBQVUsT0FBTztBQUFBLFFBQUU7QUFBQTtBQUFBLE1BRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUwsWUFBWSxRQUFRTSxjQUFjLFFBQVFWLFNBQVMsUUFBUVcsV0FBVywrQkFBK0JILGNBQWMsUUFBUUgsUUFBUSxvQkFBb0IsR0FDbkssaUNBQUMsU0FBSSxPQUFPLEVBQUVPLFNBQVMsUUFBUUMsZ0JBQWdCLGlCQUFpQkMsWUFBWSxjQUFjQyxVQUFVLFFBQVFDLEtBQUssT0FBTyxHQUN0SCxpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxPQUFPLEVBQUViLFFBQVEsYUFBYU0sVUFBVSxRQUFRRixPQUFPLFVBQVUsR0FDbEUxRCxpQkFBT3lCLFlBQVl6QixPQUFPb0UsWUFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRWQsUUFBUSxhQUFhSSxPQUFPLFdBQVdFLFVBQVUsT0FBTyxHQUFFO0FBQUE7QUFBQSxRQUNoRSxDQUFDNUQsT0FBTzBCLFVBQVUxQixPQUFPMkIsUUFBUSxFQUFFYyxPQUFPNEIsT0FBTyxFQUFFQyxLQUFLLEtBQUssS0FBSztBQUFBLFdBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVWLFVBQVUsUUFBUUYsT0FBTyxXQUFXYSxZQUFZLE1BQU0sR0FBRTtBQUFBO0FBQUEsUUFDakV2RSxPQUFPNEIsV0FBVyxRQUFRNUIsT0FBTzRCLFdBQVc0QyxTQUFZaEQsT0FBT3hCLE9BQU80QixNQUFNLEVBQUU2QyxRQUFRLENBQUMsSUFBSTtBQUFBLFFBQWE7QUFBQSxRQUFHekUsT0FBTzZCLGVBQWU7QUFBQSxRQUFFO0FBQUEsV0FEeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFMEIsWUFBWSxRQUFRTSxjQUFjLFFBQVFWLFNBQVMsUUFBUVcsV0FBVywrQkFBK0JOLFFBQVEsb0JBQW9CLEdBQzdJO0FBQUEsNkJBQUMsUUFBRyxPQUFPLEVBQUVJLFVBQVUsUUFBUU4sUUFBUSxjQUFjSSxPQUFPLFVBQVUsR0FBRyxpREFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRztBQUFBLE1BRXpHbEIsa0JBQWtCSyxXQUFXLElBQzVCLHVCQUFDLFNBQUksT0FBTyxFQUFFTSxTQUFTLFFBQVFJLFlBQVksV0FBV0MsUUFBUSxxQkFBcUJLLGNBQWMsUUFBUUgsT0FBTyxXQUFXRSxVQUFVLE9BQU8sR0FDeklwRCxtQkFBU3FDLFdBQVcsSUFDakIsbURBQ0EsMENBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBRUEsbUNBQ0U7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRWMsY0FBYyxPQUFPLEdBQ2pDO0FBQUEsaUNBQUMsV0FBTSxPQUFPLEVBQUVJLFNBQVMsU0FBU0gsVUFBVSxRQUFRVyxZQUFZLE9BQU9iLE9BQU8sV0FBV0MsY0FBYyxNQUFNLEdBQUU7QUFBQTtBQUFBLFlBQzdFbkIsa0JBQWtCSztBQUFBQSxZQUFPO0FBQUEsZUFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRTZCLE9BQU8sUUFBUXZCLFNBQVMsYUFBYVUsY0FBYyxPQUFPTCxRQUFRLHFCQUFxQkksVUFBVSxPQUFPO0FBQUEsY0FDakgsT0FBT3hEO0FBQUFBLGNBQ1AsVUFBVSxDQUFDdUUsTUFBTWhFLHFCQUFxQmdFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxjQUVuRHJDLDRCQUFrQnNDLElBQUksQ0FBQzVGLFFBQVE7QUFDOUIsc0JBQU02RixNQUFNN0YsSUFBSWdCLGFBQWFoQixJQUFJaUIsYUFBYWpCLElBQUlvQjtBQUNsRCxzQkFBTTBFLFFBQVE5RixJQUFJRyxlQUFlSCxJQUFJK0Y7QUFDckMsc0JBQU1DLFFBQVExRCxPQUFPdEMsSUFBSWdHLFNBQVMsQ0FBQyxFQUFFQyxlQUFlO0FBQ3BELHNCQUFNQyxPQUFPbkcsZUFBZUMsR0FBRztBQUUvQix1QkFDRSx1QkFBQyxZQUFpQixPQUFPNkYsS0FDdEJDO0FBQUFBO0FBQUFBLGtCQUFNO0FBQUEsa0JBQUtFO0FBQUFBLGtCQUFNO0FBQUEsa0JBQUVFO0FBQUFBLHFCQURUTCxLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUVKLENBQUM7QUFBQTtBQUFBLFlBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtCQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUVDOUIsaUJBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMTSxZQUFZO0FBQUEsY0FDWk0sY0FBYztBQUFBLGNBQ2RWLFNBQVM7QUFBQSxjQUNUSyxRQUFRO0FBQUEsY0FDUjZCLFdBQVc7QUFBQSxZQUNiO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFdEIsU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLGNBQWNFLEtBQUssUUFBUVIsY0FBYyxPQUFPLEdBQzFIO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUcsT0FBTyxFQUFFTCxRQUFRLGFBQWFNLFVBQVUsUUFBUUYsT0FBTyxVQUFVLEdBQ2xFVCx3QkFBYzVELGVBQWU0RCxjQUFjZ0MsZUFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFckIsVUFBVSxRQUFRRixPQUFPLFVBQVUsR0FBRTtBQUFBO0FBQUEsb0JBQ3ZDN0Usa0JBQWtCb0UsY0FBYzdELGVBQWU2RCxjQUFjcUMsV0FBVztBQUFBLHVCQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMUIsVUFBVSxRQUFRVyxZQUFZLE9BQU9iLE9BQU8sMEJBQTBCLEdBQUU7QUFBQTtBQUFBLGtCQUNsRmxDLE9BQU95QixjQUFjaUMsU0FBUyxDQUFDLEVBQUVDLGVBQWU7QUFBQSxrQkFBRTtBQUFBLGtCQUFDLHVCQUFDLFVBQUssT0FBTyxFQUFFdkIsVUFBVSxRQUFRVyxZQUFZLE9BQU9iLE9BQU8sVUFBVSxHQUFJekUseUJBQWVnRSxhQUFhLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVHO0FBQUEscUJBRDlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FFQ0EsY0FBY3NDLGVBQ2IsdUJBQUMsU0FBSSxPQUFPLEVBQUVqQyxRQUFRLFVBQVVJLE9BQU8sV0FBV0UsVUFBVSxRQUFRNEIsWUFBWSxNQUFNLEdBQ3BGO0FBQUEsdUNBQUMsWUFBTyxpQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QjtBQUFBLGdCQUN6Qix1QkFBQyxPQUFFLE9BQU8sRUFBRWxDLFFBQVEsWUFBWSxHQUFJTCx3QkFBY3NDLGVBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsbUJBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUdEdEMsY0FBY3pFLFdBQVd5RSxjQUFjekUsUUFBUXFFLFNBQVMsS0FDdkQsdUJBQUMsU0FBSSxPQUFPLEVBQUV3QyxXQUFXLFFBQVF0QixTQUFTLFFBQVFFLFlBQVksVUFBVUUsS0FBSyxPQUFPRCxVQUFVLE9BQU8sR0FDbkc7QUFBQSx1Q0FBQyxVQUFLLE9BQU8sRUFBRU4sVUFBVSxRQUFRRixPQUFPLFVBQVUsR0FBRywyQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Y7QUFBQSxnQkFDL0VULGNBQWN6RSxRQUFRc0c7QUFBQUEsa0JBQUksQ0FBQ1csSUFBSUMsUUFDOUI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsT0FBTztBQUFBLHdCQUNMbkMsWUFBWTtBQUFBLHdCQUNaRyxPQUFPO0FBQUEsd0JBQ1BQLFNBQVM7QUFBQSx3QkFDVFUsY0FBYztBQUFBLHdCQUNkRCxVQUFVO0FBQUEsd0JBQ1ZXLFlBQVk7QUFBQSxzQkFDZDtBQUFBLHNCQUVDaEcsNEJBQWtCa0gsRUFBRTtBQUFBO0FBQUEsb0JBVmhCQztBQUFBQSxvQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVlBO0FBQUEsZ0JBQ0Q7QUFBQSxtQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFTCxXQUFXLFFBQVF0QixTQUFTLFFBQVFDLGdCQUFnQixXQUFXLEdBQzNFLGlDQUFDLFVBQU8sU0FBUyxNQUFNL0MsaUJBQWlCLElBQUksR0FBRSw0QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQTtBQUFBO0FBQUEsVUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBd0RBO0FBQUEsV0FuRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFGQTtBQUFBLFNBL0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpR0E7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsaUJBQWlCZ0M7QUFBQUEsUUFDakIsUUFBUWpDO0FBQUFBLFFBQ1IsU0FBUyxNQUFNQyxpQkFBaUIsS0FBSztBQUFBLFFBQ3JDLFdBQVcsTUFBTTtBQUNmQSwyQkFBaUIsS0FBSztBQUN0QmUsNEJBQWtCO0FBQUEsUUFDcEI7QUFBQTtBQUFBLE1BUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUk7QUFBQSxPQXJJTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUlBO0FBRUo7QUFBQ3pDLEdBL1F1QkQsa0JBQWdCO0FBQUEsVUFDakI5QixXQUNKQyxhQUNBQyxhQUVKRyxPQUFPO0FBQUE7QUFBQSxLQUxFeUI7QUFBZ0IsSUFBQXFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJ1c2VMb2NhdGlvbiIsImFwaSIsImdldFNpdHRlclNlcnZpY2VzIiwidXNlQXV0aCIsIkJvb2tpbmdNb2RhbCIsIkJ1dHRvbiIsImV4dHJhY3RBcnJheSIsInJlcyIsIkFycmF5IiwiaXNBcnJheSIsImRhdGEiLCJpdGVtcyIsImJvb2tpbmdzIiwiZm9ybWF0U3BlY2llc05hbWUiLCJzcGVjaWVzIiwicyIsIlN0cmluZyIsInRyaW0iLCJ0b0xvd2VyQ2FzZSIsImZvcm1hdFNlcnZpY2VUeXBlIiwidHlwZSIsInQiLCJpbmNsdWRlcyIsImdldFNlcnZpY2VVbml0Iiwic3ZjIiwicmF3VHlwZSIsInNlcnZpY2VUeXBlIiwic2VydmljZU5hbWUiLCJTaXR0ZXJEZXRhaWxQYWdlIiwiX3MiLCJzaXR0ZXJJZCIsIm5hdmlnYXRlIiwibG9jYXRpb24iLCJhdXRoIiwidXNlciIsInRva2VuIiwicGFzc2VkU2l0dGVyIiwic3RhdGUiLCJzaXR0ZXIiLCJpbml0aWFsU2VydmljZUlkIiwic2VydmljZUlkIiwic2VydmljZWlkIiwic2VsZWN0ZWRTZXJ2aWNlSWQiLCJzZXJ2aWNlIiwiaWQiLCJzZXRTaXR0ZXIiLCJzZXJ2aWNlcyIsInNldFNlcnZpY2VzIiwic2V0VXNlckJvb2tpbmdzIiwic2V0U2VsZWN0ZWRTZXJ2aWNlSWQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJpc0Jvb2tpbmdPcGVuIiwic2V0SXNCb29raW5nT3BlbiIsImZldGNoU2l0dGVyRGF0YSIsInNlcnZpY2VzUmVzIiwic2VydmljZUxpc3QiLCJzaXR0ZXJSZXMiLCJnZXQiLCJjdXJyZW50U2l0dGVyIiwiTnVtYmVyIiwidXNlcm5hbWUiLCJwcm92aW5jZSIsImRpc3RyaWN0IiwicmF0aW5nIiwicmV2aWV3Q291bnQiLCJlcnIiLCJjb25zb2xlIiwiZmV0Y2hVc2VyQm9va2luZ3MiLCJhdXRoVG9rZW4iLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicmVxSGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJoZWFkZXJzIiwibGlzdCIsImF2YWlsYWJsZVNlcnZpY2VzIiwiZmlsdGVyIiwic3RhdHVzIiwiaXNBY3RpdmUiLCJpc19hY3RpdmUiLCJsZW5ndGgiLCJpc1N0aWxsQXZhaWxhYmxlIiwic29tZSIsImRlZmF1bHRJZCIsImFjdGl2ZVNlcnZpY2UiLCJmaW5kIiwicGFkZGluZyIsInRleHRBbGlnbiIsIm1heFdpZHRoIiwibWFyZ2luIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImN1cnNvciIsImNvbG9yIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwiZmxleFdyYXAiLCJnYXAiLCJmdWxsbmFtZSIsIkJvb2xlYW4iLCJqb2luIiwiZm9udFdlaWdodCIsInVuZGVmaW5lZCIsInRvRml4ZWQiLCJ3aWR0aCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsInNJZCIsInNOYW1lIiwic2VydmljZW5hbWUiLCJwcmljZSIsInRvTG9jYWxlU3RyaW5nIiwidW5pdCIsIm1hcmdpblRvcCIsInNlcnZpY2V0eXBlIiwiZGVzY3JpcHRpb24iLCJsaW5lSGVpZ2h0Iiwic3AiLCJpZHgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaXR0ZXJEZXRhaWxQYWdlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaVwiO1xuaW1wb3J0IHsgZ2V0U2l0dGVyU2VydmljZXMgfSBmcm9tIFwiLi4vc2VydmljZXMvc2l0dGVyc1wiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0L0F1dGhDb250ZXh0XCI7XG5pbXBvcnQgQm9va2luZ01vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL0Jvb2tpbmdNb2RhbFwiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9CdXR0b25cIjtcblxuLy8gSGVscGVyIHRvIHNhZmVseSBleHRyYWN0IGFycmF5IGZyb20gYW55IEFQSSByZXNwb25zZSBlbnZlbG9wZVxuY29uc3QgZXh0cmFjdEFycmF5ID0gKHJlcykgPT4ge1xuICBpZiAoIXJlcykgcmV0dXJuIFtdO1xuICBpZiAoQXJyYXkuaXNBcnJheShyZXMpKSByZXR1cm4gcmVzO1xuICBpZiAoQXJyYXkuaXNBcnJheShyZXMuZGF0YSkpIHJldHVybiByZXMuZGF0YTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocmVzLmRhdGE/LmRhdGEpKSByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocmVzLmRhdGE/Lml0ZW1zKSkgcmV0dXJuIHJlcy5kYXRhLml0ZW1zO1xuICBpZiAoQXJyYXkuaXNBcnJheShyZXMuZGF0YT8uYm9va2luZ3MpKSByZXR1cm4gcmVzLmRhdGEuYm9va2luZ3M7XG4gIGlmIChBcnJheS5pc0FycmF5KHJlcy5pdGVtcykpIHJldHVybiByZXMuaXRlbXM7XG4gIGlmIChBcnJheS5pc0FycmF5KHJlcy5ib29raW5ncykpIHJldHVybiByZXMuYm9va2luZ3M7XG4gIHJldHVybiBbXTtcbn07XG5cbi8vIE1hcCBzcGVjaWVzIHZhbHVlcyBmcm9tIERCIHRvIFRoYWkgZGlzcGxheSBsYWJlbHNcbmNvbnN0IGZvcm1hdFNwZWNpZXNOYW1lID0gKHNwZWNpZXMpID0+IHtcbiAgaWYgKCFzcGVjaWVzKSByZXR1cm4gXCJcIjtcbiAgY29uc3QgcyA9IFN0cmluZyhzcGVjaWVzKS50cmltKCkudG9Mb3dlckNhc2UoKTtcblxuICBpZiAocyA9PT0gXCJkb2dcIiB8fCBzID09PSBcIuC4quC4uOC4meC4seC4glwiKSByZXR1cm4gXCLguKrguLjguJnguLHguIJcIjtcbiAgaWYgKHMgPT09IFwiY2F0XCIgfHwgcyA9PT0gXCLguYHguKHguKdcIikgcmV0dXJuIFwi4LmB4Lih4LinXCI7XG4gIGlmIChzID09PSBcImJpcmRcIiB8fCBzID09PSBcIuC4meC4gVwiKSByZXR1cm4gXCLguJnguIFcIjtcbiAgaWYgKHMgPT09IFwiZXhvdGljXCIgfHwgcyA9PT0gXCLguKrguLHguJXguKfguYzguYHguJvguKXguIFcIiB8fCBzID09PSBcIuC4quC4seC4leC4p+C5jOC4oeC4q+C4seC4qOC4iOC4o+C4o+C4ouC5jFwiKSByZXR1cm4gXCLguKrguLHguJXguKfguYzguYHguJvguKXguIFcIjtcblxuICByZXR1cm4gc3BlY2llcztcbn07XG5cbi8vIE1hcCBzZXJ2aWNlVHlwZSBmcm9tIERCIHRvIHJlYWRhYmxlIFRoYWkgY2F0ZWdvcmllc1xuY29uc3QgZm9ybWF0U2VydmljZVR5cGUgPSAodHlwZSkgPT4ge1xuICBpZiAoIXR5cGUpIHJldHVybiBcIuC4l+C4seC5iOC4p+C5hOC4m1wiO1xuICBjb25zdCB0ID0gU3RyaW5nKHR5cGUpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuXG4gIGlmICh0ID09PSBcImRheWNhcmVcIiB8fCB0LmluY2x1ZGVzKFwi4Lij4Liy4Lii4Lin4Lix4LiZXCIpKSByZXR1cm4gXCLguJ3guLLguIHguYDguKXguLXguYnguKLguIfguKPguLLguKLguKfguLHguJlcIjtcbiAgaWYgKHQgPT09IFwiYm9hcmRpbmdcIiB8fCB0LmluY2x1ZGVzKFwi4LiE4LmJ4Liy4LiH4LiE4Li34LiZXCIpKSByZXR1cm4gXCLguJ3guLLguIHguYDguKXguLXguYnguKLguIfguITguYnguLLguIfguITguLfguJlcIjtcbiAgaWYgKHQgPT09IFwid2Fsa2luZ1wiIHx8IHQuaW5jbHVkZXMoXCLguYDguJTguLTguJlcIikpIHJldHVybiBcIuC4nuC4suC5gOC4lOC4tOC4meC5gOC4peC5iOC4mVwiO1xuICBpZiAodCA9PT0gXCJncm9vbWluZ1wiIHx8IHQuaW5jbHVkZXMoXCLguK3guLLguJrguJnguYnguLNcIikpIHJldHVybiBcIuC4reC4suC4muC4meC5ieC4s+C4leC4seC4lOC4guC4mVwiO1xuICBpZiAodCA9PT0gXCJzaXR0aW5nXCIgfHwgdC5pbmNsdWRlcyhcIuC4l+C4teC5iOC4nuC4seC4gVwiKSkgcmV0dXJuIFwi4LiU4Li54LmB4Lil4LiW4Li24LiH4LiX4Li14LmI4Lie4Lix4LiBXCI7XG5cbiAgcmV0dXJuIHR5cGU7XG59O1xuXG4vLyBEZXRlcm1pbmUgcHJpY2luZyB1bml0IGxhYmVsIGJhc2VkIG9uIHNlcnZpY2VUeXBlXG5jb25zdCBnZXRTZXJ2aWNlVW5pdCA9IChzdmMpID0+IHtcbiAgaWYgKCFzdmMpIHJldHVybiBcIuC4v1wiO1xuICBjb25zdCByYXdUeXBlID0gU3RyaW5nKHN2Yy5zZXJ2aWNlVHlwZSB8fCBzdmMuc2VydmljZU5hbWUgfHwgXCJcIikudG9Mb3dlckNhc2UoKTtcblxuICBpZiAocmF3VHlwZS5pbmNsdWRlcyhcIndhbGtpbmdcIikgfHwgcmF3VHlwZS5pbmNsdWRlcyhcIuC5gOC4lOC4tOC4meC5gOC4peC5iOC4mVwiKSB8fCByYXdUeXBlLmluY2x1ZGVzKFwi4Lie4Liy4LmA4LiU4Li04LiZXCIpKSB7XG4gICAgcmV0dXJuIFwiLyDguIrguKEuXCI7XG4gIH1cbiAgaWYgKHJhd1R5cGUuaW5jbHVkZXMoXCJkYXljYXJlXCIpIHx8IHJhd1R5cGUuaW5jbHVkZXMoXCLguKPguLLguKLguKfguLHguJlcIikpIHtcbiAgICByZXR1cm4gXCIvIOC4p+C4seC4mVwiO1xuICB9XG4gIGlmIChyYXdUeXBlLmluY2x1ZGVzKFwiYm9hcmRpbmdcIikgfHwgcmF3VHlwZS5pbmNsdWRlcyhcIuC4hOC5ieC4suC4h+C4hOC4t+C4mVwiKSkge1xuICAgIHJldHVybiBcIi8g4LiE4Li34LiZXCI7XG4gIH1cbiAgaWYgKHJhd1R5cGUuaW5jbHVkZXMoXCJncm9vbWluZ1wiKSB8fCByYXdUeXBlLmluY2x1ZGVzKFwi4Lit4Liy4Lia4LiZ4LmJ4LizXCIpIHx8IHJhd1R5cGUuaW5jbHVkZXMoXCJzaXR0aW5nXCIpKSB7XG4gICAgcmV0dXJuIFwiLyDguITguKPguLHguYnguIdcIjtcbiAgfVxuICByZXR1cm4gXCJcIjtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpdHRlckRldGFpbFBhZ2UoKSB7XG4gIGNvbnN0IHsgc2l0dGVySWQgfSA9IHVzZVBhcmFtcygpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICBjb25zdCBhdXRoID0gdXNlQXV0aCgpIHx8IHt9O1xuICBjb25zdCB1c2VyID0gYXV0aC51c2VyO1xuICBjb25zdCB0b2tlbiA9IGF1dGgudG9rZW47XG5cbiAgY29uc3QgcGFzc2VkU2l0dGVyID0gbG9jYXRpb24uc3RhdGU/LnNpdHRlciB8fCBudWxsO1xuICBjb25zdCBpbml0aWFsU2VydmljZUlkID0gU3RyaW5nKFxuICAgIGxvY2F0aW9uLnN0YXRlPy5zZXJ2aWNlSWQgPz9cbiAgICBsb2NhdGlvbi5zdGF0ZT8uc2VydmljZWlkID8/XG4gICAgbG9jYXRpb24uc3RhdGU/LnNlbGVjdGVkU2VydmljZUlkID8/XG4gICAgbG9jYXRpb24uc3RhdGU/LnNlcnZpY2U/LnNlcnZpY2VJZCA/P1xuICAgIGxvY2F0aW9uLnN0YXRlPy5zZXJ2aWNlPy5zZXJ2aWNlaWQgPz9cbiAgICBsb2NhdGlvbi5zdGF0ZT8uc2VydmljZT8uaWQgPz9cbiAgICBcIlwiXG4gICk7XG5cbiAgY29uc3QgW3NpdHRlciwgc2V0U2l0dGVyXSA9IHVzZVN0YXRlKHBhc3NlZFNpdHRlcik7XG4gIGNvbnN0IFtzZXJ2aWNlcywgc2V0U2VydmljZXNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbLCBzZXRVc2VyQm9va2luZ3NdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbc2VsZWN0ZWRTZXJ2aWNlSWQsIHNldFNlbGVjdGVkU2VydmljZUlkXSA9IHVzZVN0YXRlKGluaXRpYWxTZXJ2aWNlSWQpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzQm9va2luZ09wZW4sIHNldElzQm9va2luZ09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIDEuIEZldGNoIFNpdHRlciBQcm9maWxlICYgQWxsIFNlcnZpY2VzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hTaXR0ZXJEYXRhKCkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHNlcnZpY2VzUmVzID0gYXdhaXQgZ2V0U2l0dGVyU2VydmljZXMoc2l0dGVySWQpO1xuICAgICAgICBjb25zdCBzZXJ2aWNlTGlzdCA9IGV4dHJhY3RBcnJheShzZXJ2aWNlc1Jlcyk7XG5cbiAgICAgICAgc2V0U2VydmljZXMoc2VydmljZUxpc3QpO1xuXG4gICAgICAgIGlmICghcGFzc2VkU2l0dGVyKSB7XG4gICAgICAgICAgY29uc3Qgc2l0dGVyUmVzID0gYXdhaXQgYXBpLmdldChgL3NpdHRlcnMvJHtzaXR0ZXJJZH1gKTtcbiAgICAgICAgICBjb25zdCBjdXJyZW50U2l0dGVyID1cbiAgICAgICAgICAgIHNpdHRlclJlcz8uZGF0YT8uZGF0YSB8fCBzaXR0ZXJSZXM/LmRhdGE/LnNpdHRlciB8fCBzaXR0ZXJSZXM/LmRhdGEgfHwgbnVsbDtcblxuICAgICAgICAgIGlmIChjdXJyZW50U2l0dGVyICYmIHR5cGVvZiBjdXJyZW50U2l0dGVyID09PSBcIm9iamVjdFwiICYmICFBcnJheS5pc0FycmF5KGN1cnJlbnRTaXR0ZXIpKSB7XG4gICAgICAgICAgICBzZXRTaXR0ZXIoY3VycmVudFNpdHRlcik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFNpdHRlcih7XG4gICAgICAgICAgICAgIHNpdHRlcklkOiBOdW1iZXIoc2l0dGVySWQpLFxuICAgICAgICAgICAgICB1c2VybmFtZTogc2VydmljZUxpc3RbMF0/LnNlcnZpY2VOYW1lID8gYOC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4hyAoJHtzZXJ2aWNlTGlzdFswXS5zZXJ2aWNlTmFtZX0pYCA6IFwi4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiHXCIsXG4gICAgICAgICAgICAgIHByb3ZpbmNlOiBcIlwiLFxuICAgICAgICAgICAgICBkaXN0cmljdDogXCJcIixcbiAgICAgICAgICAgICAgcmF0aW5nOiBudWxsLFxuICAgICAgICAgICAgICByZXZpZXdDb3VudDogMCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBzaXR0ZXIgZGV0YWlsczpcIiwgZXJyKTtcbiAgICAgICAgc2V0RXJyb3IoXCLguYTguKHguYjguKrguLLguKHguLLguKPguJbguYLguKvguKXguJTguILguYnguK3guKHguLnguKXguJ7guLXguYjguYDguKXguLXguYnguKLguIfguYTguJTguYlcIik7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2l0dGVySWQpIGZldGNoU2l0dGVyRGF0YSgpO1xuICB9LCBbc2l0dGVySWQsIHBhc3NlZFNpdHRlcl0pO1xuXG4gIC8vIDIuIEZldGNoIFVzZXIgQm9va2luZ3MgKFNpbmdsZSBHRVQgL2Jvb2tpbmdzIGNhbGwpXG4gIGNvbnN0IGZldGNoVXNlckJvb2tpbmdzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGF1dGhUb2tlbiA9IHRva2VuIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidG9rZW5cIikgfHwgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJhY2Nlc3NUb2tlblwiKTtcbiAgICBjb25zdCByZXFIZWFkZXJzID0gYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9O1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvYm9va2luZ3NcIiwgeyBoZWFkZXJzOiByZXFIZWFkZXJzIH0pO1xuICAgICAgY29uc3QgbGlzdCA9IGV4dHJhY3RBcnJheShyZXMpO1xuICAgICAgc2V0VXNlckJvb2tpbmdzKGxpc3QpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBib29raW5nczpcIiwgZXJyKTtcbiAgICB9XG4gIH0sIFt0b2tlbl0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hVc2VyQm9va2luZ3MoKTtcbiAgfSwgW2ZldGNoVXNlckJvb2tpbmdzLCB1c2VyXSk7XG5cbiAgLy8gMy4gRmlsdGVyIGRyb3Bkb3duIGl0ZW1zIChPbmx5IGV4Y2x1ZGUgaW5hY3RpdmUvZHJhZnQgc2VydmljZXM7IGFsbG93IHJlcGVhdCBib29raW5ncylcbiAgY29uc3QgYXZhaWxhYmxlU2VydmljZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gKHNlcnZpY2VzIHx8IFtdKS5maWx0ZXIoKHN2YykgPT4ge1xuICAgICAgaWYgKCFzdmMpIHJldHVybiBmYWxzZTtcblxuICAgICAgaWYgKFxuICAgICAgICBzdmMuc3RhdHVzICYmXG4gICAgICAgIFtcImRyYWZ0XCIsIFwiaW5hY3RpdmVcIiwgXCJkaXNhYmxlZFwiLCBcIuC4m+C4tOC4lOC4o+C4seC4muC4muC4o+C4tOC4geC4suC4o1wiXS5pbmNsdWRlcyhTdHJpbmcoc3ZjLnN0YXR1cykudG9Mb3dlckNhc2UoKSlcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAoc3ZjLmlzQWN0aXZlID09PSBmYWxzZSB8fCBzdmMuaXNfYWN0aXZlID09PSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuICB9LCBbc2VydmljZXNdKTtcblxuICAvLyA0LiBLZWVwIHNlbGVjdGVkU2VydmljZUlkIHZhbGlkXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGF2YWlsYWJsZVNlcnZpY2VzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGlzU3RpbGxBdmFpbGFibGUgPSBhdmFpbGFibGVTZXJ2aWNlcy5zb21lKFxuICAgICAgICAocykgPT4gU3RyaW5nKHM/LnNlcnZpY2VJZCB8fCBzPy5zZXJ2aWNlaWQgfHwgcz8uaWQpID09PSBTdHJpbmcoc2VsZWN0ZWRTZXJ2aWNlSWQpXG4gICAgICApO1xuICAgICAgaWYgKCFzZWxlY3RlZFNlcnZpY2VJZCB8fCAhaXNTdGlsbEF2YWlsYWJsZSkge1xuICAgICAgICBjb25zdCBkZWZhdWx0SWQgPSBhdmFpbGFibGVTZXJ2aWNlc1swXT8uc2VydmljZUlkIHx8IGF2YWlsYWJsZVNlcnZpY2VzWzBdPy5zZXJ2aWNlaWQgfHwgYXZhaWxhYmxlU2VydmljZXNbMF0/LmlkO1xuICAgICAgICBzZXRTZWxlY3RlZFNlcnZpY2VJZChTdHJpbmcoZGVmYXVsdElkIHx8IFwiXCIpKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFthdmFpbGFibGVTZXJ2aWNlcywgc2VsZWN0ZWRTZXJ2aWNlSWRdKTtcblxuICBjb25zdCBhY3RpdmVTZXJ2aWNlID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGF2YWlsYWJsZVNlcnZpY2VzLmZpbmQoXG4gICAgICAocykgPT4gU3RyaW5nKHM/LnNlcnZpY2VJZCB8fCBzPy5zZXJ2aWNlaWQgfHwgcz8uaWQpID09PSBTdHJpbmcoc2VsZWN0ZWRTZXJ2aWNlSWQpXG4gICAgKTtcbiAgfSwgW2F2YWlsYWJsZVNlcnZpY2VzLCBzZWxlY3RlZFNlcnZpY2VJZF0pO1xuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPGRpdiBzdHlsZT17eyBwYWRkaW5nOiBcIjQwcHhcIiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PuC4geC4s+C4peC4seC4h+C5guC4q+C4peC4lOC4guC5ieC4reC4oeC4ueC4pS4uLjwvZGl2PjtcbiAgaWYgKGVycm9yIHx8ICFzaXR0ZXIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiBcIjQwcHhcIiwgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxuICAgICAgICA8cD57ZXJyb3IgfHwgXCLguYTguKHguYjguJ7guJrguILguYnguK3guKHguLnguKXguJ7guLXguYjguYDguKXguLXguYnguKLguIdcIn08L3A+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfT7guIHguKXguLHguJrguKvguJnguYnguLLguKvguKXguLHguIE8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgbWF4V2lkdGg6IFwiODAwcHhcIiwgbWFyZ2luOiBcIjAgYXV0b1wiLCBwYWRkaW5nOiBcIjI0cHggMTZweFwiIH19PlxuICAgICAgPGJ1dHRvbiBcbiAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoLTEpfSBcbiAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJub25lXCIsIGJvcmRlcjogXCJub25lXCIsIGN1cnNvcjogXCJwb2ludGVyXCIsIGNvbG9yOiBcIiM2YjcyODBcIiwgbWFyZ2luQm90dG9tOiBcIjE2cHhcIiwgZm9udFNpemU6IFwiMTRweFwiIH19XG4gICAgICA+XG4gICAgICAgIOKGkCDguIHguKXguLHguJrguYTguJvguKvguJnguYnguLLguITguYnguJnguKvguLJcbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7LyogU2l0dGVyIFByb2ZpbGUgT3ZlcnZpZXcgSGVhZGVyICovfVxuICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiNmZmZcIiwgYm9yZGVyUmFkaXVzOiBcIjE2cHhcIiwgcGFkZGluZzogXCIyNHB4XCIsIGJveFNoYWRvdzogXCIwIDJweCAxMHB4IHJnYmEoMCwwLDAsMC4wNSlcIiwgbWFyZ2luQm90dG9tOiBcIjI0cHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjZTVlN2ViXCIgfX0+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJmbGV4LXN0YXJ0XCIsIGZsZXhXcmFwOiBcIndyYXBcIiwgZ2FwOiBcIjE2cHhcIiB9fT5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgxIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgOHB4IDBcIiwgZm9udFNpemU6IFwiMjRweFwiLCBjb2xvcjogXCIjMTExODI3XCIgfX0+XG4gICAgICAgICAgICAgIHtzaXR0ZXIudXNlcm5hbWUgfHwgc2l0dGVyLmZ1bGxuYW1lfVxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgOHB4IDBcIiwgY29sb3I6IFwiIzZiNzI4MFwiLCBmb250U2l6ZTogXCIxNHB4XCIgfX0+XG4gICAgICAgICAgICAgIPCfk40ge1tzaXR0ZXIucHJvdmluY2UsIHNpdHRlci5kaXN0cmljdF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgwrcgXCIpIHx8IFwi4LmE4Lih4LmI4Lij4Liw4Lia4Li44Lie4Li34LmJ4LiZ4LiX4Li14LmIXCJ9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjE0cHhcIiwgY29sb3I6IFwiI2Q5NzcwNlwiLCBmb250V2VpZ2h0OiBcIjUwMFwiIH19PlxuICAgICAgICAgICAgICDirZAge3NpdHRlci5yYXRpbmcgIT09IG51bGwgJiYgc2l0dGVyLnJhdGluZyAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKHNpdHRlci5yYXRpbmcpLnRvRml4ZWQoMSkgOiBcIuC5hOC4oeC5iOC4oeC4teC4o+C4teC4p+C4tOC4p1wifSAoe3NpdHRlci5yZXZpZXdDb3VudCB8fCAwfSDguKPguLXguKfguLTguKcpXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNlcnZpY2UgU2VsZWN0aW9uIERyb3Bkb3duICovfVxuICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiNmZmZcIiwgYm9yZGVyUmFkaXVzOiBcIjE2cHhcIiwgcGFkZGluZzogXCIyNHB4XCIsIGJveFNoYWRvdzogXCIwIDJweCAxMHB4IHJnYmEoMCwwLDAsMC4wNSlcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjZTVlN2ViXCIgfX0+XG4gICAgICAgIDxoMiBzdHlsZT17eyBmb250U2l6ZTogXCIxOHB4XCIsIG1hcmdpbjogXCIwIDAgMTZweCAwXCIsIGNvbG9yOiBcIiMzNzQxNTFcIiB9fT7guYDguKXguLfguK3guIHguJrguKPguLTguIHguLLguKPguJfguLXguYjguJXguYnguK3guIfguIHguLLguKPguJTguLnguKPguLLguKLguKXguLDguYDguK3guLXguKLguJQ8L2gyPlxuXG4gICAgICAgIHthdmFpbGFibGVTZXJ2aWNlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiBcIjE2cHhcIiwgYmFja2dyb3VuZDogXCIjZmVmMmYyXCIsIGJvcmRlcjogXCIxcHggc29saWQgI2ZlY2FjYVwiLCBib3JkZXJSYWRpdXM6IFwiMTJweFwiLCBjb2xvcjogXCIjOTkxYjFiXCIsIGZvbnRTaXplOiBcIjE0cHhcIiB9fT5cbiAgICAgICAgICAgIHtzZXJ2aWNlcy5sZW5ndGggPT09IDBcbiAgICAgICAgICAgICAgPyBcIuC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4h+C4l+C5iOC4suC4meC4meC4teC5ieC4ouC4seC4h+C5hOC4oeC5iOC5hOC4lOC5ieC5gOC4m+C4tOC4lOC5g+C4q+C5ieC4muC4o+C4tOC4geC4suC4o+C5g+C4meC4guC4k+C4sOC4meC4teC5iVwiXG4gICAgICAgICAgICAgIDogXCLihLnvuI8g4LmE4Lih4LmI4Lih4Li14Lia4Lij4Li04LiB4Liy4Lij4LiX4Li14LmI4LmA4Lib4Li04LiU4Lij4Lix4Lia4Lit4Lii4Li54LmI4LmD4LiZ4LiC4LiT4Liw4LiZ4Li14LmJXCJ9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiBcIjIwcHhcIiB9fT5cbiAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6IFwiYmxvY2tcIiwgZm9udFNpemU6IFwiMTRweFwiLCBmb250V2VpZ2h0OiBcIjUwMFwiLCBjb2xvcjogXCIjNGI1NTYzXCIsIG1hcmdpbkJvdHRvbTogXCI2cHhcIiB9fT5cbiAgICAgICAgICAgICAgICDguKPguLLguKLguIHguLLguKPguJrguKPguLTguIHguLLguKPguJfguLXguYjguJ7guKPguYnguK3guKHguYPguKvguYnguJrguKPguLTguIHguLLguKMgKHthdmFpbGFibGVTZXJ2aWNlcy5sZW5ndGh9IOC4o+C4suC4ouC4geC4suC4oylcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIHBhZGRpbmc6IFwiMTBweCAxMnB4XCIsIGJvcmRlclJhZGl1czogXCI4cHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjZDFkNWRiXCIsIGZvbnRTaXplOiBcIjE1cHhcIiB9fVxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFNlcnZpY2VJZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkU2VydmljZUlkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHthdmFpbGFibGVTZXJ2aWNlcy5tYXAoKHN2YykgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3Qgc0lkID0gc3ZjLnNlcnZpY2VJZCB8fCBzdmMuc2VydmljZWlkIHx8IHN2Yy5pZDtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHNOYW1lID0gc3ZjLnNlcnZpY2VOYW1lIHx8IHN2Yy5zZXJ2aWNlbmFtZTtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHByaWNlID0gTnVtYmVyKHN2Yy5wcmljZSB8fCAwKS50b0xvY2FsZVN0cmluZygpO1xuICAgICAgICAgICAgICAgICAgY29uc3QgdW5pdCA9IGdldFNlcnZpY2VVbml0KHN2Yyk7XG5cbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtzSWR9IHZhbHVlPXtzSWR9PlxuICAgICAgICAgICAgICAgICAgICAgIHtzTmFtZX0g4oCUIOC4v3twcmljZX0ge3VuaXR9XG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2FjdGl2ZVNlcnZpY2UgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNmOWZhZmJcIixcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIxMnB4XCIsXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjIwcHhcIixcbiAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI2U1ZTdlYlwiLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjE2cHhcIlxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiZmxleC1zdGFydFwiLCBnYXA6IFwiMTJweFwiLCBtYXJnaW5Cb3R0b206IFwiMTJweFwiIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgNHB4IDBcIiwgZm9udFNpemU6IFwiMThweFwiLCBjb2xvcjogXCIjMTExODI3XCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVNlcnZpY2Uuc2VydmljZU5hbWUgfHwgYWN0aXZlU2VydmljZS5zZXJ2aWNlbmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMTNweFwiLCBjb2xvcjogXCIjNmI3MjgwXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAg4Lir4Lih4Lin4LiU4Lir4Lih4Li54LmIOiB7Zm9ybWF0U2VydmljZVR5cGUoYWN0aXZlU2VydmljZS5zZXJ2aWNlVHlwZSB8fCBhY3RpdmVTZXJ2aWNlLnNlcnZpY2V0eXBlKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjIycHhcIiwgZm9udFdlaWdodDogXCI3MDBcIiwgY29sb3I6IFwidmFyKC0tcHJpbWFyeSwgI2Y5NzMxNilcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAg4Li/e051bWJlcihhY3RpdmVTZXJ2aWNlLnByaWNlIHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9IDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBcIjE0cHhcIiwgZm9udFdlaWdodDogXCI1MDBcIiwgY29sb3I6IFwiIzZiNzI4MFwiIH19PntnZXRTZXJ2aWNlVW5pdChhY3RpdmVTZXJ2aWNlKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHthY3RpdmVTZXJ2aWNlLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luOiBcIjEycHggMFwiLCBjb2xvcjogXCIjNGI1NTYzXCIsIGZvbnRTaXplOiBcIjE0cHhcIiwgbGluZUhlaWdodDogXCIxLjVcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz7guKPguLLguKLguKXguLDguYDguK3guLXguKLguJTguJrguKPguLTguIHguLLguKM6PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogXCI0cHggMCAwIDBcIiB9fT57YWN0aXZlU2VydmljZS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAge2FjdGl2ZVNlcnZpY2Uuc3BlY2llcyAmJiBhY3RpdmVTZXJ2aWNlLnNwZWNpZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogXCIxMnB4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IFwiOHB4XCIsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IFwiMTNweFwiLCBjb2xvcjogXCIjNmI3MjgwXCIgfX0+4Lib4Lij4Liw4LmA4Lig4LiX4Liq4Lix4LiV4Lin4LmM4LmA4Lil4Li14LmJ4Lii4LiH4LiX4Li14LmI4Lij4Lix4Lia4Lid4Liy4LiBOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVNlcnZpY2Uuc3BlY2llcy5tYXAoKHNwLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNlZmY2ZmZcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzFkNGVkOFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjNweCAxMHB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCIxMnB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEycHhcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCI1MDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFNwZWNpZXNOYW1lKHNwKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjIwcHhcIiwgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIgfX0+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldElzQm9va2luZ09wZW4odHJ1ZSl9PlxuICAgICAgICAgICAgICAgICAgICDguIjguK3guIfguJrguKPguLTguIHguLLguKPguJnguLXguYlcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPEJvb2tpbmdNb2RhbFxuICAgICAgICBzaXR0ZXI9e3NpdHRlcn1cbiAgICAgICAgc2VsZWN0ZWRTZXJ2aWNlPXthY3RpdmVTZXJ2aWNlfVxuICAgICAgICBpc09wZW49e2lzQm9va2luZ09wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzQm9va2luZ09wZW4oZmFsc2UpfVxuICAgICAgICBvblN1Y2Nlc3M9eygpID0+IHtcbiAgICAgICAgICBzZXRJc0Jvb2tpbmdPcGVuKGZhbHNlKTtcbiAgICAgICAgICBmZXRjaFVzZXJCb29raW5ncygpO1xuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvcGFnZXMvU2l0dGVyRGV0YWlsUGFnZS5qc3gifQ==