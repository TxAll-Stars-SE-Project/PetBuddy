import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sitter/serviceForm/ServiceFormHeader.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
export default function ServiceFormHeader({ isEditMode, onClose }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-3 border-b border-slate-100", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { id: "service-modal-title", className: "text-lg font-bold text-slate-800", children: isEditMode ? "แก้ไขบริการ" : "เพิ่มบริการใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 mt-0.5", children: isEditMode ? "ปรับปรุงรายละเอียดและอัตราค่าบริการของคุณ" : "กรอกรายละเอียดบริการที่คุณต้องการเปิดรับดูแล" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onClose,
        className: "text-slate-400 hover:text-slate-700 text-lg font-bold p-1 rounded-lg transition-colors cursor-pointer",
        "aria-label": "ปิดหน้าต่าง",
        children: "✕"
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx",
        lineNumber: 47,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
}
_c = ServiceFormHeader;
var _c;
$RefreshReg$(_c, "ServiceFormHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/sitter/serviceForm/ServiceFormHeader.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JROzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJSLE9BQU9BLFdBQVc7QUFjbEIsd0JBQXdCQyxrQkFBa0IsRUFBRUMsWUFBWUMsUUFBUSxHQUFHO0FBQ2pFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcsSUFBRyx1QkFBc0IsV0FBVSxvQ0FDcENELHVCQUFhLGdCQUFnQixxQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQ1ZBLHVCQUNHLDhDQUNBLGtEQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBU0M7QUFBQUEsUUFDVCxXQUFVO0FBQUEsUUFDVixjQUFXO0FBQUEsUUFBYTtBQUFBO0FBQUEsTUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0MsS0F2QnVCSDtBQUFpQixJQUFBRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNlcnZpY2VGb3JtSGVhZGVyIiwiaXNFZGl0TW9kZSIsIm9uQ2xvc2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXJ2aWNlRm9ybUhlYWRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG4vKipcbiAqIFNlcnZpY2VGb3JtSGVhZGVyIENvbXBvbmVudFxuICogXG4gKiBIZWFkZXIgc2VjdGlvbiBmb3IgU2VydmljZUZvcm1Nb2RhbDpcbiAqIC0gRGlzcGxheXMgZHluYW1pYyB0aXRsZSAoXCLguYDguJ7guLTguYjguKHguJrguKPguLTguIHguLLguKPguYPguKvguKHguYhcIiAvIFwi4LmB4LiB4LmJ4LmE4LiC4Lia4Lij4Li04LiB4Liy4LijXCIpXG4gKiAtIFN1YnRpdGxlIGRlc2NyaXB0aW9uXG4gKiAtIE1vZGFsIGNsb3NlIGJ1dHRvbiDinJVcbiAqIFxuICogQHBhcmFtIHtPYmplY3R9IHByb3BzXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHByb3BzLmlzRWRpdE1vZGUgLSBXaGV0aGVyIG1vZGFsIGlzIGluIGVkaXQgbW9kZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHByb3BzLm9uQ2xvc2UgLSBNb2RhbCBjbG9zZSBoYW5kbGVyLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXJ2aWNlRm9ybUhlYWRlcih7IGlzRWRpdE1vZGUsIG9uQ2xvc2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgPGRpdj5cbiAgICAgICAgPGgzIGlkPVwic2VydmljZS1tb2RhbC10aXRsZVwiIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+XG4gICAgICAgICAge2lzRWRpdE1vZGUgPyBcIuC5geC4geC5ieC5hOC4guC4muC4o+C4tOC4geC4suC4o1wiIDogXCLguYDguJ7guLTguYjguKHguJrguKPguLTguIHguLLguKPguYPguKvguKHguYhcIn1cbiAgICAgICAgPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICB7aXNFZGl0TW9kZVxuICAgICAgICAgICAgPyBcIuC4m+C4o+C4seC4muC4m+C4o+C4uOC4h+C4o+C4suC4ouC4peC4sOC5gOC4reC4teC4ouC4lOC5geC4peC4sOC4reC4seC4leC4o+C4suC4hOC5iOC4suC4muC4o+C4tOC4geC4suC4o+C4guC4reC4h+C4hOC4uOC4k1wiXG4gICAgICAgICAgICA6IFwi4LiB4Lij4Lit4LiB4Lij4Liy4Lii4Lil4Liw4LmA4Lit4Li14Lii4LiU4Lia4Lij4Li04LiB4Liy4Lij4LiX4Li14LmI4LiE4Li44LiT4LiV4LmJ4Lit4LiH4LiB4Liy4Lij4LmA4Lib4Li04LiU4Lij4Lix4Lia4LiU4Li54LmB4LilXCJ9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgdGV4dC1sZyBmb250LWJvbGQgcC0xIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICBhcmlhLWxhYmVsPVwi4Lib4Li04LiU4Lir4LiZ4LmJ4Liy4LiV4LmI4Liy4LiHXCJcbiAgICAgID5cbiAgICAgICAg4pyVXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2NoYW5heXVzcGhhbnJhdHRhbmFub24vU3R1ZHkvMy9TRV9Qcm9qZWN0L1BldEJ1ZGR5L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3NpdHRlci9zZXJ2aWNlRm9ybS9TZXJ2aWNlRm9ybUhlYWRlci5qc3gifQ==