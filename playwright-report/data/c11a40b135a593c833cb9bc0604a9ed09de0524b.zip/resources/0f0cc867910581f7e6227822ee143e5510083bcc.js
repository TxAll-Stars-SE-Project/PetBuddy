import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import { Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { useAuth } from "/src/context/AuthContext.jsx";
import Toast from "/src/components/Toast.jsx";
import ForgotPasswordPage from "/src/pages/ForgotPasswordPage.jsx";
import HomePage from "/src/pages/HomePage.jsx";
import LandingPage from "/src/pages/LandingPage.jsx";
import LoginPage from "/src/pages/LoginPage.jsx";
import NotFoundPage from "/src/pages/NotFoundPage.jsx";
import OwnerBookingPage from "/src/pages/OwnerBookingPage.jsx";
import ProfilePage from "/src/pages/ProfilePage.jsx";
import RegisterPage from "/src/pages/RegisterPage.jsx";
import ResetPasswordPage from "/src/pages/ResetPasswordPage.jsx";
import SitterDashboardPage from "/src/pages/SitterDashboardPage.jsx";
import SitterDetailPage from "/src/pages/SitterDetailPage.jsx";
import SitterBookingsPage from "/src/pages/sitter/SitterBookingsPage.tsx";
import CareReportPreviewPage from "/src/pages/dev/CareReportPreviewPage.jsx";
import "/src/styles/global.css";
function ProtectedRoute({ children }) {
  _s();
  const { user } = useAuth();
  return user ? children : /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 41,
    columnNumber: 28
  }, this);
}
_s(ProtectedRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
function GuestRoute({ children }) {
  _s2();
  const { user } = useAuth();
  if (!user) return children;
  return /* @__PURE__ */ jsxDEV(Navigate, { to: user.role === "sitter" ? "/sitter/dashboard" : "/", replace: true }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
}
_s2(GuestRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c2 = GuestRoute;
function SitterRoute({ children }) {
  _s3();
  const { user } = useAuth();
  if (!user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 52,
    columnNumber: 21
  }, this);
  return user.role === "sitter" ? children : /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 53,
    columnNumber: 46
  }, this);
}
_s3(SitterRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c3 = SitterRoute;
function HomeRoute() {
  _s4();
  const { user } = useAuth();
  if (!user) return /* @__PURE__ */ jsxDEV(LandingPage, {}, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 58,
    columnNumber: 21
  }, this);
  return user.role === "sitter" ? /* @__PURE__ */ jsxDEV(Navigate, { to: "/sitter/dashboard", replace: true }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 60,
    columnNumber: 3
  }, this) : /* @__PURE__ */ jsxDEV(HomePage, {}, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 61,
    columnNumber: 3
  }, this);
}
_s4(HomeRoute, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
  return [useAuth];
});
_c4 = HomeRoute;
export default function App() {
  return /* @__PURE__ */ jsxDEV("div", { className: "app-root", children: [
    /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(HomeRoute, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 68,
        columnNumber: 34
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 68,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(GuestRoute, { children: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 69,
        columnNumber: 51
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 69,
        columnNumber: 39
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/register", element: /* @__PURE__ */ jsxDEV(GuestRoute, { children: /* @__PURE__ */ jsxDEV(RegisterPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 70,
        columnNumber: 54
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 70,
        columnNumber: 42
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/forgot-password", element: /* @__PURE__ */ jsxDEV(GuestRoute, { children: /* @__PURE__ */ jsxDEV(ForgotPasswordPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 71,
        columnNumber: 61
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 71,
        columnNumber: 49
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/reset-password", element: /* @__PURE__ */ jsxDEV(ResetPasswordPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 72,
        columnNumber: 48
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/profile", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(ProfilePage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 73,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 73,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/bookings", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(OwnerBookingPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 74,
        columnNumber: 58
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 74,
        columnNumber: 42
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 74,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/sitters/:sitterId", element: /* @__PURE__ */ jsxDEV(SitterDetailPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 75,
        columnNumber: 51
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/sitter", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/sitter/dashboard", replace: true }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 76,
        columnNumber: 40
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/sitter/dashboard",
          element: /* @__PURE__ */ jsxDEV(SitterRoute, { children: /* @__PURE__ */ jsxDEV(SitterDashboardPage, {}, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
            lineNumber: 79,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
            lineNumber: 79,
            columnNumber: 20
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
          lineNumber: 77,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Route,
        {
          path: "/sitter/bookings",
          element: /* @__PURE__ */ jsxDEV(SitterRoute, { children: /* @__PURE__ */ jsxDEV(SitterBookingsPage, {}, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
            lineNumber: 83,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
            lineNumber: 83,
            columnNumber: 20
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
          lineNumber: 81,
          columnNumber: 9
        },
        this
      ),
      import.meta.env.DEV && /* @__PURE__ */ jsxDEV(Route, { path: "/dev/care-report", element: /* @__PURE__ */ jsxDEV(CareReportPreviewPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 86,
        columnNumber: 73
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 86,
        columnNumber: 33
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(NotFoundPage, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 88,
        columnNumber: 34
      }, this) }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Toast, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this);
}
_c5 = App;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "ProtectedRoute");
$RefreshReg$(_c2, "GuestRoute");
$RefreshReg$(_c3, "SitterRoute");
$RefreshReg$(_c4, "HomeRoute");
$RefreshReg$(_c5, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUIyQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFwQjNCLFNBQVNBLFVBQVVDLE9BQU9DLGNBQWM7QUFDeEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MseUJBQXlCO0FBQ2hDLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU87QUFFUCxTQUFTQyxlQUFlLEVBQUVDLFNBQWtDLEdBQUc7QUFBQUMsS0FBQTtBQUM3RCxRQUFNLEVBQUVDLEtBQUssSUFBSWxCLFFBQVE7QUFDekIsU0FBT2tCLE9BQU9GLFdBQVcsdUJBQUMsWUFBUyxJQUFHLFVBQVMsU0FBTyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZCO0FBQ3hEO0FBQUNDLEdBSFFGLGdCQUFjO0FBQUEsVUFDSmYsT0FBTztBQUFBO0FBQUEsS0FEakJlO0FBS1QsU0FBU0ksV0FBVyxFQUFFSCxTQUFrQyxHQUFHO0FBQUFJLE1BQUE7QUFDekQsUUFBTSxFQUFFRixLQUFLLElBQUlsQixRQUFRO0FBQ3pCLE1BQUksQ0FBQ2tCLEtBQU0sUUFBT0Y7QUFDbEIsU0FBTyx1QkFBQyxZQUFTLElBQUlFLEtBQUtHLFNBQVMsV0FBVyxzQkFBc0IsS0FBSyxTQUFPLFFBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUU7QUFDbEY7QUFBQ0QsSUFKUUQsWUFBVTtBQUFBLFVBQ0FuQixPQUFPO0FBQUE7QUFBQSxNQURqQm1CO0FBTVQsU0FBU0csWUFBWSxFQUFFTixTQUFrQyxHQUFHO0FBQUFPLE1BQUE7QUFDMUQsUUFBTSxFQUFFTCxLQUFLLElBQUlsQixRQUFRO0FBQ3pCLE1BQUksQ0FBQ2tCLEtBQU0sUUFBTyx1QkFBQyxZQUFTLElBQUcsVUFBUyxTQUFPLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkI7QUFDL0MsU0FBT0EsS0FBS0csU0FBUyxXQUFXTCxXQUFXLHVCQUFDLFlBQVMsSUFBRyxLQUFJLFNBQU8sUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QjtBQUNyRTtBQUFDTyxJQUpRRCxhQUFXO0FBQUEsVUFDRHRCLE9BQU87QUFBQTtBQUFBLE1BRGpCc0I7QUFNVCxTQUFTRSxZQUFZO0FBQUFDLE1BQUE7QUFDbkIsUUFBTSxFQUFFUCxLQUFLLElBQUlsQixRQUFRO0FBQ3pCLE1BQUksQ0FBQ2tCLEtBQU0sUUFBTyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVk7QUFDOUIsU0FBT0EsS0FBS0csU0FBUyxXQUNqQix1QkFBQyxZQUFTLElBQUcscUJBQW9CLFNBQU8sUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF3QyxJQUN4Qyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBUztBQUNmO0FBQUNJLElBTlFELFdBQVM7QUFBQSxVQUNDeEIsT0FBTztBQUFBO0FBQUEsTUFEakJ3QjtBQVFULHdCQUF3QkUsTUFBTTtBQUM1QixTQUNFLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsMkJBQUMsVUFDQztBQUFBLDZCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVUsS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDLHVCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQVMsdUJBQUMsY0FBVyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVSxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUNyRSx1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLGNBQVcsaUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEIsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLE1BQzNFLHVCQUFDLFNBQU0sTUFBSyxvQkFBbUIsU0FBUyx1QkFBQyxjQUFXLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdGO0FBQUEsTUFDeEYsdUJBQUMsU0FBTSxNQUFLLG1CQUFrQixTQUFTLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsa0JBQWUsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0IsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQ2pGLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsa0JBQWUsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxNQUN2Rix1QkFBQyxTQUFNLE1BQUssc0JBQXFCLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFDL0QsdUJBQUMsU0FBTSxNQUFLLFdBQVUsU0FBUyx1QkFBQyxZQUFTLElBQUcscUJBQW9CLFNBQU8sUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QyxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsTUFDM0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQixLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBO0FBQUEsUUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRThEO0FBQUEsTUFFOUQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsdUJBQUMsZUFBWSxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQixLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQztBQUFBO0FBQUEsUUFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRTZEO0FBQUEsTUFHNURDLFlBQVlDLElBQUlDLE9BQU8sdUJBQUMsU0FBTSxNQUFLLG9CQUFtQixTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0IsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BRTFGLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxTQXJCNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBQ0EsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU07QUFBQSxPQXhCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBQ0MsTUE3QnVCSjtBQUFHLElBQUFLLElBQUFDLEtBQUFDLEtBQUFDLEtBQUFKO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFKLEtBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsIlJvdXRlIiwiUm91dGVzIiwidXNlQXV0aCIsIlRvYXN0IiwiRm9yZ290UGFzc3dvcmRQYWdlIiwiSG9tZVBhZ2UiLCJMYW5kaW5nUGFnZSIsIkxvZ2luUGFnZSIsIk5vdEZvdW5kUGFnZSIsIk93bmVyQm9va2luZ1BhZ2UiLCJQcm9maWxlUGFnZSIsIlJlZ2lzdGVyUGFnZSIsIlJlc2V0UGFzc3dvcmRQYWdlIiwiU2l0dGVyRGFzaGJvYXJkUGFnZSIsIlNpdHRlckRldGFpbFBhZ2UiLCJTaXR0ZXJCb29raW5nc1BhZ2UiLCJDYXJlUmVwb3J0UHJldmlld1BhZ2UiLCJQcm90ZWN0ZWRSb3V0ZSIsImNoaWxkcmVuIiwiX3MiLCJ1c2VyIiwiR3Vlc3RSb3V0ZSIsIl9zMiIsInJvbGUiLCJTaXR0ZXJSb3V0ZSIsIl9zMyIsIkhvbWVSb3V0ZSIsIl9zNCIsIkFwcCIsImltcG9ydCIsImVudiIsIkRFViIsIl9jNSIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOYXZpZ2F0ZSwgUm91dGUsIFJvdXRlcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCc7XG5pbXBvcnQgVG9hc3QgZnJvbSAnLi9jb21wb25lbnRzL1RvYXN0JztcbmltcG9ydCBGb3Jnb3RQYXNzd29yZFBhZ2UgZnJvbSAnLi9wYWdlcy9Gb3Jnb3RQYXNzd29yZFBhZ2UnO1xuaW1wb3J0IEhvbWVQYWdlIGZyb20gJy4vcGFnZXMvSG9tZVBhZ2UnO1xuaW1wb3J0IExhbmRpbmdQYWdlIGZyb20gJy4vcGFnZXMvTGFuZGluZ1BhZ2UnO1xuaW1wb3J0IExvZ2luUGFnZSBmcm9tICcuL3BhZ2VzL0xvZ2luUGFnZSc7XG5pbXBvcnQgTm90Rm91bmRQYWdlIGZyb20gJy4vcGFnZXMvTm90Rm91bmRQYWdlJztcbmltcG9ydCBPd25lckJvb2tpbmdQYWdlIGZyb20gJy4vcGFnZXMvT3duZXJCb29raW5nUGFnZSc7XG5pbXBvcnQgUHJvZmlsZVBhZ2UgZnJvbSAnLi9wYWdlcy9Qcm9maWxlUGFnZSc7XG5pbXBvcnQgUmVnaXN0ZXJQYWdlIGZyb20gJy4vcGFnZXMvUmVnaXN0ZXJQYWdlJztcbmltcG9ydCBSZXNldFBhc3N3b3JkUGFnZSBmcm9tICcuL3BhZ2VzL1Jlc2V0UGFzc3dvcmRQYWdlJztcbmltcG9ydCBTaXR0ZXJEYXNoYm9hcmRQYWdlIGZyb20gJy4vcGFnZXMvU2l0dGVyRGFzaGJvYXJkUGFnZSc7XG5pbXBvcnQgU2l0dGVyRGV0YWlsUGFnZSBmcm9tICcuL3BhZ2VzL1NpdHRlckRldGFpbFBhZ2UnO1xuaW1wb3J0IFNpdHRlckJvb2tpbmdzUGFnZSBmcm9tICcuL3BhZ2VzL3NpdHRlci9TaXR0ZXJCb29raW5nc1BhZ2UnO1xuaW1wb3J0IENhcmVSZXBvcnRQcmV2aWV3UGFnZSBmcm9tICcuL3BhZ2VzL2Rldi9DYXJlUmVwb3J0UHJldmlld1BhZ2UuanN4JztcbmltcG9ydCAnLi9zdHlsZXMvZ2xvYmFsLmNzcyc7XG5cbmZ1bmN0aW9uIFByb3RlY3RlZFJvdXRlKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XG4gIHJldHVybiB1c2VyID8gY2hpbGRyZW4gOiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xufVxuXG5mdW5jdGlvbiBHdWVzdFJvdXRlKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XG4gIGlmICghdXNlcikgcmV0dXJuIGNoaWxkcmVuO1xuICByZXR1cm4gPE5hdmlnYXRlIHRvPXt1c2VyLnJvbGUgPT09ICdzaXR0ZXInID8gJy9zaXR0ZXIvZGFzaGJvYXJkJyA6ICcvJ30gcmVwbGFjZSAvPjtcbn1cblxuZnVuY3Rpb24gU2l0dGVyUm91dGUoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcbiAgaWYgKCF1c2VyKSByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPjtcbiAgcmV0dXJuIHVzZXIucm9sZSA9PT0gJ3NpdHRlcicgPyBjaGlsZHJlbiA6IDxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+O1xufVxuXG5mdW5jdGlvbiBIb21lUm91dGUoKSB7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuICBpZiAoIXVzZXIpIHJldHVybiA8TGFuZGluZ1BhZ2UgLz47XG4gIHJldHVybiB1c2VyLnJvbGUgPT09ICdzaXR0ZXInXG4gICAgPyA8TmF2aWdhdGUgdG89XCIvc2l0dGVyL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz5cbiAgICA6IDxIb21lUGFnZSAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLXJvb3RcIj5cbiAgICAgIDxSb3V0ZXM+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxIb21lUm91dGUgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PEd1ZXN0Um91dGU+PExvZ2luUGFnZSAvPjwvR3Vlc3RSb3V0ZT59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlZ2lzdGVyXCIgZWxlbWVudD17PEd1ZXN0Um91dGU+PFJlZ2lzdGVyUGFnZSAvPjwvR3Vlc3RSb3V0ZT59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL2ZvcmdvdC1wYXNzd29yZFwiIGVsZW1lbnQ9ezxHdWVzdFJvdXRlPjxGb3Jnb3RQYXNzd29yZFBhZ2UgLz48L0d1ZXN0Um91dGU+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9yZXNldC1wYXNzd29yZFwiIGVsZW1lbnQ9ezxSZXNldFBhc3N3b3JkUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvcHJvZmlsZVwiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48UHJvZmlsZVBhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvYm9va2luZ3NcIiBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+PE93bmVyQm9va2luZ1BhZ2UgLz48L1Byb3RlY3RlZFJvdXRlPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvc2l0dGVycy86c2l0dGVySWRcIiBlbGVtZW50PXs8U2l0dGVyRGV0YWlsUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvc2l0dGVyXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL3NpdHRlci9kYXNoYm9hcmRcIiByZXBsYWNlIC8+fSAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL3NpdHRlci9kYXNoYm9hcmRcIlxuICAgICAgICAgIGVsZW1lbnQ9ezxTaXR0ZXJSb3V0ZT48U2l0dGVyRGFzaGJvYXJkUGFnZSAvPjwvU2l0dGVyUm91dGU+fVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPVwiL3NpdHRlci9ib29raW5nc1wiXG4gICAgICAgICAgZWxlbWVudD17PFNpdHRlclJvdXRlPjxTaXR0ZXJCb29raW5nc1BhZ2UgLz48L1NpdHRlclJvdXRlPn1cbiAgICAgICAgLz5cblxuICAgICAgICB7aW1wb3J0Lm1ldGEuZW52LkRFViAmJiA8Um91dGUgcGF0aD1cIi9kZXYvY2FyZS1yZXBvcnRcIiBlbGVtZW50PXs8Q2FyZVJlcG9ydFByZXZpZXdQYWdlIC8+fSAvPn1cblxuICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8Tm90Rm91bmRQYWdlIC8+fSAvPlxuICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8VG9hc3QgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvQXBwLnRzeCJ9