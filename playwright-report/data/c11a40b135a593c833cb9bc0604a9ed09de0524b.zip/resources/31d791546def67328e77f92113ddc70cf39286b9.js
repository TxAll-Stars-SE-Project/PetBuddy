import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/payment/PaymentSummary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
const STAGE_LABEL = { deposit: "มัดจำ", final: "ยอดคงเหลือ", full: "เต็มจำนวน" };
const STATUS_LABEL = { pending_verifying: "รอตรวจสอบ", verified: "ยืนยันแล้ว", rejected: "ถูกปฏิเสธ" };
function formatBaht(amount) {
  return `฿${Number(amount || 0).toLocaleString("th-TH")}`;
}
function formatDateTime(iso) {
  return new Date(iso).toLocaleString("th-TH", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
export default function PaymentSummary({ summary, booking, isError }) {
  _s();
  const [isQrLightboxOpen, setIsQrLightboxOpen] = useState(false);
  if (!summary) return null;
  const isDeposit = summary.paymentplan === "deposit";
  const hasPendingPayment = summary.payments?.some(
    (payment) => payment.payment_status === "pending_verifying"
  );
  const amountDueNow = summary.payment_stage === "full" ? summary.totalPrice : summary.bookingstatus === "waiting_final_payment" ? summary.remainingAmount : isDeposit ? summary.depositAmount : summary.totalPrice;
  const sitterPaymentInfo = summary.sitterPaymentInfo;
  const hasSitterPaymentInfo = Boolean(
    sitterPaymentInfo?.accountName && sitterPaymentInfo?.qrCodeUrl
  );
  return /* @__PURE__ */ jsxDEV("section", { className: "payment-summary", "aria-label": "สรุปยอดชำระเงิน", children: [
    isError && /* @__PURE__ */ jsxDEV("div", { className: "payment-fallback-banner", role: "status", children: "ไม่สามารถโหลดรายละเอียดการชำระเงินได้ กำลังใช้ยอดจากข้อมูลการจองแทน" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    hasPendingPayment && /* @__PURE__ */ jsxDEV("div", { className: "payment-pending-banner", role: "status", children: "สลิปอยู่ระหว่างรอพี่เลี้ยงตรวจสอบ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "payment-summary-booking", children: [
      booking?.sitterName ? `${booking.sitterName} · ` : "",
      booking?.serviceName || ""
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "payment-breakdown", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "payment-row", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "ราคารวม" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 79,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: formatBaht(summary.totalPrice) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 80,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "payment-row", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "รูปแบบการชำระ" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 83,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "payment-plan-tag", children: isDeposit ? "มัดจำ 30% + ชำระส่วนที่เหลือภายหลัง" : "ชำระเต็มจำนวน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 84,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      isDeposit && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "payment-row", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "ยอดมัดจำ (30%)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 91,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatBaht(summary.depositAmount) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 92,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 90,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "payment-row", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "ยอดคงเหลือ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 95,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatBaht(summary.remainingAmount) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 96,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 94,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 89,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "payment-row payment-row--total", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "ยอดที่ต้องชำระตอนนี้" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: formatBaht(amountDueNow) }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 100,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    hasSitterPaymentInfo ? /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-card", "aria-label": "ข้อมูลบัญชีรับเงินของพี่เลี้ยง", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-header", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "payment-qr-title", children: "สแกน QR Code เพื่อโอนเงินให้พี่เลี้ยง" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 110,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "payment-qr-badge", children: "พร้อมเพย์ / ธนาคาร" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 111,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 109,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-body", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            className: "payment-qr-image-btn",
            onClick: () => setIsQrLightboxOpen(true),
            "aria-label": "คลิกเพื่อขยายรูป QR Code",
            children: [
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: sitterPaymentInfo.qrCodeUrl,
                  alt: `QR Code รับเงินของ ${sitterPaymentInfo.accountName}`,
                  className: "payment-qr-image"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                  lineNumber: 120,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "payment-qr-zoom-hint", children: "คลิกที่รูปเพื่อขยาย" }, void 0, false, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                lineNumber: 125,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 114,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-details", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-account-label", children: "ชื่อบัญชีผู้รับเงิน (พี่เลี้ยง)" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 128,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-account-name", children: sitterPaymentInfo.accountName }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 129,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-amount-chip", children: [
            "ยอดโอน ",
            formatBaht(amountDueNow)
          ] }, void 0, true, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 130,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "payment-qr-verify-note", children: "ระบบจะตรวจสอบยอดเงิน เวลาโอน และชื่อผู้รับในสลิปให้ตรงกับชื่อบัญชีพี่เลี้ยงโดยอัตโนมัติ" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 133,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 127,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 113,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this) : !isError && /* @__PURE__ */ jsxDEV("div", { className: "payment-missing-qr-banner", role: "alert", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          width: "20",
          height: "20",
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          "aria-hidden": "true",
          children: [
            /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "10" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
              lineNumber: 153,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "8", x2: "12", y2: "12" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
              lineNumber: 154,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" }, void 0, false, {
              fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
              lineNumber: 155,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 142,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "พี่เลี้ยงยังไม่ได้ตั้งค่าบัญชีรับเงินหรือ QR Code" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 158,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "กรุณาติดต่อพี่เลี้ยงให้เพิ่มชื่อบัญชีและรูป QR Code ก่อนดำเนินการชำระเงิน" }, void 0, false, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 159,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 157,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    isQrLightboxOpen && hasSitterPaymentInfo && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "payment-qr-lightbox",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "รูป QR Code ขนาดขยาย",
        onClick: () => setIsQrLightboxOpen(false),
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "payment-qr-lightbox-content",
            onClick: (event) => event.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: sitterPaymentInfo.qrCodeUrl,
                  alt: `QR Code รับเงินของ ${sitterPaymentInfo.accountName}`
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                  lineNumber: 178,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "payment-qr-lightbox-meta", children: [
                /* @__PURE__ */ jsxDEV("strong", { children: sitterPaymentInfo.accountName }, void 0, false, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                  lineNumber: 183,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "ยอดโอน ",
                  formatBaht(amountDueNow)
                ] }, void 0, true, {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                  lineNumber: 184,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                lineNumber: 182,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "delete-cancel-button",
                  onClick: () => setIsQrLightboxOpen(false),
                  children: "ปิดหน้าต่างขยาย"
                },
                void 0,
                false,
                {
                  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
                  lineNumber: 186,
                  columnNumber: 13
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 174,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 167,
        columnNumber: 7
      },
      this
    ),
    summary.payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "payment-history", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "row-label", children: "ประวัติการชำระเงิน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this),
      summary.payments.map(
        (payment) => /* @__PURE__ */ jsxDEV("div", { className: "payment-history-row", children: [
          /* @__PURE__ */ jsxDEV("span", { children: STAGE_LABEL[payment.payment_stage] ?? payment.payment_stage }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 202,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatBaht(payment.amount) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 203,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `payment-status payment-status--${payment.payment_status}`, children: STATUS_LABEL[payment.payment_status] ?? payment.payment_status }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 204,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "payment-history-date", children: formatDateTime(payment.paid_at) }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
            lineNumber: 207,
            columnNumber: 15
          }, this)
        ] }, payment.paymentId, true, {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
          lineNumber: 201,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
      lineNumber: 198,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(PaymentSummary, "17l2J3TwW1W5MA7U9z4GCNg54ZU=");
_c = PaymentSummary;
var _c;
$RefreshReg$(_c, "PaymentSummary");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/payment/PaymentSummary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENRLFNBeUJFLFVBekJGOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsY0FBYyxFQUFFQyxTQUFTLFNBQVNDLE9BQU8sY0FBY0MsTUFBTSxZQUFZO0FBQy9FLE1BQU1DLGVBQWUsRUFBRUMsbUJBQW1CLGFBQWFDLFVBQVUsY0FBY0MsVUFBVSxZQUFZO0FBRXJHLFNBQVNDLFdBQVdDLFFBQVE7QUFDMUIsU0FBTyxJQUFJQyxPQUFPRCxVQUFVLENBQUMsRUFBRUUsZUFBZSxPQUFPLENBQUM7QUFDeEQ7QUFFQSxTQUFTQyxlQUFlQyxLQUFLO0FBQzNCLFNBQU8sSUFBSUMsS0FBS0QsR0FBRyxFQUFFRixlQUFlLFNBQVM7QUFBQSxJQUMzQ0ksS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDSDtBQUVBLHdCQUF3QkMsZUFBZSxFQUFFQyxTQUFTQyxTQUFTQyxRQUFRLEdBQUc7QUFBQUMsS0FBQTtBQUNwRSxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUkzQixTQUFTLEtBQUs7QUFFOUQsTUFBSSxDQUFDc0IsUUFBUyxRQUFPO0FBRXJCLFFBQU1NLFlBQVlOLFFBQVFPLGdCQUFnQjtBQUMxQyxRQUFNQyxvQkFBb0JSLFFBQVFTLFVBQVVDO0FBQUFBLElBQzFDLENBQUNDLFlBQVlBLFFBQVFDLG1CQUFtQjtBQUFBLEVBQzFDO0FBQ0EsUUFBTUMsZUFBZWIsUUFBUWMsa0JBQWtCLFNBQzNDZCxRQUFRZSxhQUNSZixRQUFRZ0Isa0JBQWtCLDBCQUN4QmhCLFFBQVFpQixrQkFDUlgsWUFDRU4sUUFBUWtCLGdCQUNSbEIsUUFBUWU7QUFFaEIsUUFBTUksb0JBQW9CbkIsUUFBUW1CO0FBQ2xDLFFBQU1DLHVCQUF1QkM7QUFBQUEsSUFDM0JGLG1CQUFtQkcsZUFBZUgsbUJBQW1CSTtBQUFBQSxFQUN2RDtBQUVBLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLG1CQUFrQixjQUFXLG1CQUM3Q3JCO0FBQUFBLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDJCQUEwQixNQUFLLFVBQVEsbUZBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRURNLHFCQUNDLHVCQUFDLFNBQUksV0FBVSwwQkFBeUIsTUFBSyxVQUFRLGlEQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVGLHVCQUFDLE9BQUUsV0FBVSwyQkFDVlA7QUFBQUEsZUFBU3VCLGFBQWEsR0FBR3ZCLFFBQVF1QixVQUFVLFFBQVE7QUFBQSxNQUNuRHZCLFNBQVN3QixlQUFlO0FBQUEsU0FGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFVBQUssdUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQyxVQUFNdEMscUJBQVdhLFFBQVFlLFVBQVUsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFdBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxVQUFLLFdBQVUsb0JBQ2JULHNCQUFZLHdDQUF3QyxtQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNDQSxhQUNDLG1DQUNFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxVQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFDcEIsdUJBQUMsVUFBTW5CLHFCQUFXYSxRQUFRa0IsYUFBYSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFDaEIsdUJBQUMsVUFBTS9CLHFCQUFXYSxRQUFRaUIsZUFBZSxLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLGFBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFRix1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwrQkFBQyxVQUFLLG9DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUMxQix1QkFBQyxVQUFNOUIscUJBQVcwQixZQUFZLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxXQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsSUFHQ08sdUJBQ0MsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixjQUFXLGtDQUMxQztBQUFBLDZCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQkFBbUIscURBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLGtDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsV0FGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNZixvQkFBb0IsSUFBSTtBQUFBLFlBQ3ZDLGNBQVc7QUFBQSxZQUVYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsS0FBS2Msa0JBQWtCSTtBQUFBQSxrQkFDdkIsS0FBSyxzQkFBc0JKLGtCQUFrQkcsV0FBVztBQUFBLGtCQUN4RCxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHOEI7QUFBQSxjQUU5Qix1QkFBQyxVQUFLLFdBQVUsd0JBQXVCLG1DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBO0FBQUE7QUFBQSxVQVg1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRCQUEyQiwrQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxTQUFJLFdBQVUsMkJBQTJCSCw0QkFBa0JHLGVBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsVUFDeEUsdUJBQUMsU0FBSSxXQUFVLDBCQUF3QjtBQUFBO0FBQUEsWUFDN0JuQyxXQUFXMEIsWUFBWTtBQUFBLGVBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwwQkFBd0IsdUdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBLElBRUEsQ0FBQ1gsV0FDQyx1QkFBQyxTQUFJLFdBQVUsNkJBQTRCLE1BQUssU0FDOUM7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sUUFBTztBQUFBLFVBQ1AsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBQ0wsUUFBTztBQUFBLFVBQ1AsYUFBWTtBQUFBLFVBQ1osZUFBYztBQUFBLFVBQ2QsZ0JBQWU7QUFBQSxVQUNmLGVBQVk7QUFBQSxVQUVaO0FBQUEsbUNBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQSxZQUNwQyx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE1BQUssSUFBRyxTQUFRLElBQUcsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQTtBQUFBO0FBQUEsUUFiMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxZQUFPLGlFQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUN6RCx1QkFBQyxPQUFFLHlGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxXQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFLSEUsb0JBQW9CZ0Isd0JBQ25CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxjQUFXO0FBQUEsUUFDWCxTQUFTLE1BQU1mLG9CQUFvQixLQUFLO0FBQUEsUUFFeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVMsQ0FBQ3FCLFVBQVVBLE1BQU1DLGdCQUFnQjtBQUFBLFlBRTFDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsS0FBS1Isa0JBQWtCSTtBQUFBQSxrQkFDdkIsS0FBSyxzQkFBc0JKLGtCQUFrQkcsV0FBVztBQUFBO0FBQUEsZ0JBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUU2RDtBQUFBLGNBRTdELHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLHVDQUFDLFlBQVFILDRCQUFrQkcsZUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUM7QUFBQSxnQkFDdkMsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBQVFuQyxXQUFXMEIsWUFBWTtBQUFBLHFCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLG1CQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTVIsb0JBQW9CLEtBQUs7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUE7QUFBQTtBQUFBLFVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1CQTtBQUFBO0FBQUEsTUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMkJBO0FBQUEsSUFHREwsUUFBUVMsVUFBVW1CLFNBQVMsS0FDMUIsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQVksa0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFBQSxNQUM1QzVCLFFBQVFTLFNBQVNvQjtBQUFBQSxRQUFJLENBQUNsQixZQUNyQix1QkFBQyxTQUE0QixXQUFVLHVCQUNyQztBQUFBLGlDQUFDLFVBQU1oQyxzQkFBWWdDLFFBQVFHLGFBQWEsS0FBS0gsUUFBUUcsaUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkUsdUJBQUMsVUFBTTNCLHFCQUFXd0IsUUFBUXZCLE1BQU0sS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0M7QUFBQSxVQUNsQyx1QkFBQyxVQUFLLFdBQVcsa0NBQWtDdUIsUUFBUUMsY0FBYyxJQUN0RTdCLHVCQUFhNEIsUUFBUUMsY0FBYyxLQUFLRCxRQUFRQyxrQkFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHdCQUF3QnJCLHlCQUFlb0IsUUFBUW1CLE9BQU8sS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxhQU5oRW5CLFFBQVFvQixXQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxNQUNEO0FBQUEsU0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQXBKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0pBO0FBRUo7QUFBQzVCLEdBL0t1QkosZ0JBQWM7QUFBQSxLQUFkQTtBQUFjLElBQUFpQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlNUQUdFX0xBQkVMIiwiZGVwb3NpdCIsImZpbmFsIiwiZnVsbCIsIlNUQVRVU19MQUJFTCIsInBlbmRpbmdfdmVyaWZ5aW5nIiwidmVyaWZpZWQiLCJyZWplY3RlZCIsImZvcm1hdEJhaHQiLCJhbW91bnQiLCJOdW1iZXIiLCJ0b0xvY2FsZVN0cmluZyIsImZvcm1hdERhdGVUaW1lIiwiaXNvIiwiRGF0ZSIsImRheSIsIm1vbnRoIiwieWVhciIsImhvdXIiLCJtaW51dGUiLCJQYXltZW50U3VtbWFyeSIsInN1bW1hcnkiLCJib29raW5nIiwiaXNFcnJvciIsIl9zIiwiaXNRckxpZ2h0Ym94T3BlbiIsInNldElzUXJMaWdodGJveE9wZW4iLCJpc0RlcG9zaXQiLCJwYXltZW50cGxhbiIsImhhc1BlbmRpbmdQYXltZW50IiwicGF5bWVudHMiLCJzb21lIiwicGF5bWVudCIsInBheW1lbnRfc3RhdHVzIiwiYW1vdW50RHVlTm93IiwicGF5bWVudF9zdGFnZSIsInRvdGFsUHJpY2UiLCJib29raW5nc3RhdHVzIiwicmVtYWluaW5nQW1vdW50IiwiZGVwb3NpdEFtb3VudCIsInNpdHRlclBheW1lbnRJbmZvIiwiaGFzU2l0dGVyUGF5bWVudEluZm8iLCJCb29sZWFuIiwiYWNjb3VudE5hbWUiLCJxckNvZGVVcmwiLCJzaXR0ZXJOYW1lIiwic2VydmljZU5hbWUiLCJldmVudCIsInN0b3BQcm9wYWdhdGlvbiIsImxlbmd0aCIsIm1hcCIsInBhaWRfYXQiLCJwYXltZW50SWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXltZW50U3VtbWFyeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuY29uc3QgU1RBR0VfTEFCRUwgPSB7IGRlcG9zaXQ6IFwi4Lih4Lix4LiU4LiI4LizXCIsIGZpbmFsOiBcIuC4ouC4reC4lOC4hOC4h+C5gOC4q+C4peC4t+C4rVwiLCBmdWxsOiBcIuC5gOC4leC5h+C4oeC4iOC4s+C4meC4p+C4mVwiIH07XG5jb25zdCBTVEFUVVNfTEFCRUwgPSB7IHBlbmRpbmdfdmVyaWZ5aW5nOiBcIuC4o+C4reC4leC4o+C4p+C4iOC4quC4reC4mlwiLCB2ZXJpZmllZDogXCLguKLguLfguJnguKLguLHguJnguYHguKXguYnguKdcIiwgcmVqZWN0ZWQ6IFwi4LiW4Li54LiB4Lib4LiP4Li04LmA4Liq4LiYXCIgfTtcblxuZnVuY3Rpb24gZm9ybWF0QmFodChhbW91bnQpIHtcbiAgcmV0dXJuIGDguL8ke051bWJlcihhbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJ0aC1USFwiKX1gO1xufVxuXG5mdW5jdGlvbiBmb3JtYXREYXRlVGltZShpc28pIHtcbiAgcmV0dXJuIG5ldyBEYXRlKGlzbykudG9Mb2NhbGVTdHJpbmcoXCJ0aC1USFwiLCB7XG4gICAgZGF5OiBcIm51bWVyaWNcIixcbiAgICBtb250aDogXCJzaG9ydFwiLFxuICAgIHllYXI6IFwibnVtZXJpY1wiLFxuICAgIGhvdXI6IFwiMi1kaWdpdFwiLFxuICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXG4gIH0pO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYXltZW50U3VtbWFyeSh7IHN1bW1hcnksIGJvb2tpbmcsIGlzRXJyb3IgfSkge1xuICBjb25zdCBbaXNRckxpZ2h0Ym94T3Blbiwgc2V0SXNRckxpZ2h0Ym94T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgaWYgKCFzdW1tYXJ5KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBpc0RlcG9zaXQgPSBzdW1tYXJ5LnBheW1lbnRwbGFuID09PSBcImRlcG9zaXRcIjtcbiAgY29uc3QgaGFzUGVuZGluZ1BheW1lbnQgPSBzdW1tYXJ5LnBheW1lbnRzPy5zb21lKFxuICAgIChwYXltZW50KSA9PiBwYXltZW50LnBheW1lbnRfc3RhdHVzID09PSBcInBlbmRpbmdfdmVyaWZ5aW5nXCIsXG4gICk7XG4gIGNvbnN0IGFtb3VudER1ZU5vdyA9IHN1bW1hcnkucGF5bWVudF9zdGFnZSA9PT0gXCJmdWxsXCJcbiAgICA/IHN1bW1hcnkudG90YWxQcmljZVxuICAgIDogc3VtbWFyeS5ib29raW5nc3RhdHVzID09PSBcIndhaXRpbmdfZmluYWxfcGF5bWVudFwiXG4gICAgICA/IHN1bW1hcnkucmVtYWluaW5nQW1vdW50XG4gICAgICA6IGlzRGVwb3NpdFxuICAgICAgICA/IHN1bW1hcnkuZGVwb3NpdEFtb3VudFxuICAgICAgICA6IHN1bW1hcnkudG90YWxQcmljZTtcblxuICBjb25zdCBzaXR0ZXJQYXltZW50SW5mbyA9IHN1bW1hcnkuc2l0dGVyUGF5bWVudEluZm87XG4gIGNvbnN0IGhhc1NpdHRlclBheW1lbnRJbmZvID0gQm9vbGVhbihcbiAgICBzaXR0ZXJQYXltZW50SW5mbz8uYWNjb3VudE5hbWUgJiYgc2l0dGVyUGF5bWVudEluZm8/LnFyQ29kZVVybCxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBheW1lbnQtc3VtbWFyeVwiIGFyaWEtbGFiZWw9XCLguKrguKPguLjguJvguKLguK3guJTguIrguLPguKPguLDguYDguIfguLTguJlcIj5cbiAgICAgIHtpc0Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LWZhbGxiYWNrLWJhbm5lclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICDguYTguKHguYjguKrguLLguKHguLLguKPguJbguYLguKvguKXguJTguKPguLLguKLguKXguLDguYDguK3guLXguKLguJTguIHguLLguKPguIrguLPguKPguLDguYDguIfguLTguJnguYTguJTguYkg4LiB4Liz4Lil4Lix4LiH4LmD4LiK4LmJ4Lii4Lit4LiU4LiI4Liy4LiB4LiC4LmJ4Lit4Lih4Li54Lil4LiB4Liy4Lij4LiI4Lit4LiH4LmB4LiX4LiZXG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHtoYXNQZW5kaW5nUGF5bWVudCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1wZW5kaW5nLWJhbm5lclwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICDguKrguKXguLTguJvguK3guKLguLnguYjguKPguLDguKvguKfguYjguLLguIfguKPguK3guJ7guLXguYjguYDguKXguLXguYnguKLguIfguJXguKPguKfguIjguKrguK3guJpcbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgPHAgY2xhc3NOYW1lPVwicGF5bWVudC1zdW1tYXJ5LWJvb2tpbmdcIj5cbiAgICAgICAge2Jvb2tpbmc/LnNpdHRlck5hbWUgPyBgJHtib29raW5nLnNpdHRlck5hbWV9IMK3IGAgOiBcIlwifVxuICAgICAgICB7Ym9va2luZz8uc2VydmljZU5hbWUgfHwgXCJcIn1cbiAgICAgIDwvcD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1icmVha2Rvd25cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXJvd1wiPlxuICAgICAgICAgIDxzcGFuPuC4o+C4suC4hOC4suC4o+C4p+C4oTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57Zm9ybWF0QmFodChzdW1tYXJ5LnRvdGFsUHJpY2UpfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1yb3dcIj5cbiAgICAgICAgICA8c3Bhbj7guKPguLnguJvguYHguJrguJrguIHguLLguKPguIrguLPguKPguLA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGF5bWVudC1wbGFuLXRhZ1wiPlxuICAgICAgICAgICAge2lzRGVwb3NpdCA/IFwi4Lih4Lix4LiU4LiI4LizIDMwJSArIOC4iuC4s+C4o+C4sOC4quC5iOC4p+C4meC4l+C4teC5iOC5gOC4q+C4peC4t+C4reC4oOC4suC4ouC4q+C4peC4seC4h1wiIDogXCLguIrguLPguKPguLDguYDguJXguYfguKHguIjguLPguJnguKfguJlcIn1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7aXNEZXBvc2l0ICYmIChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXJvd1wiPlxuICAgICAgICAgICAgICA8c3Bhbj7guKLguK3guJTguKHguLHguJTguIjguLMgKDMwJSk8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRCYWh0KHN1bW1hcnkuZGVwb3NpdEFtb3VudCl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtcm93XCI+XG4gICAgICAgICAgICAgIDxzcGFuPuC4ouC4reC4lOC4hOC4h+C5gOC4q+C4peC4t+C4rTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEJhaHQoc3VtbWFyeS5yZW1haW5pbmdBbW91bnQpfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtcm93IHBheW1lbnQtcm93LS10b3RhbFwiPlxuICAgICAgICAgIDxzcGFuPuC4ouC4reC4lOC4l+C4teC5iOC4leC5ieC4reC4h+C4iuC4s+C4o+C4sOC4leC4reC4meC4meC4teC5iTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57Zm9ybWF0QmFodChhbW91bnREdWVOb3cpfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIOC5guC4i+C4meC5geC4quC4lOC4hyBRUiBDb2RlIOC5geC4peC4sOC4iuC4t+C5iOC4reC4muC4seC4jeC4iuC4teC4o+C4seC4muC5gOC4h+C4tOC4meC4guC4reC4h+C4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4hyAoU3ByaW50IDMgVVMgNi0yKSAqL31cbiAgICAgIHtoYXNTaXR0ZXJQYXltZW50SW5mbyA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXFyLWNhcmRcIiBhcmlhLWxhYmVsPVwi4LiC4LmJ4Lit4Lih4Li54Lil4Lia4Lix4LiN4LiK4Li14Lij4Lix4Lia4LmA4LiH4Li04LiZ4LiC4Lit4LiH4Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiHXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXFyLWhlYWRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGF5bWVudC1xci10aXRsZVwiPuC4quC5geC4geC4mSBRUiBDb2RlIOC5gOC4nuC4t+C5iOC4reC5guC4reC4meC5gOC4h+C4tOC4meC5g+C4q+C5ieC4nuC4teC5iOC5gOC4peC4teC5ieC4ouC4hzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBheW1lbnQtcXItYmFkZ2VcIj7guJ7guKPguYnguK3guKHguYDguJ7guKLguYwgLyDguJjguJnguLLguITguLLguKM8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LXFyLWJvZHlcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtcXItaW1hZ2UtYnRuXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNRckxpZ2h0Ym94T3Blbih0cnVlKX1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIuC4hOC4peC4tOC4geC5gOC4nuC4t+C5iOC4reC4guC4ouC4suC4ouC4o+C4ueC4myBRUiBDb2RlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIHNyYz17c2l0dGVyUGF5bWVudEluZm8ucXJDb2RlVXJsfVxuICAgICAgICAgICAgICAgIGFsdD17YFFSIENvZGUg4Lij4Lix4Lia4LmA4LiH4Li04LiZ4LiC4Lit4LiHICR7c2l0dGVyUGF5bWVudEluZm8uYWNjb3VudE5hbWV9YH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwYXltZW50LXFyLWltYWdlXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGF5bWVudC1xci16b29tLWhpbnRcIj7guITguKXguLTguIHguJfguLXguYjguKPguLnguJvguYDguJ7guLfguYjguK3guILguKLguLLguKI8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1xci1kZXRhaWxzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1xci1hY2NvdW50LWxhYmVsXCI+4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14Lic4Li54LmJ4Lij4Lix4Lia4LmA4LiH4Li04LiZICjguJ7guLXguYjguYDguKXguLXguYnguKLguIcpPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1xci1hY2NvdW50LW5hbWVcIj57c2l0dGVyUGF5bWVudEluZm8uYWNjb3VudE5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1xci1hbW91bnQtY2hpcFwiPlxuICAgICAgICAgICAgICAgIOC4ouC4reC4lOC5guC4reC4mSB7Zm9ybWF0QmFodChhbW91bnREdWVOb3cpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicGF5bWVudC1xci12ZXJpZnktbm90ZVwiPlxuICAgICAgICAgICAgICAgIOC4o+C4sOC4muC4muC4iOC4sOC4leC4o+C4p+C4iOC4quC4reC4muC4ouC4reC4lOC5gOC4h+C4tOC4mSDguYDguKfguKXguLLguYLguK3guJkg4LmB4Lil4Liw4LiK4Li34LmI4Lit4Lic4Li54LmJ4Lij4Lix4Lia4LmD4LiZ4Liq4Lil4Li04Lib4LmD4Lir4LmJ4LiV4Lij4LiH4LiB4Lix4Lia4LiK4Li34LmI4Lit4Lia4Lix4LiN4LiK4Li14Lie4Li14LmI4LmA4Lil4Li14LmJ4Lii4LiH4LmC4LiU4Lii4Lit4Lix4LiV4LmC4LiZ4Lih4Lix4LiV4Li0XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgICFpc0Vycm9yICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtbWlzc2luZy1xci1iYW5uZXJcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgICAgd2lkdGg9XCIyMFwiXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwXCJcbiAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMTBcIiAvPlxuICAgICAgICAgICAgICA8bGluZSB4MT1cIjEyXCIgeTE9XCI4XCIgeDI9XCIxMlwiIHkyPVwiMTJcIiAvPlxuICAgICAgICAgICAgICA8bGluZSB4MT1cIjEyXCIgeTE9XCIxNlwiIHgyPVwiMTIuMDFcIiB5Mj1cIjE2XCIgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHN0cm9uZz7guJ7guLXguYjguYDguKXguLXguYnguKLguIfguKLguLHguIfguYTguKHguYjguYTguJTguYnguJXguLHguYnguIfguITguYjguLLguJrguLHguI3guIrguLXguKPguLHguJrguYDguIfguLTguJnguKvguKPguLfguK0gUVIgQ29kZTwvc3Ryb25nPlxuICAgICAgICAgICAgICA8cD7guIHguKPguLjguJPguLLguJXguLTguJTguJXguYjguK3guJ7guLXguYjguYDguKXguLXguYnguKLguIfguYPguKvguYnguYDguJ7guLTguYjguKHguIrguLfguYjguK3guJrguLHguI3guIrguLXguYHguKXguLDguKPguLnguJsgUVIgQ29kZSDguIHguYjguK3guJnguJTguLPguYDguJnguLTguJnguIHguLLguKPguIrguLPguKPguLDguYDguIfguLTguJk8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKVxuICAgICAgKX1cblxuICAgICAgey8qIExpZ2h0Ym94IOC4quC4s+C4q+C4o+C4seC4muC4guC4ouC4suC4ouC4lOC4ueC4o+C4ueC4myBRUiBDb2RlIOC4guC4meC4suC4lOC5g+C4q+C4jeC5iCAqL31cbiAgICAgIHtpc1FyTGlnaHRib3hPcGVuICYmIGhhc1NpdHRlclBheW1lbnRJbmZvICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtcXItbGlnaHRib3hcIlxuICAgICAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwi4Lij4Li54LibIFFSIENvZGUg4LiC4LiZ4Liy4LiU4LiC4Lii4Liy4LiiXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1FyTGlnaHRib3hPcGVuKGZhbHNlKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtcXItbGlnaHRib3gtY29udGVudFwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgc3JjPXtzaXR0ZXJQYXltZW50SW5mby5xckNvZGVVcmx9XG4gICAgICAgICAgICAgIGFsdD17YFFSIENvZGUg4Lij4Lix4Lia4LmA4LiH4Li04LiZ4LiC4Lit4LiHICR7c2l0dGVyUGF5bWVudEluZm8uYWNjb3VudE5hbWV9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtcXItbGlnaHRib3gtbWV0YVwiPlxuICAgICAgICAgICAgICA8c3Ryb25nPntzaXR0ZXJQYXltZW50SW5mby5hY2NvdW50TmFtZX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHNwYW4+4Lii4Lit4LiU4LmC4Lit4LiZIHtmb3JtYXRCYWh0KGFtb3VudER1ZU5vdyl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkZWxldGUtY2FuY2VsLWJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzUXJMaWdodGJveE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDguJvguLTguJTguKvguJnguYnguLLguJXguYjguLLguIfguILguKLguLLguKJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtzdW1tYXJ5LnBheW1lbnRzPy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYXltZW50LWhpc3RvcnlcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdy1sYWJlbFwiPuC4m+C4o+C4sOC4p+C4seC4leC4tOC4geC4suC4o+C4iuC4s+C4o+C4sOC5gOC4h+C4tOC4mTwvZGl2PlxuICAgICAgICAgIHtzdW1tYXJ5LnBheW1lbnRzLm1hcCgocGF5bWVudCkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e3BheW1lbnQucGF5bWVudElkfSBjbGFzc05hbWU9XCJwYXltZW50LWhpc3Rvcnktcm93XCI+XG4gICAgICAgICAgICAgIDxzcGFuPntTVEFHRV9MQUJFTFtwYXltZW50LnBheW1lbnRfc3RhZ2VdID8/IHBheW1lbnQucGF5bWVudF9zdGFnZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRCYWh0KHBheW1lbnQuYW1vdW50KX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHBheW1lbnQtc3RhdHVzIHBheW1lbnQtc3RhdHVzLS0ke3BheW1lbnQucGF5bWVudF9zdGF0dXN9YH0+XG4gICAgICAgICAgICAgICAge1NUQVRVU19MQUJFTFtwYXltZW50LnBheW1lbnRfc3RhdHVzXSA/PyBwYXltZW50LnBheW1lbnRfc3RhdHVzfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBheW1lbnQtaGlzdG9yeS1kYXRlXCI+e2Zvcm1hdERhdGVUaW1lKHBheW1lbnQucGFpZF9hdCl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9wYXltZW50L1BheW1lbnRTdW1tYXJ5LmpzeCJ9