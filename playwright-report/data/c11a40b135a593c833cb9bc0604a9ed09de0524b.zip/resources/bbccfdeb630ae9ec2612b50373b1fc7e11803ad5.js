import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ResetPasswordPage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7e20e8ce"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate, useSearchParams, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7e20e8ce";
import { api } from "/src/services/api.js";
import { passwordOk } from "/src/utils/validators.js";
import { toast } from "/src/utils/toast.js";
import Logo from "/src/components/ui/Logo.jsx";
import PasswordInput from "/src/components/ui/PasswordInput.jsx";
import Button from "/src/components/ui/Button.jsx";
import AlertBanner from "/src/components/ui/AlertBanner.jsx";
const Req = ({ children }) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
  children,
  " ",
  /* @__PURE__ */ jsxDEV("span", { className: "req", children: "*" }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
    lineNumber: 30,
    columnNumber: 44
  }, this)
] }, void 0, true, {
  fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
  lineNumber: 30,
  columnNumber: 31
}, this);
_c = Req;
const RESET_ERROR_MAP = {
  TOKEN_INVALID: { msg: "ลิงก์รีเซ็ตรหัสผ่านไม่ถูกต้อง", type: "token" },
  TOKEN_EXPIRED: { msg: "ลิงก์รีเซ็ตรหัสผ่านหมดอายุแล้ว", type: "token" },
  MISSING_FIELDS: { msg: "ข้อมูลไม่ครบถ้วน กรุณาลองใหม่", type: "token" },
  INVALID_PASSWORD: { msg: "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร ประกอบด้วยอักษรและตัวเลข", type: "password" },
  SAME_AS_OLD_PASSWORD: { msg: "รหัสผ่านใหม่ต้องไม่ซ้ำกับรหัสผ่านเดิม", type: "password" }
};
export default function ResetPasswordPage() {
  _s();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get("token");
  const [values, setValues] = useState({ password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [tokenError, setTokenError] = useState("");
  const [status, setStatus] = useState("idle");
  const set = (k) => (e) => setValues((v) => ({ ...v, [k]: e.target.value }));
  const onSubmit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!values.password || !passwordOk(values.password))
      errs.password = "รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร ประกอบด้วยอักษรและตัวเลข";
    if (!values.confirm || values.confirm !== values.password)
      errs.confirm = "รหัสผ่านไม่ตรงกัน";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setStatus("submitting");
    try {
      await api.post("/auth/reset-password", { token, newPassword: values.password });
      toast("เปลี่ยนรหัสผ่านสำเร็จ กรุณาเข้าสู่ระบบ");
      navigate("/login");
    } catch (err) {
      const statusCode = err.response?.status;
      const errorCode = err.response?.data?.error;
      if (statusCode === 400 && errorCode) {
        const mapped = RESET_ERROR_MAP[errorCode];
        if (mapped) {
          if (mapped.type === "token") {
            setTokenError(mapped.msg);
          } else {
            setErrors((prev) => ({ ...prev, password: mapped.msg }));
          }
        } else {
          toast("เกิดข้อผิดพลาด กรุณาลองใหม่", "info");
        }
      } else if (statusCode >= 500) {
        toast("เกิดข้อผิดพลาดจากเซิร์ฟเวอร์ กรุณาลองใหม่อีกครั้ง", "info");
      } else {
        toast("เกิดข้อผิดพลาด กรุณาลองใหม่", "info");
      }
    } finally {
      setStatus("idle");
    }
  };
  if (tokenError || !token) {
    return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
      /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
        lineNumber: 101,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "ตั้งรหัสผ่านใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
        lineNumber: 102,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AlertBanner, { type: "error", children: tokenError || "ลิงก์นี้หมดอายุหรือถูกใช้แล้ว" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
        lineNumber: 103,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { className: "btn btn--aslink", to: "/forgot-password", children: "ขอลิงก์ใหม่" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 100,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 99,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
    /* @__PURE__ */ jsxDEV(Logo, {}, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 113,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "ตั้งรหัสผ่านใหม่" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 114,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "auth-sub", children: "ตั้งรหัสผ่านใหม่สำหรับบัญชีของคุณ" }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 115,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit, noValidate: true, children: [
      /* @__PURE__ */ jsxDEV(
        PasswordInput,
        {
          label: /* @__PURE__ */ jsxDEV(Req, { children: "รหัสผ่านใหม่" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
            lineNumber: 117,
            columnNumber: 33
          }, this),
          placeholder: "อย่างน้อย 8 ตัว มีอักษร+ตัวเลข",
          value: values.password,
          onChange: set("password"),
          error: errors.password
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
          lineNumber: 117,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        PasswordInput,
        {
          label: /* @__PURE__ */ jsxDEV(Req, { children: "ยืนยันรหัสผ่าน" }, void 0, false, {
            fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
            lineNumber: 119,
            columnNumber: 33
          }, this),
          placeholder: "กรอกรหัสผ่านอีกครั้ง",
          value: values.confirm,
          onChange: set("confirm"),
          error: errors.confirm
        },
        void 0,
        false,
        {
          fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
          lineNumber: 119,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { type: "submit", loading: status === "submitting", children: "อัปเดตรหัสผ่าน" }, void 0, false, {
        fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
        lineNumber: 121,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
      lineNumber: 116,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
    lineNumber: 112,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
}
_s(ResetPasswordPage, "UawDJrKwy1gmzhjJb5JB1s19+8s=", false, function() {
  return [useSearchParams, useNavigate];
});
_c2 = ResetPasswordPage;
var _c, _c2;
$RefreshReg$(_c, "Req");
$RefreshReg$(_c2, "ResetPasswordPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/pages/ResetPasswordPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVThCLG1CQUFhLGNBQWI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVjlCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhQyxpQkFBaUJDLFlBQVk7QUFDbkQsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYTtBQUN0QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGlCQUFpQjtBQUV4QixNQUFNQyxNQUFNQSxDQUFDLEVBQUVDLFNBQVMsTUFBTSxtQ0FBR0E7QUFBQUE7QUFBQUEsRUFBUztBQUFBLEVBQUMsdUJBQUMsVUFBSyxXQUFVLE9BQU0saUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdUI7QUFBQSxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQTJDO0FBRXpFQyxLQUZNRjtBQUdOLE1BQU1HLGtCQUFrQjtBQUFBLEVBQ3RCQyxlQUF3QixFQUFFQyxLQUFLLGlDQUFpQ0MsTUFBTSxRQUFRO0FBQUEsRUFDOUVDLGVBQXdCLEVBQUVGLEtBQUssa0NBQWtDQyxNQUFNLFFBQVE7QUFBQSxFQUMvRUUsZ0JBQXdCLEVBQUVILEtBQUssaUNBQWlDQyxNQUFNLFFBQVE7QUFBQSxFQUM5RUcsa0JBQXdCLEVBQUVKLEtBQUssK0RBQStEQyxNQUFNLFdBQVc7QUFBQSxFQUMvR0ksc0JBQXdCLEVBQUVMLEtBQUsseUNBQXlDQyxNQUFNLFdBQVc7QUFDM0Y7QUFFQSx3QkFBd0JLLG9CQUFvQjtBQUFBQyxLQUFBO0FBQzFDLFFBQU0sQ0FBQ0MsWUFBWSxJQUFJdEIsZ0JBQWdCO0FBQ3ZDLFFBQU11QixXQUFXeEIsWUFBWTtBQUM3QixRQUFNeUIsUUFBUUYsYUFBYUcsSUFBSSxPQUFPO0FBRXRDLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJN0IsU0FBUyxFQUFFOEIsVUFBVSxJQUFJQyxTQUFTLEdBQUcsQ0FBQztBQUNsRSxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWpDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ2tDLFlBQVlDLGFBQWEsSUFBSW5DLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLE1BQU07QUFFM0MsUUFBTXNDLE1BQU1BLENBQUNDLE1BQU0sQ0FBQ0MsTUFBTVgsVUFBVSxDQUFDWSxPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDRixDQUFDLEdBQUdDLEVBQUVFLE9BQU9DLE1BQU0sRUFBRTtBQUUxRSxRQUFNQyxXQUFXLE9BQU9KLE1BQU07QUFDNUJBLE1BQUVLLGVBQWU7QUFDakIsVUFBTUMsT0FBTyxDQUFDO0FBQ2QsUUFBSSxDQUFDbEIsT0FBT0UsWUFBWSxDQUFDekIsV0FBV3VCLE9BQU9FLFFBQVE7QUFDakRnQixXQUFLaEIsV0FBVztBQUNsQixRQUFJLENBQUNGLE9BQU9HLFdBQVdILE9BQU9HLFlBQVlILE9BQU9FO0FBQy9DZ0IsV0FBS2YsVUFBVTtBQUNqQkUsY0FBVWEsSUFBSTtBQUNkLFFBQUlDLE9BQU9DLEtBQUtGLElBQUksRUFBRUcsT0FBUTtBQUU5QlosY0FBVSxZQUFZO0FBQ3RCLFFBQUk7QUFDRixZQUFNakMsSUFBSThDLEtBQUssd0JBQXdCLEVBQUV4QixPQUFPeUIsYUFBYXZCLE9BQU9FLFNBQVMsQ0FBQztBQUM5RXhCLFlBQU0sd0NBQXdDO0FBQzlDbUIsZUFBUyxRQUFRO0FBQUEsSUFDbkIsU0FBUzJCLEtBQUs7QUFDWixZQUFNQyxhQUFhRCxJQUFJRSxVQUFVbEI7QUFDakMsWUFBTW1CLFlBQVlILElBQUlFLFVBQVVFLE1BQU1DO0FBRXRDLFVBQUlKLGVBQWUsT0FBT0UsV0FBVztBQUNuQyxjQUFNRyxTQUFTNUMsZ0JBQWdCeUMsU0FBUztBQUV4QyxZQUFJRyxRQUFRO0FBQ1YsY0FBSUEsT0FBT3pDLFNBQVMsU0FBUztBQUUzQmtCLDBCQUFjdUIsT0FBTzFDLEdBQUc7QUFBQSxVQUMxQixPQUFPO0FBRUxpQixzQkFBVSxDQUFDMEIsVUFBVSxFQUFFLEdBQUdBLE1BQU03QixVQUFVNEIsT0FBTzFDLElBQUksRUFBRTtBQUFBLFVBQ3pEO0FBQUEsUUFDRixPQUFPO0FBRUxWLGdCQUFNLCtCQUErQixNQUFNO0FBQUEsUUFDN0M7QUFBQSxNQUNGLFdBQVcrQyxjQUFjLEtBQUs7QUFDNUIvQyxjQUFNLHFEQUFxRCxNQUFNO0FBQUEsTUFDbkUsT0FBTztBQUNMQSxjQUFNLCtCQUErQixNQUFNO0FBQUEsTUFDN0M7QUFBQSxJQUNGLFVBQUM7QUFDQytCLGdCQUFVLE1BQU07QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxNQUFJSCxjQUFjLENBQUNSLE9BQU87QUFDeEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFLO0FBQUEsTUFDTCx1QkFBQyxRQUFHLFdBQVUsY0FBYSxnQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLE1BQzNDLHVCQUFDLGVBQVksTUFBSyxTQUFTUSx3QkFBYyxtQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLFFBQUssV0FBVSxtQkFBa0IsSUFBRyxvQkFBbUIsMkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxTQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLO0FBQUEsSUFDTCx1QkFBQyxRQUFHLFdBQVUsY0FBYSxnQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQztBQUFBLElBQzNDLHVCQUFDLE9BQUUsV0FBVSxZQUFXLGlEQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlEO0FBQUEsSUFDekQsdUJBQUMsVUFBSyxVQUFvQixZQUFVLE1BQ2xDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUFjLE9BQU8sdUJBQUMsT0FBSSw0QkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBLFVBQVEsYUFBWTtBQUFBLFVBQ3pELE9BQU9OLE9BQU9FO0FBQUFBLFVBQVUsVUFBVVEsSUFBSSxVQUFVO0FBQUEsVUFBRyxPQUFPTixPQUFPRjtBQUFBQTtBQUFBQSxRQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFDNEU7QUFBQSxNQUM1RTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQWMsT0FBTyx1QkFBQyxPQUFJLDhCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFBUSxhQUFZO0FBQUEsVUFDM0QsT0FBT0YsT0FBT0c7QUFBQUEsVUFBUyxVQUFVTyxJQUFJLFNBQVM7QUFBQSxVQUFHLE9BQU9OLE9BQU9EO0FBQUFBO0FBQUFBLFFBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUN5RTtBQUFBLE1BQ3pFLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVNLLFdBQVcsY0FBYyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLFNBTHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ2IsR0FyRnVCRCxtQkFBaUI7QUFBQSxVQUNoQnBCLGlCQUNORCxXQUFXO0FBQUE7QUFBQSxNQUZOcUI7QUFBaUIsSUFBQVQsSUFBQStDO0FBQUEsYUFBQS9DLElBQUE7QUFBQSxhQUFBK0MsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ1c2VTZWFyY2hQYXJhbXMiLCJMaW5rIiwiYXBpIiwicGFzc3dvcmRPayIsInRvYXN0IiwiTG9nbyIsIlBhc3N3b3JkSW5wdXQiLCJCdXR0b24iLCJBbGVydEJhbm5lciIsIlJlcSIsImNoaWxkcmVuIiwiX2MiLCJSRVNFVF9FUlJPUl9NQVAiLCJUT0tFTl9JTlZBTElEIiwibXNnIiwidHlwZSIsIlRPS0VOX0VYUElSRUQiLCJNSVNTSU5HX0ZJRUxEUyIsIklOVkFMSURfUEFTU1dPUkQiLCJTQU1FX0FTX09MRF9QQVNTV09SRCIsIlJlc2V0UGFzc3dvcmRQYWdlIiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJuYXZpZ2F0ZSIsInRva2VuIiwiZ2V0IiwidmFsdWVzIiwic2V0VmFsdWVzIiwicGFzc3dvcmQiLCJjb25maXJtIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwidG9rZW5FcnJvciIsInNldFRva2VuRXJyb3IiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJzZXQiLCJrIiwiZSIsInYiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJlcnJzIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsInBvc3QiLCJuZXdQYXNzd29yZCIsImVyciIsInN0YXR1c0NvZGUiLCJyZXNwb25zZSIsImVycm9yQ29kZSIsImRhdGEiLCJlcnJvciIsIm1hcHBlZCIsInByZXYiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVzZXRQYXNzd29yZFBhZ2UuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlU2VhcmNoUGFyYW1zLCBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGkuanNcIjtcbmltcG9ydCB7IHBhc3N3b3JkT2sgfSBmcm9tIFwiLi4vdXRpbHMvdmFsaWRhdG9ycy5qc1wiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwiLi4vdXRpbHMvdG9hc3QuanNcIjtcbmltcG9ydCBMb2dvIGZyb20gXCIuLi9jb21wb25lbnRzL3VpL0xvZ28uanN4XCI7XG5pbXBvcnQgUGFzc3dvcmRJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9QYXNzd29yZElucHV0LmpzeFwiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiLi4vY29tcG9uZW50cy91aS9CdXR0b24uanN4XCI7XG5pbXBvcnQgQWxlcnRCYW5uZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvdWkvQWxlcnRCYW5uZXIuanN4XCI7XG5cbmNvbnN0IFJlcSA9ICh7IGNoaWxkcmVuIH0pID0+IDw+e2NoaWxkcmVufSA8c3BhbiBjbGFzc05hbWU9XCJyZXFcIj4qPC9zcGFuPjwvPjtcblxuLyog8J+RhyBNYXAgZXJyb3IgY29kZSDihpIg4LiC4LmJ4Lit4LiE4Lin4Liy4Lih4Lig4Liy4Lip4Liy4LmE4LiX4LiiICsg4Lib4Lij4Liw4LmA4Lig4LiXICh0b2tlbiBpc3N1ZSB2cyBwYXNzd29yZCBpc3N1ZSkgKi9cbmNvbnN0IFJFU0VUX0VSUk9SX01BUCA9IHtcbiAgVE9LRU5fSU5WQUxJRDogICAgICAgICAgeyBtc2c6IFwi4Lil4Li04LiH4LiB4LmM4Lij4Li14LmA4LiL4LmH4LiV4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4LmE4Lih4LmI4LiW4Li54LiB4LiV4LmJ4Lit4LiHXCIsIHR5cGU6IFwidG9rZW5cIiB9LFxuICBUT0tFTl9FWFBJUkVEOiAgICAgICAgICB7IG1zZzogXCLguKXguLTguIfguIHguYzguKPguLXguYDguIvguYfguJXguKPguKvguLHguKrguJzguYjguLLguJnguKvguKHguJTguK3guLLguKLguLjguYHguKXguYnguKdcIiwgdHlwZTogXCJ0b2tlblwiIH0sXG4gIE1JU1NJTkdfRklFTERTOiAgICAgICAgIHsgbXNnOiBcIuC4guC5ieC4reC4oeC4ueC4peC5hOC4oeC5iOC4hOC4o+C4muC4luC5ieC4p+C4mSDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYhcIiwgdHlwZTogXCJ0b2tlblwiIH0sXG4gIElOVkFMSURfUEFTU1dPUkQ6ICAgICAgIHsgbXNnOiBcIuC4o+C4q+C4seC4quC4nOC5iOC4suC4meC4leC5ieC4reC4h+C4oeC4teC4reC4ouC5iOC4suC4h+C4meC5ieC4reC4oiA4IOC4leC4seC4p+C4reC4seC4geC4qeC4oyDguJvguKPguLDguIHguK3guJrguJTguYnguKfguKLguK3guLHguIHguKnguKPguYHguKXguLDguJXguLHguKfguYDguKXguIJcIiwgdHlwZTogXCJwYXNzd29yZFwiIH0sXG4gIFNBTUVfQVNfT0xEX1BBU1NXT1JEOiAgIHsgbXNnOiBcIuC4o+C4q+C4seC4quC4nOC5iOC4suC4meC5g+C4q+C4oeC5iOC4leC5ieC4reC4h+C5hOC4oeC5iOC4i+C5ieC4s+C4geC4seC4muC4o+C4q+C4seC4quC4nOC5iOC4suC4meC5gOC4lOC4tOC4oVwiLCB0eXBlOiBcInBhc3N3b3JkXCIgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlc2V0UGFzc3dvcmRQYWdlKCkge1xuICBjb25zdCBbc2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHRva2VuID0gc2VhcmNoUGFyYW1zLmdldChcInRva2VuXCIpO1xuXG4gIGNvbnN0IFt2YWx1ZXMsIHNldFZhbHVlc10gPSB1c2VTdGF0ZSh7IHBhc3N3b3JkOiBcIlwiLCBjb25maXJtOiBcIlwiIH0pO1xuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xuICBjb25zdCBbdG9rZW5FcnJvciwgc2V0VG9rZW5FcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFwiaWRsZVwiKTtcblxuICBjb25zdCBzZXQgPSAoaykgPT4gKGUpID0+IHNldFZhbHVlcygodikgPT4gKHsgLi4udiwgW2tdOiBlLnRhcmdldC52YWx1ZSB9KSk7XG5cbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBlcnJzID0ge307XG4gICAgaWYgKCF2YWx1ZXMucGFzc3dvcmQgfHwgIXBhc3N3b3JkT2sodmFsdWVzLnBhc3N3b3JkKSlcbiAgICAgIGVycnMucGFzc3dvcmQgPSBcIuC4o+C4q+C4seC4quC4nOC5iOC4suC4meC4leC5ieC4reC4h+C4oeC4teC4reC4ouC5iOC4suC4h+C4meC5ieC4reC4oiA4IOC4leC4seC4p+C4reC4seC4geC4qeC4oyDguJvguKPguLDguIHguK3guJrguJTguYnguKfguKLguK3guLHguIHguKnguKPguYHguKXguLDguJXguLHguKfguYDguKXguIJcIjtcbiAgICBpZiAoIXZhbHVlcy5jb25maXJtIHx8IHZhbHVlcy5jb25maXJtICE9PSB2YWx1ZXMucGFzc3dvcmQpXG4gICAgICBlcnJzLmNvbmZpcm0gPSBcIuC4o+C4q+C4seC4quC4nOC5iOC4suC4meC5hOC4oeC5iOC4leC4o+C4h+C4geC4seC4mVwiO1xuICAgIHNldEVycm9ycyhlcnJzKTtcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJycykubGVuZ3RoKSByZXR1cm47XG5cbiAgICBzZXRTdGF0dXMoXCJzdWJtaXR0aW5nXCIpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9hdXRoL3Jlc2V0LXBhc3N3b3JkXCIsIHsgdG9rZW4sIG5ld1Bhc3N3b3JkOiB2YWx1ZXMucGFzc3dvcmQgfSk7XG4gICAgICB0b2FzdChcIuC5gOC4m+C4peC4teC5iOC4ouC4meC4o+C4q+C4seC4quC4nOC5iOC4suC4meC4quC4s+C5gOC4o+C5h+C4iCDguIHguKPguLjguJPguLLguYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJpcIik7XG4gICAgICBuYXZpZ2F0ZShcIi9sb2dpblwiKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnN0IHN0YXR1c0NvZGUgPSBlcnIucmVzcG9uc2U/LnN0YXR1cztcbiAgICAgIGNvbnN0IGVycm9yQ29kZSA9IGVyci5yZXNwb25zZT8uZGF0YT8uZXJyb3I7XG5cbiAgICAgIGlmIChzdGF0dXNDb2RlID09PSA0MDAgJiYgZXJyb3JDb2RlKSB7XG4gICAgICAgIGNvbnN0IG1hcHBlZCA9IFJFU0VUX0VSUk9SX01BUFtlcnJvckNvZGVdO1xuXG4gICAgICAgIGlmIChtYXBwZWQpIHtcbiAgICAgICAgICBpZiAobWFwcGVkLnR5cGUgPT09IFwidG9rZW5cIikge1xuICAgICAgICAgICAgLy8g4Lil4Li04LiH4LiB4LmM4Lih4Li14Lib4Lix4LiN4Lir4LiyIOKGkiDguYHguKrguJTguIfguKvguJnguYnguLIgXCLguILguK3guKXguLTguIfguIHguYzguYPguKvguKHguYhcIlxuICAgICAgICAgICAgc2V0VG9rZW5FcnJvcihtYXBwZWQubXNnKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8g4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4Lih4Li14Lib4Lix4LiN4Lir4LiyIOKGkiDguYHguKrguJTguIcgZXJyb3Ig4LmD4LiV4LmJ4LiK4LmI4Lit4LiHIGlucHV0XG4gICAgICAgICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIHBhc3N3b3JkOiBtYXBwZWQubXNnIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gZXJyb3IgY29kZSDguJfguLXguYjguYTguKHguYjguKPguLnguYnguIjguLHguIEg4oaSIGZhbGxiYWNrXG4gICAgICAgICAgdG9hc3QoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJQg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmIXCIsIFwiaW5mb1wiKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChzdGF0dXNDb2RlID49IDUwMCkge1xuICAgICAgICB0b2FzdChcIuC5gOC4geC4tOC4lOC4guC5ieC4reC4nOC4tOC4lOC4nuC4peC4suC4lOC4iOC4suC4geC5gOC4i+C4tOC4o+C5jOC4n+C5gOC4p+C4reC4o+C5jCDguIHguKPguLjguJPguLLguKXguK3guIfguYPguKvguKHguYjguK3guLXguIHguITguKPguLHguYnguIdcIiwgXCJpbmZvXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdG9hc3QoXCLguYDguIHguLTguJTguILguYnguK3guJzguLTguJTguJ7guKXguLLguJQg4LiB4Lij4Li44LiT4Liy4Lil4Lit4LiH4LmD4Lir4Lih4LmIXCIsIFwiaW5mb1wiKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U3RhdHVzKFwiaWRsZVwiKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKHRva2VuRXJyb3IgfHwgIXRva2VuKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1wYWdlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jYXJkXCI+XG4gICAgICAgICAgPExvZ28gLz5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiYXV0aC10aXRsZVwiPuC4leC4seC5ieC4h+C4o+C4q+C4seC4quC4nOC5iOC4suC4meC5g+C4q+C4oeC5iDwvaDE+XG4gICAgICAgICAgPEFsZXJ0QmFubmVyIHR5cGU9XCJlcnJvclwiPnt0b2tlbkVycm9yIHx8IFwi4Lil4Li04LiH4LiB4LmM4LiZ4Li14LmJ4Lir4Lih4LiU4Lit4Liy4Lii4Li44Lir4Lij4Li34Lit4LiW4Li54LiB4LmD4LiK4LmJ4LmB4Lil4LmJ4LinXCJ9PC9BbGVydEJhbm5lcj5cbiAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJidG4gYnRuLS1hc2xpbmtcIiB0bz1cIi9mb3Jnb3QtcGFzc3dvcmRcIj7guILguK3guKXguLTguIfguIHguYzguYPguKvguKHguYg8L0xpbms+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhZ2VcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jYXJkXCI+XG4gICAgICAgIDxMb2dvIC8+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJhdXRoLXRpdGxlXCI+4LiV4Lix4LmJ4LiH4Lij4Lir4Lix4Liq4Lic4LmI4Liy4LiZ4LmD4Lir4Lih4LmIPC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJcIj7guJXguLHguYnguIfguKPguKvguLHguKrguJzguYjguLLguJnguYPguKvguKHguYjguKrguLPguKvguKPguLHguJrguJrguLHguI3guIrguLXguILguK3guIfguITguLjguJM8L3A+XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtvblN1Ym1pdH0gbm9WYWxpZGF0ZT5cbiAgICAgICAgICA8UGFzc3dvcmRJbnB1dCBsYWJlbD17PFJlcT7guKPguKvguLHguKrguJzguYjguLLguJnguYPguKvguKHguYg8L1JlcT59IHBsYWNlaG9sZGVyPVwi4Lit4Lii4LmI4Liy4LiH4LiZ4LmJ4Lit4LiiIDgg4LiV4Lix4LinIOC4oeC4teC4reC4seC4geC4qeC4oyvguJXguLHguKfguYDguKXguIJcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy5wYXNzd29yZH0gb25DaGFuZ2U9e3NldChcInBhc3N3b3JkXCIpfSBlcnJvcj17ZXJyb3JzLnBhc3N3b3JkfSAvPlxuICAgICAgICAgIDxQYXNzd29yZElucHV0IGxhYmVsPXs8UmVxPuC4ouC4t+C4meC4ouC4seC4meC4o+C4q+C4seC4quC4nOC5iOC4suC4mTwvUmVxPn0gcGxhY2Vob2xkZXI9XCLguIHguKPguK3guIHguKPguKvguLHguKrguJzguYjguLLguJnguK3guLXguIHguITguKPguLHguYnguIdcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlcy5jb25maXJtfSBvbkNoYW5nZT17c2V0KFwiY29uZmlybVwiKX0gZXJyb3I9e2Vycm9ycy5jb25maXJtfSAvPlxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGxvYWRpbmc9e3N0YXR1cyA9PT0gXCJzdWJtaXR0aW5nXCJ9PuC4reC4seC4m+C5gOC4lOC4leC4o+C4q+C4seC4quC4nOC5iOC4suC4mTwvQnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn0iXSwiZmlsZSI6Ii9Vc2Vycy9jaGFuYXl1c3BoYW5yYXR0YW5hbm9uL1N0dWR5LzMvU0VfUHJvamVjdC9QZXRCdWRkeS9mcm9udGVuZC9zcmMvcGFnZXMvUmVzZXRQYXNzd29yZFBhZ2UuanN4In0=