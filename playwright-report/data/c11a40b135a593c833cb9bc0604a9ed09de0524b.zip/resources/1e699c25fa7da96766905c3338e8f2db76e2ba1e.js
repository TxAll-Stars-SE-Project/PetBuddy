import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/TextInput.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7e20e8ce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function TextInput({ label, error, ...rest }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "field", children: [
    /* @__PURE__ */ jsxDEV("label", { children: label }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("input", { className: "input" + (error ? " input--error" : ""), ...rest }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "field-error", children: error }, void 0, false, {
      fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx",
      lineNumber: 25,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
}
_c = TextInput;
export default TextInput;
var _c;
$RefreshReg$(_c, "TextInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/chanayusphanrattananon/Study/3/SE_Project/PetBuddy/frontend/src/components/ui/TextInput.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR007Ozs7Ozs7Ozs7Ozs7Ozs7QUFITixTQUFTQSxVQUFVLEVBQUVDLE9BQU9DLE9BQU8sR0FBR0MsS0FBSyxHQUFHO0FBQzVDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQkFBQyxXQUFPRixtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWM7QUFBQSxJQUNkLHVCQUFDLFdBQU0sV0FBVyxXQUFXQyxRQUFRLGtCQUFrQixLQUFLLEdBQUlDLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUU7QUFBQSxJQUNwRUQsU0FBUyx1QkFBQyxTQUFJLFdBQVUsZUFBZUEsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxPQUhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDRSxLQVJRSjtBQVNULGVBQWVBO0FBQVUsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiVGV4dElucHV0IiwibGFiZWwiLCJlcnJvciIsInJlc3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUZXh0SW5wdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIFRleHRJbnB1dCh7IGxhYmVsLCBlcnJvciwgLi4ucmVzdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxuICAgICAgPGxhYmVsPntsYWJlbH08L2xhYmVsPlxuICAgICAgPGlucHV0IGNsYXNzTmFtZT17XCJpbnB1dFwiICsgKGVycm9yID8gXCIgaW5wdXQtLWVycm9yXCIgOiBcIlwiKX0gey4uLnJlc3R9IC8+XG4gICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcn08L2Rpdj59XG4gICAgPC9kaXY+XG4gICk7XG59XG5leHBvcnQgZGVmYXVsdCBUZXh0SW5wdXQ7Il0sImZpbGUiOiIvVXNlcnMvY2hhbmF5dXNwaGFucmF0dGFuYW5vbi9TdHVkeS8zL1NFX1Byb2plY3QvUGV0QnVkZHkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvVGV4dElucHV0LmpzeCJ9